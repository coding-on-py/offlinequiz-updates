/**
 * OfflineQuiz plugin: Listen
 *
 * Hands-free study. A tossup is read aloud in the app's Read aloud voice, then a few seconds to
 * think, then its answer, and on to the next. Questions come from your Setup or from the tossups you
 * missed lately.
 */
QB.registerPlugin({
  id: "listen",
  name: "Listen",
  version: "2.0.1",
  author: "OfflineQuiz",
  description: "Study with your ears: tossups read aloud, a moment to think, then the answer. No typing.",
  onEnable: __qbMain,
  onDisable: function (ctx) { if (ctx._cleanup) ctx._cleanup(); },
});
