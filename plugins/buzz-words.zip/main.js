/**
 * OfflineQuiz plugin: Buzz Words  (companion to Keyword Frequency)
 *
 * For a chosen slice of questions (category / subcategory / alternate
 * subcategory / difficulty / year, and WHICH part of the question by percent),
 * it finds the most RELIABLE keywords & phrases — the ones where, whenever you
 * hear them, the answer is almost always the same. Set the confidence
 * threshold (the % chance the answer is what's shown when you hear the
 * keyword), and it lists keyword/phrase → answer pairs you can buzz on.
 *
 * Requires the Keyword Frequency plugin to be enabled (shared analysis model).
 */
QB.registerPlugin({
  id: "buzz-words",
  name: "Buzz Words",
  version: "1.12.0",
  author: "OfflineQuiz",
  description: "Find reliable buzz keywords/phrases: words that almost always point to one answer, with a configurable confidence threshold. Companion to Keyword Frequency.",
  onEnable: __qbMain,
  onDisable: function () {},
});
