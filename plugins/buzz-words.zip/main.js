/**
 * OfflineQuiz plugin: Buzzwords
 *
 * Reads every question in a chosen slice (categories, difficulty, years, part
 * of the question) and lists the words and phrases that almost always mean one
 * answer: "when you hear X, buzz Y", with how sure that is and how often it
 * came up. Confidence, times seen, answer type and order re-rank instantly.
 */
QB.registerPlugin({
  id: "buzz-words",
  name: "Buzzwords",
  version: "1.23.0",
  author: "OfflineQuiz",
  description: "Giveaway clues that almost always point to one answer.",
  onEnable: __qbMain,
  onDisable: function () {},
});
