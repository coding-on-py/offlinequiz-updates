/**
 * OfflineQuiz plugin: Buzz Words  (companion to Keyword Frequency)
 *
 * For a chosen slice of questions (category / subcategory / alternate
 * subcategory / difficulty / year, and WHICH part of the question by percent),
 * it finds the most RELIABLE keywords & phrases — the ones where, whenever you
 * hear them, the answer is almost always the same. Set the confidence
 * threshold (the % chance the answer is what's shown when you hear the
 * keyword), and it lists keyword/phrase → answer pairs you can buzz on.
 *
 * Requires the Keyword Frequency plugin to be enabled (shared analysis model).
 */
QB.registerPlugin({
  id: "buzz-words",
  name: "Buzz Words",
  version: "1.3.0",
  author: "OfflineQuiz",
  description: "Find reliable buzz keywords/phrases: words that almost always point to one answer, with a configurable confidence threshold. Companion to Keyword Frequency.",
  onEnable: function (ctx) {
    var body = null, page = null;
    function esc(s) { return (s == null ? "" : String(s)).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }

    var STOP = {};
    ("a an the this that these those it its his her hers he she they them their theirs we us our you your i me my mine of in on at to for from with within without by as is are was were be been being am do does did done not no nor so or and but if then than because while during after before until once when where which who whom whose what why how all any both each few more most other some such only own same here there over under again further about above below between into through against up down out off very can will just should now points point name names named ftp identify gives give given made make makes making one two three four five six seven eight nine ten first second third often called also another may might must shall many much work works worked title titled known includes including include described describes describe used uses use using like unlike along man woman men women person people city country state nation work novel poem play opera symphony war battle king queen god goddess").split(/\s+/).forEach(function (w) { STOP[w] = 1; });

    var ALT_SUBCATS = {
      "Other Science": ["Astronomy", "Computer Science", "Earth Science", "Engineering", "Math", "Misc Science"],
      "Other Literature": ["Drama", "Long Fiction", "Poetry", "Short Fiction", "Misc Literature"],
      "Other Fine Arts": ["Architecture", "Dance", "Film", "Jazz", "Musicals", "Opera", "Photography", "Misc Arts"],
      "Social Science": ["Anthropology", "Economics", "Linguistics", "Psychology", "Sociology", "Other Social Science"],
    };

    function kfEnabled() {
      try { return (window.QB.getActivePages() || []).some(function (p) { return p.id.indexOf("keyword-freq::") === 0; }); }
      catch (e) { return false; }
    }
    function mainAnswer(sani) { return (sani || "").split(/[\[(]/)[0].trim().replace(/[;:,.]+$/, ""); }
    // ── saved buzz words (★ a keyword→answer pair to review later) ──
    function starredBW() { return ctx.storage.get("bw-stars") || []; }
    function bwKey(it) { return (it.kw || "") + "" + (it.answer || ""); }
    function isBWStarred(it) { var k = bwKey(it); return starredBW().some(function (x) { return bwKey(x) === k; }); }
    function sliceWords(q, lo, hi) {
      var words = ((q.question_sanitized || "").replace(/\(\*\)/g, " ").toLowerCase().match(/[\p{L}\p{N}'’]+/gu) || [])
        .map(function (w) { return w.replace(/['’]s$/, ""); });   // strip possessive 's, like Keyword Frequency
      var n = words.length; if (!n) return [];
      var a = Math.round((lo / 100) * n), b = Math.round((hi / 100) * n);
      return words.slice(a, Math.max(a + 1, b));
    }
    // Does the slice contain the token sequence consecutively? (phrase match —
    // identical rule to Keyword Frequency so confidence numbers line up exactly.)
    function sliceHasSeq(slice, seq) {
      if (!seq.length) return false;
      if (seq.length === 1) return slice.indexOf(seq[0]) >= 0;
      for (var i = 0; i + seq.length <= slice.length; i++) {
        var ok = true;
        for (var j = 0; j < seq.length; j++) { if (slice[i + j] !== seq[j]) { ok = false; break; } }
        if (ok) return true;
      }
      return false;
    }
    // Is shortArr a contiguous run inside longArr?
    function containsSeq(longArr, shortArr) {
      if (shortArr.length > longArr.length) return false;
      for (var i = 0; i + shortArr.length <= longArr.length; i++) {
        var ok = true;
        for (var k = 0; k < shortArr.length; k++) { if (longArr[i + k] !== shortArr[k]) { ok = false; break; } }
        if (ok) return true;
      }
      return false;
    }
    // Collapse word/phrase redundancy: when a longer gram that CONTAINS a shorter
    // one shows up in >=80% of the shorter gram's questions, the shorter gram is
    // redundant (it's almost always part of that phrase) — drop it, keep the more
    // specific phrase. keyOf -> gram string, docOf -> its question count.
    function collapseGrams(items, keyOf, docOf) {
      var toks = items.map(function (it) { return keyOf(it).split(" "); });
      var drop = {};
      for (var i = 0; i < items.length; i++) {
        var sd = docOf(items[i]); if (!sd) continue;
        for (var j = 0; j < items.length; j++) {
          if (i === j) continue;
          if (toks[j].length <= toks[i].length) continue;      // need a strictly longer gram
          if (!containsSeq(toks[j], toks[i])) continue;         // …that contains this one
          if (docOf(items[j]) >= 0.8 * sd) { drop[keyOf(items[i])] = 1; break; }
        }
      }
      return items.filter(function (it) { return !drop[keyOf(it)]; });
    }
    // Unigrams + bigrams + trigrams; multi-word grams can't start/end on a stop word.
    function gramsOf(words, skip) {
      var out = [], clean = words.map(function (w) { return w.replace(/['’]s$/, ""); });
      for (var i = 0; i < clean.length; i++) {
        var w = clean[i];
        if (w.length >= 3 && !STOP[w] && !skip[w] && !/^\d+$/.test(w)) out.push(w);
        for (var L = 2; L <= 3; L++) {
          if (i + L > clean.length) break;
          var g = clean.slice(i, i + L);
          if (STOP[g[0]] || STOP[g[L - 1]]) continue;
          if (g.some(function (x) { return skip[x] || /^\d+$/.test(x) || x.length < 2; })) continue;
          out.push(g.join(" "));
        }
      }
      return out;
    }

    page = ctx.registerPage({
      id: "buzz", navLabel: "Buzz Words", title: "BUZZ WORDS",
      onShow: function (el) { body = el; render(); },
    });

    function render() {
      if (!body) return;
      if (!kfEnabled()) {
        body.innerHTML = '<div class="bw-wrap"><div class="bw-card"><div class="text-muted">Buzz Words is a companion to <strong>Keyword Frequency</strong>. Enable that plugin in <strong>Plugins &amp; Themes</strong> to use this.</div></div></div>';
        return;
      }
      var diffBoxes = "";
      for (var d = 0; d <= 10; d++) diffBoxes += '<label class="bw-diff"><input type="checkbox" class="bw-diff-cb" value="' + d + '"' + (d >= 2 && d <= 5 ? " checked" : "") + ">" + d + "</label>";
      body.innerHTML =
        '<div class="bw-wrap">' +
          '<div class="bw-card">' +
            '<div class="bw-row">' +
              '<select id="bw-cat" class="mode-input bw-sel"><option value="">All categories</option></select>' +
              '<select id="bw-sub" class="mode-input bw-sel" disabled><option value="">All subcategories</option></select>' +
              '<select id="bw-alt" class="mode-input bw-sel" disabled><option value="">All alternate subcategories</option></select>' +
            "</div>" +
            '<div class="bw-row"><span class="bw-label">Difficulty</span>' + diffBoxes + "</div>" +
            '<div class="bw-row"><span class="bw-label">Years</span>' +
              '<div class="dual-range bw-dual"><div class="dual-range-track"><div class="dual-range-fill" id="bw-yfill"></div></div>' +
                '<input type="range" id="bw-ymin" min="2000" max="2026" value="2000">' +
                '<input type="range" id="bw-ymax" min="2000" max="2026" value="2026"></div>' +
              '<span class="bw-label" id="bw-year-val" style="min-width:84px;text-align:right"></span>' +
            "</div>" +
            '<div class="bw-row"><span class="bw-label">Question range</span>' +
              '<div class="dual-range bw-dual"><div class="dual-range-track"><div class="dual-range-fill" id="bw-fill"></div></div>' +
                '<input type="range" id="bw-lo" min="0" max="100" step="5" value="0">' +
                '<input type="range" id="bw-hi" min="0" max="100" step="5" value="100"></div>' +
              '<span class="bw-label" id="bw-range-val" style="min-width:84px;text-align:right"></span>' +
            "</div>" +
            '<div class="bw-row">' +
              '<span class="bw-label">Buzz confidence</span>' +
              '<select id="bw-conf" class="mode-input" style="width:150px"><option value="60">≥ 60%</option><option value="70">≥ 70%</option><option value="80" selected>≥ 80%</option><option value="90">≥ 90%</option><option value="95">≥ 95%</option></select>' +
              '<span class="bw-label">Min times seen</span>' +
              '<select id="bw-min" class="mode-input" style="width:90px"><option>2</option><option selected>3</option><option>5</option><option>8</option></select>' +
              '<select id="bw-top" class="mode-input" style="width:110px"><option value="25">Top 25</option><option value="50" selected>Top 50</option><option value="100">Top 100</option><option value="200">Top 200</option></select>' +
              '<button class="btn btn-primary" id="bw-go">Find buzz words</button>' +
            "</div>" +
          "</div>" +
          '<div class="bw-card" id="bw-results"><div class="text-muted">Pick filters and a confidence, then find your buzz words.</div></div>' +
        "</div>";

      try {
        var cats = [];
        ctx.api.get("/api/categories?type=tossups").then(function (r) {
          cats = r.categories || [];
          var catSel = body.querySelector("#bw-cat");
          cats.forEach(function (c) { var o = document.createElement("option"); o.value = c.category; o.textContent = c.category; catSel.appendChild(o); });
        }).catch(function () {});
      } catch (e) {}

      var catSel = body.querySelector("#bw-cat"), subSel = body.querySelector("#bw-sub"), altSel = body.querySelector("#bw-alt");
      catSel.addEventListener("change", async function () {
        subSel.innerHTML = '<option value="">All subcategories</option>';
        altSel.innerHTML = '<option value="">All alternate subcategories</option>';
        altSel.disabled = true;
        if (!catSel.value) { subSel.disabled = true; return; }
        if (catSel.value === "Social Science") {
          ALT_SUBCATS["Social Science"].forEach(function (a) { var o = document.createElement("option"); o.value = a; o.textContent = a; subSel.appendChild(o); });
          subSel.disabled = false; return;
        }
        try {
          var subs = (await ctx.api.get("/api/subcategories?type=tossups&category=" + encodeURIComponent(catSel.value))).subcategories || [];
          subs.forEach(function (x) { var o = document.createElement("option"); o.value = x.subcategory; o.textContent = x.subcategory; subSel.appendChild(o); });
          subSel.disabled = !subs.length;
        } catch (e) { subSel.disabled = true; }
      });
      subSel.addEventListener("change", function () {
        altSel.innerHTML = '<option value="">All alternate subcategories</option>';
        var alts = (catSel.value !== "Social Science" && /^Other /.test(subSel.value)) ? ALT_SUBCATS[subSel.value] : null;
        if (alts) { alts.forEach(function (a) { var o = document.createElement("option"); o.value = a; o.textContent = a; altSel.appendChild(o); }); altSel.disabled = false; }
        else altSel.disabled = true;
      });

      function wireDual(loId, hiId, fillId, valId, min, max, fmt) {
        var lo = body.querySelector("#" + loId), hi = body.querySelector("#" + hiId);
        function paint() {
          var a = parseInt(lo.value), b = parseInt(hi.value), mn = Math.min(a, b), mx = Math.max(a, b);
          body.querySelector("#" + valId).textContent = fmt(mn, mx);
          var fill = body.querySelector("#" + fillId);
          if (fill) { fill.style.left = ((mn - min) / (max - min)) * 100 + "%"; fill.style.right = ((max - mx) / (max - min)) * 100 + "%"; }
        }
        lo.addEventListener("input", paint); hi.addEventListener("input", paint); paint();
      }
      wireDual("bw-lo", "bw-hi", "bw-fill", "bw-range-val", 0, 100, function (a, b) { return a + "% – " + b + "%"; });
      wireDual("bw-ymin", "bw-ymax", "bw-yfill", "bw-year-val", 2000, 2026, function (a, b) { return a + " – " + b; });
      body.querySelector("#bw-go").onclick = run;
    }

    function filterQs() {
      var cat = body.querySelector("#bw-cat").value, sub = body.querySelector("#bw-sub").value, alt = body.querySelector("#bw-alt").value;
      if (cat === "Social Science" && sub) { alt = sub; sub = ""; }
      var diffs = [].slice.call(body.querySelectorAll(".bw-diff-cb:checked")).map(function (c) { return c.value; });
      var ya = parseInt(body.querySelector("#bw-ymin").value), yb = parseInt(body.querySelector("#bw-ymax").value);
      var ymin = Math.min(ya, yb), ymax = Math.max(ya, yb);
      return (cat ? "&categories=" + encodeURIComponent(cat) : "") +
        (sub ? "&subcategories=" + encodeURIComponent(sub) : "") +
        (alt ? "&alternateSubcategories=" + encodeURIComponent(alt) : "") +
        (diffs.length ? "&difficulties=" + diffs.join(",") : "") +
        (ymin > 2000 ? "&yearMin=" + ymin : "") + (ymax < 2026 ? "&yearMax=" + ymax : "");
    }

    // Compute a candidate gram's TRUE answer distribution over every matching
    // question (capped at 500, exactly like Keyword Frequency's word→answers
    // search) so the confidence shown here equals what you'd see if you looked
    // the keyword up in Keyword Frequency.
    async function verifyGram(gram, rlo, rhi) {
      var seq = gram.split(" ");
      var quoted = seq.map(function (t) { return '"' + t + '"'; }).join(" ");
      var rows;
      try { rows = (await ctx.api.get("/api/tossups/search?query=" + encodeURIComponent("question_sanitized : (" + quoted + ")") + "&limit=500" + filterQs())).rows || []; }
      catch (e) { return null; }
      var counts = {}, display = {}, total = 0;
      rows.forEach(function (q) {
        if (!sliceHasSeq(sliceWords(q, rlo, rhi), seq)) return;   // adjacent phrase match in the chosen slice
        var m = mainAnswer(q.answer_sanitized); if (!m) return;
        var key = m.toLowerCase();
        counts[key] = (counts[key] || 0) + 1;
        if (!display[key]) display[key] = m;
        total++;
      });
      if (!total) return null;
      var bestKey = null, bestN = 0;
      Object.keys(counts).forEach(function (k) { if (counts[k] > bestN) { bestN = counts[k]; bestKey = k; } });
      return { kw: gram, answer: display[bestKey], conf: bestN / total, hits: bestN, total: total, phrase: seq.length > 1 };
    }

    async function run() {
      var out = body.querySelector("#bw-results");
      var conf = parseInt(body.querySelector("#bw-conf").value) / 100;
      var minSeen = parseInt(body.querySelector("#bw-min").value) || 3;
      var topN = parseInt(body.querySelector("#bw-top").value) || 50;
      var lo = parseInt(body.querySelector("#bw-lo").value), hi = parseInt(body.querySelector("#bw-hi").value);
      var rlo = Math.min(lo, hi), rhi = Math.max(lo, hi);
      out.innerHTML = '<div class="text-muted">Scanning questions…</div>';
      // Scale the discovery scan to the filtered set: scan ALL of it when it's
      // small, and a large sample when it's huge. A FIXED sample (the old 1500)
      // under-discovers broad selections — e.g. "All categories" covered <1% of
      // the corpus, so almost no keyword recurred and few buzz words surfaced,
      // which looked like the filter was returning fewer questions. (The filters
      // were never wrong; the scan was just too thin.)
      var SCAN_MAX = 12000, matchCount = 0;
      try { matchCount = (await ctx.api.get("/api/tossups/count?_=1" + filterQs())).count || 0; } catch (e) {}
      var scanLimit = matchCount ? Math.min(matchCount, SCAN_MAX) : SCAN_MAX;
      var rows = [];
      try { rows = (await ctx.api.get("/api/tossups/query?random=1&limit=" + scanLimit + filterQs())).rows || []; }
      catch (e) { out.innerHTML = '<div class="text-muted">Scan failed: ' + esc(e.message || e) + "</div>"; return; }
      if (!rows.length) { out.innerHTML = '<div class="text-muted">No questions matched those filters.</div>'; return; }
      if (!matchCount) matchCount = rows.length;

      // 1) Discover candidates from the sample. Track each gram's per-answer
      //    counts so we can PRIORITISE the grams that already look reliable in
      //    the sample (high sample-confidence) — those are the ones worth
      //    verifying exactly. Common low-confidence words (e.g. "century") are
      //    skipped: they'd never pass the threshold and would only burn queries.
      var sample = {};   // gram -> { ans:{}, total }
      rows.forEach(function (q) {
        var ans = mainAnswer(q.answer_sanitized); if (!ans) return;
        var akey = ans.toLowerCase();
        var skip = {};
        ((q.answer_sanitized || "").toLowerCase().match(/[\p{L}\p{N}'’]+/gu) || []).forEach(function (w) { skip[w.replace(/['’]s$/, "")] = 1; });
        var seen = {};
        gramsOf(sliceWords(q, rlo, rhi), skip).forEach(function (g) {
          if (seen[g]) return; seen[g] = 1;
          var m = sample[g] || (sample[g] = { ans: {}, total: 0 });
          m.total++; m.ans[akey] = (m.ans[akey] || 0) + 1;
        });
      });
      var cand = [];
      Object.keys(sample).forEach(function (g) {
        var m = sample[g]; if (m.total < 2) return;            // needs to recur in the sample
        var bestN = 0; Object.keys(m.ans).forEach(function (k) { if (m.ans[k] > bestN) bestN = m.ans[k]; });
        var sc = bestN / m.total;
        if (sc >= 0.5) cand.push({ kw: g, s: m.total, sc: sc }); // looks reliable — verify it
      });
      cand.sort(function (a, b) { return b.sc - a.sc || b.s - a.s; });   // most reliable-looking first
      var CAP = 160, capped = cand.length > CAP;
      cand = cand.slice(0, CAP);
      if (!cand.length) { out.innerHTML = '<div class="bw-meta">Not enough recurring keywords in that slice — widen the filters or the question range.</div>'; return; }

      // 2) Verify each candidate against ALL its questions (true confidence,
      //    matching Keyword Frequency). Parallel in small batches with progress.
      var verified = [], CHUNK = 8;
      for (var i = 0; i < cand.length; i += CHUNK) {
        out.innerHTML = '<div class="text-muted">Checking keywords… ' + Math.min(i + CHUNK, cand.length) + "/" + cand.length + "</div>";
        var settled = await Promise.all(cand.slice(i, i + CHUNK).map(function (c) { return verifyGram(c.kw, rlo, rhi); }));
        settled.forEach(function (r) { if (r) verified.push(r); });
      }

      // 3) Keep only keywords that clear min-times-seen and the confidence bar.
      var list = verified.filter(function (e) { return e.total >= minSeen && e.conf >= conf; });
      // 4) THEN collapse word/phrase redundancy among the survivors (true counts).
      //    Collapsing after filtering matters: otherwise a longer phrase that is
      //    itself about to be dropped for low confidence could suppress a valid
      //    shorter keyword, and both would vanish.
      list = collapseGrams(list, function (e) { return e.kw; }, function (e) { return e.total; });
      list.sort(function (a, b) { return b.conf - a.conf || b.hits - a.hits; });
      list = list.slice(0, topN);

      // Show the TRUE matching-question total so it's clear how much "All
      // categories"/"All subcategories" actually covers (vs how much was scanned).
      var scanned = rows.length >= matchCount ? ("all " + matchCount.toLocaleString()) : (rows.length.toLocaleString() + " of " + matchCount.toLocaleString());
      if (!list.length) { out.innerHTML = '<div class="bw-meta">No keyword reaches that confidence across ' + esc(scanned) + ' matching questions — lower the threshold, widen the slice, or pick a narrower category.</div>'; return; }
      out.innerHTML =
        '<div class="bw-meta">' + list.length + " buzz words · scanned " + esc(scanned) + " matching questions · ≥" + Math.round(conf * 100) + "% confidence · " + rlo + "–" + rhi + "%" + (capped ? " · checked the " + CAP + " most promising keywords" : "") + "</div>" +
        '<table class="stats-table"><thead><tr><th></th><th>#</th><th>When you hear…</th><th>…buzz</th><th>Confidence</th><th>Seen</th></tr></thead><tbody>' +
        list.map(function (e, i) {
          var st = isBWStarred(e);
          return "<tr><td><span class=\"bw-starx" + (st ? " on" : "") + "\" data-kw=\"" + esc(e.kw) + "\" data-ans=\"" + esc(e.answer) + "\" title=\"Save this buzz word\">" + (st ? "★" : "☆") + "</span></td><td>" + (i + 1) + '</td><td class="bw-kw">' + esc(e.kw) + "</td><td><strong>" + esc(e.answer) + "</strong></td><td>" + Math.round(e.conf * 100) + "% (" + e.hits + "/" + e.total + ")</td><td>" + e.total + "</td></tr>";
        }).join("") + "</tbody></table>";
      out.querySelectorAll(".bw-starx").forEach(function (s) {
        s.addEventListener("click", function () {
          var it = { kw: s.dataset.kw, answer: s.dataset.ans };
          var lst = starredBW(), k = bwKey(it), idx = lst.findIndex(function (x) { return bwKey(x) === k; });
          if (idx >= 0) lst.splice(idx, 1); else lst.push(it);
          ctx.storage.set("bw-stars", lst);
          if (ctx.playSound) ctx.playSound("star");
          var on = idx < 0; s.textContent = on ? "★" : "☆"; s.classList.toggle("on", on);
        });
      });
    }

    ctx.addCSS(
      ".bw-wrap{max-width:920px;margin:0 auto;display:flex;flex-direction:column;gap:12px;padding:16px}" +
      ".bw-card{background:var(--bg-secondary);border:1px solid var(--border);border-radius:var(--radius);padding:14px 16px;display:flex;flex-direction:column;gap:10px}" +
      ".bw-row{display:flex;align-items:center;gap:8px;flex-wrap:wrap}" +
      ".bw-sel{flex:1;min-width:150px}" +
      ".bw-label{font-size:11px;color:var(--text-secondary);flex:0 0 auto}" +
      ".bw-diff{font-size:11px;color:var(--text-secondary);display:inline-flex;align-items:center;gap:3px;cursor:pointer}" +
      ".bw-dual{flex:1;min-width:160px}" +
      ".bw-meta{font-size:11px;color:var(--text-muted)}" +
      ".bw-kw{color:var(--accent);font-weight:600}" +
      ".bw-starx{cursor:pointer;color:var(--text-muted);font-size:15px}" +
      ".bw-starx.on{color:var(--star,#dfb347)}"
    );

    // ── Database → Buzz Words tab: your saved buzz words + review as flashcards ──
    ctx.registerStarredProvider({
      id: "buzz-words", title: "Buzz Words",
      render: function renderSaved(container) {
        var list = starredBW();
        if (!list.length) { container.innerHTML = '<div class="text-muted" style="padding:16px">No saved buzz words yet — ★ a keyword in Buzz Words to review it later.</div>'; return; }
        var bar = '<div class="db-toolbar"><button class="btn btn-sm btn-primary" id="bw-review">▶ Review as flashcards</button>' +
          '<span class="text-muted" style="font-size:11px">' + list.length + ' saved · "when you hear X, buzz Y"</span></div>';
        container.innerHTML = bar + '<table class="stats-table"><thead><tr><th></th><th>When you hear…</th><th>…buzz</th></tr></thead><tbody>' +
          list.map(function (it, i) {
            return '<tr><td><span class="bw-starx on" data-i="' + i + '" title="Remove">★</span></td><td class="bw-kw">' + esc(it.kw) + "</td><td><strong>" + esc(it.answer) + "</strong></td></tr>";
          }).join("") + "</tbody></table>";
        container.querySelectorAll(".bw-starx").forEach(function (s) {
          s.addEventListener("click", function () {
            var lst = starredBW(); lst.splice(parseInt(s.dataset.i), 1); ctx.storage.set("bw-stars", lst);
            if (ctx.playSound) ctx.playSound("star"); renderSaved(container);
          });
        });
        var rv = container.querySelector("#bw-review");
        if (rv) rv.onclick = function () {
          var cards = starredBW().map(function (it) { return { front: it.kw, back: it.answer, meta: "buzz word" }; });
          if (!cards.length) return;
          if (!ctx.host || !ctx.host.launchQuestions) { ctx.toast("Update the app to review as flashcards", "error"); return; }
          try { localStorage.setItem("qb-flashcards-cards", JSON.stringify({ cards: cards, ts: Date.now() })); } catch (e) {}
          var ok = window.QB && window.QB.showPage && window.QB.showPage("flashcards::cards");
          if (!ok) { try { localStorage.removeItem("qb-flashcards-cards"); } catch (e) {} ctx.toast("Enable the Flashcards plugin first", "error"); }
        };
      },
    });

    ctx.toast("Buzz Words enabled — open it from the title menu (Extra).");
  },
  onDisable: function () {},
});
