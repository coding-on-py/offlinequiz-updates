// ── Shared kit ─────────────────────────────────────────────────────────────
// The same helpers ship in Keyword Frequency, Buzzwords and Fact Sheet (each
// plugin runs in its own scope): question text without notes, the filter row
// (the app's category picker, difficulty toggles, Years and Clues popovers),
// star / save buttons, a pager and the Database "saved" tab.
function __qbKit(ctx) {
  var K = {};
  function esc(s) { return (s == null ? "" : String(s)).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
  K.esc = esc;
  var ICONS = {
    search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>',
    down: '<path d="M6 9l6 6 6-6"/>',
    left: '<path d="M15 6l-6 6 6 6"/>',
    right: '<path d="M9 6l6 6-6 6"/>',
  };
  K.ic = function (n, s) {
    s = s || 16;
    return '<svg width="' + s + '" height="' + s + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (ICONS[n] || "") + "</svg>";
  };
  K.loadBar = function (label) { return (window.QB && QB.loadingBarHtml) ? QB.loadingBarHtml(label) : '<div class="db-empty">' + esc(label) + "</div>"; };
  K.loadBarDet = function (label, frac) {
    var pct = Math.max(0, Math.min(100, Math.round((frac || 0) * 100)));
    return '<div class="qb-loading"><div class="qb-loadbar det"><div class="qb-loadbar-fill" style="width:' + pct + '%"></div></div><span>' + esc(label) + "</span></div>";
  };
  K.empty = function (text) { return '<div class="db-empty">' + esc(text) + "</div>"; };
  K.num = function (n) { return Number(n || 0).toLocaleString(); };
  K.pct = function (x) { return Math.round(100 * (x || 0)) + "%"; };

  // ── question text ──────────────────────────────────────────────────────
  // Words come from what a question SAYS to players: the host's reading text
  // (ctx.host.questionText) when the base has it, else the plain copy.
  // Moderator / reader notes and pronunciation guides are removed whatever the
  // reading settings say: they are never clue words.
  var NOTE_LBL = /(?:note to (?:the )?(?:moderators?|readers?)\b|reader(?:'s)? note\b|moderator(?:'s)? note\b)/i;
  var NOTE_LBL_G = /(?:note to (?:the )?(?:moderators?|readers?)\b|reader(?:'s)? note\b|moderator(?:'s)? note\b)\s*(?:#\s*\d+\s*)?(?:,[^:]{0,40})?:\s*/gi;
  var NOTE_RUN = /^\s*[\[(<*]*\s*(?:note to (?:the )?(?:moderators?|readers?)\b|reader(?:'s)? note\b|moderator(?:'s)? note\b)/i;
  var ENT = { amp: "&", lt: "<", gt: ">", quot: '"', apos: "'", nbsp: " " };
  function decodeEnt(s) {
    return String(s || "").replace(/&(#x[0-9a-f]+|#\d+|[a-z]+);/gi, function (m, e) {
      if (e[0] === "#") { try { return String.fromCodePoint(e[1] === "x" || e[1] === "X" ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10)); } catch (x) { return m; } }
      var v = ENT[e.toLowerCase()]; return v == null ? m : v;
    });
  }
  K.decodeEnt = decodeEnt;
  // A note is the italic run of the HTML field that STARTS with its label.
  function noteRuns(html) {
    if (!html || html.indexOf("<") < 0) return [];
    var runs = [], it = 0, last = 0, m, re = /<\/?([a-z]+)[^>]*>/gi;
    function push(t) { if (!t) return; var p = runs[runs.length - 1], ital = it > 0; if (p && p.italic === ital) p.text += t; else runs.push({ text: t, italic: ital }); }
    while ((m = re.exec(html))) {
      push(decodeEnt(html.slice(last, m.index)));
      var tag = m[1].toLowerCase();
      if (tag === "i" || tag === "em") it = Math.max(0, it + (m[0][1] === "/" ? -1 : 1));
      last = re.lastIndex;
    }
    push(decodeEnt(html.slice(last)));
    return runs.filter(function (r) { return r.italic && NOTE_RUN.test(r.text); }).map(function (r) { return r.text.trim(); });
  }
  // The plain copy folds accents, straightens quotes and spells out dashes.
  function foldPlain(s) {
    return String(s || "").normalize("NFD").replace(/[̀-ͯ]/g, "")
      .replace(/[“”]/g, '"').replace(/[‘’]/g, "'").replace(/[–—]/g, "-").replace(/…/g, "...").replace(/ /g, " ");
  }
  function cutSpan(t, i, j) { return t.slice(0, i).replace(/\s+$/, "") + (i > 0 && j < t.length ? " " : "") + t.slice(j).replace(/^\s+/, ""); }
  function stripNotes(t, html) {
    if (!NOTE_LBL.test(t)) return t;
    noteRuns(html).forEach(function (note) {
      var cands = [foldPlain(note), note];
      for (var c = 0; c < cands.length; c++) { var i = t.indexOf(cands[c]); if (i >= 0) { t = cutSpan(t, i, i + cands[c].length); break; } }
    });
    if (!NOTE_LBL.test(t)) return t;
    t = t.replace(/\s*[\[(]\s*(?:notes?\s+to\s+(?:the\s+)?(?:moderators?|readers?)|(?:moderators?|readers?)(?:'s)?\s+notes?)\b[^\])]*[\])]/gi, " ");
    // An unformatted "Label: …" has no marked end: cut through its first
    // sentence, or to where the question visibly restarts (a lowercase word,
    // then a capitalised one, outside quotes).
    var m, guard = 0;
    NOTE_LBL_G.lastIndex = 0;
    while ((m = NOTE_LBL_G.exec(t)) && guard++ < 6) {
      var s = m.index, from = s + m[0].length, rest = t.slice(from, from + 300), b = -1;
      var w = rest.match(/^\S+\s+/), re = /[.!?]+["'”’)]*\s+|[a-z0-9"'”’)]\s+(?=[A-Z](?:[a-z'’]|\s))/g, mm;
      re.lastIndex = w ? w[0].length : 0;
      while ((mm = re.exec(rest))) {
        var stop = /^[.!?]/.test(mm[0]);
        if (!stop && ((rest.slice(0, mm.index + 1).match(/"/g) || []).length % 2)) continue;
        b = stop ? mm.index + mm[0].length : mm.index + 1; break;
      }
      while (s > 0 && /[\s*<\[(]/.test(t[s - 1])) s--;
      t = cutSpan(t, s, b >= 0 ? from + b : from);
      NOTE_LBL_G.lastIndex = s;
    }
    return t;
  }
  function stripGuides(t) {
    if (ctx.host && typeof ctx.host.stripPronunciations === "function") { try { t = ctx.host.stripPronunciations(t); } catch (e) {} }
    return String(t || "").replace(/\s*\(\s*["“][^"”()]*["”]\s*\)/g, "");
  }
  var _qtCache = typeof WeakMap === "function" ? new WeakMap() : null;
  K.qText = function (q) {
    if (!q) return "";
    if (_qtCache && _qtCache.has(q)) return _qtCache.get(q);
    var t = null;
    if (ctx.host && typeof ctx.host.questionText === "function") { try { t = ctx.host.questionText(q, "question"); } catch (e) { t = null; } }
    if (typeof t !== "string") t = q.question_sanitized || "";
    t = stripGuides(stripNotes(decodeEnt(t), q.question)).replace(/\s{2,}/g, " ").trim();
    if (_qtCache) _qtCache.set(q, t);
    return t;
  };
  // The answer line's main answer: what comes before any [accept …] / (…).
  K.mainAnswer = function (sani) { return decodeEnt(sani).split(/[\[(<]/)[0].trim().replace(/[;:,.]+$/, ""); };
  // Lowercase word tokens; internal apostrophes kept, a possessive 's dropped.
  K.tokens = function (text) {
    return (String(text || "").toLowerCase().match(/[\p{L}\p{N}'’]+/gu) || []).map(function (w) { return w.replace(/['’]s$/, ""); }).filter(Boolean);
  };
  // FTS: every token quoted (they are ANDed).
  K.ftsAll = function (col, toks) { return col + " : (" + toks.map(function (t) { return '"' + t.replace(/"/g, "") + '"'; }).join(" ") + ")"; };
  // The words of a question inside the chosen clue range (percent of the
  // question, or only what comes before the power mark).
  K.sliceWords = function (q, v) {
    var text = K.qText(q);
    if (v.power) {
      var pi = text.indexOf("(*)");
      return pi < 0 ? [] : K.tokens(text.slice(0, pi));
    }
    var words = K.tokens(text.replace(/\(\*\)/g, " "));
    var n = words.length; if (!n) return [];
    if (v.lo <= 0 && v.hi >= 100) return words;
    var a = Math.round((v.lo / 100) * n), b = Math.round((v.hi / 100) * n);
    return words.slice(a, Math.max(a + 1, b));
  };
  // Is seq a contiguous run inside arr?
  K.hasSeq = function (arr, seq) {
    if (!seq.length || seq.length > arr.length) return false;
    if (seq.length === 1) return arr.indexOf(seq[0]) >= 0;
    for (var i = 0; i + seq.length <= arr.length; i++) {
      var ok = true;
      for (var j = 0; j < seq.length; j++) if (arr[i + j] !== seq[j]) { ok = false; break; }
      if (ok) return true;
    }
    return false;
  };
  // Spelling / transliteration variants (Baldr / Balder / Baldur): one edit.
  K.lev1 = function (a, b) {
    if (a === b) return true;
    var la = a.length, lb = b.length;
    if (Math.abs(la - lb) > 1 || Math.min(la, lb) < 4) return false;
    var i = 0, j = 0, edits = 0;
    while (i < la && j < lb) {
      if (a[i] === b[j]) { i++; j++; continue; }
      if (++edits > 1) return false;
      if (la === lb) { i++; j++; } else if (la > lb) { i++; } else { j++; }
    }
    return edits + (la - i) + (lb - j) <= 1;
  };

  // ── saved view (filters survive leaving the page) ──────────────────────
  K.load = function (defaults) {
    var v = null;
    try { v = ctx.storage.get("view"); } catch (e) { v = null; }
    var out = {};
    for (var k in defaults) out[k] = defaults[k];
    if (v && typeof v === "object") for (var k2 in defaults) if (v[k2] !== undefined && v[k2] !== null) out[k2] = v[k2];
    if (!Array.isArray(out.cats)) out.cats = [];
    if (!Array.isArray(out.diffs)) out.diffs = [];
    out.lo = Math.max(0, Math.min(100, parseInt(out.lo, 10) || 0));
    out.hi = Math.max(0, Math.min(100, parseInt(out.hi, 10))); if (isNaN(out.hi)) out.hi = 100;
    if (out.lo > out.hi) { var t = out.lo; out.lo = out.hi; out.hi = t; }
    return out;
  };
  K.save = function (v) { try { ctx.storage.set("view", v); } catch (e) {} };

  // ── filter row ─────────────────────────────────────────────────────────
  var DIFF_NAMES = ["Unrated", "Middle school", "Easy high school", "Regular high school", "Hard high school", "National high school", "Easy college", "Medium college", "Regionals college", "Nationals college", "Open"];
  var Y0 = 2000, Y1 = 2026;
  K.yearsLabel = function (v) { return (!v.y0 && !v.y1) ? "Any" : (v.y0 || Y0) + "–" + (v.y1 || Y1); };
  K.cluesLabel = function (v) { return v.power ? "Before power" : (v.lo <= 0 && v.hi >= 100) ? "All" : v.lo + "–" + v.hi + "%"; };
  K.filterQs = function (v, catH) {
    var ids = [];
    if (catH) { try { ids = (catH.get() || []).filter(Boolean); } catch (e) { ids = []; } }
    else ids = (v.cats || []).filter(Boolean);
    return (ids.length ? "&categoryIds=" + encodeURIComponent(ids.join(",")) : "") +
      ((v.diffs || []).length ? "&difficulties=" + v.diffs.join(",") : "") +
      (v.y0 ? "&yearMin=" + v.y0 : "") + (v.y1 ? "&yearMax=" + v.y1 : "");
  };
  K.filterRowHtml = function (v, extra) {
    var diffs = "";
    for (var d = 0; d <= 10; d++) diffs += '<label title="' + esc(DIFF_NAMES[d]) + '"><input type="checkbox" value="' + d + '"' + ((v.diffs || []).indexOf(d) >= 0 ? " checked" : "") + "><span>" + d + "</span></label>";
    return '<div class="qrow bwq-filters">' +
      '<span class="bwq-cat-slot"></span>' +
      '<div class="diff-toggles bwq-diffs" role="group" aria-label="Difficulty"><span class="dt-lbl">Difficulty</span>' + diffs + "</div>" +
      '<div class="pop-wrap bwq-popw"><button type="button" class="btn bwq-pop-btn" data-pop="years" aria-expanded="false" aria-haspopup="dialog">Years <span class="accent-val num bwq-years-val">' + esc(K.yearsLabel(v)) + "</span>" + K.ic("down", 14) + "</button>" +
        '<div class="pop left years-pop bwq-pop" data-pop-for="years" role="dialog" aria-label="Years" hidden><form class="bwq-years-form">' +
          '<div class="yrow"><label class="ifield"><span>From</span><input class="bwq-y0" inputmode="numeric" autocomplete="off" value="' + (v.y0 || Y0) + '" aria-label="From year"></label>' +
          '<label class="ifield"><span>To</span><input class="bwq-y1" inputmode="numeric" autocomplete="off" value="' + (v.y1 || Y1) + '" aria-label="To year"></label></div>' +
          '<div class="yrow"><button type="button" class="btn btn-sm bwq-y-any" style="flex:1">Any year</button><button type="submit" class="btn btn-sm btn-primary" style="flex:1">Apply</button></div>' +
        "</form></div></div>" +
      '<div class="pop-wrap bwq-popw"><button type="button" class="btn bwq-pop-btn" data-pop="clues" aria-expanded="false" aria-haspopup="dialog">Clues <span class="accent-val bwq-clues-val">' + esc(K.cluesLabel(v)) + "</span>" + K.ic("down", 14) + "</button>" +
        '<div class="pop left bwq-pop bwq-clue-pop" data-pop-for="clues" role="dialog" aria-label="Clues" hidden>' +
          '<div class="bwq-clue-head"><span>Part of the question</span><b class="num bwq-range-val"></b></div>' +
          '<div class="dual-range bwq-dual"><div class="dual-range-track"><div class="dual-range-fill bwq-fill"></div></div>' +
            '<input type="range" class="bwq-lo" min="0" max="100" step="5" value="' + v.lo + '" aria-label="From">' +
            '<input type="range" class="bwq-hi" min="0" max="100" step="5" value="' + v.hi + '" aria-label="To"></div>' +
          '<label class="checkbox-row bwq-power-row"><input type="checkbox" class="bwq-power"' + (v.power ? " checked" : "") + "><span>Before power only</span></label>" +
        "</div></div>" +
      (extra || "") +
    "</div>";
  };

  // Popovers: the button toggles; a click elsewhere or Esc closes (the app
  // does both for every .pop — this keeps older bases working too).
  function closePops(except) {
    document.querySelectorAll(".bwq-pop:not([hidden])").forEach(function (p) {
      if (except && p === except) return;
      p.hidden = true;
      var b = p.parentNode && p.parentNode.querySelector(".bwq-pop-btn"); if (b) b.setAttribute("aria-expanded", "false");
    });
  }
  K.closePops = closePops;
  function onDocDown(e) { if (!e.target.closest || !e.target.closest(".bwq-pop, .bwq-pop-btn")) closePops(); }
  document.addEventListener("mousedown", onDocDown, true);
  ctx._unsub.push(function () { document.removeEventListener("mousedown", onDocDown, true); });
  function openPop(btn, pop) {
    var open = pop.hidden;
    closePops(open ? pop : null);
    pop.hidden = !open;
    btn.setAttribute("aria-expanded", String(open));
    if (!open) return;
    // keep it on screen (a button near the right edge on a phone)
    pop.style.left = ""; pop.style.right = "";
    // the right edge of what's visible: the viewport, or a scrolling parent
    // (its scrollbar takes width from the viewport)
    var edge = document.documentElement.clientWidth || window.innerWidth;
    for (var a = pop.parentElement; a && a !== document.body; a = a.parentElement) {
      var ox = getComputedStyle(a).overflowX;
      if (ox === "auto" || ox === "scroll" || ox === "hidden" || ox === "clip") { edge = Math.min(edge, a.getBoundingClientRect().left + a.clientWidth); break; }
    }
    var r = pop.getBoundingClientRect();
    if (r.right > edge - 8) pop.style.left = Math.min(0, edge - 8 - r.right) + "px";
    var f = pop.querySelector("input"); if (f && pop.dataset.popFor === "years") setTimeout(function () { try { f.focus(); f.select(); } catch (e) {} }, 30);
  }

  // Wires the row. onChange(kind) runs after any filter changes (v is saved).
  // Returns { cat } — the category picker handle (null on a base without one).
  K.wireFilterRow = function (root, v, onChange) {
    var row = root.querySelector(".bwq-filters");
    var fire = function (kind) { K.save(v); try { onChange(kind); } catch (e) { console.error(e); } };
    var cat = null, slot = row.querySelector(".bwq-cat-slot");
    if (ctx.host && typeof ctx.host.categoryPicker === "function") {
      try {
        cat = ctx.host.categoryPicker(null, { type: "tossups", selected: (v.cats || []).slice(), label: "Categories",
          onChange: function (ids) { v.cats = (ids || []).slice(); fire("cats"); } });
        if (cat && cat.el) slot.replaceWith(cat.el); else cat = null;
      } catch (e) { cat = null; }
    }
    if (!cat && slot) slot.remove();
    row.querySelectorAll(".bwq-diffs input").forEach(function (cb) {
      cb.addEventListener("change", function () {
        v.diffs = [].slice.call(row.querySelectorAll(".bwq-diffs input:checked")).map(function (c) { return parseInt(c.value, 10); });
        fire("diffs");
      });
    });
    row.querySelectorAll(".bwq-pop-btn").forEach(function (b) {
      b.addEventListener("click", function (e) { e.preventDefault(); openPop(b, b.parentNode.querySelector(".bwq-pop")); });
    });
    row.querySelectorAll(".bwq-pop").forEach(function (p) {
      p.addEventListener("keydown", function (e) {
        if (e.key === "Escape" && !p.hidden) { e.preventDefault(); e.stopPropagation(); closePops(); var b = p.parentNode.querySelector(".bwq-pop-btn"); if (b) b.focus(); }
      });
    });
    // Years
    var yv = row.querySelector(".bwq-years-val"), f = row.querySelector(".bwq-years-form");
    function setYears(a, b) {
      a = parseInt(a, 10); b = parseInt(b, 10);
      if (isNaN(a) || a < 1900 || a > 2100) a = Y0;
      if (isNaN(b) || b < 1900 || b > 2100) b = Y1;
      if (a > b) { var t = a; a = b; b = t; }
      var y0 = a > Y0 ? a : null, y1 = b < Y1 ? b : null;
      var changed = y0 !== (v.y0 || null) || y1 !== (v.y1 || null);
      v.y0 = y0; v.y1 = y1;
      yv.textContent = K.yearsLabel(v);
      f.querySelector(".bwq-y0").value = v.y0 || Y0; f.querySelector(".bwq-y1").value = v.y1 || Y1;
      closePops();
      if (changed) fire("years");
    }
    f.addEventListener("submit", function (e) { e.preventDefault(); setYears(f.querySelector(".bwq-y0").value, f.querySelector(".bwq-y1").value); });
    f.querySelector(".bwq-y-any").addEventListener("click", function () { setYears(Y0, Y1); });
    // Clues: a percent range of the question, or before the power mark
    var lo = row.querySelector(".bwq-lo"), hi = row.querySelector(".bwq-hi"), fill = row.querySelector(".bwq-fill");
    var rv = row.querySelector(".bwq-range-val"), cv = row.querySelector(".bwq-clues-val"), pw = row.querySelector(".bwq-power");
    function paintRange() {
      var a = parseInt(lo.value, 10), b = parseInt(hi.value, 10), mn = Math.min(a, b), mx = Math.max(a, b);
      v.lo = mn; v.hi = mx;
      fill.style.left = mn + "%"; fill.style.right = (100 - mx) + "%";
      rv.textContent = mn + "–" + mx + "%";
      lo.disabled = hi.disabled = !!v.power;
      row.querySelector(".bwq-dual").classList.toggle("off", !!v.power);
      cv.textContent = K.cluesLabel(v);
    }
    var rangeAt = null;
    lo.addEventListener("input", paintRange); hi.addEventListener("input", paintRange);
    var rangeDone = function () { var s = v.lo + "-" + v.hi; if (s !== rangeAt) { rangeAt = s; fire("clues"); } };
    lo.addEventListener("change", rangeDone); hi.addEventListener("change", rangeDone);
    pw.addEventListener("change", function () { v.power = pw.checked; paintRange(); fire("clues"); });
    paintRange(); rangeAt = v.lo + "-" + v.hi;
    return { cat: cat };
  };

  // ── star / save ────────────────────────────────────────────────────────
  K.canSave = function () { return !!((ctx.host && ctx.host.openItemSaveMenu) || window.QBFolders); };
  K.starBtn = function (on, attrs) {
    return '<button type="button" class="star-btn bwq-star' + (on ? " on" : "") + '" aria-label="' + (on ? "Unstar" : "Star") + '" aria-pressed="' + !!on + '"' + (attrs || "") + ">" + (on ? "★" : "☆") + "</button>";
  };
  K.setStar = function (btn, on) {
    if (!btn) return;
    btn.classList.toggle("on", !!on); btn.textContent = on ? "★" : "☆";
    btn.setAttribute("aria-pressed", String(!!on)); btn.setAttribute("aria-label", on ? "Unstar" : "Star");
  };
  K.saveBtn = function (attrs) { return K.canSave() ? '<button type="button" class="star-btn save-plus bwq-save" aria-label="Save to review or a folder"' + (attrs || "") + ">+</button>" : ""; };
  K.openSave = function (spec, anchor) {
    if (ctx.host && ctx.host.openItemSaveMenu) ctx.host.openItemSaveMenu(spec, anchor);
    else if (window.QBFolders) window.QBFolders.pick(spec.folder.type, spec.folder.item, anchor);
  };

  // ── pager ──────────────────────────────────────────────────────────────
  // The app's own pager (the Database's: page strip + "Page n of N" jump) when the base has it;
  // else a plain ‹ Page n of N ›. where: "top" (in the .rhead) or "bottom" (in a .rfoot).
  K.pagerHtml = function (page, pages, where) {
    if (pages <= 1) return "";
    if (ctx.host && typeof ctx.host.pagerHtml === "function" && typeof ctx.host.wirePagers === "function") {
      try { return ctx.host.pagerHtml(where || "top", page, pages); } catch (e) {}
    }
    return '<nav class="bwq-pager" aria-label="Pages">' +
      '<button type="button" class="btn btn-icon" data-pg="' + (page - 1) + '" aria-label="Previous page"' + (page <= 0 ? " disabled" : "") + ">" + K.ic("left", 16) + "</button>" +
      '<span class="bwq-pagenum">Page <b class="num">' + (page + 1) + '</b> of <span class="num">' + pages + "</span></span>" +
      '<button type="button" class="btn btn-icon" data-pg="' + (page + 1) + '" aria-label="Next page"' + (page >= pages - 1 ? " disabled" : "") + ">" + K.ic("right", 16) + "</button></nav>";
  };
  K.wirePager = function (root, go) {
    if (ctx.host && typeof ctx.host.pagerHtml === "function" && typeof ctx.host.wirePagers === "function") {
      // the host's wiring scrolls back to the .rhead after a bottom-pager click itself
      try { ctx.host.wirePagers(root, function (p) { go(p, false); }); return; } catch (e) {}
    }
    root.querySelectorAll(".bwq-pager [data-pg]").forEach(function (b) {
      b.addEventListener("click", function () { if (!b.disabled) go(parseInt(b.dataset.pg, 10), !!b.closest(".bwq-foot")); });
    });
  };

  // ── other plugins / pages ─────────────────────────────────────────────
  K.pageActive = function (id) {
    try { return !!(window.QB && QB.getActivePages && (QB.getActivePages() || []).some(function (p) { return p.id === id || p.id.indexOf(id + "::") === 0; })); } catch (e) { return false; }
  };
  K.hasFlashcards = function () { return K.pageActive("flashcards::cards"); };
  K.reviewAsFlashcards = function (cards) {
    if (!cards.length) return false;
    try { localStorage.setItem("qb-flashcards-cards", JSON.stringify({ cards: cards, ts: Date.now() })); } catch (e) {}
    var ok = !!(window.QB && QB.showPage && QB.showPage("flashcards::cards"));
    if (!ok) { try { localStorage.removeItem("qb-flashcards-cards"); } catch (e) {} }
    return ok;
  };
  K.searchDb = function (opts) { if (ctx.host && ctx.host.searchDatabase) ctx.host.searchDatabase(opts); };

  // ── Database → <plugin> tab: the saved pairs ───────────────────────────
  // o: { title, empty, key, list(), save(list), front(it), back(it), card(it), saveSpec(it) }
  K.savedTab = function (o) {
    var host = null;
    function paint() {
      if (!host || !host.isConnected) return;
      var list = o.list();
      if (!list.length) { host.innerHTML = K.empty(o.empty); return; }
      var fc = K.hasFlashcards();
      host.innerHTML =
        '<div class="db-toolbar bwq-saved-bar"><span class="bwq-saved-n">' + K.num(list.length) + " saved</span><span class=\"spacer\"></span>" +
          (fc ? '<button type="button" class="btn btn-sm btn-primary bwq-review">Review as flashcards</button>' : "") + "</div>" +
        '<div class="list bwq-saved">' + list.map(function (it, i) {
          return '<div class="list-row bwq-saved-row" data-i="' + i + '"><span class="bwq-front">' + esc(o.front(it)) + '</span><span class="bwq-arrow" aria-hidden="true">→</span><span class="bwq-back">' + esc(o.back(it)) + "</span>" +
            '<span class="bwq-acts">' + K.saveBtn(' data-i="' + i + '"') + K.starBtn(true, ' data-i="' + i + '"') + "</span></div>";
        }).join("") + "</div>";
      host.querySelectorAll(".bwq-star").forEach(function (s) {
        s.addEventListener("click", function () {
          // Unstarring greys the row out (star it again to keep it); it leaves on the next visit.
          var it = list[parseInt(s.dataset.i, 10)]; if (!it) return;
          var cur = o.list(), k = o.key(it), idx = cur.findIndex(function (x) { return o.key(x) === k; });
          var on = idx < 0;
          if (on) cur.push(it); else cur.splice(idx, 1);
          o.save(cur);
          K.setStar(s, on);
          var row = s.closest(".bwq-saved-row"); if (row) row.classList.toggle("off", !on);
          if (ctx.playSound) ctx.playSound("star");
        });
      });
      host.querySelectorAll(".bwq-save").forEach(function (b) {
        b.addEventListener("click", function () { var it = list[parseInt(b.dataset.i, 10)]; if (it) K.openSave(o.saveSpec(it), b); });
      });
      var rv = host.querySelector(".bwq-review");
      if (rv) rv.addEventListener("click", function () { K.reviewAsFlashcards(o.list().map(o.card)); });
    }
    ctx.on("plugins:changed", function () { paint(); });
    ctx.registerStarredProvider({ id: o.id, title: o.title, render: function (container) { host = container; paint(); } });
  };
  return K;
}

// ── Buzzwords ──────────────────────────────────────────────────────────────
// Reads every question in the chosen scope (categories, difficulty, years,
// part of the question) and lists the words and phrases that almost always
// mean one answer — "when you hear X, buzz Y" — with how sure that is and how
// often it came up. Confidence, times seen, answer type and order apply
// instantly to the last scan.
function __qbMain(ctx) {
  var K = __qbKit(ctx), esc = K.esc;
  var STOP = {};
  ("a an the this that these those it its his her hers he she they them their theirs we us our you your i me my mine of in on at to for from with within without by as is are was were be been being am do does did done not no nor so or and but if then than because while during after before until once when where which who whom whose what why how all any both each few more most other some such only own same here there over under again further about above below between into through against up down out off very can will just should now points point name names named ftp identify gives give given made make makes making one two three four five six seven eight nine ten first second third often called also another may might must shall many much work works worked title titled known includes including include described describes describe used uses use using like unlike along man woman men women person people city country state nation work novel poem play opera symphony war battle king queen god goddess author authors poet poets composer composers writer writers artist artists painter sculptor novelist playwright philosopher thinker scientist character characters figure entity thing things wrote written writes have has had having").split(/\s+/).forEach(function (w) { STOP[w] = 1; });

  var v = K.load({ cats: [], diffs: [2, 3, 4, 5], y0: null, y1: null, lo: 0, hi: 100, power: false, type: "all", conf: 80, min: 3, sort: "conf" });
  var TYPES = [["all", "Any answer"], ["person", "People"], ["place", "Places"], ["work", "Works"], ["event", "Events"], ["group", "Groups"], ["thing", "Things & ideas"]];
  var CONFS = [60, 70, 80, 90, 95, 100], MINS = [2, 3, 5, 10, 20];
  if (!TYPES.some(function (t) { return t[0] === v.type; })) v.type = "all";
  if (CONFS.indexOf(+v.conf) < 0) v.conf = 80;
  if (MINS.indexOf(+v.min) < 0) v.min = 3;
  if (v.sort !== "seen") v.sort = "conf";

  var body = null, catH = null, scan = null, gen = 0, scanning = false, viewCache = null, pageNo = 0, rescanT = null;
  var PAGE = 50;
  function el(sel) { return body && body.querySelector(sel); }

  // What kind of thing an answer is, from the database's answer-type tags.
  var PERSON = { "Person": 1, "Fictional Character": 1, "Deity or Mythic Being": 1, "Legendary or Scriptural Figure": 1 };
  var PLACE = { "Place": 1, "Place Type or Landform": 1 };
  var EVENT = { "Event": 1, "Period or Movement": 1 };
  var GROUP = { "Organization or Company": 1, "Group, Dynasty or Family": 1, "People or Ethnic Group": 1, "Musical Group or Band": 1 };
  function bucket(t) {
    if (!t) return "";
    if (/^Work:/.test(t)) return "work";
    return PERSON[t] ? "person" : PLACE[t] ? "place" : EVENT[t] ? "event" : GROUP[t] ? "group" : "thing";
  }
  function answerType(q) {
    var t = q && q.tags;
    if (!t) return "";
    if (typeof t === "string") { var m = /"answer_type"\s*:\s*\[\s*"((?:[^"\\]|\\.)*)"/.exec(t); return m ? bucket(m[1]) : ""; }
    return bucket(t.answer_type && t.answer_type[0]);
  }

  // ── saved buzzwords (★) ──
  function stars() { return ctx.storage.get("bw-stars") || []; }
  function starKey(it) { return (it.kw || "") + "\u0001" + (it.answer || ""); }
  function isStarred(kw, answer) { var k = starKey({ kw: kw, answer: answer }); return stars().some(function (x) { return starKey(x) === k; }); }
  function toggleStar(kw, answer, btn) {
    var lst = stars(), k = starKey({ kw: kw, answer: answer }), i = lst.findIndex(function (x) { return starKey(x) === k; });
    if (i >= 0) lst.splice(i, 1); else lst.push({ kw: kw, answer: answer });
    ctx.storage.set("bw-stars", lst);
    K.setStar(btn, i < 0);
    if (ctx.playSound) ctx.playSound("star");
  }
  function saveSpec(kw, answer) { return { review: { kind: "buzzword", front: kw, back: answer, meta: "buzz word" }, folder: { type: "buzzwords", item: { kw: kw, answer: answer } } }; }

  ctx.registerPage({
    id: "buzz", navLabel: "Buzzwords", title: "Buzzwords",
    // built once: a later visit keeps the results (and a scan still running)
    onShow: function (elx) { body = elx; if (!el("#bw-go")) render(); },
  });

  function opt(val, label, cur) { return '<option value="' + val + '"' + (String(cur) === String(val) ? " selected" : "") + ">" + esc(label) + "</option>"; }
  function render() {
    body.innerHTML =
      '<div class="bwq bw">' +
        K.filterRowHtml(v, '<span class="spacer"></span><button type="button" class="btn btn-primary" id="bw-go">Find buzzwords</button>') +
        '<div class="qrow bw-knobs">' +
          '<select id="bw-type" class="mode-input" aria-label="Answer type">' + TYPES.map(function (t) { return opt(t[0], t[1], v.type); }).join("") + "</select>" +
          '<select id="bw-conf" class="mode-input" aria-label="Confidence">' + CONFS.map(function (c) { return opt(c, c === 100 ? "100% sure" : c + "%+ sure", v.conf); }).join("") + "</select>" +
          '<select id="bw-min" class="mode-input" aria-label="Times seen">' + MINS.map(function (m) { return opt(m, "Seen " + m + "+ times", v.min); }).join("") + "</select>" +
          '<div class="seg" id="bw-sort" role="group" aria-label="Order">' +
            '<button type="button" data-sort="conf" aria-pressed="' + (v.sort === "conf") + '">Surest</button>' +
            '<button type="button" data-sort="seen" aria-pressed="' + (v.sort === "seen") + '">Most seen</button>' +
          "</div>" +
        "</div>" +
        '<div id="bw-results">' + K.empty("No buzzwords yet") + "</div>" +
      "</div>";
    catH = K.wireFilterRow(body, v, function () {
      // the scope changed: a shown (or running) scan follows it
      if (!scan && !scanning) return;
      clearTimeout(rescanT); rescanT = setTimeout(runScan, 350);
    }).cat;
    el("#bw-go").addEventListener("click", function () { if (scanning) stopScan(); else runScan(); });
    var knob = function () { K.save(v); viewCache = null; pageNo = 0; if (scan && !scanning) paint(); };
    el("#bw-type").addEventListener("change", function (e) { v.type = e.target.value; knob(); });
    el("#bw-conf").addEventListener("change", function (e) { v.conf = parseInt(e.target.value, 10) || 80; knob(); });
    el("#bw-min").addEventListener("change", function (e) { v.min = parseInt(e.target.value, 10) || 3; knob(); });
    el("#bw-sort").addEventListener("click", function (e) {
      var b = e.target.closest("[data-sort]"); if (!b || b.dataset.sort === v.sort) return;
      v.sort = b.dataset.sort;
      body.querySelectorAll("#bw-sort [data-sort]").forEach(function (x) { x.setAttribute("aria-pressed", String(x === b)); });
      knob();
    });
  }
  function setScanning(on) {
    scanning = on;
    var b = el("#bw-go"); if (b) { b.textContent = on ? "Stop" : "Find buzzwords"; b.classList.toggle("btn-primary", !on); }
    try { if (ctx.host && ctx.host.setBusy) ctx.host.setBusy("buzz-words-scan", on); } catch (e) {}
  }
  function stopScan() {
    // what was shown before belongs to other filters now: start clean
    gen++; setScanning(false); scan = null; viewCache = null;
    var out = el("#bw-results"); if (out) out.innerHTML = K.empty("No buzzwords yet");
  }

  // ── the scan ───────────────────────────────────────────────────────────
  // Every question in scope is read once. A word or phrase seen only once is
  // kept as a 32-bit hash in a typed table (most are); from its second sighting
  // on it gets real counts per answer. One that has clearly become generic
  // (12+ sightings, no answer above a third) stops being counted.
  function gramsOf(words, skip, emit) {
    for (var i = 0; i < words.length; i++) {
      var w = words[i];
      if (w.length >= 3 && !STOP[w] && !skip[w] && !/^\d+$/.test(w)) emit(w);
      for (var L = 2; L <= 3; L++) {
        if (i + L > words.length) break;
        var g = words.slice(i, i + L);
        if (STOP[g[0]] || STOP[g[L - 1]]) continue;
        var bad = false;
        for (var k = 0; k < L; k++) if (skip[g[k]] || g[k].length < 2 || /^\d+$/.test(g[k])) { bad = true; break; }
        if (!bad) emit(g.join(" "));
      }
    }
  }
  function hashStr(s) { var h = 2166136261; for (var i = 0; i < s.length; i++) h = Math.imul(h ^ s.charCodeAt(i), 16777619); return (h >>> 0) || 1; }
  // The scan is done where the questions are (the website's server, the app's backend:
  // GET /api/analysis/buzzwords — one answer, kept there, so the same scope comes back at once,
  // for everyone on the website). An older backend without it: the scan runs here, as before.
  var serverScan = true;
  async function runServerScan(my, out, filters, cv) {
    var total = 0;
    try { total = ((await ctx.api.get("/api/tossups/count?_=1" + filters)) || {}).count || 0; } catch (e) { total = 0; }
    if (my !== gen) return true;
    // the first time a scope is read takes about a second per 9,000 questions; again, no time
    var t0 = Date.now(), est = Math.max(1200, total / 9), label = "Finding buzzwords in " + K.num(total) + " questions…";
    out.innerHTML = K.loadBarDet(label, 0);
    var tick = setInterval(function () { if (my !== gen) { clearInterval(tick); return; } out.innerHTML = K.loadBarDet(label, Math.min(0.95, (Date.now() - t0) / est)); }, 250);
    var r = null, err = null;
    try { r = await ctx.api.get("/api/analysis/buzzwords?_=1" + filters + "&lo=" + cv.lo + "&hi=" + cv.hi + (cv.power ? "&power=1" : ""), 180000); } catch (e) { err = e; }
    clearInterval(tick);
    if (my !== gen) return true;
    var missing = (err && /Unknown API route/i.test(String(err.message || err))) || (r && r.error === "Not found");
    if (missing) { serverScan = false; return false; }   // an older backend: scan here
    if (!r || !Array.isArray(r.cands)) { setScanning(false); scan = null; out.innerHTML = K.empty("Scan failed" + (err && err.message ? " — " + err.message : "")); return true; }
    var cands = new Array(r.cands.length);
    for (var i = 0; i < r.cands.length; i++) { var c = r.cands[i]; cands[i] = { kw: c[0], answer: r.answers[c[1]], hits: c[2], total: c[3], conf: c[2] / c[3], type: r.types[c[1]] || "" }; }
    setScanning(false);
    scan = { n: r.n, cands: cands };
    if (!r.n) { out.innerHTML = K.empty("No questions match these filters"); return true; }
    paint();
    return true;
  }
  async function runScan() {
    clearTimeout(rescanT);
    var my = ++gen;
    setScanning(true);
    viewCache = null; pageNo = 0;
    var out = el("#bw-results");
    var filters = K.filterQs(v, catH), cv = { lo: v.lo, hi: v.hi, power: v.power }, total = 0;
    if (serverScan && await runServerScan(my, out, filters, cv)) return;
    if (my !== gen) return;
    out.innerHTML = K.loadBar("Counting questions…");
    try { total = ((await ctx.api.get("/api/tossups/count?_=1" + filters)) || {}).count || 0; } catch (e) { total = 0; }
    if (my !== gen) return;
    var slots = 1 << 20; while (slots < total * 48 && slots < (1 << 24)) slots <<= 1;
    var H = new Uint32Array(slots), A = new Int32Array(slots), MASK = slots - 1, used = 0, LIMIT = Math.floor(slots * 0.75);
    var stats = new Map(), ansIds = new Map(), disp = [], types = [];
    var aid = 0;
    function see(g) {
      var st = stats.get(g);
      if (st !== undefined) {
        if (st === 0) return;
        st.t++;
        if (st.m === null) {
          if (st.ba === aid) { st.b++; return; }
          st.m = [st.ba, st.b, aid, 1];
        } else {
          var m = st.m, i = 0;
          while (i < m.length && m[i] !== aid) i += 2;
          if (i < m.length) { var c = ++m[i + 1]; if (c > st.b) { st.b = c; st.ba = aid; } } else m.push(aid, 1);
        }
        if (st.t >= 12 && st.b * 3 < st.t) stats.set(g, 0);
        return;
      }
      var h = hashStr(g), j = h & MASK;
      while (H[j] !== 0) {
        if (H[j] === h) { var a0 = A[j]; stats.set(g, a0 === aid ? { t: 2, b: 2, ba: aid, m: null } : { t: 2, b: 1, ba: a0, m: [a0, 1, aid, 1] }); return; }
        j = (j + 1) & MASK;
      }
      if (used < LIMIT) { H[j] = h; A[j] = aid; used++; }
    }
    var BATCH = 2500, scanned = 0, rows;
    for (var off = 0; ; off += BATCH) {
      try { rows = ((await ctx.api.get("/api/tossups/query?limit=" + BATCH + "&offset=" + off + filters)) || {}).rows || []; }
      catch (e) { if (my === gen) { setScanning(false); scan = null; out.innerHTML = K.empty("Scan failed"); } return; }
      if (my !== gen) return;
      for (var r = 0; r < rows.length; r++) {
        var q = rows[r], full = K.mainAnswer(q.answer_sanitized); if (!full) continue;
        var key = full.toLowerCase(), id = ansIds.get(key);
        if (id === undefined) { id = disp.length; ansIds.set(key, id); disp.push(full); types.push(null); }
        aid = id;
        var bt = answerType(q);
        if (bt) { var tt = types[id] || (types[id] = {}); tt[bt] = (tt[bt] || 0) + 1; }
        var skip = Object.create(null);
        K.tokens(q.answer_sanitized).forEach(function (w) { skip[w] = 1; });
        var seen = new Set();
        gramsOf(K.sliceWords(q, cv), skip, function (g) { if (!seen.has(g)) { seen.add(g); see(g); } });
      }
      scanned += rows.length;
      out.innerHTML = K.loadBarDet("Reading questions… " + K.num(scanned) + (total ? " of " + K.num(total) : ""), total ? scanned / total : 0);
      if (rows.length < BATCH) break;
    }
    if (my !== gen) return;
    var cands = [];
    stats.forEach(function (st, g) {
      if (st === 0 || st.t < 2 || st.b < 0.6 * st.t) return;
      var tt = types[st.ba], best = "thing", bn = 0;
      if (tt) for (var k in tt) if (tt[k] > bn) { bn = tt[k]; best = k; }
      cands.push({ kw: g, answer: disp[st.ba], hits: st.b, total: st.t, conf: st.b / st.t, type: tt ? best : "" });
    });
    stats = null; H = A = null;
    setScanning(false);
    scan = { n: scanned, cands: cands };
    if (!scanned) { out.innerHTML = K.empty("No questions match these filters"); return; }
    paint();
  }

  // A shorter keyword inside a longer one seen in >= 80% of its questions is
  // redundant ("lazarus" when "lady lazarus" says it).
  function collapse(items) {
    var idx = Object.create(null), drop = Object.create(null);
    items.forEach(function (it) { idx[it.kw] = it; });
    items.forEach(function (it) {
      var t = it.kw.split(" "); if (t.length < 2) return;
      for (var L = 1; L < t.length; L++) for (var s = 0; s + L <= t.length; s++) {
        var sub = t.slice(s, s + L).join(" "), si = idx[sub];
        if (si && it.total >= 0.8 * si.total) drop[sub] = 1;
      }
    });
    return items.filter(function (it) { return !drop[it.kw]; });
  }
  function currentList() {
    var key = [v.type, v.conf, v.min, v.sort].join("|");
    if (viewCache && viewCache.key === key && viewCache.scan === scan) return viewCache.list;
    var cmin = v.conf / 100 - 1e-9;
    var list = scan.cands.filter(function (c) { return c.total >= v.min && c.conf >= cmin && (v.type === "all" || c.type === v.type); });
    list = collapse(list);
    if (v.sort === "seen") list.sort(function (a, b) { return b.total - a.total || b.conf - a.conf || (a.kw < b.kw ? -1 : 1); });
    else list.sort(function (a, b) { return b.conf - a.conf || b.hits - a.hits || (a.kw < b.kw ? -1 : 1); });
    viewCache = { key: key, scan: scan, list: list };
    return list;
  }

  function paint(pg) {
    var out = el("#bw-results"); if (!out || !scan) return;
    if (pg != null) pageNo = pg;
    var list = currentList();
    if (!list.length) { out.innerHTML = '<div class="rhead"><span class="total num">0 buzzwords</span><span class="bwq-sub">from ' + K.num(scan.n) + " questions</span></div>" + K.empty("No buzzwords match"); return; }
    var pages = Math.max(1, Math.ceil(list.length / PAGE));
    pageNo = Math.max(0, Math.min(pages - 1, pageNo));
    var start = pageNo * PAGE, slice = list.slice(start, start + PAGE);
    out.innerHTML =
      '<div class="rhead"><span class="total num">' + K.num(list.length) + (list.length === 1 ? " buzzword" : " buzzwords") + "</span>" +
        '<span class="bwq-sub">from ' + K.num(scan.n) + " questions</span><span class=\"spacer\"></span>" + K.pagerHtml(pageNo, pages) + "</div>" +
      '<div class="list bw-list">' +
        '<div class="list-row bwq-head" aria-hidden="true"><span class="lr-rank">#</span><span class="bw-pair"><span class="bwq-term">When you hear</span><span class="bw-ans">Buzz</span></span>' +
          '<span class="bwq-p">Sure</span><span class="bwq-n">Seen</span><span class="bwq-acts"></span></div>' +
        slice.map(function (e, j) {
          var i = start + j;
          return '<div class="list-row" data-i="' + i + '"><span class="lr-rank num">' + (i + 1) + "</span>" +
            '<span class="bw-pair"><span class="bwq-term bw-kw bwq-link" data-kw="' + esc(e.kw) + '">' + esc(e.kw) + '</span><span class="bw-ans">' + esc(e.answer) + "</span></span>" +
            '<span class="bwq-p num">' + K.pct(e.conf) + "</span>" +
            '<span class="bwq-n num">' + K.num(e.total) + "</span>" +
            '<span class="bwq-acts">' + K.saveBtn() + K.starBtn(isStarred(e.kw, e.answer)) + "</span></div>";
        }).join("") +
      "</div>" +
      (pages > 1 ? '<div class="bwq-foot rfoot">' + K.pagerHtml(pageNo, pages, "bottom") + "</div>" : "");
    K.wirePager(out, function (p, fromFoot) { paint(p); if (fromFoot) { var h = out.querySelector(".rhead"); if (h && h.scrollIntoView) h.scrollIntoView({ block: "start" }); } });
    if (ctx.host && ctx.host.positionPagerStrips) ctx.host.positionPagerStrips();
    out.querySelectorAll(".list-row[data-i]").forEach(function (row) {
      var e = list[parseInt(row.dataset.i, 10)]; if (!e) return;
      var st = row.querySelector(".bwq-star"), sv = row.querySelector(".bwq-save");
      row.querySelector(".bwq-link").addEventListener("click", function () { K.searchDb({ query: e.kw, field: "question", exact: true, qtype: "tossup" }); });
      st.addEventListener("click", function (ev) { ev.stopPropagation(); toggleStar(e.kw, e.answer, st); });
      if (sv) sv.addEventListener("click", function (ev) { ev.stopPropagation(); K.openSave(saveSpec(e.kw, e.answer), sv); });
      row.addEventListener("contextmenu", function (ev) {
        if (!window.QB || !QB.contextMenu) return;
        ev.preventDefault();
        var items = [
          { label: "Find questions with “" + e.kw + "”", onClick: function () { K.searchDb({ query: e.kw, field: "question", exact: true, qtype: "tossup" }); } },
          { label: "Find questions answered by it", onClick: function () { K.searchDb({ query: e.answer, field: "answer", exact: false }); } },
        ];
        if (K.pageActive("keyword-freq::kwfreq")) items.push({ label: "Answers for “" + e.kw + "”", onClick: function () { try { localStorage.setItem("qb-kf-handoff", JSON.stringify({ mode: "words", term: e.kw })); } catch (x) {} QB.showPage("keyword-freq::kwfreq"); } });
        var fsp = null;
        try { fsp = (QB.getActivePages() || []).find(function (p) { return p.id.indexOf("fact-sheet::") === 0; }); } catch (x) { fsp = null; }
        if (fsp) items.push({ label: "Fact sheet for " + e.answer, onClick: function () { try { localStorage.setItem("qb-facts-handoff", JSON.stringify({ term: e.answer })); } catch (x) {} QB.showPage(fsp.id); } });
        items.push({ sep: true });
        items.push({ label: st.classList.contains("on") ? "Unstar" : "Star", onClick: function () { st.click(); } });
        if (sv) items.push({ label: "Save to review or a folder…", onClick: function () { K.openSave(saveSpec(e.kw, e.answer), sv); } });
        QB.contextMenu(ev.clientX, ev.clientY, items, { title: e.kw + " → " + e.answer });
      });
    });
  }

  // ── Database → Buzzwords: saved buzzwords ──
  K.savedTab({
    id: "buzz-words", title: "Buzzwords", empty: "No saved buzzwords yet",
    list: stars, save: function (l) { ctx.storage.set("bw-stars", l); }, key: starKey,
    front: function (it) { return it.kw; }, back: function (it) { return it.answer; },
    card: function (it) { return { front: it.kw, back: it.answer, meta: "buzz word" }; },
    saveSpec: function (it) { return saveSpec(it.kw, it.answer); },
  });
  ctx._unsub.push(function () { gen++; clearTimeout(rescanT); try { if (ctx.host && ctx.host.setBusy) ctx.host.setBusy("buzz-words-scan", false); } catch (e) {} });
}
