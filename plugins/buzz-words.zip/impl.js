function __qbMain(ctx) {
    var body = null, page = null;
    function esc(s) { return (s == null ? "" : String(s)).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }

    // ── Answer-type classification (person/place/thing/event/group) ──
    // Derived from each question's referent phrases ("name this X", "this X").
    // The noun map was built empirically from the full corpus: 96.7% of all
    // questions classify into a bucket; the rest land in "other".
    var TYPE_MAP = Object.create(null), TYPE_BIGRAMS = Object.create(null);
    (function () {
      function addT(type, words) { words.split(" ").forEach(function (w) { TYPE_MAP[w] = type; }); }
      addT("person", "author composer man poet artist character philosopher painter god goddess leader king queen playwright president figure son daughter father mother wife husband brother sister director scientist emperor empress ruler woman thinker physicist architect minister founder sculptor writer hero heroine protagonist psychologist mathematician politician actor actress economist creator dictator singer anthropologist senator sociologist player prophet novelist monarch photographer chemist deity saint pope historian biologist dramatist essayist critic journalist explorer inventor commander admiral athlete musician guitarist pianist violinist rapper chancellor tsar czar sultan pharaoh knight duke bishop cardinal priest monk nun rabbi girl boy child person individual official justice judge lawyer doctor nurse teacher professor student spy assassin pirate outlaw villain titan nymph muse apostle disciple martyr missionary theologian linguist geologist astronomer physician surgeon psychiatrist biochemist entrepreneur businessman magnate tycoon banker diplomat ambassador governor mayor congressman statesman revolutionary activist abolitionist reformer conqueror warlord chieftain chief vocalist drummer conductor choreographer dancer filmmaker screenwriter cartoonist illustrator designer printmaker muralist biographer engineer general lady lord prince princess wizard witch giant dwarf demon angel archangel twin sibling nephew niece uncle aunt cousin heir widow orphan slave servant maid butler soldier warrior gladiator hunter shepherd farmer miner sailor captain pilot astronaut cosmonaut driver racer boxer wrestler swimmer runner golfer quarterback pitcher catcher goalkeeper striker defender midfielder guard jester bard minstrel troubadour abbess abbot vicar deacon chaplain friar hermit sage oracle seer shaman druid alchemist astrologer");
      addT("place", "country city state nation island region river lake mountain capital empire kingdom colony province territory continent sea ocean desert town village valley peninsula bay gulf strait republic location place site port county district borough land homeland coast waterfall glacier volcano archipelago isthmus plateau plain prairie savanna tundra fjord lagoon delta estuary tributary canal reservoir dam sound channel reef atoll cape headland cliff gorge canyon ravine cave grotto oasis spring geyser hometown building monument cathedral church temple mosque palace castle tower shrine pagoda basilica abbey monastery fort fortress citadel acropolis pyramid mausoleum tomb cemetery park garden square plaza avenue boulevard street road highway bridge airport station harbor pier dock wharf");
      addT("thing", "novel work play poem book film quantity property concept element painting opera instrument story collection substance term word language number form genre title object organ compound song animal plant metal system molecule text protein organelle epic symphony particle color colour theory law function force effect material disease condition equation theorem album document essay novella ballet letter acid gas constant value model phrase style medium device structure feature cell star planet moon comet asteroid constellation galaxy mineral rock ion isotope enzyme hormone vitamin drug medication vaccine bacterium virus fungus organism creature being currency unit measure measurement symbol sign flag anthem motto award prize trophy medal position profession class kind type sort set series sequence field branch discipline subject art artwork sculpture statue fresco mural portrait photograph print sonata concerto quartet aria hymn carol musical show program sitcom cartoon comic magazine newspaper journal website adjective noun verb pronoun preposition suffix prefix alphabet script alloy polymer plastic fabric textile dye pigment gemstone jewel crystal fluid liquid solid vapor plasma ratio fraction integer polynomial matrix vector tensor algorithm formula graph curve surface shape polygon polyhedron angle triangle circle sphere cube tissue gland muscle bone nerve vein artery limb appendage antibody antigen gene chromosome genome allele nucleotide sugar lipid fat oil salt base solvent solute catalyst reagent indicator electrolyte semiconductor superconductor insulator conductor magnet lens mirror telescope microscope tool machine engine motor turbine reactor generator battery circuit transistor diode capacitor resistor antenna satellite rocket missile spacecraft probe rover ship boat submarine vessel train locomotive automobile car truck bicycle airplane aircraft helicopter drone weapon sword spear bow arrow shield armor helmet cannon rifle pistol bomb grenade food dish drink beverage wine beer spirit cocktail bread cheese fruit vegetable grain spice herb crop tree flower shrub vine moss fern algae bird fish insect mammal reptile amphibian arthropod mollusk crustacean primate rodent feline canine bear whale dolphin shark snake lizard turtle frog spider bee ant beetle butterfly moth dinosaur fossil breed species genus phylum dance game sport pastime hobby craft skill talent dialect accent religion mythology pantheon scripture prayer psalm sutra veda gospel epistle commandment doctrine dogma creed sacrament sin virtue vice emotion feeling sense instinct memory dream nightmare idea ideal principle axiom postulate paradox dilemma fallacy argument thesis hypothesis conjecture speech address sermon lecture debate interview monologue soliloquy dialogue quotation quote proverb idiom slogan catchphrase pun riddle joke pen surname name nickname pseudonym alias honorific epithet");
      addT("event", "event process war battle conflict action technique activity practice phenomenon reaction revolution uprising rebellion movement election operation ceremony festival holiday ritual massacre riot protest strike coup invasion siege crusade expedition voyage journey migration exodus scandal affair trial experiment discovery disaster earthquake eruption flood famine epidemic pandemic tournament match race marathon procedure strategy tactic period era decade century treaty pact accord armistice truce agreement compromise purchase annexation secession succession coronation abdication assassination execution martyrdom pilgrimage hajj fast feast carnival parade pageant rite baptism confirmation communion marriage wedding divorce funeral burial cremation birth death plague genocide holocaust conquest restoration reformation renaissance enlightenment awakening revival crisis panic depression recession boom rush boycott embargo blockade raid ambush skirmish campaign offensive retreat surrender ceasefire mutiny insurrection insurgency revolt putsch");
      addT("group", "group people family dynasty organization company team band party tribe ethnicity civilization army navy regiment sect denomination caste clan gang guild union league alliance coalition committee council parliament congress agency corporation firm studio label network government administration cabinet institution school court academy society club fraternity sorority order cult congregation choir orchestra ensemble troupe cast crew squad battalion brigade legion militia");
      var bg = { "body of water": "place", "mountain range": "place", "prime minister": "person", "short story": "thing", "point guard": "person", "art movement": "group", "ethnic group": "group", "video game": "thing", "board game": "thing", "card game": "thing", "musical instrument": "thing", "chemical element": "thing", "programming language": "thing", "sign language": "thing", "world war": "event", "civil war": "event", "trade route": "place", "state of matter": "thing", "group of": "group", "school of": "group", "unit of": "thing", "method of": "event", "process of": "event", "act of": "event", "war of": "event", "battle of": "event" };
      for (var k in bg) TYPE_BIGRAMS[k] = bg[k];
    })();
    function typeSing(w) {
      if (TYPE_MAP[w]) return w;
      var s;
      if (/ies$/.test(w)) { s = w.replace(/ies$/, "y"); if (TYPE_MAP[s]) return s; }
      if (/(ses|xes|zes|ches|shes)$/.test(w)) { s = w.replace(/es$/, ""); if (TYPE_MAP[s]) return s; }
      if (/s$/.test(w)) { s = w.replace(/s$/, ""); if (TYPE_MAP[s]) return s; }
      return null;
    }
    function typeOfWindow(win) {
      var toks = win.split(/\s+/).slice(0, 4);
      for (var i = 0; i + 1 < toks.length; i++) { var b = toks[i] + " " + toks[i + 1]; if (TYPE_BIGRAMS[b]) return TYPE_BIGRAMS[b]; }
      for (var j = 0; j < toks.length; j++) { var sg = typeSing(toks[j].replace(/['’].*$/, "")); if (sg) return TYPE_MAP[sg]; }
      return null;
    }
    // Merge spelling/transliteration variants (Baldr/Balder/Baldur) so a joint
    // probability isn't fragmented across near-identical answer strings.
    function lev1(a, b) {
      if (a === b) return true;
      var la = a.length, lb = b.length;
      if (Math.abs(la - lb) > 1 || Math.min(la, lb) < 4) return false;
      var i = 0, j = 0, edits = 0;
      while (i < la && j < lb) {
        if (a[i] === b[j]) { i++; j++; continue; }
        if (++edits > 1) return false;
        if (la === lb) { i++; j++; } else if (la > lb) { i++; } else { j++; }
      }
      return edits + (la - i) + (lb - j) <= 1;
    }
    function mergeVariants(entries) { // [{key, display, n, types}] sorted by n desc
      var reps = [];
      entries.forEach(function (e) {
        for (var i = 0; i < reps.length; i++) {
          if (lev1(reps[i].key, e.key)) {
            reps[i].n += e.n;
            if (e.types) for (var t in e.types) { reps[i].types = reps[i].types || Object.create(null); reps[i].types[t] = (reps[i].types[t] || 0) + e.types[t]; }
            return;
          }
        }
        reps.push(e);
      });
      return reps;
    }
    function majType(tally) {
      if (!tally) return "other";
      var best = "other", bn = 0;
      for (var k in tally) if (tally[k] > bn) { bn = tally[k]; best = k; }
      return best;
    }
    function classifyQuestionType(qText) {
      var t = (qText || "").toLowerCase();
      var m = t.match(/(?:name|identify|give)\s+(?:this|these)\s+([a-z][a-z'’-]*(?:\s+[a-z'’of-]+){0,3})/);
      if (m) { var c = typeOfWindow(m[1]); if (c) return c; }
      var votes = Object.create(null), re = /\bth(?:is|ese)\s+([a-z][a-z'’-]*(?:\s+[a-z'’of-]+){0,3})/g, mm;
      while ((mm = re.exec(t))) { var c2 = typeOfWindow(mm[1]); if (c2) votes[c2] = (votes[c2] || 0) + 1; }
      var best = null, bn = 0;
      for (var kk in votes) if (votes[kk] > bn) { bn = votes[kk]; best = kk; }
      return best || "other";
    }

    var STOP = {};
    ("a an the this that these those it its his her hers he she they them their theirs we us our you your i me my mine of in on at to for from with within without by as is are was were be been being am do does did done not no nor so or and but if then than because while during after before until once when where which who whom whose what why how all any both each few more most other some such only own same here there over under again further about above below between into through against up down out off very can will just should now points point name names named ftp identify gives give given made make makes making one two three four five six seven eight nine ten first second third often called also another may might must shall many much work works worked title titled known includes including include described describes describe used uses use using like unlike along man woman men women person people city country state nation work novel poem play opera symphony war battle king queen god goddess").split(/\s+/).forEach(function (w) { STOP[w] = 1; });

    var ALT_SUBCATS = {
      "Other Science": ["Astronomy", "Computer Science", "Earth Science", "Engineering", "Math", "Misc Science"],
      "Other Literature": ["Drama", "Long Fiction", "Poetry", "Short Fiction", "Misc Literature"],
      "Other Fine Arts": ["Architecture", "Dance", "Film", "Jazz", "Musicals", "Opera", "Photography", "Misc Arts"],
      "Social Science": ["Anthropology", "Economics", "Linguistics", "Psychology", "Sociology", "Other Social Science"],
    };

    function kfEnabled() {
      try { return (window.QB.getActivePages() || []).some(function (p) { return p.id.indexOf("keyword-freq::") === 0; }); }
      catch (e) { return false; }
    }
    function mainAnswer(sani) { return (sani || "").split(/[\[(]/)[0].trim().replace(/[;:,.]+$/, ""); }
    // ── saved buzz words (★ a keyword→answer pair to review later) ──
    function starredBW() { return ctx.storage.get("bw-stars") || []; }
    function bwKey(it) { return (it.kw || "") + "" + (it.answer || ""); }
    function isBWStarred(it) { var k = bwKey(it); return starredBW().some(function (x) { return bwKey(x) === k; }); }
    function bwAddBtn(dataI) {
      if (!((ctx.host && ctx.host.openItemSaveMenu) || window.QBFolders)) return "";
      return '<span class="bw-foldx" data-i="' + dataI + '" title="Add to review / folder">+</span>';
    }
    function bwAdd(it, anchor) {
      var spec = { review: { kind: "buzzword", front: it.kw, back: it.answer, meta: "buzz word" }, folder: { type: "buzzwords", item: { kw: it.kw, answer: it.answer } } };
      if (ctx.host && ctx.host.openItemSaveMenu) ctx.host.openItemSaveMenu(spec, anchor);
      else if (window.QBFolders) window.QBFolders.pick("buzzwords", spec.folder.item, anchor);
    }
    function sliceWords(q, lo, hi, powerOnly) {
      var text = q.question_sanitized || "";
      if (powerOnly) {
        // "Before power" mode: only the pre-(*) text counts; questions without
        // a powermark are excluded entirely.
        var pi = text.indexOf("(*)");
        if (pi < 0) return [];
        return (text.slice(0, pi).toLowerCase().match(/[\p{L}\p{N}'’]+/gu) || [])
          .map(function (w) { return w.replace(/['’]s$/, ""); });
      }
      var words = (text.replace(/\(\*\)/g, " ").toLowerCase().match(/[\p{L}\p{N}'’]+/gu) || [])
        .map(function (w) { return w.replace(/['’]s$/, ""); });   // strip possessive 's, like Keyword Frequency
      var n = words.length; if (!n) return [];
      var a = Math.round((lo / 100) * n), b = Math.round((hi / 100) * n);
      return words.slice(a, Math.max(a + 1, b));
    }
    // Does the slice contain the token sequence consecutively? (phrase match —
    // identical rule to Keyword Frequency so confidence numbers line up exactly.)
    function sliceHasSeq(slice, seq) {
      if (!seq.length) return false;
      if (seq.length === 1) return slice.indexOf(seq[0]) >= 0;
      for (var i = 0; i + seq.length <= slice.length; i++) {
        var ok = true;
        for (var j = 0; j < seq.length; j++) { if (slice[i + j] !== seq[j]) { ok = false; break; } }
        if (ok) return true;
      }
      return false;
    }
    // Is shortArr a contiguous run inside longArr?
    function containsSeq(longArr, shortArr) {
      if (shortArr.length > longArr.length) return false;
      for (var i = 0; i + shortArr.length <= longArr.length; i++) {
        var ok = true;
        for (var k = 0; k < shortArr.length; k++) { if (longArr[i + k] !== shortArr[k]) { ok = false; break; } }
        if (ok) return true;
      }
      return false;
    }
    // Collapse word/phrase redundancy: when a longer gram that CONTAINS a shorter
    // one shows up in >=80% of the shorter gram's questions, the shorter gram is
    // redundant (it's almost always part of that phrase) — drop it, keep the more
    // specific phrase. keyOf -> gram string, docOf -> its question count.
    function collapseGrams(items, keyOf, docOf) {
      var toks = items.map(function (it) { return keyOf(it).split(" "); });
      var drop = {};
      for (var i = 0; i < items.length; i++) {
        var sd = docOf(items[i]); if (!sd) continue;
        for (var j = 0; j < items.length; j++) {
          if (i === j) continue;
          if (toks[j].length <= toks[i].length) continue;      // need a strictly longer gram
          if (!containsSeq(toks[j], toks[i])) continue;         // …that contains this one
          if (docOf(items[j]) >= 0.8 * sd) { drop[keyOf(items[i])] = 1; break; }
        }
      }
      return items.filter(function (it) { return !drop[keyOf(it)]; });
    }
    // Unigrams + bigrams + trigrams; multi-word grams can't start/end on a stop word.
    function gramsOf(words, skip) {
      var out = [], clean = words.map(function (w) { return w.replace(/['’]s$/, ""); });
      for (var i = 0; i < clean.length; i++) {
        var w = clean[i];
        if (w.length >= 3 && !STOP[w] && !skip[w] && !/^\d+$/.test(w)) out.push(w);
        for (var L = 2; L <= 3; L++) {
          if (i + L > clean.length) break;
          var g = clean.slice(i, i + L);
          if (STOP[g[0]] || STOP[g[L - 1]]) continue;
          if (g.some(function (x) { return skip[x] || /^\d+$/.test(x) || x.length < 2; })) continue;
          out.push(g.join(" "));
        }
      }
      return out;
    }

    page = ctx.registerPage({
      id: "buzz", navLabel: "Buzz Words", title: "BUZZ WORDS",
      // Re-rendering on every visit would wipe results and orphan an in-flight
      // scan — only build the page the first time (or if the DOM was torn down).
      onShow: function (el) { body = el; if (!body.querySelector("#bw-go")) render(); },
    });

    function render() {
      if (!body) return;
      if (!kfEnabled()) {
        body.innerHTML = '<div class="bw-wrap"><div class="bw-card"><div class="text-muted">Buzz Words is a companion to <strong>Keyword Frequency</strong>. Enable that plugin in <strong>Plugins &amp; Themes</strong> to use this.</div></div></div>';
        return;
      }
      var diffBoxes = "";
      for (var d = 0; d <= 10; d++) diffBoxes += '<label class="bw-diff"><input type="checkbox" class="bw-diff-cb" value="' + d + '"' + (d >= 2 && d <= 5 ? " checked" : "") + ">" + d + "</label>";
      body.innerHTML =
        '<div class="bw-wrap">' +
          '<div class="bw-card">' +
            '<div class="bw-row">' +
              '<select id="bw-cat" class="mode-input bw-sel"><option value="">All categories</option></select>' +
              '<select id="bw-sub" class="mode-input bw-sel" disabled><option value="">All subcategories</option></select>' +
              '<select id="bw-alt" class="mode-input bw-sel" disabled><option value="">All alternate subcategories</option></select>' +
            "</div>" +
            '<div class="bw-row"><span class="bw-label">Difficulty</span>' + diffBoxes + "</div>" +
            '<div class="bw-row"><span class="bw-label">Years</span>' +
              '<div class="dual-range bw-dual"><div class="dual-range-track"><div class="dual-range-fill" id="bw-yfill"></div></div>' +
                '<input type="range" id="bw-ymin" min="2000" max="2026" value="2000">' +
                '<input type="range" id="bw-ymax" min="2000" max="2026" value="2026"></div>' +
              '<span class="bw-label" id="bw-year-val" style="min-width:84px;text-align:right"></span>' +
            "</div>" +
            '<div class="bw-row"><span class="bw-label">Question range</span>' +
              '<div class="dual-range bw-dual"><div class="dual-range-track"><div class="dual-range-fill" id="bw-fill"></div></div>' +
                '<input type="range" id="bw-lo" min="0" max="100" step="5" value="0">' +
                '<input type="range" id="bw-hi" min="0" max="100" step="5" value="100"></div>' +
              '<span class="bw-label" id="bw-range-val" style="min-width:84px;text-align:right"></span>' +
              '<label class="checkbox-row" style="margin-left:8px" title="Only text BEFORE the (*) powermark counts; questions without a powermark are skipped. Disables the % range."><input type="checkbox" id="bw-power"> Before power only</label>' +
            "</div>" +
            '<div class="bw-row">' +
              '<span class="bw-label">Buzz confidence</span>' +
              '<select id="bw-conf" class="mode-input" style="width:150px"><option value="60">≥ 60%</option><option value="70">≥ 70%</option><option value="80" selected>≥ 80%</option><option value="90">≥ 90%</option><option value="95">≥ 95%</option></select>' +
              '<span class="bw-label">Min times seen</span>' +
              '<select id="bw-min" class="mode-input" style="width:90px"><option>2</option><option selected>3</option><option>5</option><option>8</option></select>' +
              '<select id="bw-top" class="mode-input" style="width:110px"><option value="25">Top 25</option><option value="50" selected>Top 50</option><option value="100">Top 100</option><option value="200">Top 200</option><option value="500">Top 500</option><option value="1000">Top 1000</option></select>' +
              '<select id="bw-type" class="mode-input" style="width:120px" title="Filter by what kind of answer it is"><option value="all">All types</option><option value="person">People</option><option value="place">Places</option><option value="thing">Things</option><option value="event">Events</option><option value="group">Groups</option><option value="other">Other</option></select>' +
              '<button class="btn btn-primary" id="bw-go">Find buzz words</button>' +
            "</div>" +
          "</div>" +
          '<div class="bw-card" id="bw-results"><div class="text-muted"></div></div>' +
        "</div>";

      try {
        var cats = [];
        ctx.api.get("/api/categories?type=tossups").then(function (r) {
          cats = r.categories || [];
          var catSel = body.querySelector("#bw-cat");
          cats.forEach(function (c) { var o = document.createElement("option"); o.value = c.category; o.textContent = c.category; catSel.appendChild(o); });
        }).catch(function () {});
      } catch (e) {}

      var catSel = body.querySelector("#bw-cat"), subSel = body.querySelector("#bw-sub"), altSel = body.querySelector("#bw-alt");
      catSel.addEventListener("change", async function () {
        subSel.innerHTML = '<option value="">All subcategories</option>';
        altSel.innerHTML = '<option value="">All alternate subcategories</option>';
        altSel.disabled = true;
        if (!catSel.value) { subSel.disabled = true; return; }
        if (catSel.value === "Social Science") {
          ALT_SUBCATS["Social Science"].forEach(function (a) { var o = document.createElement("option"); o.value = a; o.textContent = a; subSel.appendChild(o); });
          subSel.disabled = false; return;
        }
        try {
          var subs = (await ctx.api.get("/api/subcategories?type=tossups&category=" + encodeURIComponent(catSel.value))).subcategories || [];
          subs.forEach(function (x) { var o = document.createElement("option"); o.value = x.subcategory; o.textContent = x.subcategory; subSel.appendChild(o); });
          subSel.disabled = !subs.length;
        } catch (e) { subSel.disabled = true; }
      });
      subSel.addEventListener("change", function () {
        altSel.innerHTML = '<option value="">All alternate subcategories</option>';
        var alts = (catSel.value !== "Social Science" && /^Other /.test(subSel.value)) ? ALT_SUBCATS[subSel.value] : null;
        if (alts) { alts.forEach(function (a) { var o = document.createElement("option"); o.value = a; o.textContent = a; altSel.appendChild(o); }); altSel.disabled = false; }
        else altSel.disabled = true;
      });

      function wireDual(loId, hiId, fillId, valId, min, max, fmt) {
        var lo = body.querySelector("#" + loId), hi = body.querySelector("#" + hiId);
        function paint() {
          var a = parseInt(lo.value), b = parseInt(hi.value), mn = Math.min(a, b), mx = Math.max(a, b);
          body.querySelector("#" + valId).textContent = fmt(mn, mx);
          var fill = body.querySelector("#" + fillId);
          if (fill) { fill.style.left = ((mn - min) / (max - min)) * 100 + "%"; fill.style.right = ((max - mx) / (max - min)) * 100 + "%"; }
        }
        lo.addEventListener("input", paint); hi.addEventListener("input", paint); paint();
      }
      wireDual("bw-lo", "bw-hi", "bw-fill", "bw-range-val", 0, 100, function (a, b) { return a + "% – " + b + "%"; });
      wireDual("bw-ymin", "bw-ymax", "bw-yfill", "bw-year-val", 2000, 2026, function (a, b) { return a + " – " + b; });
      body.querySelector("#bw-go").onclick = run;
      var tsel = body.querySelector("#bw-type");
      if (tsel) tsel.onchange = function () { typeFilter = tsel.value; if (_repaint) _repaint(); };
      // "Before power only" disables the question-percentage range entirely.
      var pw = body.querySelector("#bw-power");
      if (pw) pw.onchange = function () {
        ["bw-lo", "bw-hi"].forEach(function (id) { var el = body.querySelector("#" + id); if (el) el.disabled = pw.checked; });
        var dual = body.querySelector("#bw-fill"); if (dual && dual.closest(".dual-range")) dual.closest(".dual-range").style.opacity = pw.checked ? "0.35" : "";
        var rv = body.querySelector("#bw-range-val"); if (rv) rv.textContent = pw.checked ? "before (*)" : rv.textContent.replace(/^before.*/, "0% – 100%");
      };
    }

    function filterQs() {
      var cat = body.querySelector("#bw-cat").value, sub = body.querySelector("#bw-sub").value, alt = body.querySelector("#bw-alt").value;
      if (cat === "Social Science" && sub) { alt = sub; sub = ""; }
      var diffs = [].slice.call(body.querySelectorAll(".bw-diff-cb:checked")).map(function (c) { return c.value; });
      var ya = parseInt(body.querySelector("#bw-ymin").value), yb = parseInt(body.querySelector("#bw-ymax").value);
      var ymin = Math.min(ya, yb), ymax = Math.max(ya, yb);
      return (cat ? "&categories=" + encodeURIComponent(cat) : "") +
        (sub ? "&subcategories=" + encodeURIComponent(sub) : "") +
        (alt ? "&alternateSubcategories=" + encodeURIComponent(alt) : "") +
        (diffs.length ? "&difficulties=" + diffs.join(",") : "") +
        (ymin > 2000 ? "&yearMin=" + ymin : "") + (ymax < 2026 ? "&yearMax=" + ymax : "");
    }

    // Compute a candidate gram's TRUE answer distribution over every matching
    // question (capped at 500, exactly like Keyword Frequency's word→answers
    // search) so the confidence shown here equals what you'd see if you looked
    // the keyword up in Keyword Frequency.
    async function verifyGram(gram, rlo, rhi) {
      var seq = gram.split(" ");
      var quoted = seq.map(function (t) { return '"' + t + '"'; }).join(" ");
      var rows;
      try { rows = (await ctx.api.get("/api/tossups/search?query=" + encodeURIComponent("question_sanitized : (" + quoted + ")") + "&limit=500" + filterQs())).rows || []; }
      catch (e) { return null; }
      var counts = {}, display = {}, total = 0;
      rows.forEach(function (q) {
        if (!sliceHasSeq(sliceWords(q, rlo, rhi, powerOnly), seq)) return;   // adjacent phrase match in the chosen slice
        var m = mainAnswer(q.answer_sanitized); if (!m) return;
        var key = m.toLowerCase();
        counts[key] = (counts[key] || 0) + 1;
        if (!display[key]) display[key] = m;
        total++;
      });
      if (!total) return null;
      var bestKey = null, bestN = 0;
      Object.keys(counts).forEach(function (k) { if (counts[k] > bestN) { bestN = counts[k]; bestKey = k; } });
      return { kw: gram, answer: display[bestKey], conf: bestN / total, hits: bestN, total: total, phrase: seq.length > 1 };
    }

    var _scanGen = 0; // bumping this aborts any in-flight scan loop
    var typeFilter = "all";  // person | place | thing | event | group | other | all
    var selHints = [];       // hints selected for a joint P(answer | hints) search
    var jointState = null;   // last joint result ({hints,total,rows}) or {loading:true}
    var lastScan = null;     // {rlo, rhi, filters} snapshot of the last completed scan
    var _repaint = null;     // repaint hook exposed by the last scan's paint()
    async function run() {
      var gen = ++_scanGen;
      var out = body.querySelector("#bw-results");
      var conf = parseInt(body.querySelector("#bw-conf").value) / 100;
      var minSeen = parseInt(body.querySelector("#bw-min").value) || 3;
      var topN = parseInt(body.querySelector("#bw-top").value) || 50;
      var lo = parseInt(body.querySelector("#bw-lo").value), hi = parseInt(body.querySelector("#bw-hi").value);
      var rlo = Math.min(lo, hi), rhi = Math.max(lo, hi);
      var pEl = body.querySelector("#bw-power");
      var powerOnly = !!(pEl && pEl.checked);
      out.innerHTML = '<div class="text-muted" style="padding:10px 0">Scanning questions…</div>';
      // Scale the discovery scan to the filtered set: scan ALL of it when it's
      // small, and a large sample when it's huge. A FIXED sample (the old 1500)
      // under-discovers broad selections — e.g. "All categories" covered <1% of
      // the corpus, so almost no keyword recurred and few buzz words surfaced,
      // which looked like the filter was returning fewer questions. (The filters
      // were never wrong; the scan was just too thin.)
      var matchCount = 0;
      try { matchCount = (await ctx.api.get("/api/tossups/count?_=1" + filterQs())).count || 0; } catch (e) {}

      // Scan EVERY matching question in deterministic pages, accumulating each
      // gram's complete answer distribution. Because the whole set is covered,
      // that distribution IS the exact confidence — no separate verify step.
      var BATCH = 2500, scannedN = 0, MAXG = 800000, gramCount = 0, grams = {};
      var ansTypes = Object.create(null); // answerKey -> {person:n, place:n, …}
      for (var off = 0; ; off += BATCH) {
        var rows;
        try { rows = (await ctx.api.get("/api/tossups/query?limit=" + BATCH + "&offset=" + off + filterQs())).rows || []; }
        catch (e) { if (gen === _scanGen) out.innerHTML = '<div class="text-muted">Scan failed: ' + esc(e.message || e) + "</div>"; return; }
        if (gen !== _scanGen) return; // a newer scan superseded this one
        if (!rows.length) break;
        rows.forEach(function (q) {
          var ansFull = mainAnswer(q.answer_sanitized); if (!ansFull) return;
          var akey = ansFull.toLowerCase();
          var qt = classifyQuestionType(q.question_sanitized);
          var tt = ansTypes[akey] = ansTypes[akey] || Object.create(null);
          tt[qt] = (tt[qt] || 0) + 1;
          var skip = {};
          ((q.answer_sanitized || "").toLowerCase().match(/[\p{L}\p{N}'’]+/gu) || []).forEach(function (w) { skip[w.replace(/['’]s$/, "")] = 1; });
          var seen = {};
          gramsOf(sliceWords(q, rlo, rhi, powerOnly), skip).forEach(function (g) {
            if (seen[g]) return; seen[g] = 1;
            var m = grams[g];
            if (!m) { if (gramCount >= MAXG) return; m = grams[g] = { ans: {}, disp: {}, total: 0 }; gramCount++; }
            m.total++; m.ans[akey] = (m.ans[akey] || 0) + 1;
            if (!m.disp[akey]) m.disp[akey] = ansFull;
          });
        });
        scannedN += rows.length;
        out.innerHTML = '<div class="text-muted" style="padding:10px 0">Scanning all matching questions… ' + scannedN.toLocaleString() +
          (matchCount ? " / " + matchCount.toLocaleString() + " (" + Math.round((scannedN / matchCount) * 100) + "%)" : "") + "</div>";
        if (rows.length < BATCH) break;
      }
      if (!scannedN) { out.innerHTML = '<div class="text-muted">No questions matched those filters.</div>'; return; }
      if (!matchCount) matchCount = scannedN;

      // Build buzz words straight from the complete distribution.
      var list = [];
      Object.keys(grams).forEach(function (g) {
        var m = grams[g];
        if (m.total < minSeen) return;
        var bestK = null, bestN = 0;
        Object.keys(m.ans).forEach(function (k) { if (m.ans[k] > bestN) { bestN = m.ans[k]; bestK = k; } });
        var c = bestN / m.total;
        if (c < conf) return;
        list.push({ kw: g, answer: m.disp[bestK], conf: c, hits: bestN, total: m.total, phrase: g.indexOf(" ") >= 0, type: majType(ansTypes[bestK]) });
      });
      list = collapseGrams(list, function (e) { return e.kw; }, function (e) { return e.total; });
      list.sort(function (a, b) { return b.conf - a.conf || b.hits - a.hits; });
      list = list.slice(0, topN);

      var scanned = "all " + matchCount.toLocaleString();
      if (!list.length) { out.innerHTML = '<div class="bw-meta">No keyword reaches that confidence across ' + esc(scanned) + ' matching questions — lower the threshold, widen the slice, or pick a narrower category.</div>'; return; }
      var rangeLabel = powerOnly ? "before (*) only" : rlo + "–" + rhi + "%";
      var metaHtml = '<div class="bw-meta">' + list.length + " buzz words · scanned " + esc(scanned) + " matching questions · ≥" + Math.round(conf * 100) + "% confidence · " + rangeLabel + "</div>";
      lastScan = { rlo: rlo, rhi: rhi, powerOnly: powerOnly, filters: filterQs() };
      var PAGE = 50, page = 0;
      var TYPE_LABEL = { person: "Person", place: "Place", thing: "Thing", event: "Event", group: "Group", other: "Other" };
      function jointBlockHtml() {
        var h = "";
        if (selHints.length || jointState) {
          h += '<div class="bw-jointbar">' +
            (selHints.length
              ? "<span>" + selHints.length + " hint" + (selHints.length === 1 ? "" : "s") + " selected: <strong>" + selHints.map(esc).join(" · ") + "</strong></span>" +
                ' <button class="btn btn-sm btn-primary" id="bw-joint-go">Find answers for these hints</button>'
              : "") +
            ' <button class="btn btn-sm btn-ghost" id="bw-joint-clear">Clear</button></div>';
        }
        if (jointState && jointState.loading) h += '<div class="text-muted" style="padding:8px 0">Searching questions containing all hints…</div>';
        else if (jointState) {
          var jrows = typeFilter === "all" ? jointState.rows : jointState.rows.filter(function (r) { return r.type === typeFilter; });
          h += '<div class="bw-meta">P(answer | ' + jointState.hints.map(esc).join(" + ") + ") · " +
            jointState.total + " question" + (jointState.total === 1 ? "" : "s") + " contain all hints " + (powerOnly ? "before (*)" : "in the " + rlo + "–" + rhi + "% slice") +
            (jointState.total < 5 ? ' · <span style="color:var(--yellow)">small sample — treat with care</span>' : "") + "</div>";
          h += jrows.length
            ? '<table class="stats-table"><thead><tr><th>#</th><th>Answer</th><th>Type</th><th>Probability</th></tr></thead><tbody>' +
              jrows.map(function (r, i) {
                return "<tr><td>" + (i + 1) + '</td><td><strong>' + esc(r.answer) + "</strong></td><td>" + (TYPE_LABEL[r.type] || "Other") + "</td><td>" + Math.round(r.p * 100) + "% (" + r.n + "/" + jointState.total + ")</td></tr>";
              }).join("") + "</tbody></table><div style='height:14px'></div>"
            : '<div class="text-muted" style="padding:8px 0">' + (jointState.total ? "No answers of that type — switch the type filter." : "No question contains all these hints in that slice — remove a hint or widen the slice.") + "</div>";
        }
        return h;
      }
      function paint() {
        var view = typeFilter === "all" ? list : list.filter(function (e) { return e.type === typeFilter; });
        var pages = Math.max(1, Math.ceil(view.length / PAGE));
        if (page >= pages) page = pages - 1;
        if (page < 0) page = 0;
        var start = page * PAGE, slice = view.slice(start, start + PAGE);
        out.innerHTML = jointBlockHtml() + metaHtml +
          (typeFilter !== "all" ? '<div class="bw-meta">' + view.length + " of " + list.length + " rows match type “" + TYPE_LABEL[typeFilter] + "”</div>" : "") +
          '<table class="stats-table"><thead><tr><th></th><th>#</th><th>When you hear… <span class="bw-meta">(click to select)</span></th><th>…buzz</th><th>Type</th><th>P(answer)</th><th>Seen</th></tr></thead><tbody>' +
          slice.map(function (e, j) {
            var i = start + j, st = isBWStarred(e);
            var sel = selHints.indexOf(e.kw) >= 0;
            return "<tr><td><span class=\"bw-starx" + (st ? " on" : "") + "\" data-i=\"" + i + "\" title=\"Save this buzz word\">" + (st ? "★" : "☆") + "</span>" + bwAddBtn(i) + "</td><td>" + (i + 1) + '</td><td class="bw-kw' + (sel ? " bw-kwsel" : "") + '" data-kw="' + esc(e.kw) + '" title="Click to select this hint (combine several to search answers)">' + esc(e.kw) + "</td><td><strong>" + esc(e.answer) + "</strong></td><td>" + (TYPE_LABEL[e.type] || "Other") + "</td><td>" + Math.round(e.conf * 100) + "% (" + e.hits + "/" + e.total + ")</td><td>" + e.total + "</td></tr>";
          }).join("") + "</tbody></table>" +
          (pages > 1 ? '<div class="bw-pager"><button class="btn btn-sm" id="bw-prev"' + (page === 0 ? " disabled" : "") + '>‹ Prev</button><span class="bw-meta">Page ' + (page + 1) + " of " + pages + "</span><button class=\"btn btn-sm\" id=\"bw-next\"" + (page >= pages - 1 ? " disabled" : "") + ">Next ›</button></div>" : "");
        out.querySelectorAll(".bw-starx").forEach(function (s) {
          s.addEventListener("click", function () {
            var e = view[parseInt(s.dataset.i)]; if (!e) return;
            var it = { kw: e.kw, answer: e.answer };
            var lst = starredBW(), k = bwKey(it), idx = lst.findIndex(function (x) { return bwKey(x) === k; });
            if (idx >= 0) lst.splice(idx, 1); else lst.push(it);
            ctx.storage.set("bw-stars", lst);
            if (ctx.playSound) ctx.playSound("star");
            var on = idx < 0; s.textContent = on ? "★" : "☆"; s.classList.toggle("on", on);
          });
        });
        out.querySelectorAll(".bw-foldx").forEach(function (s) {
          s.addEventListener("click", function () {
            var e = view[parseInt(s.dataset.i)];
            if (e) bwAdd({ kw: e.kw, answer: e.answer }, s);
          });
        });
        out.querySelectorAll(".bw-kw[data-kw]").forEach(function (td) {
          td.onclick = function () {
            var kw = td.dataset.kw, ix = selHints.indexOf(kw);
            if (ix >= 0) selHints.splice(ix, 1);
            else { if (selHints.length >= 4) { ctx.toast("Combine up to 4 hints", "error"); return; } selHints.push(kw); }
            paint();
          };
          var tr = td.parentElement;
          if (tr) tr.oncontextmenu = function (ev) {
            if (!window.QB || !QB.contextMenu) return;
            ev.preventDefault();
            var e = null;
            for (var vi = 0; vi < view.length; vi++) if (view[vi].kw === td.dataset.kw) { e = view[vi]; break; }
            if (!e) return;
            var canSearch = ctx.host && ctx.host.searchDatabase;
            var sel = selHints.indexOf(e.kw) >= 0;
            var items = [
              { label: sel ? "Unselect hint" : "Select as hint (combine to search)", onClick: function () { td.onclick(); } },
              { sep: true },
            ];
            if (canSearch) {
              items.push({ label: "Find questions containing “" + e.kw + "”", onClick: function () { ctx.host.searchDatabase({ query: e.kw, field: "question", exact: true, qtype: "tossup" }); } });
              items.push({ label: "Find questions answered by “" + e.answer + "”", onClick: function () { ctx.host.searchDatabase({ query: e.answer, field: "answer", exact: false }); } });
              items.push({ sep: true });
            }
            items.push({ label: isBWStarred(e) ? "Unstar buzz word" : "Star buzz word", onClick: function () { var s = tr.querySelector(".bw-starx"); if (s) s.click(); } });
            items.push({ label: "Add to review / folder…", onClick: function () { bwAdd({ kw: e.kw, answer: e.answer }, tr.querySelector(".bw-foldx") || tr); } });
            QB.contextMenu(ev.clientX, ev.clientY, items, { title: e.kw + " → " + e.answer });
          };
        });
        var go = out.querySelector("#bw-joint-go"); if (go) go.onclick = runJoint;
        var cl = out.querySelector("#bw-joint-clear"); if (cl) cl.onclick = function () { selHints = []; jointState = null; paint(); };
        var pv = out.querySelector("#bw-prev"), nx = out.querySelector("#bw-next");
        if (pv) pv.onclick = function () { page--; paint(); };
        if (nx) nx.onclick = function () { page++; paint(); };
      }
      _repaint = paint;
      async function runJoint() {
        if (!selHints.length || !lastScan) return;
        jointState = { loading: true };
        paint();
        var toks = [];
        selHints.forEach(function (h) { h.split(" ").forEach(function (t) { toks.push('"' + t + '"'); }); });
        var jrows = [];
        try {
          jrows = (await ctx.api.get("/api/tossups/search?query=" + encodeURIComponent("question_sanitized : (" + toks.join(" ") + ")") + "&limit=1000" + lastScan.filters)).rows || [];
        } catch (e) { jointState = null; ctx.toast("Search failed: " + (e.message || e), "error"); paint(); return; }
        var seqs = selHints.map(function (h) { return h.split(" "); });
        var counts = Object.create(null), disp = Object.create(null), types = Object.create(null), total = 0;
        jrows.forEach(function (q) {
          var sl = sliceWords(q, lastScan.rlo, lastScan.rhi, lastScan.powerOnly);
          for (var si = 0; si < seqs.length; si++) if (!containsSeq(sl, seqs[si])) return;
          var a = mainAnswer(q.answer_sanitized); if (!a) return;
          var k = a.toLowerCase();
          total++;
          counts[k] = (counts[k] || 0) + 1;
          if (!disp[k]) disp[k] = a;
          var qt = classifyQuestionType(q.question_sanitized);
          var tt = types[k] = types[k] || Object.create(null);
          tt[qt] = (tt[qt] || 0) + 1;
        });
        var entries = Object.keys(counts).map(function (k) { return { key: k, display: disp[k], n: counts[k], types: types[k] }; })
          .sort(function (a, b) { return b.n - a.n; });
        entries = mergeVariants(entries);
        jointState = {
          hints: selHints.slice(), total: total, textMatches: jrows.length,
          rows: entries.map(function (e) { return { answer: e.display, n: e.n, p: total ? e.n / total : 0, type: majType(e.types) }; })
            .sort(function (a, b) { return b.p - a.p || b.n - a.n; }).slice(0, 40),
        };
        paint();
      }
      paint();
    }


    // ── Database → Buzz Words tab: your saved buzz words + review as flashcards ──
    ctx.registerStarredProvider({
      id: "buzz-words", title: "Buzz Words",
      render: function renderSaved(container) {
        var list = starredBW();
        if (!list.length) { container.innerHTML = '<div class="text-muted" style="padding:16px">No saved buzz words yet — ★ a keyword in Buzz Words to review it later.</div>'; return; }
        var bar = '<div class="db-toolbar"><button class="btn btn-sm btn-primary" id="bw-review">▶ Review as flashcards</button>' +
          '<span class="text-muted" style="font-size:11px">' + list.length + ' saved · "when you hear X, buzz Y"</span></div>';
        container.innerHTML = bar + '<table class="stats-table"><thead><tr><th></th><th>When you hear…</th><th>…buzz</th></tr></thead><tbody>' +
          list.map(function (it, i) {
            return '<tr><td><span class="bw-starx on" data-i="' + i + '" title="Star / unstar">★</span>' + bwAddBtn(i) + '</td><td class="bw-kw">' + esc(it.kw) + "</td><td><strong>" + esc(it.answer) + "</strong></td></tr>";
          }).join("") + "</tbody></table>";
        container.querySelectorAll(".bw-foldx").forEach(function (s) {
          s.addEventListener("click", function () {
            var it = list[parseInt(s.dataset.i)];
            if (it) bwAdd({ kw: it.kw, answer: it.answer }, s);
          });
        });
        container.querySelectorAll(".bw-starx").forEach(function (s) {
          s.addEventListener("click", function () {
            // Toggle the star WITHOUT removing the row — unstar just greys it out
            // so you can re-star; the row is only dropped on the next render.
            var it = list[parseInt(s.dataset.i)];
            if (!it) return;
            var k = bwKey(it), lst = starredBW();
            var idx = lst.findIndex(function (x) { return bwKey(x) === k; });
            var nowStar;
            if (idx >= 0) { lst.splice(idx, 1); nowStar = false; } else { lst.push(it); nowStar = true; }
            ctx.storage.set("bw-stars", lst);
            s.textContent = nowStar ? "★" : "☆";
            s.classList.toggle("on", nowStar);
            var tr = s.closest("tr"); if (tr) tr.classList.toggle("bw-unstarred", !nowStar);
            if (ctx.playSound) ctx.playSound("star");
          });
        });
        var rv = container.querySelector("#bw-review");
        if (rv) rv.onclick = function () {
          var cards = starredBW().map(function (it) { return { front: it.kw, back: it.answer, meta: "buzz word" }; });
          if (!cards.length) return;
          if (!ctx.host || !ctx.host.launchQuestions) { ctx.toast("Update the app to review as flashcards", "error"); return; }
          try { localStorage.setItem("qb-flashcards-cards", JSON.stringify({ cards: cards, ts: Date.now() })); } catch (e) {}
          var ok = window.QB && window.QB.showPage && window.QB.showPage("flashcards::cards");
          if (!ok) { try { localStorage.removeItem("qb-flashcards-cards"); } catch (e) {} ctx.toast("Enable the Flashcards plugin first", "error"); }
        };
      },
    });

    ctx.toast("Buzz Words enabled");
  }
