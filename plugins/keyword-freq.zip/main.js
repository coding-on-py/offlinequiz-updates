/**
 * OfflineQuiz plugin: Keyword Frequency
 *
 * Two modes:
 *  - Search an answer → the words its questions use most (clue vocabulary).
 *  - Search a word    → the answers whose questions use that word most.
 * Click any result to run the opposite search on it. Filter by any node of the
 * category tree, difficulty and years; the percent bar restricts which slice of
 * each question is read (rounded to the nearest word). Moderator notes and
 * pronunciation guides are never counted.
 */
QB.registerPlugin({
  id: "keyword-freq",
  name: "Keyword Frequency",
  version: "2.17.0",
  author: "OfflineQuiz",
  description: "Answer → top keywords, or word → top answers, with filters and a question-percent range.",
  onEnable: __qbMain,
  onDisable: function () {},
});
