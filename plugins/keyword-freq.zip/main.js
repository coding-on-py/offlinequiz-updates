/**
 * OfflineQuiz plugin: Keyword Frequency
 *
 * Answer → words: the words and phrases an answer's questions use most, and how
 * often each one points back to that answer. Word → answers: the answers whose
 * questions use a word (or several, comma-separated) most often. Filters:
 * categories, difficulty, years, and which part of each question is read.
 * Moderator notes and pronunciation guides are never counted.
 */
QB.registerPlugin({
  id: "keyword-freq",
  name: "Keyword Frequency",
  version: "2.20.0",
  author: "OfflineQuiz",
  description: "The words that come up most for an answer, and the answers that come up most for a word.",
  onEnable: __qbMain,
  onDisable: function () {},
});
