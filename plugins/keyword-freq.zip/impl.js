// ── Shared kit ─────────────────────────────────────────────────────────────
// The same helpers ship in Keyword Frequency, Buzzwords and Fact Sheet (each
// plugin runs in its own scope): question text without notes, the filter row
// (the app's category picker, difficulty toggles, Years and Clues popovers),
// star / save buttons, a pager and the Database "saved" tab.
function __qbKit(ctx) {
  var K = {};
  function esc(s) { return (s == null ? "" : String(s)).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
  K.esc = esc;
  var ICONS = {
    search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>',
    down: '<path d="M6 9l6 6 6-6"/>',
    left: '<path d="M15 6l-6 6 6 6"/>',
    right: '<path d="M9 6l6 6-6 6"/>',
  };
  K.ic = function (n, s) {
    s = s || 16;
    return '<svg width="' + s + '" height="' + s + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (ICONS[n] || "") + "</svg>";
  };
  K.loadBar = function (label) { return (window.QB && QB.loadingBarHtml) ? QB.loadingBarHtml(label) : '<div class="db-empty">' + esc(label) + "</div>"; };
  K.loadBarDet = function (label, frac) {
    var pct = Math.max(0, Math.min(100, Math.round((frac || 0) * 100)));
    return '<div class="qb-loading"><div class="qb-loadbar det"><div class="qb-loadbar-fill" style="width:' + pct + '%"></div></div><span>' + esc(label) + "</span></div>";
  };
  K.empty = function (text) { return '<div class="db-empty">' + esc(text) + "</div>"; };
  K.num = function (n) { return Number(n || 0).toLocaleString(); };
  K.pct = function (x) { return Math.round(100 * (x || 0)) + "%"; };

  // ── question text ──────────────────────────────────────────────────────
  // Words come from what a question SAYS to players: the host's reading text
  // (ctx.host.questionText) when the base has it, else the plain copy.
  // Moderator / reader notes and pronunciation guides are removed whatever the
  // reading settings say: they are never clue words.
  var NOTE_LBL = /(?:note to (?:the )?(?:moderators?|readers?)\b|reader(?:'s)? note\b|moderator(?:'s)? note\b)/i;
  var NOTE_LBL_G = /(?:note to (?:the )?(?:moderators?|readers?)\b|reader(?:'s)? note\b|moderator(?:'s)? note\b)\s*(?:#\s*\d+\s*)?(?:,[^:]{0,40})?:\s*/gi;
  var NOTE_RUN = /^\s*[\[(<*]*\s*(?:note to (?:the )?(?:moderators?|readers?)\b|reader(?:'s)? note\b|moderator(?:'s)? note\b)/i;
  var ENT = { amp: "&", lt: "<", gt: ">", quot: '"', apos: "'", nbsp: " " };
  function decodeEnt(s) {
    return String(s || "").replace(/&(#x[0-9a-f]+|#\d+|[a-z]+);/gi, function (m, e) {
      if (e[0] === "#") { try { return String.fromCodePoint(e[1] === "x" || e[1] === "X" ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10)); } catch (x) { return m; } }
      var v = ENT[e.toLowerCase()]; return v == null ? m : v;
    });
  }
  K.decodeEnt = decodeEnt;
  // A note is the italic run of the HTML field that STARTS with its label.
  function noteRuns(html) {
    if (!html || html.indexOf("<") < 0) return [];
    var runs = [], it = 0, last = 0, m, re = /<\/?([a-z]+)[^>]*>/gi;
    function push(t) { if (!t) return; var p = runs[runs.length - 1], ital = it > 0; if (p && p.italic === ital) p.text += t; else runs.push({ text: t, italic: ital }); }
    while ((m = re.exec(html))) {
      push(decodeEnt(html.slice(last, m.index)));
      var tag = m[1].toLowerCase();
      if (tag === "i" || tag === "em") it = Math.max(0, it + (m[0][1] === "/" ? -1 : 1));
      last = re.lastIndex;
    }
    push(decodeEnt(html.slice(last)));
    return runs.filter(function (r) { return r.italic && NOTE_RUN.test(r.text); }).map(function (r) { return r.text.trim(); });
  }
  // The plain copy folds accents, straightens quotes and spells out dashes.
  function foldPlain(s) {
    return String(s || "").normalize("NFD").replace(/[̀-ͯ]/g, "")
      .replace(/[“”]/g, '"').replace(/[‘’]/g, "'").replace(/[–—]/g, "-").replace(/…/g, "...").replace(/ /g, " ");
  }
  function cutSpan(t, i, j) { return t.slice(0, i).replace(/\s+$/, "") + (i > 0 && j < t.length ? " " : "") + t.slice(j).replace(/^\s+/, ""); }
  function stripNotes(t, html) {
    if (!NOTE_LBL.test(t)) return t;
    noteRuns(html).forEach(function (note) {
      var cands = [foldPlain(note), note];
      for (var c = 0; c < cands.length; c++) { var i = t.indexOf(cands[c]); if (i >= 0) { t = cutSpan(t, i, i + cands[c].length); break; } }
    });
    if (!NOTE_LBL.test(t)) return t;
    t = t.replace(/\s*[\[(]\s*(?:notes?\s+to\s+(?:the\s+)?(?:moderators?|readers?)|(?:moderators?|readers?)(?:'s)?\s+notes?)\b[^\])]*[\])]/gi, " ");
    // An unformatted "Label: …" has no marked end: cut through its first
    // sentence, or to where the question visibly restarts (a lowercase word,
    // then a capitalised one, outside quotes).
    var m, guard = 0;
    NOTE_LBL_G.lastIndex = 0;
    while ((m = NOTE_LBL_G.exec(t)) && guard++ < 6) {
      var s = m.index, from = s + m[0].length, rest = t.slice(from, from + 300), b = -1;
      var w = rest.match(/^\S+\s+/), re = /[.!?]+["'”’)]*\s+|[a-z0-9"'”’)]\s+(?=[A-Z](?:[a-z'’]|\s))/g, mm;
      re.lastIndex = w ? w[0].length : 0;
      while ((mm = re.exec(rest))) {
        var stop = /^[.!?]/.test(mm[0]);
        if (!stop && ((rest.slice(0, mm.index + 1).match(/"/g) || []).length % 2)) continue;
        b = stop ? mm.index + mm[0].length : mm.index + 1; break;
      }
      while (s > 0 && /[\s*<\[(]/.test(t[s - 1])) s--;
      t = cutSpan(t, s, b >= 0 ? from + b : from);
      NOTE_LBL_G.lastIndex = s;
    }
    return t;
  }
  function stripGuides(t) {
    if (ctx.host && typeof ctx.host.stripPronunciations === "function") { try { t = ctx.host.stripPronunciations(t); } catch (e) {} }
    return String(t || "").replace(/\s*\(\s*["“][^"”()]*["”]\s*\)/g, "");
  }
  var _qtCache = typeof WeakMap === "function" ? new WeakMap() : null;
  K.qText = function (q) {
    if (!q) return "";
    if (_qtCache && _qtCache.has(q)) return _qtCache.get(q);
    var t = null;
    if (ctx.host && typeof ctx.host.questionText === "function") { try { t = ctx.host.questionText(q, "question"); } catch (e) { t = null; } }
    if (typeof t !== "string") t = q.question_sanitized || "";
    t = stripGuides(stripNotes(decodeEnt(t), q.question)).replace(/\s{2,}/g, " ").trim();
    if (_qtCache) _qtCache.set(q, t);
    return t;
  };
  // The answer line's main answer: what comes before any [accept …] / (…).
  K.mainAnswer = function (sani) { return decodeEnt(sani).split(/[\[(<]/)[0].trim().replace(/[;:,.]+$/, ""); };
  // Lowercase word tokens; internal apostrophes kept, a possessive 's dropped.
  K.tokens = function (text) {
    return (String(text || "").toLowerCase().match(/[\p{L}\p{N}'’]+/gu) || []).map(function (w) { return w.replace(/['’]s$/, ""); }).filter(Boolean);
  };
  // FTS: every token quoted (they are ANDed).
  K.ftsAll = function (col, toks) { return col + " : (" + toks.map(function (t) { return '"' + t.replace(/"/g, "") + '"'; }).join(" ") + ")"; };
  // The words of a question inside the chosen clue range (percent of the
  // question, or only what comes before the power mark).
  K.sliceWords = function (q, v) {
    var text = K.qText(q);
    if (v.power) {
      var pi = text.indexOf("(*)");
      return pi < 0 ? [] : K.tokens(text.slice(0, pi));
    }
    var words = K.tokens(text.replace(/\(\*\)/g, " "));
    var n = words.length; if (!n) return [];
    if (v.lo <= 0 && v.hi >= 100) return words;
    var a = Math.round((v.lo / 100) * n), b = Math.round((v.hi / 100) * n);
    return words.slice(a, Math.max(a + 1, b));
  };
  // Is seq a contiguous run inside arr?
  K.hasSeq = function (arr, seq) {
    if (!seq.length || seq.length > arr.length) return false;
    if (seq.length === 1) return arr.indexOf(seq[0]) >= 0;
    for (var i = 0; i + seq.length <= arr.length; i++) {
      var ok = true;
      for (var j = 0; j < seq.length; j++) if (arr[i + j] !== seq[j]) { ok = false; break; }
      if (ok) return true;
    }
    return false;
  };
  // Spelling / transliteration variants (Baldr / Balder / Baldur): one edit.
  K.lev1 = function (a, b) {
    if (a === b) return true;
    var la = a.length, lb = b.length;
    if (Math.abs(la - lb) > 1 || Math.min(la, lb) < 4) return false;
    var i = 0, j = 0, edits = 0;
    while (i < la && j < lb) {
      if (a[i] === b[j]) { i++; j++; continue; }
      if (++edits > 1) return false;
      if (la === lb) { i++; j++; } else if (la > lb) { i++; } else { j++; }
    }
    return edits + (la - i) + (lb - j) <= 1;
  };

  // ── saved view (filters survive leaving the page) ──────────────────────
  K.load = function (defaults) {
    var v = null;
    try { v = ctx.storage.get("view"); } catch (e) { v = null; }
    var out = {};
    for (var k in defaults) out[k] = defaults[k];
    if (v && typeof v === "object") for (var k2 in defaults) if (v[k2] !== undefined && v[k2] !== null) out[k2] = v[k2];
    if (!Array.isArray(out.cats)) out.cats = [];
    if (!Array.isArray(out.diffs)) out.diffs = [];
    out.lo = Math.max(0, Math.min(100, parseInt(out.lo, 10) || 0));
    out.hi = Math.max(0, Math.min(100, parseInt(out.hi, 10))); if (isNaN(out.hi)) out.hi = 100;
    if (out.lo > out.hi) { var t = out.lo; out.lo = out.hi; out.hi = t; }
    return out;
  };
  K.save = function (v) { try { ctx.storage.set("view", v); } catch (e) {} };

  // ── filter row ─────────────────────────────────────────────────────────
  var DIFF_NAMES = ["Unrated", "Middle school", "Easy high school", "Regular high school", "Hard high school", "National high school", "Easy college", "Medium college", "Regionals college", "Nationals college", "Open"];
  var Y0 = 2000, Y1 = 2026;
  K.yearsLabel = function (v) { return (!v.y0 && !v.y1) ? "Any" : (v.y0 || Y0) + "–" + (v.y1 || Y1); };
  K.cluesLabel = function (v) { return v.power ? "Before power" : (v.lo <= 0 && v.hi >= 100) ? "All" : v.lo + "–" + v.hi + "%"; };
  K.filterQs = function (v, catH) {
    var ids = [];
    if (catH) { try { ids = (catH.get() || []).filter(Boolean); } catch (e) { ids = []; } }
    else ids = (v.cats || []).filter(Boolean);
    return (ids.length ? "&categoryIds=" + encodeURIComponent(ids.join(",")) : "") +
      ((v.diffs || []).length ? "&difficulties=" + v.diffs.join(",") : "") +
      (v.y0 ? "&yearMin=" + v.y0 : "") + (v.y1 ? "&yearMax=" + v.y1 : "");
  };
  K.filterRowHtml = function (v, extra) {
    var diffs = "";
    for (var d = 0; d <= 10; d++) diffs += '<label title="' + esc(DIFF_NAMES[d]) + '"><input type="checkbox" value="' + d + '"' + ((v.diffs || []).indexOf(d) >= 0 ? " checked" : "") + "><span>" + d + "</span></label>";
    return '<div class="qrow kfq-filters">' +
      '<span class="kfq-cat-slot"></span>' +
      '<div class="diff-toggles kfq-diffs" role="group" aria-label="Difficulty"><span class="dt-lbl">Difficulty</span>' + diffs + "</div>" +
      '<div class="pop-wrap kfq-popw"><button type="button" class="btn kfq-pop-btn" data-pop="years" aria-expanded="false" aria-haspopup="dialog">Years <span class="accent-val num kfq-years-val">' + esc(K.yearsLabel(v)) + "</span>" + K.ic("down", 14) + "</button>" +
        '<div class="pop left years-pop kfq-pop" data-pop-for="years" role="dialog" aria-label="Years" hidden><form class="kfq-years-form">' +
          '<div class="yrow"><label class="ifield"><span>From</span><input class="kfq-y0" inputmode="numeric" autocomplete="off" value="' + (v.y0 || Y0) + '" aria-label="From year"></label>' +
          '<label class="ifield"><span>To</span><input class="kfq-y1" inputmode="numeric" autocomplete="off" value="' + (v.y1 || Y1) + '" aria-label="To year"></label></div>' +
          '<div class="yrow"><button type="button" class="btn btn-sm kfq-y-any" style="flex:1">Any year</button><button type="submit" class="btn btn-sm btn-primary" style="flex:1">Apply</button></div>' +
        "</form></div></div>" +
      '<div class="pop-wrap kfq-popw"><button type="button" class="btn kfq-pop-btn" data-pop="clues" aria-expanded="false" aria-haspopup="dialog">Clues <span class="accent-val kfq-clues-val">' + esc(K.cluesLabel(v)) + "</span>" + K.ic("down", 14) + "</button>" +
        '<div class="pop left kfq-pop kfq-clue-pop" data-pop-for="clues" role="dialog" aria-label="Clues" hidden>' +
          '<div class="kfq-clue-head"><span>Part of the question</span><b class="num kfq-range-val"></b></div>' +
          '<div class="dual-range kfq-dual"><div class="dual-range-track"><div class="dual-range-fill kfq-fill"></div></div>' +
            '<input type="range" class="kfq-lo" min="0" max="100" step="5" value="' + v.lo + '" aria-label="From">' +
            '<input type="range" class="kfq-hi" min="0" max="100" step="5" value="' + v.hi + '" aria-label="To"></div>' +
          '<label class="checkbox-row kfq-power-row"><input type="checkbox" class="kfq-power"' + (v.power ? " checked" : "") + "><span>Before power only</span></label>" +
        "</div></div>" +
      (extra || "") +
    "</div>";
  };

  // Popovers: the button toggles; a click elsewhere or Esc closes (the app
  // does both for every .pop — this keeps older bases working too).
  function closePops(except) {
    document.querySelectorAll(".kfq-pop:not([hidden])").forEach(function (p) {
      if (except && p === except) return;
      p.hidden = true;
      var b = p.parentNode && p.parentNode.querySelector(".kfq-pop-btn"); if (b) b.setAttribute("aria-expanded", "false");
    });
  }
  K.closePops = closePops;
  function onDocDown(e) { if (!e.target.closest || !e.target.closest(".kfq-pop, .kfq-pop-btn")) closePops(); }
  document.addEventListener("mousedown", onDocDown, true);
  ctx._unsub.push(function () { document.removeEventListener("mousedown", onDocDown, true); });
  function openPop(btn, pop) {
    var open = pop.hidden;
    closePops(open ? pop : null);
    pop.hidden = !open;
    btn.setAttribute("aria-expanded", String(open));
    if (!open) return;
    // keep it on screen (a button near the right edge on a phone)
    pop.style.left = ""; pop.style.right = "";
    // the right edge of what's visible: the viewport, or a scrolling parent
    // (its scrollbar takes width from the viewport)
    var edge = document.documentElement.clientWidth || window.innerWidth;
    for (var a = pop.parentElement; a && a !== document.body; a = a.parentElement) {
      var ox = getComputedStyle(a).overflowX;
      if (ox === "auto" || ox === "scroll" || ox === "hidden" || ox === "clip") { edge = Math.min(edge, a.getBoundingClientRect().left + a.clientWidth); break; }
    }
    var r = pop.getBoundingClientRect();
    if (r.right > edge - 8) pop.style.left = Math.min(0, edge - 8 - r.right) + "px";
    var f = pop.querySelector("input"); if (f && pop.dataset.popFor === "years") setTimeout(function () { try { f.focus(); f.select(); } catch (e) {} }, 30);
  }

  // Wires the row. onChange(kind) runs after any filter changes (v is saved).
  // Returns { cat } — the category picker handle (null on a base without one).
  K.wireFilterRow = function (root, v, onChange) {
    var row = root.querySelector(".kfq-filters");
    var fire = function (kind) { K.save(v); try { onChange(kind); } catch (e) { console.error(e); } };
    var cat = null, slot = row.querySelector(".kfq-cat-slot");
    if (ctx.host && typeof ctx.host.categoryPicker === "function") {
      try {
        cat = ctx.host.categoryPicker(null, { type: "tossups", selected: (v.cats || []).slice(), label: "Categories",
          onChange: function (ids) { v.cats = (ids || []).slice(); fire("cats"); } });
        if (cat && cat.el) slot.replaceWith(cat.el); else cat = null;
      } catch (e) { cat = null; }
    }
    if (!cat && slot) slot.remove();
    row.querySelectorAll(".kfq-diffs input").forEach(function (cb) {
      cb.addEventListener("change", function () {
        v.diffs = [].slice.call(row.querySelectorAll(".kfq-diffs input:checked")).map(function (c) { return parseInt(c.value, 10); });
        fire("diffs");
      });
    });
    row.querySelectorAll(".kfq-pop-btn").forEach(function (b) {
      b.addEventListener("click", function (e) { e.preventDefault(); openPop(b, b.parentNode.querySelector(".kfq-pop")); });
    });
    row.querySelectorAll(".kfq-pop").forEach(function (p) {
      p.addEventListener("keydown", function (e) {
        if (e.key === "Escape" && !p.hidden) { e.preventDefault(); e.stopPropagation(); closePops(); var b = p.parentNode.querySelector(".kfq-pop-btn"); if (b) b.focus(); }
      });
    });
    // Years
    var yv = row.querySelector(".kfq-years-val"), f = row.querySelector(".kfq-years-form");
    function setYears(a, b) {
      a = parseInt(a, 10); b = parseInt(b, 10);
      if (isNaN(a) || a < 1900 || a > 2100) a = Y0;
      if (isNaN(b) || b < 1900 || b > 2100) b = Y1;
      if (a > b) { var t = a; a = b; b = t; }
      var y0 = a > Y0 ? a : null, y1 = b < Y1 ? b : null;
      var changed = y0 !== (v.y0 || null) || y1 !== (v.y1 || null);
      v.y0 = y0; v.y1 = y1;
      yv.textContent = K.yearsLabel(v);
      f.querySelector(".kfq-y0").value = v.y0 || Y0; f.querySelector(".kfq-y1").value = v.y1 || Y1;
      closePops();
      if (changed) fire("years");
    }
    f.addEventListener("submit", function (e) { e.preventDefault(); setYears(f.querySelector(".kfq-y0").value, f.querySelector(".kfq-y1").value); });
    f.querySelector(".kfq-y-any").addEventListener("click", function () { setYears(Y0, Y1); });
    // Clues: a percent range of the question, or before the power mark
    var lo = row.querySelector(".kfq-lo"), hi = row.querySelector(".kfq-hi"), fill = row.querySelector(".kfq-fill");
    var rv = row.querySelector(".kfq-range-val"), cv = row.querySelector(".kfq-clues-val"), pw = row.querySelector(".kfq-power");
    function paintRange() {
      var a = parseInt(lo.value, 10), b = parseInt(hi.value, 10), mn = Math.min(a, b), mx = Math.max(a, b);
      v.lo = mn; v.hi = mx;
      fill.style.left = mn + "%"; fill.style.right = (100 - mx) + "%";
      rv.textContent = mn + "–" + mx + "%";
      lo.disabled = hi.disabled = !!v.power;
      row.querySelector(".kfq-dual").classList.toggle("off", !!v.power);
      cv.textContent = K.cluesLabel(v);
    }
    var rangeAt = null;
    lo.addEventListener("input", paintRange); hi.addEventListener("input", paintRange);
    var rangeDone = function () { var s = v.lo + "-" + v.hi; if (s !== rangeAt) { rangeAt = s; fire("clues"); } };
    lo.addEventListener("change", rangeDone); hi.addEventListener("change", rangeDone);
    pw.addEventListener("change", function () { v.power = pw.checked; paintRange(); fire("clues"); });
    paintRange(); rangeAt = v.lo + "-" + v.hi;
    return { cat: cat };
  };

  // ── star / save ────────────────────────────────────────────────────────
  K.canSave = function () { return !!((ctx.host && ctx.host.openItemSaveMenu) || window.QBFolders); };
  K.starBtn = function (on, attrs) {
    return '<button type="button" class="star-btn kfq-star' + (on ? " on" : "") + '" aria-label="' + (on ? "Unstar" : "Star") + '" aria-pressed="' + !!on + '"' + (attrs || "") + ">" + (on ? "★" : "☆") + "</button>";
  };
  K.setStar = function (btn, on) {
    if (!btn) return;
    btn.classList.toggle("on", !!on); btn.textContent = on ? "★" : "☆";
    btn.setAttribute("aria-pressed", String(!!on)); btn.setAttribute("aria-label", on ? "Unstar" : "Star");
  };
  K.saveBtn = function (attrs) { return K.canSave() ? '<button type="button" class="star-btn save-plus kfq-save" aria-label="Save to review or a folder"' + (attrs || "") + ">+</button>" : ""; };
  K.openSave = function (spec, anchor) {
    if (ctx.host && ctx.host.openItemSaveMenu) ctx.host.openItemSaveMenu(spec, anchor);
    else if (window.QBFolders) window.QBFolders.pick(spec.folder.type, spec.folder.item, anchor);
  };

  // ── pager ──────────────────────────────────────────────────────────────
  K.pagerHtml = function (page, pages) {
    if (pages <= 1) return "";
    return '<nav class="kfq-pager" aria-label="Pages">' +
      '<button type="button" class="btn btn-icon" data-pg="' + (page - 1) + '" aria-label="Previous page"' + (page <= 0 ? " disabled" : "") + ">" + K.ic("left", 16) + "</button>" +
      '<span class="kfq-pagenum">Page <b class="num">' + (page + 1) + '</b> of <span class="num">' + pages + "</span></span>" +
      '<button type="button" class="btn btn-icon" data-pg="' + (page + 1) + '" aria-label="Next page"' + (page >= pages - 1 ? " disabled" : "") + ">" + K.ic("right", 16) + "</button></nav>";
  };
  K.wirePager = function (root, go) {
    root.querySelectorAll(".kfq-pager [data-pg]").forEach(function (b) {
      b.addEventListener("click", function () { if (!b.disabled) go(parseInt(b.dataset.pg, 10), !!b.closest(".kfq-foot")); });
    });
  };

  // ── other plugins / pages ─────────────────────────────────────────────
  K.pageActive = function (id) {
    try { return !!(window.QB && QB.getActivePages && (QB.getActivePages() || []).some(function (p) { return p.id === id || p.id.indexOf(id + "::") === 0; })); } catch (e) { return false; }
  };
  K.hasFlashcards = function () { return K.pageActive("flashcards::cards"); };
  K.reviewAsFlashcards = function (cards) {
    if (!cards.length) return false;
    try { localStorage.setItem("qb-flashcards-cards", JSON.stringify({ cards: cards, ts: Date.now() })); } catch (e) {}
    var ok = !!(window.QB && QB.showPage && QB.showPage("flashcards::cards"));
    if (!ok) { try { localStorage.removeItem("qb-flashcards-cards"); } catch (e) {} }
    return ok;
  };
  K.searchDb = function (opts) { if (ctx.host && ctx.host.searchDatabase) ctx.host.searchDatabase(opts); };

  // ── Database → <plugin> tab: the saved pairs ───────────────────────────
  // o: { title, empty, key, list(), save(list), front(it), back(it), card(it), saveSpec(it) }
  K.savedTab = function (o) {
    var host = null;
    function paint() {
      if (!host || !host.isConnected) return;
      var list = o.list();
      if (!list.length) { host.innerHTML = K.empty(o.empty); return; }
      var fc = K.hasFlashcards();
      host.innerHTML =
        '<div class="db-toolbar kfq-saved-bar"><span class="kfq-saved-n">' + K.num(list.length) + " saved</span><span class=\"spacer\"></span>" +
          (fc ? '<button type="button" class="btn btn-sm btn-primary kfq-review">Review as flashcards</button>' : "") + "</div>" +
        '<div class="list kfq-saved">' + list.map(function (it, i) {
          return '<div class="list-row kfq-saved-row" data-i="' + i + '"><span class="kfq-front">' + esc(o.front(it)) + '</span><span class="kfq-arrow" aria-hidden="true">→</span><span class="kfq-back">' + esc(o.back(it)) + "</span>" +
            '<span class="kfq-acts">' + K.saveBtn(' data-i="' + i + '"') + K.starBtn(true, ' data-i="' + i + '"') + "</span></div>";
        }).join("") + "</div>";
      host.querySelectorAll(".kfq-star").forEach(function (s) {
        s.addEventListener("click", function () {
          // Unstarring greys the row out (star it again to keep it); it leaves on the next visit.
          var it = list[parseInt(s.dataset.i, 10)]; if (!it) return;
          var cur = o.list(), k = o.key(it), idx = cur.findIndex(function (x) { return o.key(x) === k; });
          var on = idx < 0;
          if (on) cur.push(it); else cur.splice(idx, 1);
          o.save(cur);
          K.setStar(s, on);
          var row = s.closest(".kfq-saved-row"); if (row) row.classList.toggle("off", !on);
          if (ctx.playSound) ctx.playSound("star");
        });
      });
      host.querySelectorAll(".kfq-save").forEach(function (b) {
        b.addEventListener("click", function () { var it = list[parseInt(b.dataset.i, 10)]; if (it) K.openSave(o.saveSpec(it), b); });
      });
      var rv = host.querySelector(".kfq-review");
      if (rv) rv.addEventListener("click", function () { K.reviewAsFlashcards(o.list().map(o.card)); });
    }
    ctx.on("plugins:changed", function () { paint(); });
    ctx.registerStarredProvider({ id: o.id, title: o.title, render: function (container) { host = container; paint(); } });
  };
  return K;
}

// ── Keyword Frequency ──────────────────────────────────────────────────────
// Answer → words: the words and phrases an answer's questions use most, with
// how often each one points back to that answer.
// Word → answers: the answers whose questions use a word (or several words,
// comma-separated, all required) most often.
// Filters: categories, difficulty, years, and which part of each question is
// read (a percent range, or only before the power mark).
function __qbMain(ctx) {
  var K = __qbKit(ctx), esc = K.esc;
  var STOP = {};
  ("a an the this that these those it its his her hers he she they them their theirs we us our you your i me my mine of in on at to for from with within without by as is are was were be been being am do does did done not no nor so or and but if then than because while during after before until once when where which who whom whose what why how all any both each few more most other some such only own same here there over under again further about above below between into through against up down out off very can will just should now points point name names named ftp identify gives give given made make makes making one two three four five six seven eight nine ten first second third often called also another may might must shall many much work works worked title titled known includes including include described describes describe used uses use using like unlike along man woman men women person people city country state nation work novel poem play opera symphony war battle king queen god goddess author authors poet poets composer composers writer writers artist artists painter sculptor novelist playwright philosopher thinker scientist character characters figure entity thing things wrote written writes have has had having").split(/\s+/).forEach(function (w) { STOP[w] = 1; });

  var hadView = !!ctx.storage.get("view");
  var v = K.load({ mode: "answers", cats: [], diffs: [], y0: null, y1: null, lo: 0, hi: 100, power: false });
  if (!hadView) {
    // settings from 2.17 and earlier: the percent range and "before power"
    var r0 = ctx.storage.get("range");
    if (r0 && typeof r0 === "object") { var a0 = parseInt(r0.lo, 10) || 0, b0 = parseInt(r0.hi, 10); if (isNaN(b0)) b0 = 100; v.lo = Math.min(a0, b0); v.hi = Math.max(a0, b0); }
    if (ctx.storage.get("powerOnly")) v.power = true;
    K.save(v);
  }
  if (v.mode !== "words") v.mode = "answers";

  var body = null, page = null, catH = null, cur = null, last = null, seq = 0, stack = [];
  var PAGE = 50;
  function fold(s) { return String(s || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase(); }
  function answerHas(q, toks) {
    var m = fold(K.mainAnswer(q.answer_sanitized));
    for (var i = 0; i < toks.length; i++) if (m.indexOf(fold(toks[i])) < 0) return false;
    return true;
  }
  function el(sel) { return body && body.querySelector(sel); }

  // ── saved word → answer pairs (★), reviewed as flashcards ──
  function stars() { return ctx.storage.get("kf-stars") || []; }
  function starKey(it) { return (it.front || "") + "\u0001" + (it.back || ""); }
  function isStarred(front, back) { var k = starKey({ front: front, back: back }); return stars().some(function (x) { return starKey(x) === k; }); }
  function toggleStar(front, back, btn) {
    var lst = stars(), k = starKey({ front: front, back: back }), i = lst.findIndex(function (x) { return starKey(x) === k; });
    if (i >= 0) lst.splice(i, 1); else lst.push({ front: front, back: back });
    ctx.storage.set("kf-stars", lst);
    K.setStar(btn, i < 0);
    if (ctx.playSound) ctx.playSound("star");
  }
  function saveSpec(front, back) { return { review: { kind: "keyword", front: front, back: back, meta: "keyword" }, folder: { type: "keywords", item: { front: front, back: back } } }; }

  page = ctx.registerPage({
    id: "kwfreq", navLabel: "Keyword Frequency", title: "Keyword Frequency",
    onShow: function (elx) {
      body = elx;
      if (!el("#kw-input")) render();
      // Handoff from the app's right-click ("Top answers for it", "Keywords, treating it as an answer").
      try {
        var h = JSON.parse(localStorage.getItem("qb-kf-handoff") || "null");
        if (h && h.term) {
          localStorage.removeItem("qb-kf-handoff");
          run(h.term, h.mode === "words" ? "words" : "answers");
        }
      } catch (e) {}
    },
  });
  function active() { return page && page.screenEl && page.screenEl.classList.contains("active"); }

  // Esc walks back through searches ("titration" → click "technique" → Esc
  // returns to "titration"); with nothing left the app goes back.
  ctx.onBack(function () {
    if (!active() || !stack.length || !body) return false;
    var s = stack.pop();
    run(s.term, s.mode, { push: false });
    return true;
  });

  function setMode(mode) {
    v.mode = mode === "words" ? "words" : "answers";
    body.querySelectorAll("#kf-mode [data-mode]").forEach(function (b) { b.setAttribute("aria-pressed", String(b.dataset.mode === v.mode)); });
    var inp = el("#kw-input"); if (inp) inp.placeholder = v.mode === "words" ? "Type a word or phrase" : "Type an answer";
  }

  function render() {
    body.innerHTML =
      '<div class="kfq kf">' +
        '<form class="cfield kfq-search" id="kf-form" autocomplete="off">' + K.ic("search", 18) +
          '<input type="search" enterkeyhint="search" id="kw-input" class="cinput" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" aria-label="Search">' +
          '<div class="seg" id="kf-mode" role="group" aria-label="Search by">' +
            '<button type="button" data-mode="answers">Answer → words</button>' +
            '<button type="button" data-mode="words">Word → answers</button>' +
          "</div>" +
          '<button type="submit" class="btn btn-primary" id="kw-go">Search</button>' +
        "</form>" +
        K.filterRowHtml(v) +
        '<div id="kw-results">' + K.empty("No search yet") + "</div>" +
      "</div>";
    setMode(v.mode);
    catH = K.wireFilterRow(body, v, function () { if (last) run(last.term, last.mode, { push: false }); }).cat;
    var form = el("#kf-form"), inp = el("#kw-input");
    form.addEventListener("submit", function (e) { e.preventDefault(); run(inp.value, v.mode); });
    form.addEventListener("mousedown", function (e) { if (e.target === form) { e.preventDefault(); inp.focus(); } });
    el("#kf-mode").addEventListener("click", function (e) {
      var b = e.target.closest("[data-mode]"); if (!b || b.dataset.mode === v.mode) return;
      setMode(b.dataset.mode); K.save(v);
      if (inp.value.trim()) run(inp.value, v.mode);
    });
  }

  function run(term, mode, opts) {
    opts = opts || {};
    if (!body || !el("#kw-input")) return;
    term = String(term || "").trim();
    var out = el("#kw-results");
    setMode(mode);
    el("#kw-input").value = term;
    if (!term) { cur = last = null; out.innerHTML = K.empty("No search yet"); return; }
    last = { term: term, mode: v.mode };
    if (opts.push !== false && cur && (cur.term !== term || cur.mode !== v.mode)) stack.push({ term: cur.term, mode: cur.mode });
    K.save(v);
    var my = ++seq;
    out.innerHTML = K.loadBar("Searching…");
    var done = function (c) { if (my !== seq) return; cur = c; paint(0); };
    var fail = function (msg) { if (my !== seq) return; cur = null; out.innerHTML = K.empty(msg); };
    if (v.mode === "words") searchWords(term, done, fail); else searchAnswer(term, done, fail);
  }

  // ── Answer → words ─────────────────────────────────────────────────────
  // Unigrams + bigrams + trigrams. A multi-word phrase can't start or end on a
  // stop word ('stationary phase' counts, 'of the' doesn't); words of the
  // answer line itself are skipped.
  function gramsOf(words, skip) {
    var out = [];
    for (var i = 0; i < words.length; i++) {
      var w = words[i];
      if (w.length >= 3 && !STOP[w] && !skip[w] && !/^\d+$/.test(w)) out.push(w);
      for (var L = 2; L <= 3; L++) {
        if (i + L > words.length) break;
        var g = words.slice(i, i + L);
        if (STOP[g[0]] || STOP[g[L - 1]]) continue;
        if (g.some(function (x) { return skip[x] || /^\d+$/.test(x) || x.length < 2; })) continue;
        out.push(g.join(" "));
      }
    }
    return out;
  }
  // A shorter gram that sits inside a longer one found in >= 80% of its
  // questions is redundant ("carothers" when "carothers equation" says it).
  function collapse(items) {
    var idx = Object.create(null), drop = Object.create(null);
    items.forEach(function (it) { idx[it.w] = it; });
    items.forEach(function (it) {
      var t = it.w.split(" "); if (t.length < 2) return;
      for (var L = 1; L < t.length; L++) for (var s = 0; s + L <= t.length; s++) {
        var sub = t.slice(s, s + L).join(" "), si = idx[sub];
        if (si && it.docs >= 0.8 * si.docs) drop[sub] = 1;
      }
    });
    return items.filter(function (it) { return !drop[it.w]; });
  }
  // How the answer is usually written, when one spelling covers most of its
  // questions ("plath" → "Sylvia Plath"); else what was typed.
  function answerName(rows, term) {
    var c = Object.create(null), best = "", bn = 0;
    rows.forEach(function (q) { var m = K.mainAnswer(q.answer_sanitized); if (!m) return; c[m] = (c[m] || 0) + 1; if (c[m] > bn) { bn = c[m]; best = m; } });
    return best && bn * 2 >= rows.length ? best : term;
  }
  function searchAnswer(term, done, fail) {
    var toks = K.tokens(term);
    if (!toks.length) return fail("No matches");
    var filters = K.filterQs(v, catH);
    ctx.api.get("/api/tossups/search?query=" + encodeURIComponent(K.ftsAll("answer_sanitized", toks)) + "&limit=500" + filters).then(function (d) {
      var rows = ((d && d.rows) || []).filter(function (q) { return answerHas(q, toks); });
      if (!rows.length) return fail("No questions found");
      var totals = Object.create(null), docs = Object.create(null);
      rows.forEach(function (q) {
        var skip = Object.create(null);
        toks.forEach(function (t) { skip[t] = 1; });
        K.tokens(q.answer_sanitized).forEach(function (w) { skip[w] = 1; });
        var seen = Object.create(null);
        gramsOf(K.sliceWords(q, v), skip).forEach(function (g) {
          totals[g] = (totals[g] || 0) + 1;
          if (!seen[g]) { seen[g] = 1; docs[g] = (docs[g] || 0) + 1; }
        });
      });
      // a phrase must recur (2+ questions) to earn a row
      var list = Object.keys(docs).map(function (g) { return { w: g, docs: docs[g], total: totals[g] }; })
        .filter(function (e) { return e.w.indexOf(" ") < 0 || e.docs >= 2; });
      list.sort(function (a, b) { return b.docs - a.docs || b.total - a.total; });
      list = collapse(list.slice(0, 1500)).slice(0, 500);
      if (!list.length) return fail("No words in that part of the questions");
      done({ mode: "answers", term: term, toks: toks, name: answerName(rows, term), total: rows.length, list: list, filters: filters, clue: v.power ? "P" : v.lo + "-" + v.hi });
    }).catch(function () { fail("Search failed"); });
  }
  // Of every question using the word (in the chosen part), how many answer
  // the searched answer — fetched for the rows on screen only, cached.
  var probCache = Object.create(null), probGen = 0;
  function wordProb(w, c, cb) {
    var key = w + "|" + c.toks.join(" ") + "|" + c.filters + "|" + c.clue;
    if (probCache[key]) return cb(probCache[key]);
    var seqw = w.split(" ");
    ctx.api.get("/api/tossups/search?query=" + encodeURIComponent(K.ftsAll("question_sanitized", seqw)) + "&limit=400" + c.filters).then(function (d) {
      var total = 0, hit = 0;
      ((d && d.rows) || []).forEach(function (q) {
        if (!K.hasSeq(K.sliceWords(q, v), seqw)) return;
        total++;
        if (answerHas(q, c.toks)) hit++;
      });
      var r = { p: total ? hit / total : 0, hit: hit, total: total };
      probCache[key] = r; cb(r);
    }).catch(function () { cb(null); });
  }
  function fillProbs(out, c) {
    var gen = ++probGen, cells = [].slice.call(out.querySelectorAll(".kfq-p[data-w]")), idx = 0, busy = 0;
    function next() {
      if (gen !== probGen) return;
      while (busy < 4 && idx < cells.length) {
        (function (cell) {
          busy++;
          wordProb(cell.dataset.w, c, function (r) {
            busy--;
            if (gen === probGen && cell.isConnected) {
              cell.innerHTML = r && r.total ? K.pct(r.p) + "<small>" + r.hit + "/" + r.total + "</small>" : "–";
              cell.classList.toggle("hi", !!(r && r.total && r.p >= 0.8));
            }
            next();
          });
        })(cells[idx++]);
      }
    }
    next();
  }

  // ── Word → answers ─────────────────────────────────────────────────────
  // Comma-separated words are separate hints that must ALL appear (each one
  // as a phrase) inside the chosen part of the question.
  function searchWords(term, done, fail) {
    var hints = term.split(",").map(function (h) { return K.tokens(h); }).filter(function (s) { return s.length; });
    var toks = [];
    hints.forEach(function (s) { s.forEach(function (t) { toks.push(t); }); });
    if (!toks.length) return fail("No matches");
    var filters = K.filterQs(v, catH);
    ctx.api.get("/api/tossups/search?query=" + encodeURIComponent(K.ftsAll("question_sanitized", toks)) + "&limit=1000" + filters).then(function (d) {
      var counts = Object.create(null), disp = Object.create(null), total = 0;
      ((d && d.rows) || []).forEach(function (q) {
        var sl = K.sliceWords(q, v);
        for (var i = 0; i < hints.length; i++) if (!K.hasSeq(sl, hints[i])) return;
        var m = K.mainAnswer(q.answer_sanitized); if (!m) return;
        var k = m.toLowerCase();
        total++; counts[k] = (counts[k] || 0) + 1; if (!disp[k]) disp[k] = m;
      });
      if (!total) return fail("No matches");
      var list = Object.keys(counts).map(function (k) { return { key: k, a: disp[k], n: counts[k] }; }).sort(function (a, b) { return b.n - a.n; });
      // merge spelling variants so the share isn't split (Baldr / Balder)
      var reps = [];
      list.forEach(function (e) { for (var i = 0; i < reps.length; i++) if (K.lev1(reps[i].key, e.key)) { reps[i].n += e.n; return; } reps.push(e); });
      reps.sort(function (a, b) { return b.n - a.n; });
      done({ mode: "words", term: term, hint: hints.map(function (s) { return s.join(" "); }).join(" + "), total: total, list: reps.slice(0, 500) });
    }).catch(function () { fail("Search failed"); });
  }

  // ── results ────────────────────────────────────────────────────────────
  function paint(pg) {
    var out = el("#kw-results"), c = cur; if (!out || !c) return;
    var pages = Math.max(1, Math.ceil(c.list.length / PAGE));
    c.page = Math.max(0, Math.min(pages - 1, pg || 0));
    var start = c.page * PAGE, slice = c.list.slice(start, start + PAGE);
    var ans = c.mode === "answers";
    var head = '<div class="rhead"><span class="total num">' + K.num(c.total) + (c.total === 1 ? " question" : " questions") + "</span>" +
      '<span class="kfq-sub">' + (ans ? "about " + esc(c.name) : "with “" + esc(c.hint) + "”") + "</span>" +
      '<span class="spacer"></span>' + K.pagerHtml(c.page, pages) + "</div>";
    var rows = slice.map(function (e, j) {
      var i = start + j;
      if (ans) {
        return '<div class="list-row" data-i="' + i + '"><span class="lr-rank num">' + (i + 1) + "</span>" +
          '<span class="kfq-cell"><span class="kfq-term kw-word kfq-link" data-w="' + esc(e.w) + '">' + esc(e.w) + "</span><small>" + K.num(e.docs) + (e.docs === 1 ? " question" : " questions") + "</small></span>" +
          '<span class="freq-bar"><span style="width:' + Math.max(1, Math.round(100 * e.docs / c.list[0].docs)) + '%"></span></span>' +
          '<span class="kfq-n opt num">' + K.num(e.docs) + "</span>" +
          '<span class="kfq-p num" data-w="' + esc(e.w) + '">…</span>' +
          '<span class="kfq-acts">' + K.saveBtn() + K.starBtn(isStarred(e.w, c.name)) + "</span></div>";
      }
      var p = c.total ? e.n / c.total : 0;
      return '<div class="list-row" data-i="' + i + '"><span class="lr-rank num">' + (i + 1) + "</span>" +
        '<span class="kfq-cell"><span class="kfq-term kw-word kfq-link" data-w="' + esc(e.a) + '">' + esc(e.a) + "</span><small>" + K.num(e.n) + (e.n === 1 ? " question" : " questions") + "</small></span>" +
        '<span class="freq-bar"><span style="width:' + Math.max(1, Math.round(100 * e.n / c.list[0].n)) + '%"></span></span>' +
        '<span class="kfq-n opt num">' + K.num(e.n) + "</span>" +
        '<span class="kfq-p num' + (p >= 0.8 && c.total >= 3 ? " hi" : "") + '">' + K.pct(p) + "</span>" +
        '<span class="kfq-acts">' + K.saveBtn() + K.starBtn(isStarred(c.hint, e.a)) + "</span></div>";
    }).join("");
    out.innerHTML = head +
      '<div class="list kf-list">' +
        '<div class="list-row kfq-head" aria-hidden="true"><span class="lr-rank">#</span><span class="kfq-cell">' + (ans ? "Word or phrase" : "Answer") + '</span><span class="kfq-barcol"></span>' +
          '<span class="kfq-n opt">Questions</span><span class="kfq-p">' + (ans ? "Points to it" : "Share") + '</span><span class="kfq-acts"></span></div>' +
        rows +
      "</div>" +
      (pages > 1 ? '<div class="kfq-foot">' + K.pagerHtml(c.page, pages) + "</div>" : "");
    K.wirePager(out, function (p, fromFoot) { paint(p); if (fromFoot) { var h = out.querySelector(".rhead"); if (h && h.scrollIntoView) h.scrollIntoView({ block: "start" }); } });
    out.querySelectorAll(".list-row[data-i]").forEach(function (row) {
      var e = c.list[parseInt(row.dataset.i, 10)]; if (!e) return;
      var front = ans ? e.w : c.hint, back = ans ? c.name : e.a;
      row.querySelector(".kfq-link").addEventListener("click", function () { if (ans) run(e.w, "words"); else run(e.a, "answers"); });
      var st = row.querySelector(".kfq-star"), sv = row.querySelector(".kfq-save");
      st.addEventListener("click", function (ev) { ev.stopPropagation(); toggleStar(front, back, st); });
      if (sv) sv.addEventListener("click", function (ev) { ev.stopPropagation(); K.openSave(saveSpec(front, back), sv); });
      row.addEventListener("contextmenu", function (ev) {
        if (!window.QB || !QB.contextMenu) return;
        ev.preventDefault();
        var items = [];
        if (ans) {
          items.push({ label: "Answers for “" + e.w + "”", onClick: function () { run(e.w, "words"); } });
          items.push({ label: "Find questions with it", onClick: function () { K.searchDb({ query: e.w, field: "question", exact: true, qtype: "tossup" }); } });
        } else {
          items.push({ label: "Words for “" + e.a + "”", onClick: function () { run(e.a, "answers"); } });
          items.push({ label: "Find questions answered by it", onClick: function () { K.searchDb({ query: e.a, field: "answer", exact: false }); } });
          var fsp = null;
          try { fsp = (QB.getActivePages() || []).find(function (p) { return p.id.indexOf("fact-sheet::") === 0; }); } catch (x) { fsp = null; }
          if (fsp) items.push({ label: "Fact sheet for it", onClick: function () { try { localStorage.setItem("qb-facts-handoff", JSON.stringify({ term: e.a })); } catch (x) {} QB.showPage(fsp.id); } });
        }
        items.push({ sep: true });
        items.push({ label: st.classList.contains("on") ? "Unstar" : "Star", onClick: function () { st.click(); } });
        if (sv) items.push({ label: "Save to review or a folder…", onClick: function () { K.openSave(saveSpec(front, back), sv); } });
        QB.contextMenu(ev.clientX, ev.clientY, items, { title: front + " → " + back });
      });
    });
    if (ans) fillProbs(out, c);
  }

  // ── Database → Keyword Frequency: saved pairs ──
  K.savedTab({
    id: "keyword-freq", title: "Keyword Frequency", empty: "No saved words yet",
    list: stars, save: function (l) { ctx.storage.set("kf-stars", l); }, key: starKey,
    front: function (it) { return it.front; }, back: function (it) { return it.back; },
    card: function (it) { return { front: it.front, back: it.back, meta: "keyword" }; },
    saveSpec: function (it) { return saveSpec(it.front, it.back); },
  });
}
