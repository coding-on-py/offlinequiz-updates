function __qbMain(ctx) {
  // The Review-as-flashcards button follows Flashcards being turned on/off while
  // this tab stays on screen (Back revives the Database without re-rendering it).
  function hasFc() { try { return !(window.QB && QB.getActivePages) || (QB.getActivePages() || []).some(function (p) { return p.id === "flashcards::cards"; }); } catch (e) { return true; } }
  if (ctx.on) ctx.on("plugins:changed", function () {
    var b = document.getElementById("kf-review"); if (!b) return;
    var ok = hasFc(); b.disabled = !ok;
    if (ok) b.removeAttribute("title"); else b.title = "Needs Flashcards plugin";
  });
    var body = null, page = null;

    function esc(s) { return (s == null ? "" : String(s)).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
    function loadBar(label) { return (window.QB && QB.loadingBarHtml) ? QB.loadingBarHtml(label) : '<div class="text-muted">' + esc(label) + "</div>"; }
    function loadBarDet(label, frac) {
      var pct = Math.max(0, Math.min(100, Math.round((frac || 0) * 100)));
      return '<div class="qb-loading"><div class="qb-loadbar det"><div class="qb-loadbar-fill" style="width:' + pct + '%"></div></div><span>' + esc(label) + "</span></div>";
    }

    var STOP = {};
    ("a an the this that these those it its his her hers he she they them their theirs we us our you your i me my mine of in on at to for from with within without by as is are was were be been being am do does did done not no nor so or and but if then than because while during after before until once when where which who whom whose what why how all any both each few more most other some such only own same here there over under again further about above below between into through against up down out off very can will just should now points point name names named ftp identify gives give given made make makes making one two three four five six seven eight nine ten first second third often called also another may might must shall many much work works worked title titled known includes including include described describes describe used uses use using like unlike along man woman men women person people city country state nation work novel poem play opera symphony war battle king queen god goddess").split(/\s+/).forEach(function (w) { STOP[w] = 1; });

    // ── question text ─────────────────────────────────────────────────────
    // Words are counted from what a question SAYS to players: the host's
    // reading text (ctx.host.questionText) when the base has it, else the plain
    // copy. Moderator / reader notes and pronunciation guides are then removed
    // whatever the reading settings say: they are never clue words.
    var NOTE_LBL = /(?:note to (?:the )?(?:moderators?|readers?)\b|reader(?:'s)? note\b|moderator(?:'s)? note\b)/i;
    var NOTE_LBL_G = /(?:note to (?:the )?(?:moderators?|readers?)\b|reader(?:'s)? note\b|moderator(?:'s)? note\b)\s*(?:#\s*\d+\s*)?(?:,[^:]{0,40})?:\s*/gi;
    var NOTE_RUN = /^\s*[\[(<*]*\s*(?:note to (?:the )?(?:moderators?|readers?)\b|reader(?:'s)? note\b|moderator(?:'s)? note\b)/i;
    var ENT = { amp: "&", lt: "<", gt: ">", quot: '"', apos: "'", nbsp: "\u00a0" };
    function decodeEnt(s) {
      return String(s || "").replace(/&(#x[0-9a-f]+|#\d+|[a-z]+);/gi, function (m, e) {
        if (e[0] === "#") { try { return String.fromCodePoint(e[1] === "x" || e[1] === "X" ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10)); } catch (x) { return m; } }
        var v = ENT[e.toLowerCase()]; return v == null ? m : v;
      });
    }
    // A note is the italic run of the HTML field that STARTS with its label.
    function noteRuns(html) {
      if (!html || html.indexOf("<") < 0) return [];
      var runs = [], it = 0, last = 0, m, re = /<\/?([a-z]+)[^>]*>/gi;
      function push(t) { if (!t) return; var p = runs[runs.length - 1], ital = it > 0; if (p && p.italic === ital) p.text += t; else runs.push({ text: t, italic: ital }); }
      while ((m = re.exec(html))) {
        push(decodeEnt(html.slice(last, m.index)));
        var tag = m[1].toLowerCase();
        if (tag === "i" || tag === "em") it = Math.max(0, it + (m[0][1] === "/" ? -1 : 1));
        last = re.lastIndex;
      }
      push(decodeEnt(html.slice(last)));
      return runs.filter(function (r) { return r.italic && NOTE_RUN.test(r.text); }).map(function (r) { return r.text.trim(); });
    }
    // The plain copy folds accents, straightens quotes and spells out dashes.
    function foldPlain(s) {
      return String(s || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "")
        .replace(/[“”]/g, '"').replace(/[‘’]/g, "'").replace(/[–—]/g, "-").replace(/…/g, "...").replace(/\u00a0/g, " ");
    }
    function cutSpan(t, i, j) { return t.slice(0, i).replace(/\s+$/, "") + (i > 0 && j < t.length ? " " : "") + t.slice(j).replace(/^\s+/, ""); }
    function stripNotes(t, html) {
      if (!NOTE_LBL.test(t)) return t;
      noteRuns(html).forEach(function (note) {
        var cands = [foldPlain(note), note];
        for (var c = 0; c < cands.length; c++) { var i = t.indexOf(cands[c]); if (i >= 0) { t = cutSpan(t, i, i + cands[c].length); break; } }
      });
      if (!NOTE_LBL.test(t)) return t;
      t = t.replace(/\s*[\[(]\s*(?:notes?\s+to\s+(?:the\s+)?(?:moderators?|readers?)|(?:moderators?|readers?)(?:'s)?\s+notes?)\b[^\])]*[\])]/gi, " ");
      // An unformatted "Label: …" has no marked end: cut through its first
      // sentence, or to where the question visibly restarts (a lowercase word,
      // then a capitalised one, outside quotes).
      var m, guard = 0;
      NOTE_LBL_G.lastIndex = 0;
      while ((m = NOTE_LBL_G.exec(t)) && guard++ < 6) {
        var s = m.index, from = s + m[0].length, rest = t.slice(from, from + 300), b = -1;
        var w = rest.match(/^\S+\s+/), re = /[.!?]+["'”’)]*\s+|[a-z0-9"'”’)]\s+(?=[A-Z](?:[a-z'’]|\s))/g, mm;
        re.lastIndex = w ? w[0].length : 0;
        while ((mm = re.exec(rest))) {
          var stop = /^[.!?]/.test(mm[0]);
          if (!stop && ((rest.slice(0, mm.index + 1).match(/"/g) || []).length % 2)) continue;
          b = stop ? mm.index + mm[0].length : mm.index + 1; break;
        }
        while (s > 0 && /[\s*<\[(]/.test(t[s - 1])) s--;
        t = cutSpan(t, s, b >= 0 ? from + b : from);
        NOTE_LBL_G.lastIndex = s;
      }
      return t;
    }
    function stripGuides(t) {
      if (ctx.host && typeof ctx.host.stripPronunciations === "function") { try { t = ctx.host.stripPronunciations(t); } catch (e) {} }
      return String(t || "").replace(/\s*\(\s*["“][^"”()]*["”]\s*\)/g, "");
    }
    var _qtCache = typeof WeakMap === "function" ? new WeakMap() : null;
    function qText(q) {
      if (!q) return "";
      if (_qtCache && _qtCache.has(q)) return _qtCache.get(q);
      var t = null;
      if (ctx.host && typeof ctx.host.questionText === "function") { try { t = ctx.host.questionText(q, "question"); } catch (e) { t = null; } }
      if (typeof t !== "string") t = q.question_sanitized || "";
      t = stripGuides(stripNotes(decodeEnt(t), q.question)).replace(/\s{2,}/g, " ").trim();
      if (_qtCache) _qtCache.set(q, t);
      return t;
    }

    // ── category picker ─────────────────────────────────────────────────────
    // Default: the app's standard selector (ctx.host.categoryPicker) — several
    // whole subtrees at once, sent as categoryIds=a,b (empty = all categories).
    // Not kept between launches (like the other filters on this page).
    var catBtn = null;
    function hasCatPicker() { return !!(ctx.host && typeof ctx.host.categoryPicker === "function"); }
    // Older base without it: a cascade over the category tree. Level 1 → 2 → 3
    // selects, then a 4th listing every deeper node under the level-3 pick as
    // an "A > B" relative path. Option values are node ids; the DEEPEST pick is
    // the filter, sent as categories=<id> (its whole subtree).
    var CAT_SELS_HTML =
      '<select id="kw-cat" class="mode-input kw-sel"><option value="">All categories</option></select>' +
      '<select id="kw-sub" class="mode-input kw-sel" disabled><option value="">All subcategories</option></select>' +
      '<select id="kw-alt" class="mode-input kw-sel" disabled><option value="">All topics</option></select>' +
      '<select id="kw-deep" class="mode-input kw-sel" disabled><option value="">All subtopics</option></select>';
    var CAT_ALL = ["All categories", "All subcategories", "All topics", "All subtopics"];
    var _catTree = null;   // { roots, byId } once loaded
    function loadCatTree() {
      var p = (ctx.host && typeof ctx.host.getCategoryTree === "function")
        ? Promise.resolve().then(function () { return ctx.host.getCategoryTree("tossups"); })
        : ctx.api.get("/api/category-tree?type=tossups").then(function (d) { return (d && d.tree) || []; });
      return p.then(function (roots) {
        var byId = Object.create(null);
        (function walk(list) { (list || []).forEach(function (n) { byId[n.id] = n; walk(n.children); }); })(roots);
        _catTree = { roots: roots || [], byId: byId };
        return _catTree;
      });
    }
    function fillCatSel(sel, level, items) {
      if (!sel) return;
      sel.innerHTML = '<option value="">' + CAT_ALL[level] + "</option>";
      items.forEach(function (it) { var o = document.createElement("option"); o.value = it.id; o.textContent = it.label; sel.appendChild(o); });
      sel.disabled = level > 0 && !items.length;
    }
    function wireCatCascade(sels) {
      function kids(sel) { var n = _catTree && sel && sel.value ? _catTree.byId[sel.value] : null; return n ? n.children || [] : []; }
      function named(list) { return list.map(function (n) { return { id: n.id, label: n.name }; }); }
      function deep() {
        var out = [];
        (function walk(list, prefix) {
          list.forEach(function (c) { var lab = prefix ? prefix + " > " + c.name : c.name; out.push({ id: c.id, label: lab }); walk(c.children || [], lab); });
        })(kids(sels[2]), "");
        return out;
      }
      for (var i = 1; i < sels.length; i++) fillCatSel(sels[i], i, []);
      sels[0].addEventListener("change", function () { fillCatSel(sels[1], 1, named(kids(sels[0]))); fillCatSel(sels[2], 2, []); fillCatSel(sels[3], 3, []); });
      sels[1].addEventListener("change", function () { fillCatSel(sels[2], 2, named(kids(sels[1]))); fillCatSel(sels[3], 3, []); });
      sels[2].addEventListener("change", function () { fillCatSel(sels[3], 3, deep()); });
      return loadCatTree().then(function (t) {
        if (!t.roots.length) throw new Error("no tree");
        fillCatSel(sels[0], 0, named(t.roots));
      }).catch(function () {
        // Older base without the tree: level-1 names (the server accepts them).
        return ctx.api.get("/api/categories?type=tossups").then(function (d) {
          fillCatSel(sels[0], 0, ((d && d.categories) || []).map(function (c) { return { id: c.category, label: c.category }; }));
        }).catch(function () {});
      });
    }
    function catPick(sels) {
      for (var i = sels.length - 1; i >= 0; i--) { var s = sels[i]; if (s && !s.disabled && s.value) return s.value; }
      return "";
    }
    function catSels() { return ["#kw-cat", "#kw-sub", "#kw-alt", "#kw-deep"].map(function (id) { return body.querySelector(id); }); }

    page = ctx.registerPage({
      id: "kwfreq", navLabel: "Keyword Frequency", title: "KEYWORD FREQUENCY",
      onShow: function (el) {
        body = el;
        if (!body.querySelector("#kw-input")) render();
        // Handoff from the app's right-click ("Top answers for '<selection>'").
        try {
          var h = JSON.parse(localStorage.getItem("qb-kf-handoff") || "null");
          if (h && h.term) {
            localStorage.removeItem("qb-kf-handoff");
            var tries = 0;
            (function applyHandoff() {
              var ms = body.querySelector("#kw-mode"), inp = body.querySelector("#kw-input");
              if (!ms || !inp) { if (tries++ < 20) setTimeout(applyHandoff, 60); return; }
              ms.value = (h.mode === "answers" || h.mode === "reverse") ? h.mode : "words";
              ms.dispatchEvent(new Event("change"));
              inp.value = h.term;
              run();
            })();
          }
        } catch (e) {}
      },
    });
    function active() { return page && page.screenEl && page.screenEl.classList.contains("active"); }

    // Esc walks back through searches (e.g. "titration" → click "technique" →
    // Esc returns to "titration"); with nothing left, the app navigates back.
    var viewStack = [], curView = null, restoringView = false;
    ctx.onBack(function () {
      if (!active() || !viewStack.length || !body) return false;
      var v = viewStack.pop();
      curView = null;          // re-set by run() without re-pushing
      restoringView = true;
      try {
        var ms = body.querySelector("#kw-mode");
        ms.value = v.mode;
        ms.dispatchEvent(new Event("change"));
        body.querySelector("#kw-input").value = v.term;
        run();
      } finally { restoringView = false; }
      return true;
    });

    function pctRange() {
      var r = ctx.storage.get("range") || { lo: 0, hi: 100 };
      return { lo: Math.min(r.lo, r.hi), hi: Math.max(r.lo, r.hi), power: !!ctx.storage.get("powerOnly") };
    }
    function mainAnswer(sani) { return decodeEnt(sani).split(/[\[(<]/)[0].trim().replace(/[;:,.]+$/, ""); }
    // ── saved words/phrases/answers (★ to review later as flashcards) ──
    function starredKF() { return ctx.storage.get("kf-stars") || []; }
    function kfKey(it) { return (it.front || "") + "" + (it.back || ""); }
    function isKFStarred(it) { var k = kfKey(it); return starredKF().some(function (x) { return kfKey(x) === k; }); }
    function kfAddBtn(front, back) {
      if (!((ctx.host && ctx.host.openItemSaveMenu) || window.QBFolders)) return "";
      return '<span class="kw-foldx" data-f="' + esc(front) + '" data-b="' + esc(back) + '" title="Add to review / folder">+</span>';
    }
    function kfAdd(front, back, anchor) {
      var spec = { review: { kind: "keyword", front: front, back: back, meta: "keyword" }, folder: { type: "keywords", item: { front: front, back: back } } };
      if (ctx.host && ctx.host.openItemSaveMenu) ctx.host.openItemSaveMenu(spec, anchor);
      else if (window.QBFolders) window.QBFolders.pick("keywords", spec.folder.item, anchor);
    }
    function kfStarHtml(front, back) { var st = isKFStarred({ front: front, back: back }); return '<span class="kw-starx' + (st ? " on" : "") + '" data-f="' + esc(front) + '" data-b="' + esc(back) + '" title="Save to review later">' + (st ? "★" : "☆") + "</span>" + kfAddBtn(front, back); }
    function wireKFStars(out) {
      out.querySelectorAll(".kw-starx").forEach(function (s) {
        s.addEventListener("click", function (ev) {
          ev.stopPropagation();
          var it = { front: s.dataset.f, back: s.dataset.b };
          var lst = starredKF(), k = kfKey(it), idx = lst.findIndex(function (x) { return kfKey(x) === k; });
          if (idx >= 0) lst.splice(idx, 1); else lst.push(it);
          ctx.storage.set("kf-stars", lst);
          if (ctx.playSound) ctx.playSound("star");
          var on = idx < 0; s.textContent = on ? "★" : "☆"; s.classList.toggle("on", on);
        });
      });
      out.querySelectorAll(".kw-foldx").forEach(function (s) {
        s.addEventListener("click", function (ev) { ev.stopPropagation(); kfAdd(s.dataset.f, s.dataset.b, s); });
      });
    }
    function kfPaginate(out, metaHtml, theadHtml, list, rowFn, afterRender) {
      var PAGE = 50, page = 0;
      function paint() {
        var pages = Math.max(1, Math.ceil(list.length / PAGE));
        if (page >= pages) page = pages - 1;
        if (page < 0) page = 0;
        var start = page * PAGE, slice = list.slice(start, start + PAGE);
        out.innerHTML = metaHtml + '<table class="stats-table">' + theadHtml + "<tbody>" +
          slice.map(function (e, j) { return rowFn(e, start + j); }).join("") + "</tbody></table>" +
          (pages > 1 ? '<div class="kw-pager"><button class="btn btn-sm" id="kw-prev"' + (page === 0 ? " disabled" : "") + '>‹ Prev</button><span class="kw-meta">Page ' + (page + 1) + " of " + pages + '</span><button class="btn btn-sm" id="kw-next"' + (page >= pages - 1 ? " disabled" : "") + '>Next ›</button></div>' : "");
        if (afterRender) afterRender(out);
        var pv = out.querySelector("#kw-prev"), nx = out.querySelector("#kw-next");
        if (pv) pv.onclick = function () { page--; paint(); };
        if (nx) nx.onclick = function () { page++; paint(); };
      }
      paint();
    }

    async function render() {
      var diffBoxes = "";
      for (var d = 0; d <= 10; d++) diffBoxes += '<label class="kw-diff"><input type="checkbox" class="kw-diff-cb" value="' + d + '">' + d + "</label>";
      var r = ctx.storage.get("range") || { lo: 0, hi: 100 };
      body.innerHTML =
        '<div class="kw-wrap">' +
          '<div class="kw-card">' +
            '<div class="kw-row">' +
              '<select id="kw-mode" class="mode-input kw-sel" style="flex:0 0 auto;min-width:240px">' +
                '<option value="answers">Answer → keywords</option>' +
                '<option value="words">Word → answers</option>' +
                '<option value="reverse">Answer → leading words</option>' +
              "</select>" +
              '<input type="text" id="kw-input" class="mode-input" placeholder="Search answers\u2026" autocomplete="off" autocorrect="off" spellcheck="false" style="flex:1;min-width:180px">' +
              '<select id="kw-x" class="mode-input hidden" style="flex:0 0 auto;width:150px" title="The answer must rank in each word\u2019s top X answers">' +
                '<option value="1">in top 1</option><option value="2" selected>in top 2</option><option value="3">in top 3</option><option value="5">in top 5</option><option value="10">in top 10</option>' +
              "</select>" +
              '<select id="kw-top" class="mode-input" style="flex:0 0 auto;width:110px">' +
                '<option value="10">Top 10</option><option value="20">Top 20</option><option value="50" selected>Top 50</option><option value="100">Top 100</option><option value="200">Top 200</option><option value="500">Top 500</option><option value="1000">Top 1000</option>' +
              "</select>" +
              '<button class="btn btn-primary" id="kw-go">Search</button>' +
            "</div>" +
            '<div class="kw-row" id="kw-cat-row">' + (hasCatPicker() ? "" : CAT_SELS_HTML) + "</div>" +
            '<div class="kw-row"><span class="kw-label">Difficulty</span>' + diffBoxes + "</div>" +
            '<div class="kw-row"><span class="kw-label">Years</span>' +
              '<div class="dual-range kw-dual"><div class="dual-range-track"><div class="dual-range-fill" id="kw-yfill"></div></div>' +
                '<input type="range" id="kw-ymin" min="2000" max="2026" value="2000">' +
                '<input type="range" id="kw-ymax" min="2000" max="2026" value="2026"></div>' +
              '<span class="kw-label" id="kw-year-val" style="min-width:84px;text-align:right"></span>' +
            "</div>" +
            '<div class="kw-row"><span class="kw-label">Question range</span>' +
              '<div class="dual-range kw-dual"><div class="dual-range-track"><div class="dual-range-fill" id="kw-fill"></div></div>' +
                '<input type="range" id="kw-lo" min="0" max="100" step="5" value="' + r.lo + '">' +
                '<input type="range" id="kw-hi" min="0" max="100" step="5" value="' + r.hi + '"></div>' +
              '<span class="kw-label" id="kw-range-val" style="min-width:84px;text-align:right"></span>' +
              '<label class="kw-diff" style="margin-left:8px" title="Only text BEFORE the (*) powermark counts; questions without a powermark are skipped. Disables the % range."><input type="checkbox" id="kw-power"' + (r.power ? " checked" : "") + "> Before power only</label>" +
            "</div>" +
          "</div>" +
          '<div class="kw-card" id="kw-results"></div>' +
        "</div>";

      catBtn = null;
      var catRow = body.querySelector("#kw-cat-row");
      if (hasCatPicker()) {
        try {
          catBtn = ctx.host.categoryPicker(null, { selected: [], type: "tossups", label: "Categories" });
          catRow.appendChild(catBtn.el);
        } catch (e) { catBtn = null; }
        if (!catBtn) catRow.innerHTML = CAT_SELS_HTML;
      }
      if (!catBtn) wireCatCascade(catSels());

      function wireDual(loId, hiId, fillId, valId, save, min, max, fmt) {
        var lo = body.querySelector("#" + loId), hi = body.querySelector("#" + hiId);
        function paint() {
          var a = parseInt(lo.value), b = parseInt(hi.value);
          var mn = Math.min(a, b), mx = Math.max(a, b);
          if (save) save(mn, mx);
          body.querySelector("#" + valId).textContent = fmt(mn, mx);
          var fill = body.querySelector("#" + fillId);
          if (fill) { fill.style.left = ((mn - min) / (max - min)) * 100 + "%"; fill.style.right = ((max - mx) / (max - min)) * 100 + "%"; }
        }
        lo.addEventListener("input", paint); hi.addEventListener("input", paint); paint();
      }
      wireDual("kw-lo", "kw-hi", "kw-fill", "kw-range-val", function (a, b) { ctx.storage.set("range", { lo: a, hi: b }); }, 0, 100, function (a, b) { return a + "% – " + b + "%"; });
      var kpw = body.querySelector("#kw-power");
      function syncPowerUI() {
        var on = !!(kpw && kpw.checked);
        ["kw-lo", "kw-hi"].forEach(function (id) { var el = body.querySelector("#" + id); if (el) el.disabled = on; });
        var fill = body.querySelector("#kw-fill"); if (fill && fill.closest(".dual-range")) fill.closest(".dual-range").style.opacity = on ? "0.35" : "";
        var rv = body.querySelector("#kw-range-val"); if (rv && on) rv.textContent = "before (*)";
        else if (rv && !on) { var rr = pctRange(); rv.textContent = rr.lo + "% – " + rr.hi + "%"; }
      }
      if (kpw) { kpw.onchange = function () { ctx.storage.set("powerOnly", kpw.checked); syncPowerUI(); }; syncPowerUI(); }
      wireDual("kw-ymin", "kw-ymax", "kw-yfill", "kw-year-val", null, 2000, 2026, function (a, b) { return a + " – " + b; });

      var go = function () { run(); };
      body.querySelector("#kw-go").onclick = go;
      body.querySelector("#kw-input").addEventListener("keydown", function (e) { if (e.key === "Enter") go(); });
      var modeSel = body.querySelector("#kw-mode");
      function syncPlaceholder() {
        var rev = modeSel.value === "reverse";
        body.querySelector("#kw-input").placeholder = modeSel.value === "words" ? "Search words\u2026" : "Search answers\u2026";
        body.querySelector("#kw-input").title = modeSel.value === "words" ? "Comma = require all (e.g. mistletoe, blind)" : "";
        var xs = body.querySelector("#kw-x"); if (xs) xs.classList.toggle("hidden", !rev);
        var tn = body.querySelector("#kw-top"); if (tn) tn.classList.toggle("hidden", rev);
      }
      modeSel.addEventListener("change", syncPlaceholder);
      syncPlaceholder();
    }

    function catQs() {
      if (catBtn) {
        var ids = [];
        try { ids = catBtn.get() || []; } catch (e) { ids = []; }
        return ids.length ? "&categoryIds=" + ids.map(function (i) { return encodeURIComponent(i); }).join(",") : "";
      }
      var cat = catPick(catSels());
      return cat ? "&categories=" + encodeURIComponent(cat) : "";
    }
    function filterQs() {
      var diffs = [].slice.call(body.querySelectorAll(".kw-diff-cb:checked")).map(function (c) { return c.value; });
      var ya = parseInt(body.querySelector("#kw-ymin").value), yb = parseInt(body.querySelector("#kw-ymax").value);
      var ymin = Math.min(ya, yb), ymax = Math.max(ya, yb);
      return catQs() +
        (diffs.length ? "&difficulties=" + diffs.join(",") : "") +
        (ymin > 2000 ? "&yearMin=" + ymin : "") + (ymax < 2026 ? "&yearMax=" + ymax : "");
    }

    function crossSearch(mode, term) {
      var ms = body.querySelector("#kw-mode");
      ms.value = mode;
      ms.dispatchEvent(new Event("change"));
      body.querySelector("#kw-input").value = term;
      run();
    }

    async function run() {
      var word = (body.querySelector("#kw-input").value || "").trim();
      var mode = body.querySelector("#kw-mode").value;
      var topN = parseInt(body.querySelector("#kw-top").value) || 50;
      var out = body.querySelector("#kw-results");
      if (!word) { out.innerHTML = '<div class="text-muted">Type something first.</div>'; return; }
      if (!restoringView && curView && (curView.term !== word || curView.mode !== mode)) viewStack.push(curView);
      curView = { mode: mode, term: word };
      out.innerHTML = loadBar("Searching…");

      if (mode === "reverse") { await runReverse(word, pctRange(), out); return; }
      // Tokenize the typed term EXACTLY like sliceWords does (keep internal
      // apostrophes, strip a trailing possessive 's). Otherwise a word such as
      // "o'brien" / "coup d'état" splits into pieces that never match the slice
      // tokens — searches fail here, and Buzz Words numbers wouldn't reproduce.
      // Comma-separated input = multiple hints that must ALL appear ("words"
      // mode). Each hint is tokenized separately; the FTS query ANDs every token.
      var hints = word.split(",").map(function (h) { return h.trim(); }).filter(Boolean);
      var hintSeqs = hints.map(function (h) {
        return (h.match(/[\p{L}\p{N}'’]+/gu) || []).map(function (t) { return t.toLowerCase().replace(/['’]s$/, ""); }).filter(Boolean);
      }).filter(function (s) { return s.length; });
      var tokens = [];
      hintSeqs.forEach(function (s) { s.forEach(function (t) { tokens.push(t); }); });
      if (!tokens.length) { out.innerHTML = '<div class="text-muted">Nothing searchable in that.</div>'; return; }
      var quoted = tokens.map(function (t) { return '"' + t + '"'; }).join(" ");
      var col = mode === "answers" ? "answer_sanitized" : "question_sanitized";
      var url = "/api/tossups/search?query=" + encodeURIComponent(col + " : (" + quoted + ")") + "&limit=500" + filterQs();

      var rows = [];
      try { rows = (await ctx.api.get(url)).rows || []; } catch (e) {
        out.innerHTML = '<div class="text-muted">Search failed: ' + esc(e.message || e) + "</div>"; return;
      }
      if (!rows.length) { out.innerHTML = '<div class="text-muted">No matching questions.</div>'; return; }

      var range = pctRange();
      if (mode === "answers") renderKeywords(rows, word, tokens, range, topN, out);
      else renderAnswers(rows, word, hintSeqs, range, topN, out);
    }

    // Reverse: given an ANSWER, find clue-words whose own "top answers" list
    // ranks this answer within the chosen top X. (e.g. chromatography → the
    // word "diffusion", because chromatography is the #1 answer for diffusion.)
    async function runReverse(answer, range, out) {
      var X = parseInt(body.querySelector("#kw-x").value) || 2;
      var targetKey = mainAnswer(answer).toLowerCase();
      var tokens = answer.match(/[\p{L}\p{N}]+/gu) || [];
      if (!tokens.length) { out.innerHTML = '<div class="text-muted">Nothing searchable in that.</div>'; return; }
      var quoted = tokens.map(function (t) { return '"' + t + '"'; }).join(" ");
      out.innerHTML = loadBar("Finding candidate words\u2026");
      var arows = [];
      try { arows = (await ctx.api.get("/api/tossups/search?query=" + encodeURIComponent("answer_sanitized : (" + quoted + ")") + "&limit=500" + filterQs())).rows || []; }
      catch (e) { out.innerHTML = '<div class="text-muted">Search failed: ' + esc(e.message || e) + "</div>"; return; }
      if (!arows.length) { out.innerHTML = '<div class="text-muted">No questions have that answer.</div>'; return; }
      // candidate clue words from those questions, by document frequency
      var freq = {};
      arows.forEach(function (q) {
        var seen = {};
        sliceWords(q, range).forEach(function (w) {
          w = w.replace(/['\u2019]s$/, "");
          if (w.length < 3 || STOP[w] || /^\d+$/.test(w)) return;
          if (!seen[w]) { seen[w] = 1; freq[w] = (freq[w] || 0) + 1; }
        });
      });
      var candidates = Object.keys(freq).sort(function (a, b) { return freq[b] - freq[a]; }).slice(0, 25);
      if (!candidates.length) { out.innerHTML = '<div class="text-muted">No candidate words in that slice.</div>'; return; }
      var results = [];
      for (var ci = 0; ci < candidates.length; ci++) {
        out.innerHTML = loadBarDet("Checking words\u2026 " + (ci + 1) + "/" + candidates.length, (ci + 1) / candidates.length);
        var w = candidates[ci];
        var wrows = [];
        try { wrows = (await ctx.api.get("/api/tossups/search?query=" + encodeURIComponent('question_sanitized : ("' + w + '")') + "&limit=300" + filterQs())).rows || []; }
        catch (e) { continue; }
        var counts = {};
        wrows.forEach(function (q) {
          if (sliceWords(q, range).indexOf(w) < 0) return;
          var m = mainAnswer(q.answer_sanitized); if (!m) return;
          var k = m.toLowerCase(); counts[k] = (counts[k] || 0) + 1;
        });
        var ranked = Object.keys(counts).sort(function (a, b) { return counts[b] - counts[a]; });
        var rank = ranked.indexOf(targetKey) + 1;
        if (rank >= 1 && rank <= X) results.push({ word: w, rank: rank, total: ranked.length });
      }
      results.sort(function (a, b) { return a.rank - b.rank; });
      if (!results.length) { out.innerHTML = '<div class="kw-meta">No leading words found.</div>'; return; }
      out.innerHTML =
        '<div class="kw-meta">words whose top ' + X + ' answers include \u201c' + esc(answer) + "\u201d \u00b7 " + range.lo + "\u2013" + range.hi + "%</div>" +
        '<table class="stats-table"><thead><tr><th>#</th><th>Word</th><th>Rank of answer</th></tr></thead><tbody>' +
        results.map(function (e, i) {
          return "<tr><td>" + (i + 1) + '</td><td class="kw-word" data-w="' + esc(e.word) + '">' + esc(e.word) + "</td><td>#" + e.rank + " of " + e.total + "</td></tr>";
        }).join("") + "</tbody></table>";
      out.querySelectorAll(".kw-word").forEach(function (td) {
        td.addEventListener("click", function () { crossSearch("words", td.dataset.w); });
      });
    }

    function sliceWords(q, range) {
      var text = qText(q);
      if (range && range.power) {
        // "Before power" mode: only pre-(*) text counts; unmarked questions are excluded.
        var pi = text.indexOf("(*)");
        if (pi < 0) return [];
        return (text.slice(0, pi).toLowerCase().match(/[\p{L}\p{N}'’]+/gu) || [])
          .map(function (w) { return w.replace(/['’]s$/, ""); });
      }
      var words = (text.replace(/\(\*\)/g, " ").toLowerCase().match(/[\p{L}\p{N}'’]+/gu) || [])
        .map(function (w) { return w.replace(/['’]s$/, ""); });
      var n = words.length; if (!n) return [];
      var a = Math.round((range.lo / 100) * n), b = Math.round((range.hi / 100) * n);
      return words.slice(a, Math.max(a + 1, b));
    }
    // Does the slice contain the token sequence CONSECUTIVELY? (phrase match)
    function sliceHasSeq(slice, seq) {
      if (!seq.length) return false;
      if (seq.length === 1) return slice.indexOf(seq[0]) >= 0;
      for (var i = 0; i + seq.length <= slice.length; i++) {
        var ok = true;
        for (var j = 0; j < seq.length; j++) { if (slice[i + j] !== seq[j]) { ok = false; break; } }
        if (ok) return true;
      }
      return false;
    }
    // Is shortArr a contiguous run inside longArr?
    function containsSeq(longArr, shortArr) {
      if (shortArr.length > longArr.length) return false;
      for (var i = 0; i + shortArr.length <= longArr.length; i++) {
        var ok = true;
        for (var k = 0; k < shortArr.length; k++) { if (longArr[i + k] !== shortArr[k]) { ok = false; break; } }
        if (ok) return true;
      }
      return false;
    }
    // Collapse word/phrase redundancy: when a longer gram that CONTAINS a shorter
    // one appears in >=80% of the shorter gram's questions, the shorter is
    // redundant (almost always part of that phrase) — drop it, keep the phrase.
    // So "carothers" + "carothers equation" with equal counts shows only the
    // phrase, while a common word like "equation" (which the phrase covers only a
    // little of) is kept. keyOf -> gram string, docOf -> its question count.
    function collapseGrams(items, keyOf, docOf) {
      var toks = items.map(function (it) { return keyOf(it).split(" "); });
      var drop = {};
      for (var i = 0; i < items.length; i++) {
        var sd = docOf(items[i]); if (!sd) continue;
        for (var j = 0; j < items.length; j++) {
          if (i === j) continue;
          if (toks[j].length <= toks[i].length) continue;
          if (!containsSeq(toks[j], toks[i])) continue;
          if (docOf(items[j]) >= 0.8 * sd) { drop[keyOf(items[i])] = 1; break; }
        }
      }
      return items.filter(function (it) { return !drop[keyOf(it)]; });
    }
    // Unigrams + bigrams + trigrams from a slice. Multi-word grams must NOT
    // start/end on a stop word (so 'hello world' counts but 'of the' doesn't),
    // and skip grams touching the searched answer's own words.
    function gramsOf(words, skip) {
      var out = [];
      var clean = words.map(function (w) { return w.replace(/['’]s$/, ""); });
      for (var i = 0; i < clean.length; i++) {
        var w = clean[i];
        if (w.length >= 3 && !STOP[w] && !skip[w] && !/^\d+$/.test(w)) out.push(w); // unigram
        for (var L = 2; L <= 3; L++) {
          if (i + L > clean.length) break;
          var gram = clean.slice(i, i + L);
          var first = gram[0], last = gram[L - 1];
          if (STOP[first] || STOP[last]) continue;
          if (gram.some(function (g) { return skip[g] || /^\d+$/.test(g) || g.length < 2; })) continue;
          out.push(gram.join(" "));
        }
      }
      return out;
    }

    // mode 1: answer → top keywords in its questions
    // P(answer | keyword): of ALL questions whose slice contains the keyword,
    // what fraction are answered by the searched answer? Computed lazily for
    // the visible page (one small FTS query per keyword, cached).
    var _probCache = Object.create(null), _probGen = 0;
    function keywordProb(w, targetTokens, range, filters, cb) {
      var key = w + "|" + targetTokens.join(" ") + "|" + filters + "|" + (range.power ? "P" : range.lo + "-" + range.hi);
      if (_probCache[key]) { cb(_probCache[key]); return; }
      var seq = w.split(" ");
      var quoted = seq.map(function (t) { return '"' + t + '"'; }).join(" ");
      ctx.api.get("/api/tossups/search?query=" + encodeURIComponent('question_sanitized : (' + quoted + ')') + "&limit=400" + filters).then(function (d) {
        var rs = (d && d.rows) || [];
        var total = 0, hit = 0;
        rs.forEach(function (q) {
          if (!sliceHasSeq(sliceWords(q, range), seq)) return;
          total++;
          var al = (q.answer_sanitized || "").toLowerCase();
          var ok = true;
          for (var i = 0; i < targetTokens.length; i++) if (al.indexOf(targetTokens[i]) < 0) { ok = false; break; }
          if (ok) hit++;
        });
        var r = { p: total ? hit / total : 0, hit: hit, total: total };
        _probCache[key] = r;
        cb(r);
      }).catch(function () { cb(null); });
    }
    function fillKeywordProbs(o, word, range, filters) {
      var targetTokens = (word.toLowerCase().match(/[\p{L}\p{N}'’]+/gu) || []).map(function (t) { return t.replace(/['’]s$/, ""); });
      var gen = ++_probGen;
      var cells = [].slice.call(o.querySelectorAll(".kw-prob[data-w]"));
      var idx = 0, workers = 0;
      function next() {
        if (gen !== _probGen) return;
        while (workers < 4 && idx < cells.length) {
          (function (cell) {
            workers++;
            keywordProb(cell.dataset.w, targetTokens, range, filters, function (r) {
              workers--;
              if (gen === _probGen && cell.isConnected) {
                cell.textContent = r && r.total ? Math.round(100 * r.p) + "% (" + r.hit + "/" + r.total + ")" : "–";
                if (r && r.total && r.p >= 0.8) cell.classList.add("kw-prob-hi");
              }
              next();
            });
          })(cells[idx++]);
        }
      }
      next();
    }

    function renderKeywords(rows, word, tokens, range, topN, out) {
      var searchWords = {};
      tokens.forEach(function (t) { searchWords[t.toLowerCase()] = 1; });
      var totals = {}, docs = {};
      rows.forEach(function (q) {
        var skip = {};
        Object.keys(searchWords).forEach(function (w) { skip[w] = 1; });
        ((q.answer_sanitized || "").toLowerCase().match(/[\p{L}\p{N}'’]+/gu) || []).forEach(function (w) { skip[w.replace(/['’]s$/, "")] = 1; });
        var seen = {};
        gramsOf(sliceWords(q, range), skip).forEach(function (g) {
          totals[g] = (totals[g] || 0) + 1;
          if (!seen[g]) { seen[g] = 1; docs[g] = (docs[g] || 0) + 1; }
        });
      });
      // A phrase only earns its place if it recurs (≥2 questions) — otherwise
      // single-word keywords dominate, which is right.
      var list = Object.keys(totals).map(function (w) { return { w: w, total: totals[w], docs: docs[w], phrase: w.indexOf(" ") >= 0 }; })
        .filter(function (e) { return !e.phrase || e.docs >= 2; });
      list.sort(function (a, b) { return b.docs - a.docs || b.total - a.total; });
      // Collapse redundant word/phrase pairs. Only the high-frequency head can
      // hold visible duplicates (a word ranks at least as high as any phrase it
      // contains), so collapsing a generous prefix and keeping the tail is enough.
      var HEAD = Math.max(topN * 3, 400);
      list = collapseGrams(list.slice(0, HEAD), function (e) { return e.w; }, function (e) { return e.docs; }).concat(list.slice(HEAD));
      list = list.slice(0, topN);
      if (!list.length) { out.innerHTML = '<div class="text-muted">No notable words or phrases in that slice.</div>'; return; }
      var metaHtml = '<div class="kw-meta">' + rows.length + " questions with answer “" + esc(word) + "” · " + (range.power ? "before (*)" : range.lo + "–" + range.hi + "%") + " · words + phrases</div>";
      var filters = filterQs();
      var thead = '<thead><tr><th></th><th>#</th><th>Word / phrase</th><th>Questions</th><th>Total uses</th><th title="Of all questions using this word in the slice, how many are answered by the searched answer">P(→ ' + esc(word.length > 18 ? word.slice(0, 17) + "…" : word) + ")</th></tr></thead>";
      kfPaginate(out, metaHtml, thead, list, function (e, i) {
        return "<tr><td>" + kfStarHtml(e.w, word) + "</td><td>" + (i + 1) + '</td><td class="kw-word" data-w="' + esc(e.w) + '">' + esc(e.w) + "</td><td>" + e.docs + "</td><td>" + e.total + '</td><td class="kw-prob" data-w="' + esc(e.w) + '">…</td></tr>';
      }, function (o) {
        fillKeywordProbs(o, word, range, filters);
        o.querySelectorAll(".kw-word").forEach(function (td) {
          td.addEventListener("click", function () { crossSearch("words", td.dataset.w); });
          var tr = td.parentElement;
          if (tr) tr.oncontextmenu = function (ev) {
            if (!window.QB || !QB.contextMenu) return;
            ev.preventDefault();
            var w = td.dataset.w;
            var items = [{ label: "Top answers for this word (here)", onClick: function () { crossSearch("words", w); } }];
            if (ctx.host && ctx.host.searchDatabase) items.push({ label: "Find questions containing it (Database)", onClick: function () { ctx.host.searchDatabase({ query: w, field: "question", exact: true, qtype: "tossup" }); } });
            items.push({ sep: true });
            items.push({ label: "Star / unstar", onClick: function () { var s = tr.querySelector(".kw-starx"); if (s) s.click(); } });
            items.push({ label: "Add to review / folder…", onClick: function () { kfAdd(w, word, tr.querySelector(".kw-foldx") || tr); } });
            QB.contextMenu(ev.clientX, ev.clientY, items, { title: w + " → " + word });
          };
        });
        wireKFStars(o);
      });
    }

    // mode 2: word → top answers whose questions use it (within the slice)
    function kfLev1(a, b) {
      if (a === b) return true;
      var la = a.length, lb = b.length;
      if (Math.abs(la - lb) > 1 || Math.min(la, lb) < 4) return false;
      var i = 0, j = 0, edits = 0;
      while (i < la && j < lb) {
        if (a[i] === b[j]) { i++; j++; continue; }
        if (++edits > 1) return false;
        if (la === lb) { i++; j++; } else if (la > lb) { i++; } else { j++; }
      }
      return edits + (la - i) + (lb - j) <= 1;
    }
    function renderAnswers(rows, word, hintSeqs, range, topN, out) {
      // hintSeqs: one token-sequence per comma-separated hint. A question only
      // counts when EVERY hint appears (adjacent) inside the slice, so the
      // percentages are P(answer | all hints together).
      var counts = {}, display = {}, total = 0;
      var matched = []; // slice-passing rows, kept for the booster-hint search
      rows.forEach(function (q) {
        var slice = sliceWords(q, range);
        for (var i = 0; i < hintSeqs.length; i++) if (!sliceHasSeq(slice, hintSeqs[i])) return;
        var main = mainAnswer(q.answer_sanitized);
        if (!main) return;
        total++;
        var key = main.toLowerCase();
        counts[key] = (counts[key] || 0) + 1;
        if (!display[key]) display[key] = main;
        matched.push({ slice: slice, akey: key });
      });
      var list = Object.keys(counts).map(function (k) { return { key: k, a: display[k], n: counts[k] }; });
      list.sort(function (x, y) { return y.n - x.n; });
      // Merge spelling/transliteration variants (Baldr/Balder/Baldur) so the
      // probability isn't fragmented across near-identical answers.
      var reps = [];
      list.forEach(function (e) {
        for (var i = 0; i < reps.length; i++) if (kfLev1(reps[i].key, e.key)) { reps[i].n += e.n; return; }
        reps.push(e);
      });
      list = reps.sort(function (x, y) { return y.n - x.n; }).slice(0, topN);
      if (!list.length) { out.innerHTML = '<div class="text-muted">“' + esc(word) + "” not found in that slice.</div>"; return; }
      var hintLabel = hintSeqs.map(function (s) { return s.join(" "); }).join(" + ");
      var metaHtml = '<div class="kw-meta">P(answer | ' + esc(hintLabel) + ") · " + total + " matching question" + (total === 1 ? "" : "s") + " · " + (range.power ? "before (*)" : range.lo + "–" + range.hi + "%") +
        (total && total < 5 ? ' · <span style="color:var(--yellow)">small sample</span>' : "") + "</div>";
      // ── Booster hints: find a SMALL extra hint that raises P(answer) ──
      // Candidates come from the target answer's own matched questions; the
      // combined probability is computed from the rows we already have, and the
      // candidate's "alone" strength via one small search each — the best
      // booster is weak alone but strong together.
      function findBooster(targetKey, targetDisp, baseN) {
        var baseP = total ? baseN / total : 0;
        document.querySelector(".kw-boost-overlay") && document.querySelector(".kw-boost-overlay").remove();
        var ov = document.createElement("div");
        ov.className = "qb-overlay kw-boost-overlay";
        ov.innerHTML = '<div class="kw-boost-card"><div class="kw-boost-title">Booster hints for “' + esc(targetDisp) + '”<span class="qb-info" data-tip="Smaller “alone” % = subtler hint. Click one to re-search with it added.">i</span></div>' +
          '<div class="kw-meta">' + esc(hintSeqs.map(function (s) { return s.join(" "); }).join(" + ")) + " alone → " + Math.round(100 * baseP) + "% (" + baseN + "/" + total + ")</div>" +
          '<div class="kw-boost-body">' + loadBar("Scoring candidate hints…") + "</div>" +
          '<div style="text-align:right;margin-top:10px"><button class="btn btn-sm kw-boost-close">Close</button></div></div>';
        ov.addEventListener("click", function (ev) { if (ev.target === ov || ev.target.closest(".kw-boost-close")) ov.remove(); });
        document.body.appendChild(ov);
        var hintTok = {}; hintSeqs.forEach(function (s) { s.forEach(function (t) { hintTok[t] = 1; }); });
        var ansTok = {}; (targetKey.match(/[\p{L}\p{N}'’]+/gu) || []).forEach(function (t) { ansTok[t.replace(/['’]s$/, "")] = 1; });
        var freq = Object.create(null);
        matched.forEach(function (m) {
          if (m.akey !== targetKey) return;
          var seen = {};
          m.slice.forEach(function (w) {
            if (seen[w] || w.length < 3 || STOP[w] || hintTok[w] || ansTok[w] || /^\d+$/.test(w)) return;
            seen[w] = 1; freq[w] = (freq[w] || 0) + 1;
          });
        });
        var scored = Object.keys(freq).sort(function (a, b) { return freq[b] - freq[a]; }).slice(0, 24).map(function (w) {
          var tot = 0, hit = 0;
          matched.forEach(function (m) { if (m.slice.indexOf(w) < 0) return; tot++; if (m.akey === targetKey) hit++; });
          return { w: w, tot: tot, hit: hit, newP: tot ? hit / tot : 0 };
        }).filter(function (s) { return s.tot >= 2 && s.newP > baseP + 0.05; })
          .sort(function (a, b) { return b.newP - a.newP || b.tot - a.tot; }).slice(0, 6);
        if (!scored.length) { ov.querySelector(".kw-boost-body").innerHTML = '<div class="text-muted">No booster hints found.</div>'; return; }
        var filters = filterQs();
        var targetTokens = (targetDisp.toLowerCase().match(/[\p{L}\p{N}'’]+/gu) || []).map(function (t) { return t.replace(/['’]s$/, ""); });
        var done = 0;
        scored.forEach(function (s) {
          keywordProb(s.w, targetTokens, range, filters, function (r) {
            s.aloneP = r && r.total ? r.p : 0;
            s.aloneN = r ? r.total : 0;
            if (++done === scored.length) {
              // best booster: biggest gain over what the word gives away alone
              scored.sort(function (a, b) { return (b.newP - b.aloneP) - (a.newP - a.aloneP); });
              var bb = ov.querySelector(".kw-boost-body");
              if (!bb) return;
              bb.innerHTML = scored.map(function (x) {
                  return '<div class="kw-boost-row" data-w="' + esc(x.w) + '"><strong>+ ' + esc(x.w) + "</strong>" +
                    '<span class="kw-boost-nums">alone ' + Math.round(100 * x.aloneP) + "% → together <strong>" + Math.round(100 * x.newP) + "%</strong> (" + x.hit + "/" + x.tot + ")</span></div>";
                }).join("");
              bb.querySelectorAll(".kw-boost-row").forEach(function (rw) {
                rw.onclick = function () {
                  ov.remove();
                  var input = document.querySelector("#kw-input");
                  if (input) { input.value = hintSeqs.map(function (sq) { return sq.join(" "); }).join(", ") + ", " + rw.dataset.w; run(); }
                };
              });
            }
          });
        });
      }

      var thead = '<thead><tr><th></th><th>#</th><th>Answer</th><th>Probability</th><th>Boost</th></tr></thead>';
      kfPaginate(out, metaHtml, thead, list, function (e, i) {
        return "<tr><td>" + kfStarHtml(word, e.a) + "</td><td>" + (i + 1) + '</td><td class="kw-word" data-w="' + esc(e.a) + '">' + esc(e.a) + "</td><td>" + (total ? Math.round(100 * e.n / total) : 0) + "% (" + e.n + "/" + total + ')</td><td><button class="btn btn-sm kw-boost-btn" data-k="' + esc(e.key || e.a.toLowerCase()) + '" data-a="' + esc(e.a) + '" data-n="' + e.n + '" title="Find a small extra hint that raises this probability">⤴ boost</button></td></tr>';
      }, function (o) {
        o.querySelectorAll(".kw-boost-btn").forEach(function (b) {
          b.addEventListener("click", function (ev) { ev.stopPropagation(); findBooster(b.dataset.k, b.dataset.a, parseInt(b.dataset.n, 10) || 0); });
        });
        o.querySelectorAll(".kw-word").forEach(function (td) {
          td.addEventListener("click", function () { crossSearch("answers", td.dataset.w); });
          var tr = td.parentElement;
          if (tr) tr.oncontextmenu = function (ev) {
            if (!window.QB || !QB.contextMenu) return;
            ev.preventDefault();
            var a = td.dataset.w;
            var bb = tr.querySelector(".kw-boost-btn");
            var items = [
              { label: "Find a booster hint", onClick: function () { if (bb) bb.click(); } },
              { label: "Keywords for this answer (here)", onClick: function () { crossSearch("answers", a); } },
            ];
            if (ctx.host && ctx.host.searchDatabase) items.push({ label: "Find questions answered by it (Database)", onClick: function () { ctx.host.searchDatabase({ query: a, field: "answer", exact: false }); } });
            items.push({ sep: true });
            items.push({ label: "Star / unstar", onClick: function () { var s = tr.querySelector(".kw-starx"); if (s) s.click(); } });
            items.push({ label: "Add to review / folder…", onClick: function () { kfAdd(word, a, tr.querySelector(".kw-foldx") || tr); } });
            QB.contextMenu(ev.clientX, ev.clientY, items, { title: a });
          };
        });
        wireKFStars(o);
      });
    }


    // ── Database → Keyword Frequency tab: saved words/phrases/answers ──
    ctx.registerStarredProvider({
      id: "keyword-freq", title: "Keyword Frequency",
      render: function renderSaved(container) {
        var list = starredKF();
        if (!list.length) { container.innerHTML = '<div class="text-muted" style="padding:16px">Nothing saved yet.</div>'; return; }
        var fcOk = true;
        try { if (window.QB && window.QB.getActivePages) fcOk = (window.QB.getActivePages() || []).some(function (p) { return p.id === "flashcards::cards"; }); } catch (e) {}
        var bar = '<div class="db-toolbar"><button class="btn btn-sm btn-primary" id="kf-review"' + (fcOk ? "" : ' disabled title="Needs Flashcards plugin"') + '>▶ Review as flashcards</button>' +
          '<span class="text-muted" style="font-size:11px">' + list.length + " saved</span></div>";
        container.innerHTML = bar + '<table class="stats-table"><thead><tr><th></th><th>When you hear…</th><th>…think</th></tr></thead><tbody>' +
          list.map(function (it, i) {
            return '<tr><td><span class="kw-starx on" data-i="' + i + '" title="Star / unstar">★</span>' + kfAddBtn(it.front, it.back) + '</td><td class="kw-word">' + esc(it.front) + "</td><td><strong>" + esc(it.back) + "</strong></td></tr>";
          }).join("") + "</tbody></table>";
        container.querySelectorAll(".kw-foldx").forEach(function (s) {
          s.addEventListener("click", function () { kfAdd(s.dataset.f, s.dataset.b, s); });
        });
        container.querySelectorAll(".kw-starx").forEach(function (s) {
          s.addEventListener("click", function () {
            // Toggle in place (grey out) instead of instantly removing the row.
            var it = list[parseInt(s.dataset.i)];
            if (!it) return;
            var k = kfKey(it), lst = starredKF();
            var idx = lst.findIndex(function (x) { return kfKey(x) === k; });
            var nowStar;
            if (idx >= 0) { lst.splice(idx, 1); nowStar = false; } else { lst.push(it); nowStar = true; }
            ctx.storage.set("kf-stars", lst);
            s.textContent = nowStar ? "★" : "☆";
            s.classList.toggle("on", nowStar);
            var tr = s.closest("tr"); if (tr) tr.classList.toggle("kw-unstarred", !nowStar);
            if (ctx.playSound) ctx.playSound("star");
          });
        });
        var rv = container.querySelector("#kf-review");
        if (rv) rv.onclick = function () {
          var cards = starredKF().map(function (it) { return { front: it.front, back: it.back, meta: "keyword" }; });
          if (!cards.length) return;
          try { localStorage.setItem("qb-flashcards-cards", JSON.stringify({ cards: cards, ts: Date.now() })); } catch (e) {}
          var ok = window.QB && window.QB.showPage && window.QB.showPage("flashcards::cards");
          if (!ok) { try { localStorage.removeItem("qb-flashcards-cards"); } catch (e) {} ctx.toast("Enable the Flashcards plugin first", "error"); }
        };
      },
    });

    ctx.toast("Keyword Frequency enabled.");
  }
