function __qbMain(ctx) {
    var body = null, page = null;

    function esc(s) { return (s == null ? "" : String(s)).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
    function loadBar(label) { return (window.QB && QB.loadingBarHtml) ? QB.loadingBarHtml(label) : '<div class="text-muted">' + esc(label) + "</div>"; }
    function loadBarDet(label, frac) {
      var pct = Math.max(0, Math.min(100, Math.round((frac || 0) * 100)));
      return '<div class="qb-loading"><div class="qb-loadbar det"><div class="qb-loadbar-fill" style="width:' + pct + '%"></div></div><span>' + esc(label) + "</span></div>";
    }

    var STOP = {};
    ("a an the this that these those it its his her hers he she they them their theirs we us our you your i me my mine of in on at to for from with within without by as is are was were be been being am do does did done not no nor so or and but if then than because while during after before until once when where which who whom whose what why how all any both each few more most other some such only own same here there over under again further about above below between into through against up down out off very can will just should now points point name names named ftp identify gives give given made make makes making one two three four five six seven eight nine ten first second third often called also another may might must shall many much work works worked title titled known includes including include described describes describe used uses use using like unlike along man woman men women person people city country state nation work novel poem play opera symphony war battle king queen god goddess").split(/\s+/).forEach(function (w) { STOP[w] = 1; });

    var ALT_SUBCATS = {
      "Other Science": ["Astronomy", "Computer Science", "Earth Science", "Engineering", "Math", "Misc Science"],
      "Other Literature": ["Drama", "Long Fiction", "Poetry", "Short Fiction", "Misc Literature"],
      "Other Fine Arts": ["Architecture", "Dance", "Film", "Jazz", "Musicals", "Opera", "Photography", "Misc Arts"],
      "Social Science": ["Anthropology", "Economics", "Linguistics", "Psychology", "Sociology", "Other Social Science"],
    };

    page = ctx.registerPage({
      id: "kwfreq", navLabel: "Keyword Frequency", title: "KEYWORD FREQUENCY",
      onShow: function (el) { body = el; if (!body.querySelector("#kw-input")) render(); },
    });
    function active() { return page && page.screenEl && page.screenEl.classList.contains("active"); }

    // Esc walks back through searches (e.g. "titration" → click "technique" →
    // Esc returns to "titration"); with nothing left, the app navigates back.
    var viewStack = [], curView = null, restoringView = false;
    ctx.onBack(function () {
      if (!active() || !viewStack.length || !body) return false;
      var v = viewStack.pop();
      curView = null;          // re-set by run() without re-pushing
      restoringView = true;
      try {
        var ms = body.querySelector("#kw-mode");
        ms.value = v.mode;
        ms.dispatchEvent(new Event("change"));
        body.querySelector("#kw-input").value = v.term;
        run();
      } finally { restoringView = false; }
      return true;
    });

    function pctRange() {
      var r = ctx.storage.get("range") || { lo: 0, hi: 100 };
      return { lo: Math.min(r.lo, r.hi), hi: Math.max(r.lo, r.hi), power: !!ctx.storage.get("powerOnly") };
    }
    function mainAnswer(sani) { return (sani || "").split(/[\[(]/)[0].trim().replace(/[;:,.]+$/, ""); }
    // ── saved words/phrases/answers (★ to review later as flashcards) ──
    function starredKF() { return ctx.storage.get("kf-stars") || []; }
    function kfKey(it) { return (it.front || "") + "" + (it.back || ""); }
    function isKFStarred(it) { var k = kfKey(it); return starredKF().some(function (x) { return kfKey(x) === k; }); }
    function kfAddBtn(front, back) {
      if (!((ctx.host && ctx.host.openItemSaveMenu) || window.QBFolders)) return "";
      return '<span class="kw-foldx" data-f="' + esc(front) + '" data-b="' + esc(back) + '" title="Add to review / folder">+</span>';
    }
    function kfAdd(front, back, anchor) {
      var spec = { review: { kind: "keyword", front: front, back: back, meta: "keyword" }, folder: { type: "keywords", item: { front: front, back: back } } };
      if (ctx.host && ctx.host.openItemSaveMenu) ctx.host.openItemSaveMenu(spec, anchor);
      else if (window.QBFolders) window.QBFolders.pick("keywords", spec.folder.item, anchor);
    }
    function kfStarHtml(front, back) { var st = isKFStarred({ front: front, back: back }); return '<span class="kw-starx' + (st ? " on" : "") + '" data-f="' + esc(front) + '" data-b="' + esc(back) + '" title="Save to review later">' + (st ? "★" : "☆") + "</span>" + kfAddBtn(front, back); }
    function wireKFStars(out) {
      out.querySelectorAll(".kw-starx").forEach(function (s) {
        s.addEventListener("click", function (ev) {
          ev.stopPropagation();
          var it = { front: s.dataset.f, back: s.dataset.b };
          var lst = starredKF(), k = kfKey(it), idx = lst.findIndex(function (x) { return kfKey(x) === k; });
          if (idx >= 0) lst.splice(idx, 1); else lst.push(it);
          ctx.storage.set("kf-stars", lst);
          if (ctx.playSound) ctx.playSound("star");
          var on = idx < 0; s.textContent = on ? "★" : "☆"; s.classList.toggle("on", on);
        });
      });
      out.querySelectorAll(".kw-foldx").forEach(function (s) {
        s.addEventListener("click", function (ev) { ev.stopPropagation(); kfAdd(s.dataset.f, s.dataset.b, s); });
      });
    }
    function kfPaginate(out, metaHtml, theadHtml, list, rowFn, afterRender) {
      var PAGE = 50, page = 0;
      function paint() {
        var pages = Math.max(1, Math.ceil(list.length / PAGE));
        if (page >= pages) page = pages - 1;
        if (page < 0) page = 0;
        var start = page * PAGE, slice = list.slice(start, start + PAGE);
        out.innerHTML = metaHtml + '<table class="stats-table">' + theadHtml + "<tbody>" +
          slice.map(function (e, j) { return rowFn(e, start + j); }).join("") + "</tbody></table>" +
          (pages > 1 ? '<div class="kw-pager"><button class="btn btn-sm" id="kw-prev"' + (page === 0 ? " disabled" : "") + '>‹ Prev</button><span class="kw-meta">Page ' + (page + 1) + " of " + pages + '</span><button class="btn btn-sm" id="kw-next"' + (page >= pages - 1 ? " disabled" : "") + '>Next ›</button></div>' : "");
        if (afterRender) afterRender(out);
        var pv = out.querySelector("#kw-prev"), nx = out.querySelector("#kw-next");
        if (pv) pv.onclick = function () { page--; paint(); };
        if (nx) nx.onclick = function () { page++; paint(); };
      }
      paint();
    }

    async function render() {
      var diffBoxes = "";
      for (var d = 0; d <= 10; d++) diffBoxes += '<label class="kw-diff"><input type="checkbox" class="kw-diff-cb" value="' + d + '">' + d + "</label>";
      var r = ctx.storage.get("range") || { lo: 0, hi: 100 };
      body.innerHTML =
        '<div class="kw-wrap">' +
          '<div class="kw-card">' +
            '<div class="kw-row">' +
              '<select id="kw-mode" class="mode-input kw-sel" style="flex:0 0 auto;min-width:240px">' +
                '<option value="answers">Search an answer (finds keywords)</option>' +
                '<option value="words">Search a word (finds top answers)</option>' +
                '<option value="reverse">Search an answer (finds leading words)</option>' +
              "</select>" +
              '<input type="text" id="kw-input" class="mode-input" placeholder="Search answers\u2026" autocomplete="off" autocorrect="off" spellcheck="false" style="flex:1;min-width:180px">' +
              '<select id="kw-x" class="mode-input hidden" style="flex:0 0 auto;width:150px" title="The answer must rank in each word\u2019s top X answers">' +
                '<option value="1">in top 1</option><option value="2" selected>in top 2</option><option value="3">in top 3</option><option value="5">in top 5</option><option value="10">in top 10</option>' +
              "</select>" +
              '<select id="kw-top" class="mode-input" style="flex:0 0 auto;width:110px">' +
                '<option value="10">Top 10</option><option value="20">Top 20</option><option value="50" selected>Top 50</option><option value="100">Top 100</option><option value="200">Top 200</option><option value="500">Top 500</option><option value="1000">Top 1000</option>' +
              "</select>" +
              '<button class="btn btn-primary" id="kw-go">Search</button>' +
            "</div>" +
            '<div class="kw-row">' +
              '<select id="kw-cat" class="mode-input kw-sel"><option value="">All categories</option></select>' +
              '<select id="kw-sub" class="mode-input kw-sel" disabled><option value="">All subcategories</option></select>' +
              '<select id="kw-alt" class="mode-input kw-sel" disabled><option value="">All alternate subcategories</option></select>' +
            "</div>" +
            '<div class="kw-row"><span class="kw-label">Difficulty</span>' + diffBoxes + "</div>" +
            '<div class="kw-row"><span class="kw-label">Years</span>' +
              '<div class="dual-range kw-dual"><div class="dual-range-track"><div class="dual-range-fill" id="kw-yfill"></div></div>' +
                '<input type="range" id="kw-ymin" min="2000" max="2026" value="2000">' +
                '<input type="range" id="kw-ymax" min="2000" max="2026" value="2026"></div>' +
              '<span class="kw-label" id="kw-year-val" style="min-width:84px;text-align:right"></span>' +
            "</div>" +
            '<div class="kw-row"><span class="kw-label">Question range</span>' +
              '<div class="dual-range kw-dual"><div class="dual-range-track"><div class="dual-range-fill" id="kw-fill"></div></div>' +
                '<input type="range" id="kw-lo" min="0" max="100" step="5" value="' + r.lo + '">' +
                '<input type="range" id="kw-hi" min="0" max="100" step="5" value="' + r.hi + '"></div>' +
              '<span class="kw-label" id="kw-range-val" style="min-width:84px;text-align:right"></span>' +
              '<label class="kw-diff" style="margin-left:8px" title="Only text BEFORE the (*) powermark counts; questions without a powermark are skipped. Disables the % range."><input type="checkbox" id="kw-power"' + (r.power ? " checked" : "") + "> Before power only</label>" +
            "</div>" +
          "</div>" +
          '<div class="kw-card" id="kw-results"><div class="text-muted">Pick a mode and search.</div></div>' +
        "</div>";

      try {
        var cats = (await ctx.api.get("/api/categories?type=tossups")).categories || [];
        var catSel = body.querySelector("#kw-cat");
        cats.forEach(function (c) { var o = document.createElement("option"); o.value = c.category; o.textContent = c.category; catSel.appendChild(o); });
      } catch (e) {}
      var catSel2 = body.querySelector("#kw-cat"), subSel = body.querySelector("#kw-sub"), altSel = body.querySelector("#kw-alt");
      catSel2.addEventListener("change", async function () {
        subSel.innerHTML = '<option value="">All subcategories</option>';
        altSel.innerHTML = '<option value="">All alternate subcategories</option>';
        altSel.disabled = true;
        if (!catSel2.value) { subSel.disabled = true; return; }
        if (catSel2.value === "Social Science") {
          ALT_SUBCATS["Social Science"].forEach(function (a) { var o = document.createElement("option"); o.value = a; o.textContent = a; subSel.appendChild(o); });
          subSel.disabled = false; return;
        }
        try {
          var subs = (await ctx.api.get("/api/subcategories?type=tossups&category=" + encodeURIComponent(catSel2.value))).subcategories || [];
          subs.forEach(function (x) { var o = document.createElement("option"); o.value = x.subcategory; o.textContent = x.subcategory; subSel.appendChild(o); });
          subSel.disabled = !subs.length;
        } catch (e) { subSel.disabled = true; }
      });
      subSel.addEventListener("change", function () {
        altSel.innerHTML = '<option value="">All alternate subcategories</option>';
        var alts = (catSel2.value !== "Social Science" && /^Other /.test(subSel.value)) ? ALT_SUBCATS[subSel.value] : null;
        if (alts) { alts.forEach(function (a) { var o = document.createElement("option"); o.value = a; o.textContent = a; altSel.appendChild(o); }); altSel.disabled = false; }
        else altSel.disabled = true;
      });

      function wireDual(loId, hiId, fillId, valId, save, min, max, fmt) {
        var lo = body.querySelector("#" + loId), hi = body.querySelector("#" + hiId);
        function paint() {
          var a = parseInt(lo.value), b = parseInt(hi.value);
          var mn = Math.min(a, b), mx = Math.max(a, b);
          if (save) save(mn, mx);
          body.querySelector("#" + valId).textContent = fmt(mn, mx);
          var fill = body.querySelector("#" + fillId);
          if (fill) { fill.style.left = ((mn - min) / (max - min)) * 100 + "%"; fill.style.right = ((max - mx) / (max - min)) * 100 + "%"; }
        }
        lo.addEventListener("input", paint); hi.addEventListener("input", paint); paint();
      }
      wireDual("kw-lo", "kw-hi", "kw-fill", "kw-range-val", function (a, b) { ctx.storage.set("range", { lo: a, hi: b }); }, 0, 100, function (a, b) { return a + "% – " + b + "%"; });
      var kpw = body.querySelector("#kw-power");
      function syncPowerUI() {
        var on = !!(kpw && kpw.checked);
        ["kw-lo", "kw-hi"].forEach(function (id) { var el = body.querySelector("#" + id); if (el) el.disabled = on; });
        var fill = body.querySelector("#kw-fill"); if (fill && fill.closest(".dual-range")) fill.closest(".dual-range").style.opacity = on ? "0.35" : "";
        var rv = body.querySelector("#kw-range-val"); if (rv && on) rv.textContent = "before (*)";
        else if (rv && !on) { var rr = pctRange(); rv.textContent = rr.lo + "% – " + rr.hi + "%"; }
      }
      if (kpw) { kpw.onchange = function () { ctx.storage.set("powerOnly", kpw.checked); syncPowerUI(); }; syncPowerUI(); }
      wireDual("kw-ymin", "kw-ymax", "kw-yfill", "kw-year-val", null, 2000, 2026, function (a, b) { return a + " – " + b; });

      var go = function () { run(); };
      body.querySelector("#kw-go").onclick = go;
      body.querySelector("#kw-input").addEventListener("keydown", function (e) { if (e.key === "Enter") go(); });
      var modeSel = body.querySelector("#kw-mode");
      function syncPlaceholder() {
        var rev = modeSel.value === "reverse";
        body.querySelector("#kw-input").placeholder = modeSel.value === "words" ? "Search words\u2026 (comma = require all, e.g. mistletoe, blind)" : "Search answers\u2026";
        var xs = body.querySelector("#kw-x"); if (xs) xs.classList.toggle("hidden", !rev);
        var tn = body.querySelector("#kw-top"); if (tn) tn.classList.toggle("hidden", rev);
      }
      modeSel.addEventListener("change", syncPlaceholder);
      syncPlaceholder();
    }

    function filterQs() {
      var cat = body.querySelector("#kw-cat").value;
      var sub = body.querySelector("#kw-sub").value;
      var alt = body.querySelector("#kw-alt").value;
      if (cat === "Social Science" && sub) { alt = sub; sub = ""; }
      var diffs = [].slice.call(body.querySelectorAll(".kw-diff-cb:checked")).map(function (c) { return c.value; });
      var ya = parseInt(body.querySelector("#kw-ymin").value), yb = parseInt(body.querySelector("#kw-ymax").value);
      var ymin = Math.min(ya, yb), ymax = Math.max(ya, yb);
      return (cat ? "&categories=" + encodeURIComponent(cat) : "") +
        (sub ? "&subcategories=" + encodeURIComponent(sub) : "") +
        (alt ? "&alternateSubcategories=" + encodeURIComponent(alt) : "") +
        (diffs.length ? "&difficulties=" + diffs.join(",") : "") +
        (ymin > 2000 ? "&yearMin=" + ymin : "") + (ymax < 2026 ? "&yearMax=" + ymax : "");
    }

    function crossSearch(mode, term) {
      var ms = body.querySelector("#kw-mode");
      ms.value = mode;
      ms.dispatchEvent(new Event("change"));
      body.querySelector("#kw-input").value = term;
      run();
    }

    async function run() {
      var word = (body.querySelector("#kw-input").value || "").trim();
      var mode = body.querySelector("#kw-mode").value;
      var topN = parseInt(body.querySelector("#kw-top").value) || 50;
      var out = body.querySelector("#kw-results");
      if (!word) { out.innerHTML = '<div class="text-muted">Type something first.</div>'; return; }
      if (!restoringView && curView && (curView.term !== word || curView.mode !== mode)) viewStack.push(curView);
      curView = { mode: mode, term: word };
      out.innerHTML = loadBar("Searching…");

      if (mode === "reverse") { await runReverse(word, pctRange(), out); return; }
      // Tokenize the typed term EXACTLY like sliceWords does (keep internal
      // apostrophes, strip a trailing possessive 's). Otherwise a word such as
      // "o'brien" / "coup d'état" splits into pieces that never match the slice
      // tokens — searches fail here, and Buzz Words numbers wouldn't reproduce.
      // Comma-separated input = multiple hints that must ALL appear ("words"
      // mode). Each hint is tokenized separately; the FTS query ANDs every token.
      var hints = word.split(",").map(function (h) { return h.trim(); }).filter(Boolean);
      var hintSeqs = hints.map(function (h) {
        return (h.match(/[\p{L}\p{N}'’]+/gu) || []).map(function (t) { return t.toLowerCase().replace(/['’]s$/, ""); }).filter(Boolean);
      }).filter(function (s) { return s.length; });
      var tokens = [];
      hintSeqs.forEach(function (s) { s.forEach(function (t) { tokens.push(t); }); });
      if (!tokens.length) { out.innerHTML = '<div class="text-muted">Nothing searchable in that.</div>'; return; }
      var quoted = tokens.map(function (t) { return '"' + t + '"'; }).join(" ");
      var col = mode === "answers" ? "answer_sanitized" : "question_sanitized";
      var url = "/api/tossups/search?query=" + encodeURIComponent(col + " : (" + quoted + ")") + "&limit=500" + filterQs();

      var rows = [];
      try { rows = (await ctx.api.get(url)).rows || []; } catch (e) {
        out.innerHTML = '<div class="text-muted">Search failed: ' + esc(e.message || e) + "</div>"; return;
      }
      if (!rows.length) { out.innerHTML = '<div class="text-muted">No matching questions.</div>'; return; }

      var range = pctRange();
      if (mode === "answers") renderKeywords(rows, word, tokens, range, topN, out);
      else renderAnswers(rows, word, hintSeqs, range, topN, out);
    }

    // Reverse: given an ANSWER, find clue-words whose own "top answers" list
    // ranks this answer within the chosen top X. (e.g. chromatography → the
    // word "diffusion", because chromatography is the #1 answer for diffusion.)
    async function runReverse(answer, range, out) {
      var X = parseInt(body.querySelector("#kw-x").value) || 2;
      var targetKey = mainAnswer(answer).toLowerCase();
      var tokens = answer.match(/[\p{L}\p{N}]+/gu) || [];
      if (!tokens.length) { out.innerHTML = '<div class="text-muted">Nothing searchable in that.</div>'; return; }
      var quoted = tokens.map(function (t) { return '"' + t + '"'; }).join(" ");
      out.innerHTML = loadBar("Finding candidate words\u2026");
      var arows = [];
      try { arows = (await ctx.api.get("/api/tossups/search?query=" + encodeURIComponent("answer_sanitized : (" + quoted + ")") + "&limit=500" + filterQs())).rows || []; }
      catch (e) { out.innerHTML = '<div class="text-muted">Search failed: ' + esc(e.message || e) + "</div>"; return; }
      if (!arows.length) { out.innerHTML = '<div class="text-muted">No questions have that answer.</div>'; return; }
      // candidate clue words from those questions, by document frequency
      var freq = {};
      arows.forEach(function (q) {
        var seen = {};
        sliceWords(q, range).forEach(function (w) {
          w = w.replace(/['\u2019]s$/, "");
          if (w.length < 3 || STOP[w] || /^\d+$/.test(w)) return;
          if (!seen[w]) { seen[w] = 1; freq[w] = (freq[w] || 0) + 1; }
        });
      });
      var candidates = Object.keys(freq).sort(function (a, b) { return freq[b] - freq[a]; }).slice(0, 25);
      if (!candidates.length) { out.innerHTML = '<div class="text-muted">No candidate words in that slice.</div>'; return; }
      var results = [];
      for (var ci = 0; ci < candidates.length; ci++) {
        out.innerHTML = loadBarDet("Checking words\u2026 " + (ci + 1) + "/" + candidates.length, (ci + 1) / candidates.length);
        var w = candidates[ci];
        var wrows = [];
        try { wrows = (await ctx.api.get("/api/tossups/search?query=" + encodeURIComponent('question_sanitized : ("' + w + '")') + "&limit=300" + filterQs())).rows || []; }
        catch (e) { continue; }
        var counts = {};
        wrows.forEach(function (q) {
          if (sliceWords(q, range).indexOf(w) < 0) return;
          var m = mainAnswer(q.answer_sanitized); if (!m) return;
          var k = m.toLowerCase(); counts[k] = (counts[k] || 0) + 1;
        });
        var ranked = Object.keys(counts).sort(function (a, b) { return counts[b] - counts[a]; });
        var rank = ranked.indexOf(targetKey) + 1;
        if (rank >= 1 && rank <= X) results.push({ word: w, rank: rank, total: ranked.length });
      }
      results.sort(function (a, b) { return a.rank - b.rank; });
      if (!results.length) { out.innerHTML = '<div class="kw-meta">No leading words found \u2014 try a larger top-X or a wider question range.</div>'; return; }
      out.innerHTML =
        '<div class="kw-meta">words whose top ' + X + ' answers include \u201c' + esc(answer) + "\u201d \u00b7 " + range.lo + "\u2013" + range.hi + "%</div>" +
        '<table class="stats-table"><thead><tr><th>#</th><th>Word</th><th>Rank of answer</th></tr></thead><tbody>' +
        results.map(function (e, i) {
          return "<tr><td>" + (i + 1) + '</td><td class="kw-word" data-w="' + esc(e.word) + '">' + esc(e.word) + "</td><td>#" + e.rank + " of " + e.total + "</td></tr>";
        }).join("") + "</tbody></table>";
      out.querySelectorAll(".kw-word").forEach(function (td) {
        td.addEventListener("click", function () { crossSearch("words", td.dataset.w); });
      });
    }

    function sliceWords(q, range) {
      var text = q.question_sanitized || "";
      if (range && range.power) {
        // "Before power" mode: only pre-(*) text counts; unmarked questions are excluded.
        var pi = text.indexOf("(*)");
        if (pi < 0) return [];
        return (text.slice(0, pi).toLowerCase().match(/[\p{L}\p{N}'’]+/gu) || [])
          .map(function (w) { return w.replace(/['’]s$/, ""); });
      }
      var words = (text.replace(/\(\*\)/g, " ").toLowerCase().match(/[\p{L}\p{N}'’]+/gu) || [])
        .map(function (w) { return w.replace(/['’]s$/, ""); });
      var n = words.length; if (!n) return [];
      var a = Math.round((range.lo / 100) * n), b = Math.round((range.hi / 100) * n);
      return words.slice(a, Math.max(a + 1, b));
    }
    // Does the slice contain the token sequence CONSECUTIVELY? (phrase match)
    function sliceHasSeq(slice, seq) {
      if (!seq.length) return false;
      if (seq.length === 1) return slice.indexOf(seq[0]) >= 0;
      for (var i = 0; i + seq.length <= slice.length; i++) {
        var ok = true;
        for (var j = 0; j < seq.length; j++) { if (slice[i + j] !== seq[j]) { ok = false; break; } }
        if (ok) return true;
      }
      return false;
    }
    // Is shortArr a contiguous run inside longArr?
    function containsSeq(longArr, shortArr) {
      if (shortArr.length > longArr.length) return false;
      for (var i = 0; i + shortArr.length <= longArr.length; i++) {
        var ok = true;
        for (var k = 0; k < shortArr.length; k++) { if (longArr[i + k] !== shortArr[k]) { ok = false; break; } }
        if (ok) return true;
      }
      return false;
    }
    // Collapse word/phrase redundancy: when a longer gram that CONTAINS a shorter
    // one appears in >=80% of the shorter gram's questions, the shorter is
    // redundant (almost always part of that phrase) — drop it, keep the phrase.
    // So "carothers" + "carothers equation" with equal counts shows only the
    // phrase, while a common word like "equation" (which the phrase covers only a
    // little of) is kept. keyOf -> gram string, docOf -> its question count.
    function collapseGrams(items, keyOf, docOf) {
      var toks = items.map(function (it) { return keyOf(it).split(" "); });
      var drop = {};
      for (var i = 0; i < items.length; i++) {
        var sd = docOf(items[i]); if (!sd) continue;
        for (var j = 0; j < items.length; j++) {
          if (i === j) continue;
          if (toks[j].length <= toks[i].length) continue;
          if (!containsSeq(toks[j], toks[i])) continue;
          if (docOf(items[j]) >= 0.8 * sd) { drop[keyOf(items[i])] = 1; break; }
        }
      }
      return items.filter(function (it) { return !drop[keyOf(it)]; });
    }
    // Unigrams + bigrams + trigrams from a slice. Multi-word grams must NOT
    // start/end on a stop word (so 'hello world' counts but 'of the' doesn't),
    // and skip grams touching the searched answer's own words.
    function gramsOf(words, skip) {
      var out = [];
      var clean = words.map(function (w) { return w.replace(/['’]s$/, ""); });
      for (var i = 0; i < clean.length; i++) {
        var w = clean[i];
        if (w.length >= 3 && !STOP[w] && !skip[w] && !/^\d+$/.test(w)) out.push(w); // unigram
        for (var L = 2; L <= 3; L++) {
          if (i + L > clean.length) break;
          var gram = clean.slice(i, i + L);
          var first = gram[0], last = gram[L - 1];
          if (STOP[first] || STOP[last]) continue;
          if (gram.some(function (g) { return skip[g] || /^\d+$/.test(g) || g.length < 2; })) continue;
          out.push(gram.join(" "));
        }
      }
      return out;
    }

    // mode 1: answer → top keywords in its questions
    function renderKeywords(rows, word, tokens, range, topN, out) {
      var searchWords = {};
      tokens.forEach(function (t) { searchWords[t.toLowerCase()] = 1; });
      var totals = {}, docs = {};
      rows.forEach(function (q) {
        var skip = {};
        Object.keys(searchWords).forEach(function (w) { skip[w] = 1; });
        ((q.answer_sanitized || "").toLowerCase().match(/[\p{L}\p{N}'’]+/gu) || []).forEach(function (w) { skip[w.replace(/['’]s$/, "")] = 1; });
        var seen = {};
        gramsOf(sliceWords(q, range), skip).forEach(function (g) {
          totals[g] = (totals[g] || 0) + 1;
          if (!seen[g]) { seen[g] = 1; docs[g] = (docs[g] || 0) + 1; }
        });
      });
      // A phrase only earns its place if it recurs (≥2 questions) — otherwise
      // single-word keywords dominate, which is right.
      var list = Object.keys(totals).map(function (w) { return { w: w, total: totals[w], docs: docs[w], phrase: w.indexOf(" ") >= 0 }; })
        .filter(function (e) { return !e.phrase || e.docs >= 2; });
      list.sort(function (a, b) { return b.docs - a.docs || b.total - a.total; });
      // Collapse redundant word/phrase pairs. Only the high-frequency head can
      // hold visible duplicates (a word ranks at least as high as any phrase it
      // contains), so collapsing a generous prefix and keeping the tail is enough.
      var HEAD = Math.max(topN * 3, 400);
      list = collapseGrams(list.slice(0, HEAD), function (e) { return e.w; }, function (e) { return e.docs; }).concat(list.slice(HEAD));
      list = list.slice(0, topN);
      if (!list.length) { out.innerHTML = '<div class="text-muted">No notable words or phrases in that slice.</div>'; return; }
      var metaHtml = '<div class="kw-meta">' + rows.length + " questions with answer “" + esc(word) + "” · " + (range.power ? "before (*)" : range.lo + "–" + range.hi + "%") + " · words + phrases</div>";
      var thead = '<thead><tr><th></th><th>#</th><th>Word / phrase</th><th>Questions</th><th>Total uses</th></tr></thead>';
      kfPaginate(out, metaHtml, thead, list, function (e, i) {
        return "<tr><td>" + kfStarHtml(e.w, word) + "</td><td>" + (i + 1) + '</td><td class="kw-word" data-w="' + esc(e.w) + '">' + esc(e.w) + "</td><td>" + e.docs + "</td><td>" + e.total + "</td></tr>";
      }, function (o) {
        o.querySelectorAll(".kw-word").forEach(function (td) {
          td.addEventListener("click", function () { crossSearch("words", td.dataset.w); });
          var tr = td.parentElement;
          if (tr) tr.oncontextmenu = function (ev) {
            if (!window.QB || !QB.contextMenu) return;
            ev.preventDefault();
            var w = td.dataset.w;
            var items = [{ label: "Top answers for this word (here)", onClick: function () { crossSearch("words", w); } }];
            if (ctx.host && ctx.host.searchDatabase) items.push({ label: "Find questions containing it (Database)", onClick: function () { ctx.host.searchDatabase({ query: w, field: "question", exact: true, qtype: "tossup" }); } });
            items.push({ sep: true });
            items.push({ label: "Star / unstar", onClick: function () { var s = tr.querySelector(".kw-starx"); if (s) s.click(); } });
            items.push({ label: "Add to review / folder…", onClick: function () { kfAdd(w, word, tr.querySelector(".kw-foldx") || tr); } });
            QB.contextMenu(ev.clientX, ev.clientY, items, { title: w + " → " + word });
          };
        });
        wireKFStars(o);
      });
    }

    // mode 2: word → top answers whose questions use it (within the slice)
    function kfLev1(a, b) {
      if (a === b) return true;
      var la = a.length, lb = b.length;
      if (Math.abs(la - lb) > 1 || Math.min(la, lb) < 4) return false;
      var i = 0, j = 0, edits = 0;
      while (i < la && j < lb) {
        if (a[i] === b[j]) { i++; j++; continue; }
        if (++edits > 1) return false;
        if (la === lb) { i++; j++; } else if (la > lb) { i++; } else { j++; }
      }
      return edits + (la - i) + (lb - j) <= 1;
    }
    function renderAnswers(rows, word, hintSeqs, range, topN, out) {
      // hintSeqs: one token-sequence per comma-separated hint. A question only
      // counts when EVERY hint appears (adjacent) inside the slice, so the
      // percentages are P(answer | all hints together).
      var counts = {}, display = {}, total = 0;
      rows.forEach(function (q) {
        var slice = sliceWords(q, range);
        for (var i = 0; i < hintSeqs.length; i++) if (!sliceHasSeq(slice, hintSeqs[i])) return;
        var main = mainAnswer(q.answer_sanitized);
        if (!main) return;
        total++;
        var key = main.toLowerCase();
        counts[key] = (counts[key] || 0) + 1;
        if (!display[key]) display[key] = main;
      });
      var list = Object.keys(counts).map(function (k) { return { key: k, a: display[k], n: counts[k] }; });
      list.sort(function (x, y) { return y.n - x.n; });
      // Merge spelling/transliteration variants (Baldr/Balder/Baldur) so the
      // probability isn't fragmented across near-identical answers.
      var reps = [];
      list.forEach(function (e) {
        for (var i = 0; i < reps.length; i++) if (kfLev1(reps[i].key, e.key)) { reps[i].n += e.n; return; }
        reps.push(e);
      });
      list = reps.sort(function (x, y) { return y.n - x.n; }).slice(0, topN);
      if (!list.length) { out.innerHTML = '<div class="text-muted">“' + esc(word) + "” doesn’t appear in that slice of any matching question." + (hintSeqs.length > 1 ? " (Every comma-separated hint must appear.)" : "") + "</div>"; return; }
      var hintLabel = hintSeqs.map(function (s) { return s.join(" "); }).join(" + ");
      var metaHtml = '<div class="kw-meta">P(answer | ' + esc(hintLabel) + ") · " + total + " matching question" + (total === 1 ? "" : "s") + " · " + (range.power ? "before (*)" : range.lo + "–" + range.hi + "%") +
        (total && total < 5 ? ' · <span style="color:var(--yellow)">small sample — treat with care</span>' : "") + "</div>";
      var thead = '<thead><tr><th></th><th>#</th><th>Answer</th><th>Probability</th><th>Questions</th></tr></thead>';
      kfPaginate(out, metaHtml, thead, list, function (e, i) {
        return "<tr><td>" + kfStarHtml(word, e.a) + "</td><td>" + (i + 1) + '</td><td class="kw-word" data-w="' + esc(e.a) + '">' + esc(e.a) + "</td><td>" + (total ? Math.round(100 * e.n / total) : 0) + "% (" + e.n + "/" + total + ")</td><td>" + e.n + "</td></tr>";
      }, function (o) {
        o.querySelectorAll(".kw-word").forEach(function (td) {
          td.addEventListener("click", function () { crossSearch("answers", td.dataset.w); });
          var tr = td.parentElement;
          if (tr) tr.oncontextmenu = function (ev) {
            if (!window.QB || !QB.contextMenu) return;
            ev.preventDefault();
            var a = td.dataset.w;
            var items = [{ label: "Keywords for this answer (here)", onClick: function () { crossSearch("answers", a); } }];
            if (ctx.host && ctx.host.searchDatabase) items.push({ label: "Find questions answered by it (Database)", onClick: function () { ctx.host.searchDatabase({ query: a, field: "answer", exact: false }); } });
            items.push({ sep: true });
            items.push({ label: "Star / unstar", onClick: function () { var s = tr.querySelector(".kw-starx"); if (s) s.click(); } });
            items.push({ label: "Add to review / folder…", onClick: function () { kfAdd(word, a, tr.querySelector(".kw-foldx") || tr); } });
            QB.contextMenu(ev.clientX, ev.clientY, items, { title: a });
          };
        });
        wireKFStars(o);
      });
    }


    // ── Database → Keyword Frequency tab: saved words/phrases/answers ──
    ctx.registerStarredProvider({
      id: "keyword-freq", title: "Keyword Frequency",
      render: function renderSaved(container) {
        var list = starredKF();
        if (!list.length) { container.innerHTML = '<div class="text-muted" style="padding:16px">Nothing saved yet — ★ a word, phrase, or answer in Keyword Frequency to review it later.</div>'; return; }
        var bar = '<div class="db-toolbar"><button class="btn btn-sm btn-primary" id="kf-review">▶ Review as flashcards</button>' +
          '<span class="text-muted" style="font-size:11px">' + list.length + " saved</span></div>";
        container.innerHTML = bar + '<table class="stats-table"><thead><tr><th></th><th>When you hear…</th><th>…think</th></tr></thead><tbody>' +
          list.map(function (it, i) {
            return '<tr><td><span class="kw-starx on" data-i="' + i + '" title="Star / unstar">★</span>' + kfAddBtn(it.front, it.back) + '</td><td class="kw-word">' + esc(it.front) + "</td><td><strong>" + esc(it.back) + "</strong></td></tr>";
          }).join("") + "</tbody></table>";
        container.querySelectorAll(".kw-foldx").forEach(function (s) {
          s.addEventListener("click", function () { kfAdd(s.dataset.f, s.dataset.b, s); });
        });
        container.querySelectorAll(".kw-starx").forEach(function (s) {
          s.addEventListener("click", function () {
            // Toggle in place (grey out) instead of instantly removing the row.
            var it = list[parseInt(s.dataset.i)];
            if (!it) return;
            var k = kfKey(it), lst = starredKF();
            var idx = lst.findIndex(function (x) { return kfKey(x) === k; });
            var nowStar;
            if (idx >= 0) { lst.splice(idx, 1); nowStar = false; } else { lst.push(it); nowStar = true; }
            ctx.storage.set("kf-stars", lst);
            s.textContent = nowStar ? "★" : "☆";
            s.classList.toggle("on", nowStar);
            var tr = s.closest("tr"); if (tr) tr.classList.toggle("kw-unstarred", !nowStar);
            if (ctx.playSound) ctx.playSound("star");
          });
        });
        var rv = container.querySelector("#kf-review");
        if (rv) rv.onclick = function () {
          var cards = starredKF().map(function (it) { return { front: it.front, back: it.back, meta: "keyword" }; });
          if (!cards.length) return;
          try { localStorage.setItem("qb-flashcards-cards", JSON.stringify({ cards: cards, ts: Date.now() })); } catch (e) {}
          var ok = window.QB && window.QB.showPage && window.QB.showPage("flashcards::cards");
          if (!ok) { try { localStorage.removeItem("qb-flashcards-cards"); } catch (e) {} ctx.toast("Enable the Flashcards plugin first", "error"); }
        };
      },
    });

    ctx.toast("Keyword Frequency enabled.");
  }
