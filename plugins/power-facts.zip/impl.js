function __qbMain(ctx) {
  var body = null, page = null;
  var FACTS = (typeof __qbPowerFacts !== "undefined" && Array.isArray(__qbPowerFacts)) ? __qbPowerFacts : [];
  function esc(s) { return (s == null ? "" : String(s)).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
  // Stable id per fact (survives re-ordering of the data file): djb2 of answer + fact.
  function fid(f) { var s = f.a + "|" + f.f, h = 5381; for (var i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0; return (h >>> 0).toString(36); }
  FACTS.forEach(function (f) { f.id = fid(f); });
  var CATS = []; FACTS.forEach(function (f) { if (CATS.indexOf(f.c) < 0) CATS.push(f.c); });

  var st = { mode: "browse", cat: "", sub: "", q: "", hideKnown: false };
  Object.assign(st, ctx.storage.get("view") || {});
  var known = {}; (ctx.storage.get("known") || []).forEach(function (id) { known[id] = 1; });
  function saveKnown() { ctx.storage.set("known", Object.keys(known)); }
  function saveView() { ctx.storage.set("view", { mode: st.mode, cat: st.cat, sub: st.sub, hideKnown: st.hideKnown }); }
  function strictness() { try { return (ctx.host.getPracticeConfig && ctx.host.getPracticeConfig().strictness) || 10; } catch (e) { return 10; } }

  function pool() {
    var q = st.q.toLowerCase();
    return FACTS.filter(function (f) {
      if (st.cat && f.c !== st.cat) return false;
      if (st.sub && (f.t || "Other") !== st.sub) return false;
      if (st.hideKnown && known[f.id]) return false;
      if (q && (f.a + " " + f.f + " " + f.q + " " + (f.s || "")).toLowerCase().indexOf(q) < 0) return false;
      return true;
    });
  }
  function counts() { var t = 0, k = 0; FACTS.forEach(function (f) { if (st.cat && f.c !== st.cat) return; if (st.sub && (f.t || "Other") !== st.sub) return; t++; if (known[f.id]) k++; }); return { t: t, k: k }; }
  // Our own subcategories (not the database's): Mythology splits into Greek /
  // Norse / Egyptian…, Science into Biology / Physics…, assigned per fact (f.t).
  function subsOf(cat) { var m = {}; FACTS.forEach(function (f) { if (f.c === cat) { var t = f.t || "Other"; m[t] = (m[t] || 0) + 1; } }); return Object.keys(m).sort(function (a, b) { return (a === "Other") - (b === "Other") || m[b] - m[a]; }).map(function (t) { return { t: t, n: m[t] }; }); }

  // ── shared header ─────────────────────────────────────────────────────
  function header() {
    var c = counts();
    return '<div class="pf-top">' +
      '<div class="pf-modes">' + [["browse", "Browse"], ["study", "Study"], ["quiz", "Quiz"]].map(function (m) { return '<button class="btn btn-sm' + (st.mode === m[0] ? " btn-primary" : " btn-ghost") + '" data-mode="' + m[0] + '">' + m[1] + "</button>"; }).join("") + "</div>" +
      '<span class="pill" title="facts you marked as known in this category">' + c.k + "/" + c.t + " known</span>" +
      '<label class="checkbox-row" style="margin-left:auto"><input type="checkbox" id="pf-hide"' + (st.hideKnown ? " checked" : "") + "> Hide known</label>" +
      "</div>" +
      '<div class="pf-cats"><button class="chip' + (!st.cat ? " active" : "") + '" data-cat="">All ' + FACTS.length + "</button>" +
      CATS.map(function (cat) { var n = FACTS.filter(function (f) { return f.c === cat; }).length; return '<button class="chip' + (st.cat === cat ? " active" : "") + '" data-cat="' + esc(cat) + '">' + esc(cat) + " " + n + "</button>"; }).join("") + "</div>" +
      (st.cat ? '<div class="pf-cats pf-subs"><button class="chip' + (!st.sub ? " active" : "") + '" data-sub="">All ' + esc(st.cat) + "</button>" +
        subsOf(st.cat).map(function (s) { return '<button class="chip' + (st.sub === s.t ? " active" : "") + '" data-sub="' + esc(s.t) + '">' + esc(s.t) + " " + s.n + "</button>"; }).join("") + "</div>" : "");
  }
  function wireHeader() {
    body.querySelectorAll("[data-mode]").forEach(function (b) { b.onclick = function () { st.mode = b.dataset.mode; saveView(); render(); }; });
    body.querySelectorAll("[data-cat]").forEach(function (b) { b.onclick = function () { st.cat = b.dataset.cat; st.sub = ""; card = null; deck = []; quiz.f = null; saveView(); render(); }; });
    body.querySelectorAll("[data-sub]").forEach(function (b) { b.onclick = function () { st.sub = b.dataset.sub; card = null; deck = []; quiz.f = null; saveView(); render(); }; });
    var h = body.querySelector("#pf-hide"); if (h) h.onchange = function (e) { st.hideKnown = e.target.checked; saveView(); render(); };
  }
  function factRow(f) {
    return '<div class="pf-row' + (known[f.id] ? " known" : "") + '" data-id="' + f.id + '">' +
      '<div class="pf-fact">' + esc(f.f) + "</div>" +
      '<div class="pf-meta"><span class="pill pf-ans">' + esc(f.a) + '</span><span class="text-muted">' + esc(f.c + (f.t ? " · " + f.t : "")) + '</span><span class="text-muted" title="how many different tossups use this fact before the power mark">in ' + f.n + " tossups pre-power</span>" +
      '<span class="pf-actions"><button class="btn btn-sm btn-ghost pf-play" data-ans="' + esc(f.a) + '" title="Play tossups on this answer">Play</button><button class="btn btn-sm btn-ghost pf-know" data-id="' + f.id + '">' + (known[f.id] ? "Unmark" : "Know it") + "</button></span></div></div>";
  }

  // ── browse ────────────────────────────────────────────────────────────
  function renderBrowse() {
    var list = pool();
    body.innerHTML = '<div class="pf-wrap">' + header() +
      '<div class="pf-search"><input type="text" id="pf-q" class="mode-input" placeholder="Search facts, answers, subcategories…" value="' + esc(st.q) + '"><span class="text-muted">' + list.length + " facts</span></div>" +
      '<div class="pf-list">' + (list.length ? list.slice(0, 400).map(factRow).join("") + (list.length > 400 ? '<div class="text-muted" style="padding:10px">Showing 400 of ' + list.length + "</div>" : "") : '<div class="text-muted" style="padding:16px">Nothing here.</div>') + "</div></div>";
    wireHeader();
    var q = body.querySelector("#pf-q");
    q.addEventListener("input", function () { st.q = q.value; var pos = q.selectionStart; renderBrowse(); var q2 = body.querySelector("#pf-q"); q2.focus(); q2.setSelectionRange(pos, pos); });
    wireRows();
  }
  function wireRows() {
    body.querySelectorAll(".pf-know").forEach(function (b) { b.onclick = function () { toggleKnown(b.dataset.id); render(); }; });
    body.querySelectorAll(".pf-play").forEach(function (b) { b.onclick = function () { playAnswer(b.dataset.ans, b); }; });
  }
  function toggleKnown(id) { if (known[id]) delete known[id]; else known[id] = 1; saveKnown(); }
  async function playAnswer(answer, btn) {
    if (btn) { btn.disabled = true; btn.textContent = "…"; }
    var ids = [];
    try { var d = await ctx.api.get("/api/tossups/search?query=" + encodeURIComponent('answer_sanitized : ("' + String(answer).replace(/"/g, "") + '")') + "&limit=20"); ids = (d.rows || []).map(function (r) { return r.id; }); } catch (e) {}
    if (btn) { btn.disabled = false; btn.textContent = "Play"; }
    if (!ids.length) { if (btn) { btn.disabled = true; btn.textContent = "None"; } ctx.toast("No questions found for that answer", "error"); return; }
    if (!(ctx.host && ctx.host.launchQuestions && ctx.host.launchQuestions("tossups", ids))) ctx.toast("Needs a newer app version", "error");
  }

  // ── study (flashcards) ────────────────────────────────────────────────
  var card = null, revealed = false, deck = [], done = 0;
  function nextCard() {
    if (!deck.length) { var p = pool().filter(function (f) { return !known[f.id]; }); for (var i = p.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)); var t = p[i]; p[i] = p[j]; p[j] = t; } deck = p; done = 0; }
    card = deck.shift() || null; revealed = false;
  }
  function renderStudy() {
    if (!card) nextCard();
    body.innerHTML = '<div class="pf-wrap">' + header() + '<div class="pf-study">' +
      (!card ? '<div class="text-muted" style="padding:30px;text-align:center">All facts known.</div>' :
        '<div class="pf-card">' +
          '<div class="pf-cardtop"><span class="pill">' + esc(card.c + (card.t ? " · " + card.t : "")) + '</span><span class="text-muted">' + done + " reviewed · " + deck.length + " left</span></div>" +
          '<div class="pf-clue">' + esc(card.q) + "</div>" +
          (revealed ? '<div class="pf-answer"><div class="result-answer">ANSWER: <span class="actual">' + esc(card.a) + '</span></div><div class="pf-fact" style="margin-top:8px">' + esc(card.f) + "</div>" +
            '<div class="pf-btns"><button class="btn btn-primary" id="pf-got">[1] Got it</button><button class="btn" id="pf-again">[2] Again later</button></div></div>'
            : '<div class="pf-btns"><button class="btn btn-primary" id="pf-reveal">[Space] Reveal</button></div>') +
        "</div>") + "</div></div>";
    wireHeader();
    var r = body.querySelector("#pf-reveal"); if (r) r.onclick = function () { revealed = true; renderStudy(); };
    var g = body.querySelector("#pf-got"); if (g) g.onclick = function () { known[card.id] = 1; saveKnown(); done++; nextCard(); renderStudy(); };
    var a = body.querySelector("#pf-again"); if (a) a.onclick = function () { deck.push(card); done++; nextCard(); renderStudy(); };
  }

  // ── quiz (type the answer, judged by the real checker) ───────────────
  var quiz = { f: null, res: null, right: 0, asked: 0, streak: 0 };
  function nextQuiz() { var p = pool().filter(function (f) { return !known[f.id]; }); quiz.f = p.length ? p[Math.floor(Math.random() * p.length)] : null; quiz.res = null; }
  async function answerQuiz(text) {
    if (!quiz.f || quiz.res) return;
    var status = "reject";
    if (String(text || "").trim()) { try { var r = await ctx.api.post("/api/evaluate-answer", { answerline: quiz.f.a, sanitized: quiz.f.a, answer: String(text).trim(), strictness: strictness() }); status = r.status || "reject"; } catch (e) {} }
    var ok = status === "accept" || status === "prompt";
    quiz.asked++; if (ok) { quiz.right++; quiz.streak++; known[quiz.f.id] = 1; saveKnown(); ctx.playSound("correct"); } else { quiz.streak = 0; ctx.playSound("incorrect"); }
    quiz.res = { ok: ok, given: String(text || "").trim() };
    renderQuiz();
  }
  function renderQuiz() {
    if (!quiz.f) nextQuiz();
    body.innerHTML = '<div class="pf-wrap">' + header() + '<div class="pf-study">' +
      '<div class="pf-cardtop"><span class="pill">Score ' + quiz.right + "/" + quiz.asked + '</span><span class="pill' + (quiz.streak >= 3 ? " pill-green" : "") + '">Streak ' + quiz.streak + "</span></div>" +
      (!quiz.f ? '<div class="text-muted" style="padding:30px;text-align:center">Nothing left to quiz here.</div>' :
        '<div class="pf-card"><div class="pf-cardtop"><span class="pill">' + esc(quiz.f.c + (quiz.f.t ? " · " + quiz.f.t : "")) + '</span></div><div class="pf-clue">' + esc(quiz.f.q) + "</div>" +
        (quiz.res ? '<div class="result-banner ' + (quiz.res.ok ? "correct" : "incorrect") + '">' + (quiz.res.ok ? "correct" : (quiz.res.given ? "wrong: " + esc(quiz.res.given) : "skipped")) + '</div><div class="result-answer">ANSWER: <span class="actual">' + esc(quiz.f.a) + '</span></div><div class="pf-fact" style="margin-top:8px">' + esc(quiz.f.f) + '</div><div class="pf-btns"><button class="btn btn-primary" id="pf-next">[N] Next</button></div>'
          : '<div class="buzz-prompt"><span class="prompt-symbol">&gt;</span><input type="text" id="pf-input" placeholder="answer…" autocomplete="off" autocorrect="off" spellcheck="false"></div>') + "</div>") + "</div></div>";
    wireHeader();
    var inp = body.querySelector("#pf-input"); if (inp) { inp.focus(); inp.addEventListener("keydown", function (e) { if (e.key === "Enter") { e.stopPropagation(); answerQuiz(inp.value); } }); }
    var n = body.querySelector("#pf-next"); if (n) n.onclick = function () { nextQuiz(); renderQuiz(); };
  }

  function render() { if (!body) return; if (st.mode === "study") renderStudy(); else if (st.mode === "quiz") renderQuiz(); else renderBrowse(); }
  function active() { return page && page.screenEl && page.screenEl.classList.contains("active"); }
  function keys(e) {
    if (!active()) return; var tag = (e.target && e.target.tagName) || "";
    if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return;
    if (st.mode === "study" && card) {
      if (e.key === " " && !revealed) { e.preventDefault(); revealed = true; renderStudy(); }
      else if (revealed && e.key === "1") { known[card.id] = 1; saveKnown(); done++; nextCard(); renderStudy(); }
      else if (revealed && e.key === "2") { deck.push(card); done++; nextCard(); renderStudy(); }
    }
    if (st.mode === "quiz" && quiz.res && (e.key === "n" || e.key === "N")) { nextQuiz(); renderQuiz(); }
  }
  document.addEventListener("keydown", keys, true);
  ctx._cleanup = function () { document.removeEventListener("keydown", keys, true); };

  page = ctx.registerPage({ id: "facts", navLabel: "Power Facts", title: "POWER FACTS", onShow: function (el) { body = el; render(); } });
  ctx.toast("Power Facts enabled — " + FACTS.length + " facts");
}
