/**
 * OfflineQuiz plugin: Power Facts
 *
 * The facts that get you to the buzzer before the (*). Every entry was mined
 * from this app's own question database: a fact appears here only if several
 * DIFFERENT tossups about the same answer use it before the power mark — so
 * it is common enough to recur, and early enough to be niche. Browse by
 * category, drill them as flashcards, or quiz yourself with the real answer
 * checker; anything you know gets marked and stops showing up.
 */
QB.registerPlugin({
  id: "power-facts",
  name: "Power Facts",
  version: "1.3.0",
  author: "OfflineQuiz",
  description: "Recurring pre-power clues mined from the database — the niche-but-common facts that earn powers — as a browsable list, flashcards, and a typed quiz.",
  onEnable: __qbMain,
  onDisable: function (ctx) { if (ctx._cleanup) ctx._cleanup(); },
});
