/**
 * OfflineQuiz plugin: Gap Finder
 *
 * Your accuracy in each category set against NAQT's high school distribution: how many tossups a
 * packet has in it and how many you'd likely miss. One button builds a practice set weighted to
 * the categories that cost you the most.
 */
QB.registerPlugin({
  id: "gap-finder",
  name: "Gap Finder",
  version: "1.0.0",
  author: "OfflineQuiz",
  description: "See which categories cost you the most tossups in a real packet, and practice a mix weighted to them.",
  onEnable: __qbMain,
  onDisable: function (ctx) { if (ctx._cleanup) ctx._cleanup(); },
});
