/**
 * OfflineQuiz plugin: Set Series
 *
 * Sets grouped into the tournaments they belong to, across every year in the database. Each year
 * shows its packets and which of them you've already heard, and one button plays the next packet
 * you haven't.
 */
QB.registerPlugin({
  id: "set-series",
  name: "Set Series",
  version: "1.0.0",
  author: "OfflineQuiz",
  description: "Every year of a tournament together, like all ACF Falls or NSCs, with the packets you've heard.",
  onEnable: __qbMain,
  onDisable: function (ctx) { if (ctx._cleanup) ctx._cleanup(); },
});
