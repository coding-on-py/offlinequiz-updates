function __qbMain(ctx) {
  var body = null, page = null;
  var RELAY = "https://offlinequiz-mp-relay.warren2028045.workers.dev";
  var users = [], view = "roster", selected = null, sortKey = "totalPoints";

  function esc(s) { return (s == null ? "" : String(s)).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
  function code() { return (ctx.storage.get("class-code") || "").trim().toLowerCase(); }
  function adminKey() { return ctx.storage.get("admin-key") || ""; }
  function when(ts) { return ts ? new Date(ts).toLocaleString() : "—"; }

  var METRICS = [
    { key: "totalPoints", label: "Total points", get: function (u) { return (u.stats || {}).totalPoints || 0; } },
    { key: "totalQuestions", label: "Questions", get: function (u) { return (u.stats || {}).totalQuestions || 0; } },
    { key: "powers", label: "Powers", get: function (u) { return (u.stats || {}).powers || 0; } },
    { key: "pointsPerQuestion", label: "Points / question", get: function (u) { return (u.stats || {}).pointsPerQuestion || 0; }, dec: 2 },
    { key: "tossupAccuracy", label: "Accuracy %", get: function (u) { return (u.stats || {}).tossupAccuracy || 0; }, dec: 1 },
    { key: "ppb", label: "PPB", get: function (u) { return (u.stats || {}).ppb || 0; }, dec: 2 },
    { key: "achievements", label: "Achievements", get: function (u) { return (u.achievements || []).length; } },
    { key: "searches", label: "Fact Sheet searches", get: function (u) { return (u.searches || []).reduce(function (a, x) { return a + (x.count || 0); }, 0); } },
    { key: "negs", label: "Negs (fewest is better)", get: function (u) { return (u.stats || {}).negs || 0; }, asc: true },
  ];
  function metric(k) { for (var i = 0; i < METRICS.length; i++) if (METRICS[i].key === k) return METRICS[i]; return METRICS[0]; }

  async function load() {
    var c = code();
    var host = body.querySelector("#ca-body");
    if (!c) { host.innerHTML = '<div class="text-muted" style="padding:16px">Enter your class code and admin key, then press Load.</div>'; return; }
    host.innerHTML = (window.QB && QB.loadingBarHtml) ? QB.loadingBarHtml("Loading class…") : '<div class="text-muted">Loading…</div>';
    try {
      var res = await fetch(RELAY + "/class/" + encodeURIComponent(c) + "?key=" + encodeURIComponent(adminKey()));
      var d = null;
      try { d = await res.json(); } catch (e) {}
      if (!res.ok) throw new Error((d && d.error) || ("server said " + res.status));
      users = (d && d.users) || [];
      paint();
    } catch (e) {
      var msg = String((e && e.message) || e);
      host.innerHTML = '<div class="ca-bad" style="padding:16px">' +
        esc(/unauthorized/i.test(msg) ? "Admin key rejected — check the key you set with `wrangler secret put ADMIN_KEY`."
          : /Failed to fetch|NetworkError|load failed/i.test(msg) ? "Couldn't reach the relay — check your internet."
          : "Load failed: " + msg) + "</div>";
    }
  }

  function paint() {
    var host = body.querySelector("#ca-body");
    if (!host) return;
    if (!users.length) { host.innerHTML = '<div class="text-muted" style="padding:16px">No students have uploaded to this class yet.</div>'; return; }
    if (view === "leaderboard") return paintLeaderboard(host);
    if (view === "student" && selected) return paintStudent(host, selected);
    paintRoster(host);
  }

  function paintRoster(host) {
    var rows = users.slice().sort(function (a, b) { return ((b.stats || {}).totalPoints || 0) - ((a.stats || {}).totalPoints || 0); });
    host.innerHTML =
      '<table class="stats-table"><thead><tr><th>Student</th><th>Questions</th><th>Points</th><th>Powers</th><th>Negs</th><th>PPB</th><th>Achv</th><th>Searches</th><th>Last upload</th></tr></thead><tbody>' +
      rows.map(function (u, i) {
        var s = u.stats || {};
        return '<tr class="ca-row" data-i="' + i + '" style="cursor:pointer" title="Open this student">' +
          "<td><strong>" + esc(u.name || u.userId) + "</strong></td>" +
          "<td>" + (s.totalQuestions || 0) + "</td><td>" + (s.totalPoints || 0) + "</td><td>" + (s.powers || 0) + "</td><td>" + (s.negs || 0) + "</td>" +
          "<td>" + (s.ppb != null ? s.ppb : "—") + "</td><td>" + ((u.achievements || []).length) + "</td>" +
          "<td>" + ((u.searches || []).reduce(function (a, x) { return a + (x.count || 0); }, 0)) + "</td>" +
          '<td class="text-muted">' + esc(when(u.receivedAt)) + "</td></tr>";
      }).join("") + "</tbody></table>";
    host.querySelectorAll(".ca-row").forEach(function (tr) {
      tr.onclick = function () { selected = rows[parseInt(tr.dataset.i, 10)]; view = "student"; paint(); syncTabs(); };
    });
  }

  function paintLeaderboard(host) {
    var m = metric(sortKey);
    var ranked = users.slice().sort(function (a, b) { return m.asc ? m.get(a) - m.get(b) : m.get(b) - m.get(a); });
    host.innerHTML =
      '<div class="ca-lbhead"><label class="ca-lbl">Rank by</label><select id="ca-metric" class="mode-input" style="width:220px">' +
        METRICS.map(function (x) { return '<option value="' + x.key + '"' + (x.key === sortKey ? " selected" : "") + ">" + esc(x.label) + "</option>"; }).join("") +
      "</select></div>" +
      '<div class="ca-lb">' + ranked.map(function (u, i) {
        var v = m.get(u);
        return '<div class="ca-lbrow' + (i < 3 ? " top" : "") + '"><span class="ca-rank">' + (i + 1) + "</span>" +
          '<span class="ca-who">' + esc(u.name || u.userId) + "</span>" +
          '<span class="ca-val">' + (m.dec ? Number(v).toFixed(m.dec) : v) + "</span></div>";
      }).join("") + "</div>";
    host.querySelector("#ca-metric").onchange = function (e) { sortKey = e.target.value; paint(); };
  }

  function paintStudent(host, u) {
    var s = u.stats || {};
    var searches = (u.searches || []).slice().sort(function (a, b) { return (b.count || 0) - (a.count || 0); });
    host.innerHTML =
      '<div class="ca-back"><button class="btn btn-sm btn-ghost" id="ca-back">‹ All students</button></div>' +
      '<div class="ca-name">' + esc(u.name || u.userId) + '<span class="text-muted" style="font-size:12px;font-weight:400"> · last upload ' + esc(when(u.receivedAt)) + "</span></div>" +
      '<div class="ca-cards">' +
        [["Questions", s.totalQuestions || 0], ["Points", s.totalPoints || 0], ["Pts/Q", s.pointsPerQuestion != null ? s.pointsPerQuestion : "—"],
         ["Accuracy", (s.tossupAccuracy != null ? s.tossupAccuracy + "%" : "—")], ["Powers", s.powers || 0], ["Negs", s.negs || 0],
         ["Bonuses", s.bonusesHeard || 0], ["PPB", s.ppb != null ? s.ppb : "—"], ["Starred", ((u.starred || {}).tossups || 0) + ((u.starred || {}).bonuses || 0)]]
          .map(function (c) { return '<div class="ca-card"><div class="ca-cv">' + esc(String(c[1])) + '</div><div class="ca-cl">' + esc(c[0]) + "</div></div>"; }).join("") +
      "</div>" +
      '<div class="ca-h">Achievements (' + ((u.achievements || []).length) + ")</div>" +
      '<div class="ca-chips">' + ((u.achievements || []).map(function (id) {
        var nm = (u.achievementNames && u.achievementNames[id]) || id;
        return '<span class="ca-chip">' + esc(nm) + "</span>";
      }).join("") || '<span class="text-muted">None yet</span>') + "</div>" +
      '<div class="ca-h">Fact Sheet searches (' + searches.length + " answers)</div>" +
      (searches.length
        ? '<table class="stats-table"><thead><tr><th>Answer searched</th><th>Times</th><th>Last</th></tr></thead><tbody>' +
          searches.map(function (x) { return "<tr><td>" + esc(x.term) + "</td><td>" + (x.count || 0) + '</td><td class="text-muted">' + esc(when(x.last)) + "</td></tr>"; }).join("") +
          "</tbody></table>"
        : '<div class="text-muted">No searches yet</div>') +
      '<div class="ca-h">Buzzes on searched answers (' + ((u.buzzes || []).length) + ")</div>" +
      ((u.buzzes || []).length
        ? '<table class="stats-table"><thead><tr><th>Answer</th><th>Their answer</th><th>Buzz location</th><th>Pts</th><th>Category</th></tr></thead><tbody>' +
          u.buzzes.map(function (b) {
            var loc = b.celerity != null ? Math.round(b.celerity * 100) + "% in" : (b.buzzPosition != null ? "char " + b.buzzPosition : "—");
            return "<tr><td><strong>" + esc(b.answer) + "</strong></td><td>" + esc(b.given || "—") + "</td><td>" + esc(loc) + "</td><td>" + (b.points != null ? b.points : "—") + '</td><td class="text-muted">' + esc(b.category || "") + "</td></tr>";
          }).join("") + "</tbody></table>"
        : '<div class="text-muted">No buzzes recorded on answers they searched</div>');
    host.querySelector("#ca-back").onclick = function () { view = "roster"; selected = null; paint(); syncTabs(); };
  }

  function syncTabs() {
    body.querySelectorAll(".ca-tab").forEach(function (t) {
      t.classList.toggle("active", t.dataset.view === (view === "student" ? "roster" : view));
    });
  }

  function render() {
    body.innerHTML =
      '<div class="ca-wrap">' +
        '<div class="ca-bar">' +
          '<input id="ca-code" class="mode-input" style="width:190px" placeholder="class code" value="' + esc(code()) + '" autocomplete="off" spellcheck="false">' +
          '<input id="ca-key" class="mode-input" type="password" style="width:190px" placeholder="admin key" value="' + esc(adminKey()) + '" autocomplete="off">' +
          '<button class="btn btn-primary" id="ca-load">Load class</button>' +
          '<span class="ca-tabs"><button class="ca-tab active" data-view="roster">Students</button><button class="ca-tab" data-view="leaderboard">Leaderboard</button></span>' +
        "</div>" +
        '<div id="ca-body"><div class="text-muted" style="padding:16px">Enter your class code and admin key, then press Load.</div></div>' +
      "</div>";
    body.querySelector("#ca-code").onchange = function (e) { ctx.storage.set("class-code", e.target.value.trim()); };
    body.querySelector("#ca-key").onchange = function (e) { ctx.storage.set("admin-key", e.target.value); };
    body.querySelector("#ca-load").onclick = load;
    body.querySelectorAll(".ca-tab").forEach(function (t) {
      t.onclick = function () { view = t.dataset.view; selected = null; syncTabs(); paint(); };
    });
  }

  page = ctx.registerPage({
    id: "dash", navLabel: "Class Dashboard", title: "CLASS DASHBOARD",
    onShow: function (el) { body = el; if (!body.querySelector("#ca-load")) render(); },
  });
}
