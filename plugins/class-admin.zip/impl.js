function __qbMain(ctx) {
  var body = null, page = null;
  var RELAY = "https://offlinequiz-mp-relay.warren2028045.workers.dev";
  var users = [], view = "roster", selected = null, sortKey = "totalPoints", range = "all";

  function esc(s) { return (s == null ? "" : String(s)).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
  // The one pool every client plugin uploads to. Nothing to configure.
  var POOL = "everyone";
  function when(ts) { return ts ? new Date(ts).toLocaleString() : "—"; }

  // ── time ranges ──────────────────────────────────────────────────────────
  // Ranged numbers come from the per-day buckets class-sync 1.6+ uploads
  // (snapshot.daily, keyed by the student's local calendar date). A student
  // whose plugin predates buckets has NO ranged data — that renders as "—",
  // never as a fake 0.
  var RANGES = [
    { key: "all", label: "All time", days: null },
    { key: "today", label: "Today", days: 1 },
    { key: "week", label: "Last 7 days", days: 7 },
    { key: "month", label: "Last 30 days", days: 30 },
  ];
  function dayKey(d) { return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0"); }
  function rangeKeySet(days) {
    var out = {}, now = new Date();
    for (var i = 0; i < days; i++) out[dayKey(new Date(now.getFullYear(), now.getMonth(), now.getDate() - i))] = 1;
    return out;
  }
  // Stats for the active range: u.stats for "all", summed buckets otherwise,
  // null when the student has no buckets to sum.
  function statsFor(u) {
    if (range === "all") return u.stats || {};
    if (!u.daily) return null;
    var days = 30;
    for (var i = 0; i < RANGES.length; i++) if (RANGES[i].key === range) days = RANGES[i].days;
    var keys = rangeKeySet(days);
    var t = { q: 0, pts: 0, pow: 0, neg: 0, cor: 0, bq: 0, bpts: 0 };
    Object.keys(u.daily).forEach(function (k) {
      if (!keys[k]) return;
      var b = u.daily[k] || {};
      t.q += b.q || 0; t.pts += b.pts || 0; t.pow += b.pow || 0; t.neg += b.neg || 0;
      t.cor += b.cor || 0; t.bq += b.bq || 0; t.bpts += b.bpts || 0;
    });
    return {
      totalQuestions: t.q, totalPoints: t.pts, powers: t.pow, negs: t.neg,
      pointsPerQuestion: t.q ? +(t.pts / t.q).toFixed(2) : 0,
      tossupAccuracy: t.q ? +((t.cor / t.q) * 100).toFixed(1) : 0,
      bonusesHeard: t.bq, ppb: t.bq ? +(t.bpts / t.bq).toFixed(2) : 0,
    };
  }
  function statVal(u, key) { var s = statsFor(u); return s ? (s[key] || 0) : 0; }

  var METRICS = [
    { key: "totalPoints", label: "Total points", ranged: true, get: function (u) { return statVal(u, "totalPoints"); } },
    { key: "totalQuestions", label: "Questions", ranged: true, get: function (u) { return statVal(u, "totalQuestions"); } },
    { key: "powers", label: "Powers", ranged: true, get: function (u) { return statVal(u, "powers"); } },
    { key: "pointsPerQuestion", label: "Points / question", ranged: true, get: function (u) { return statVal(u, "pointsPerQuestion"); }, dec: 2 },
    { key: "tossupAccuracy", label: "Accuracy %", ranged: true, get: function (u) { return statVal(u, "tossupAccuracy"); }, dec: 1 },
    { key: "ppb", label: "PPB", ranged: true, get: function (u) { return statVal(u, "ppb"); }, dec: 2 },
    { key: "achievements", label: "Achievements (all time)", get: function (u) { return (u.achievements || []).length; } },
    { key: "searches", label: "Fact Sheet searches (all time)", get: function (u) { return (u.searches || []).reduce(function (a, x) { return a + (x.count || 0); }, 0); } },
    { key: "negs", label: "Negs (fewest is better)", ranged: true, get: function (u) { return statVal(u, "negs"); }, asc: true },
  ];
  function metric(k) { for (var i = 0; i < METRICS.length; i++) if (METRICS[i].key === k) return METRICS[i]; return METRICS[0]; }

  async function load() {
    var host = body.querySelector("#ca-body");
    if (!host) return;
    host.innerHTML = (window.QB && QB.loadingBarHtml) ? QB.loadingBarHtml("Loading students…") : '<div class="text-muted">Loading…</div>';
    try {
      var res = await fetch(RELAY + "/class/" + POOL);
      var d = null;
      try { d = await res.json(); } catch (e) {}
      if (!res.ok) throw new Error((d && d.error) || ("server said " + res.status));
      // A relay without the class endpoints answers every path with a 200
      // plain-text banner. Without this check that parses to null and looks
      // identical to "nobody has uploaded yet", which sends you hunting the
      // wrong problem.
      if (!d || !Array.isArray(d.users)) throw new Error("NOT_DEPLOYED");
      users = (d && d.users) || [];
      // Re-point an open student detail at the freshly fetched record —
      // `selected` otherwise still references an object from the previous
      // fetch, so a refresh would repaint the old numbers.
      if (selected) {
        var again = null;
        for (var i = 0; i < users.length; i++) if (users[i].userId === selected.userId) { again = users[i]; break; }
        selected = again;
        if (!selected && view === "student") view = "roster";
      }
      paint();
    } catch (e) {
      var msg = String((e && e.message) || e);
      host.innerHTML = '<div class="ca-bad" style="padding:16px">' +
        esc(/Failed to fetch|NetworkError|load failed/i.test(msg)
          ? "Couldn’t reach the relay — check your internet."
          : /NOT_DEPLOYED|not configured/i.test(msg)
          ? "The relay is running but has no class storage yet, so no upload has been saved. Deploy it: create the CLASS KV namespace, put its id in relay/wrangler.toml, then run npx wrangler deploy. See docs/class-sync-setup.md."
          : "Load failed: " + msg) + "</div>";
    }
  }

  function paint() {
    var host = body.querySelector("#ca-body");
    if (!host) return;
    if (!users.length) { host.innerHTML = '<div class="text-muted" style="padding:16px">No students have uploaded to this class yet.</div>'; return; }
    if (view === "leaderboard") return paintLeaderboard(host);
    if (view === "student" && selected) return paintStudent(host, selected);
    paintRoster(host);
  }

  function paintRoster(host) {
    var rows = users.slice().sort(function (a, b) { return statVal(b, "totalPoints") - statVal(a, "totalPoints"); });
    var cell = function (s, key) { return s ? String(s[key] != null ? s[key] : 0) : "—"; };
    host.innerHTML =
      (range !== "all" ? '<div class="text-muted" style="padding:4px 2px;font-size:11px">Showing ' + esc(metricRangeLabel()) + ' — a "—" means that student’s Class Sync plugin is too old to report daily data. Achievements and searches are all-time.</div>' : "") +
      '<table class="stats-table"><thead><tr><th>Student</th><th>Questions</th><th>Points</th><th>Powers</th><th>Negs</th><th>PPB</th><th>Achv</th><th>Searches</th><th>Last upload</th></tr></thead><tbody>' +
      rows.map(function (u, i) {
        var s = statsFor(u);
        return '<tr class="ca-row" data-i="' + i + '" style="cursor:pointer" title="Open this student">' +
          "<td><strong>" + esc(u.name || u.userId) + "</strong></td>" +
          "<td>" + cell(s, "totalQuestions") + "</td><td>" + cell(s, "totalPoints") + "</td><td>" + cell(s, "powers") + "</td><td>" + cell(s, "negs") + "</td>" +
          "<td>" + (s ? (s.ppb != null ? s.ppb : "—") : "—") + "</td><td>" + ((u.achievements || []).length) + "</td>" +
          "<td>" + ((u.searches || []).reduce(function (a, x) { return a + (x.count || 0); }, 0)) + "</td>" +
          '<td class="text-muted">' + esc(when(u.receivedAt)) + "</td></tr>";
      }).join("") + "</tbody></table>";
    host.querySelectorAll(".ca-row").forEach(function (tr) {
      tr.onclick = function () { selected = rows[parseInt(tr.dataset.i, 10)]; view = "student"; paint(); syncTabs(); };
    });
  }
  function metricRangeLabel() {
    for (var i = 0; i < RANGES.length; i++) if (RANGES[i].key === range) return RANGES[i].label.toLowerCase();
    return "all time";
  }

  function paintLeaderboard(host) {
    var m = metric(sortKey);
    // No-data students (pre-1.6 uploader in a ranged view) always sort LAST —
    // on ascending metrics ("fewest negs") their 0 would otherwise top the board.
    var noData = function (u) { return m.ranged && range !== "all" && !statsFor(u); };
    var ranked = users.slice().sort(function (a, b) {
      var na = noData(a), nb = noData(b);
      if (na !== nb) return na ? 1 : -1;
      return m.asc ? m.get(a) - m.get(b) : m.get(b) - m.get(a);
    });
    host.innerHTML =
      '<div class="ca-lbhead"><label class="ca-lbl">Rank by</label><select id="ca-metric" class="mode-input" style="width:220px">' +
        METRICS.map(function (x) { return '<option value="' + x.key + '"' + (x.key === sortKey ? " selected" : "") + ">" + esc(x.label) + "</option>"; }).join("") +
      "</select></div>" +
      '<div class="ca-lb">' + ranked.map(function (u, i) {
        var v = m.get(u);
        var nd = noData(u);
        return '<div class="ca-lbrow' + (i < 3 && !nd ? " top" : "") + '"><span class="ca-rank">' + (i + 1) + "</span>" +
          '<span class="ca-who">' + esc(u.name || u.userId) + "</span>" +
          '<span class="ca-val">' + (nd ? "—" : (m.dec ? Number(v).toFixed(m.dec) : v)) + "</span></div>";
      }).join("") + "</div>";
    host.querySelector("#ca-metric").onchange = function (e) { sortKey = e.target.value; paint(); };
  }

  function paintStudent(host, u) {
    var s = statsFor(u);
    var noRange = !s;
    if (noRange) s = {};
    var stat = function (key) { return noRange ? "—" : (s[key] != null ? s[key] : 0); };
    var searches = (u.searches || []).slice().sort(function (a, b) { return (b.count || 0) - (a.count || 0); });
    host.innerHTML =
      '<div class="ca-back"><button class="btn btn-sm btn-ghost" id="ca-back">‹ All students</button></div>' +
      '<div class="ca-name">' + esc(u.name || u.userId) + '<span class="text-muted" style="font-size:12px;font-weight:400"> · last upload ' + esc(when(u.receivedAt)) + (range !== "all" ? " · showing " + esc(metricRangeLabel()) : "") + "</span></div>" +
      (noRange ? '<div class="text-muted" style="font-size:12px;padding:2px 0 6px">No daily data — this student’s Class Sync plugin is too old to report per-day stats. Switch the range to "All time".</div>' : "") +
      '<div class="ca-cards">' +
        [["Questions", stat("totalQuestions")], ["Points", stat("totalPoints")], ["Pts/Q", noRange ? "—" : (s.pointsPerQuestion != null ? s.pointsPerQuestion : "—")],
         ["Accuracy", noRange ? "—" : (s.tossupAccuracy != null ? s.tossupAccuracy + "%" : "—")], ["Powers", stat("powers")], ["Negs", stat("negs")],
         ["Bonuses", stat("bonusesHeard")], ["PPB", noRange ? "—" : (s.ppb != null ? s.ppb : "—")], ["Starred", ((u.starred || {}).tossups || 0) + ((u.starred || {}).bonuses || 0)]]
          .map(function (c) { return '<div class="ca-card"><div class="ca-cv">' + esc(String(c[1])) + '</div><div class="ca-cl">' + esc(c[0]) + "</div></div>"; }).join("") +
      "</div>" +
      '<div class="ca-h">Achievements (' + ((u.achievements || []).length) + ")</div>" +
      '<div class="ca-chips">' + ((u.achievements || []).map(function (id) {
        var nm = (u.achievementNames && u.achievementNames[id]) || id;
        return '<span class="ca-chip">' + esc(nm) + "</span>";
      }).join("") || '<span class="text-muted">None yet</span>') + "</div>" +
      '<div class="ca-h">Fact Sheet searches (' + searches.length + " answers)</div>" +
      (searches.length
        ? '<table class="stats-table"><thead><tr><th>Answer searched</th><th>Times</th><th>Last</th></tr></thead><tbody>' +
          searches.map(function (x) { return "<tr><td>" + esc(x.term) + "</td><td>" + (x.count || 0) + '</td><td class="text-muted">' + esc(when(x.last)) + "</td></tr>"; }).join("") +
          "</tbody></table>"
        : '<div class="text-muted">No searches yet</div>') +
      '<div class="ca-h">Buzzes on searched answers (' + ((u.buzzes || []).length) + ")</div>" +
      ((u.buzzes || []).length
        ? '<table class="stats-table"><thead><tr><th>Answer</th><th>Their answer</th><th>Buzz location</th><th>Pts</th><th>Category</th></tr></thead><tbody>' +
          u.buzzes.map(function (b) {
            var loc = b.celerity != null ? Math.round(b.celerity * 100) + "% in" : (b.buzzPosition != null ? "char " + b.buzzPosition : "—");
            return "<tr><td><strong>" + esc(b.answer) + "</strong></td><td>" + esc(b.given || "—") + "</td><td>" + esc(loc) + "</td><td>" + (b.points != null ? b.points : "—") + '</td><td class="text-muted">' + esc(b.category || "") + "</td></tr>";
          }).join("") + "</tbody></table>"
        : '<div class="text-muted">No buzzes recorded on answers they searched</div>');
    host.querySelector("#ca-back").onclick = function () { view = "roster"; selected = null; paint(); syncTabs(); };
  }

  function syncTabs() {
    body.querySelectorAll(".ca-tab").forEach(function (t) {
      t.classList.toggle("active", t.dataset.view === (view === "student" ? "roster" : view));
    });
  }

  function render() {
    body.innerHTML =
      '<div class="ca-wrap">' +
        '<div class="ca-bar">' +
          '<span class="ca-lbl">Everyone using the Class Sync plugin</span>' +
          '<select id="ca-range" class="mode-input" style="width:140px" title="Which time period the stats cover">' +
            RANGES.map(function (r) { return '<option value="' + r.key + '"' + (r.key === range ? " selected" : "") + ">" + esc(r.label) + "</option>"; }).join("") +
          "</select>" +
          '<button class="btn btn-sm btn-ghost" id="ca-load">Refresh</button>' +
          '<span class="ca-tabs"><button class="ca-tab active" data-view="roster">Students</button><button class="ca-tab" data-view="leaderboard">Leaderboard</button></span>' +
        "</div>" +
        '<div id="ca-body"></div>' +
      "</div>";
    body.querySelector("#ca-range").onchange = function (e) { range = e.target.value; paint(); };
    body.querySelector("#ca-load").onclick = load;
    body.querySelectorAll(".ca-tab").forEach(function (t) {
      t.onclick = function () { view = t.dataset.view; selected = null; syncTabs(); paint(); };
    });
  }

  page = ctx.registerPage({
    id: "dash", navLabel: "Class Dashboard", title: "CLASS DASHBOARD",
    // Opening the page fresh still refetches — a teacher opening it wants the
    // current roster, not a stale one — but arriving via Back leaves the page
    // exactly as it was (same tab, same student), instead of rebuilding it.
    onShow: function (el, info) {
      body = el;
      if (!body.querySelector("#ca-body")) { render(); load(); return; }
      syncTabs();
      if (!(info && info.back)) load();
    },
  });

  function active() { return page && page.screenEl && page.screenEl.classList.contains("active"); }
  // Back handlers are global, so only act when this page is the active screen:
  // Esc inside a student detail steps back to the roster; elsewhere the app
  // handles Back normally and leaves the page.
  if (ctx.onBack) ctx.onBack(function () {
    if (!active() || !body || view !== "student") return false;
    view = "roster"; selected = null; paint(); syncTabs();
    return true;
  });
}
