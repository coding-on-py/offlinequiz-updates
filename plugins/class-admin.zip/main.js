QB.registerPlugin({
  id: "class-admin",
  name: "Class Dashboard",
  version: "1.0.0",
  author: "OfflineQuiz",
  description: "Teacher view: every student who uploaded via Class Sync — stats, achievements, Fact Sheet searches, and leaderboards.",
  onEnable: __qbMain,
});
