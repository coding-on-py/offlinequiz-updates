/**
 * OfflineQuiz plugin: Flashcards
 *
 * Tossups as flashcards: the FRONT is one clue (a sentence of the question),
 * the BACK is the answer and its answer line. Cards come from the practice
 * filters (the page's Setup drawer is the practice panel), from starred
 * cards, or from a list handed over by Review / Starred / other plugins.
 * Setup's "Hint from" range picks WHERE in the question the clue comes from
 * (lead-in … giveaway). [Space] flip · [1] Again · [2] Got it · [S] Skip.
 */
QB.registerPlugin({
  id: "flashcards",
  name: "Flashcards",
  version: "4.28.0",
  author: "OfflineQuiz",
  description: "Tossup clues as flashcards: a clue on the front, the answer on the back.",
  hotkeys: [
    { id: "flip", label: "Flip card", default: "Space" },
    { id: "again", label: "Again (flipped card)", default: "1" },
    { id: "good", label: "Got it (flipped card)", default: "2" },
    { id: "skip", label: "Skip / next card", default: "s" },
  ],
  onEnable: __qbMain,
  onDisable: function (ctx) { if (ctx._cleanup) ctx._cleanup(); },
});
