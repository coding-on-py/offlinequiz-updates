/**
 * OfflineQuiz plugin: Flashcards
 *
 * Random tossups (filtered by the SAME panel as Tossups practice — changing
 * the filters rebuilds the deck) become flashcards: the FRONT shows one
 * sentence of the question as the hint; flip to see the answer and its full
 * answer line. A dual slider picks WHERE in the question the hint sentence
 * comes from (0% = first/hardest clue … 100% = the giveaway).
 * [Space] flip · [1] Again (flip back to the hint) · [2] Got it (next card).
 * Cards can be starred — they appear in their own Database tab.
 */
QB.registerPlugin({
  id: "flashcards",
  name: "Flashcards",
  version: "4.24.0",
  author: "OfflineQuiz",
  description: "Filtered tossups as flashcards: one-sentence hint on the front, answer + answer line on the back. Starrable; hint depth configurable.",
  hotkeys: [
    { id: "flip", label: "Flip card", default: "Space" },
    { id: "again", label: "Again (flipped card)", default: "1" },
    { id: "good", label: "Got it (flipped card)", default: "2" },
    { id: "skip", label: "Skip / next card", default: "s" },
  ],
  onEnable: __qbMain,
  onDisable: function (ctx) { if (ctx._cleanup) ctx._cleanup(); },
});
