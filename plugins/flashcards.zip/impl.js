function __qbMain(ctx) {
    var body = null, page = null;
    var card = null, flipped = false, loading = false;
    var reviewPoolIds = []; // the review ids backing the current review pool
    var seen = [], pos = -1; // history of shown cards (for the Back button)
    var sourceMode = "random";  // "random" (filtered) | "starred" | "review" | "custom"
    var pool = null, poolIdx = 0, exhausted = false;
    var tally = { good: 0, again: 0, skip: 0 }; // this visit's cards, by result
    var prefetched = null; // { key, promise } — the next random tossup, fetched ahead

    // ── lifetime stats (persisted in plugin storage) ──
    function lifeStats() {
      return ctx.storage.get("stats") || { studied: 0, firstTry: 0, agains: 0, decks: 0 };
    }
    function bumpLife(fn) { var st = lifeStats(); fn(st); ctx.storage.set("stats", st); }
    var borrowedPanel = null, panelHome = null, panelObserver = null;

    function esc(s) { return (s == null ? "" : String(s)).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
    var KEY_DEFAULTS = { flip: "Space", again: "1", good: "2", skip: "S" };
    function keyLabel(id) {
      try { var v = ctx.keyLabel && ctx.keyLabel(id); if (v && v !== "?") return v; } catch (e) {}
      return KEY_DEFAULTS[id] || "?";
    }
    function kbd(id) { return "<kbd>" + esc(keyLabel(id)) + "</kbd>"; }
    var SVG = function (inner, size) { return '<svg viewBox="0 0 24 24" width="' + (size || 16) + '" height="' + (size || 16) + '" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + inner + "</svg>"; };
    var IC = {
      sliders: '<path d="M4 6h10M18 6h2M4 12h4M12 12h8M4 18h12"/><circle cx="16" cy="6" r="2"/><circle cx="10" cy="12" r="2"/><circle cx="18" cy="18" r="2"/>',
      left: '<path d="M15 6l-6 6 6 6"/>',
      x: '<path d="M6 6l12 12M18 6L6 18"/>',
      check: '<path d="M5 12l5 5 9-10"/>',
      cards: '<rect x="2.5" y="7" width="14" height="13" rx="2"/><path d="M7 3.5h12a2 2 0 012 2V16"/>',
    };
    var ENT = { amp: "&", lt: "<", gt: ">", quot: '"', apos: "'", nbsp: " " };
    function decodeEnt(s) {
      return String(s || "").replace(/&(#x[0-9a-f]+|#\d+|[a-z]+);/gi, function (m, e) {
        try { if (e[0] === "#") return String.fromCodePoint(e[1] === "x" || e[1] === "X" ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10)); } catch (err) { return m; }
        var v = ENT[e.toLowerCase()]; return v != null ? v : m;
      });
    }
    // Allow-listed inline HTML, like the base's answer lines: <b> <u> <i> <em>
    // <strong> <sup> survive, any other "<…>" is text, entities decode once.
    function ansHtml(raw, fallback) {
      var src = (raw && String(raw).trim()) ? String(raw) : String(fallback || "");
      var html = src.split(/(<\/?(?:b|u|i|em|strong|sup)>)/i).map(function (p, i) { return i % 2 ? p.toLowerCase() : esc(decodeEnt(p)); }).join("");
      var d = document.createElement("div"); d.innerHTML = html; return d.innerHTML;
    }
    // The question as the practice screen reads it (host helper: notes and
    // pronunciation guides per the user's settings). Older bases: the plain
    // copy with guides stripped when Hide pronunciations is on.
    function readText(q) {
      try { if (ctx.host && ctx.host.questionText) { var t = ctx.host.questionText(q, "question"); if (t != null) return String(t); } } catch (e) {}
      var s = (q && q.question_sanitized) || "";
      try { var cfg = ctx.host.getPracticeConfig && ctx.host.getPracticeConfig(); if (cfg && cfg.hidePron && ctx.host.stripPronunciations) s = ctx.host.stripPronunciations(s); } catch (e) {}
      return s;
    }
    // A moderator note ("<i>Note to moderator: …</i>"; the plain copy has
    // nothing marking where it ends) is never a hint, even when notes are
    // shown: cut every such italic run of the HTML out of the plain text.
    var NOTE_RUN = /^\s*(?:note to (?:the )?(?:moderators?|readers?)\b|reader(?:'s)? note\b|moderator(?:'s)? note\b)/i;
    function foldSan(s) {
      return String(s || "").normalize("NFD").replace(/[̀-ͯ]/g, "")
        .replace(/[“”]/g, '"').replace(/[‘’]/g, "'").replace(/[–—]/g, "-").replace(/…/g, "...").replace(/ /g, " ");
    }
    function cutNoteRuns(text, html) {
      var t = String(text || ""), s = String(html || "");
      if (s.indexOf("<") < 0) return t;
      var runs = [], it = 0, last = 0, m, re = /<\/?([a-z]+)[^>]*>/gi;
      function push(x) { if (!x) return; var p = runs[runs.length - 1], ital = it > 0; if (p && p.italic === ital) p.text += x; else runs.push({ text: x, italic: ital }); }
      while ((m = re.exec(s))) {
        push(decodeEnt(s.slice(last, m.index)));
        var tag = m[1].toLowerCase();
        if (tag === "i" || tag === "em") it = Math.max(0, it + (m[0][1] === "/" ? -1 : 1));
        last = re.lastIndex;
      }
      push(decodeEnt(s.slice(last)));
      runs.forEach(function (r) {
        if (!r.italic || !NOTE_RUN.test(r.text)) return;
        var note = r.text.trim(), cands = [foldSan(note), note];
        try { if (ctx.host && ctx.host.stripPronunciations) cands.push(ctx.host.stripPronunciations(foldSan(note))); } catch (e) {}
        for (var k = 0; k < cands.length; k++) {
          var i = cands[k] ? t.indexOf(cands[k]) : -1;
          if (i >= 0) { t = t.slice(0, i).replace(/\s+$/, "") + (i > 0 ? " " : "") + t.slice(i + cands[k].length).replace(/^\s+/, ""); break; }
        }
      });
      return t;
    }
    function hintText(q) { return cutNoteRuns(readText(q), q && q.question); }
    function mainAnswer(sani) { return (sani || "").split(/[\[(]/)[0].trim().replace(/[;:,.]+$/, ""); }
    // The answer as printed: the answer line's HTML without its tags (keeps
    // accents and quotes; the plain copy can split words at underlines).
    function displayAnswer(q) {
      var raw = q && q.answer ? decodeEnt(String(q.answer).replace(/<[^>]+>/g, "")) : "";
      return mainAnswer(raw) || mainAnswer(q && q.answer_sanitized);
    }
    function shuffle(a) { for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)); var t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
    // Quote-aware sentence split: 'love." At' ends the sentence at the quote.
    // Abbreviation-aware: a naive period split broke "the Michipicoten and
    // St. Ignace islands" (and "The St. Mary's river") into fragments. A chunk
    // ending in a known abbreviation or a single initial is glued to the next
    // one, as is any chunk the split left starting with a lowercase letter.
    var SENT_ABBR = /(?:\b(?:St|Ste|Mt|Mts|Dr|Mr|Mrs|Ms|Messrs|Mme|Mlle|Prof|Sr|Jr|Rev|Fr|Gen|Col|Capt|Lt|Sgt|Maj|Adm|Hon|Pres|Gov|Sen|Rep|Supt|Msgr|vs|etc|cf|ca|al|Inc|Co|Corp|Ltd|Bros|approx|No|Nos|Op|op|no|Vol|vol|Ch|ch|Fig|fig|Ft|Pt|pt|Rte|Ave|Blvd|[A-Za-z])\.["”’']?)$/;
    function mergeAbbrevChunks(parts) {
      var out = [], cur = "";
      for (var i = 0; i < parts.length; i++) {
        cur = cur ? cur + " " + parts[i] : parts[i];
        if (i < parts.length - 1 && SENT_ABBR.test(cur.trim())) continue;
        out.push(cur.trim());
        cur = "";
      }
      if (cur.trim()) out.push(cur.trim());
      return out;
    }
    function splitSentences(text) {
      var chunks = (text || "").replace(/\(\*\)/g, "")
        .split(/(?<=[.!?…]["”’']?)\s+(?=["“‘']?[A-Z0-9(])/);
      return mergeAbbrevChunks(chunks)
        .map(function (c) { return c.trim(); })
        .filter(Boolean);
    }

    function hintRange() {
      var r = ctx.storage.get("hintRange") || { lo: 0, hi: 100 };
      return { lo: Math.min(r.lo, r.hi), hi: Math.max(r.lo, r.hi) };
    }

    // The practice filters as query parameters — the same ones the base sends
    // for a random question (categories are tree node ids; tags as JSON).
    function filtersToQuery(f, limit) {
      f = f || {}; var p = ["random=1", "limit=" + (limit || 1)];
      if (f.standard) p.push("standard=1");
      if (f.categories && f.categories.length) p.push("categories=" + encodeURIComponent(f.categories.join(",")));
      if (f.subcategories && f.subcategories.length) p.push("subcategories=" + encodeURIComponent(f.subcategories.join(",")));
      if (f.alternateSubcategories && f.alternateSubcategories.length) p.push("alternateSubcategories=" + encodeURIComponent(f.alternateSubcategories.join(",")));
      if (f.difficulties && f.difficulties.length) p.push("difficulties=" + f.difficulties.join(","));
      if (f.setIds && f.setIds.length) p.push("setIds=" + encodeURIComponent(f.setIds.join(",")));
      else if (f.setNames && f.setNames.length) p.push("setNames=" + encodeURIComponent(f.setNames.join(",")));
      if (f.packetNumbers && f.packetNumbers.length) p.push("packetNumbers=" + f.packetNumbers.join(","));
      if (f.yearMin != null) p.push("yearMin=" + f.yearMin);
      if (f.yearMax != null) p.push("yearMax=" + f.yearMax);
      if (f.powermarkOnly) p.push("powermarkOnly=true");
      if (f.cleanOnly) p.push("cleanOnly=1");
      if (f.tags && f.tags.length) p.push("tags=" + encodeURIComponent(JSON.stringify(f.tags.map(function (t) { var o = { f: t.f, v: t.v, x: t.x ? 1 : 0 }; if (t.id) o.id = t.id; return o; }))));
      return p.join("&");
    }
    function activeFilters() { try { return (ctx.host.getActiveFilters && ctx.host.getActiveFilters()) || {}; } catch (e) { return {}; } }

    // A USEFUL hint names what the question wants: "this man…",
    // "these particles…", "For 10 points, name this…". Sentences without a
    // referent ("Two answers required.") make worthless flashcards.
    function goodHint(t) {
      return /\b(this|these)\s+[a-z]/i.test(t) ||
             /for\s+(10|ten)\s+points/i.test(t) ||
             /\b(name|identify|give)\s+(this|these|the)\b/i.test(t);
    }

    function makeCard(q, hint, hintNo) {
      return { qid: q.id, answer: displayAnswer(q), fullRaw: q.answer || "", fullSani: q.answer_sanitized || "",
        hint: hint, hintNo: hintNo, category: q.category || "", subcategory: q.subcategory || "", category_path: q.category_path || "",
        difficulty: q.difficulty != null ? q.difficulty : null, year: q.set_year || null,
        meta: (q.category || "") + (q.subcategory ? " / " + q.subcategory : "") + " · diff " + (q.difficulty != null ? q.difficulty : "?") };
    }
    function cardFromTossup(q) {
      var sents = splitSentences(hintText(q));
      if (!sents.length) return null;
      var r = hintRange();
      var n = sents.length;
      var loIdx = Math.max(0, Math.min(n - 1, Math.floor((r.lo / 100) * n)));
      var hiIdx = Math.max(loIdx, Math.min(n - 1, Math.ceil((r.hi / 100) * n) - 1));
      // Prefer referent sentences inside the range; else the nearest referent
      // sentence outside it; else fall back to anything in range.
      var good = [];
      for (var gi = 0; gi < n; gi++) if (goodHint(sents[gi])) good.push(gi);
      var inRange = good.filter(function (i) { return i >= loIdx && i <= hiIdx; });
      var idx;
      if (inRange.length) idx = inRange[Math.floor(Math.random() * inRange.length)];
      else if (good.length) {
        var mid = (loIdx + hiIdx) / 2;
        idx = good.reduce(function (best, i) { return Math.abs(i - mid) < Math.abs(best - mid) ? i : best; }, good[0]);
      } else {
        idx = loIdx + Math.floor(Math.random() * (hiIdx - loIdx + 1));
      }
      // Too short to be a clue? Pull in the neighbouring sentence too.
      var hint = sents[idx];
      var hintNo = (idx + 1) + "/" + n;
      if (hint.length < 60) {
        if (idx + 1 < n) { hint = hint + " " + sents[idx + 1]; hintNo = (idx + 1) + "–" + (idx + 2) + "/" + n; }
        else if (idx > 0) { hint = sents[idx - 1] + " " + hint; hintNo = idx + "–" + (idx + 1) + "/" + n; }
      }
      return makeCard(q, hint, hintNo);
    }
    // Every referent ("good") hint sentence within the hint range becomes its
    // own card, so review/starred study covers EVERY hint, not just one.
    function allHintCards(q) {
      var sents = splitSentences(hintText(q));
      var n = sents.length; if (!n) return [];
      var r = hintRange();
      var loIdx = Math.max(0, Math.min(n - 1, Math.floor((r.lo / 100) * n)));
      var hiIdx = Math.max(loIdx, Math.min(n - 1, Math.ceil((r.hi / 100) * n) - 1));
      var out = [];
      for (var i = loIdx; i <= hiIdx; i++) { if (goodHint(sents[i])) out.push(makeCard(q, sents[i], (i + 1) + "/" + n)); }
      if (!out.length) { var c = cardFromTossup(q); if (c) out.push(c); }
      return out;
    }
    async function buildReviewPool() {
      var cards = [];
      for (var i = 0; i < reviewPoolIds.length; i++) {
        try { var d = await ctx.api.get("/api/tossups/" + encodeURIComponent(reviewPoolIds[i])); if (d.tossup) allHintCards(d.tossup).forEach(function (c) { cards.push(c); }); } catch (e) {}
      }
      pool = shuffle(cards); poolIdx = 0; exhausted = false;
    }
    function buildStarredPool() {
      pool = shuffle(filteredStarred().slice()); poolIdx = 0; exhausted = false;
    }
    function finiteMode() { return sourceMode === "review" || sourceMode === "starred" || sourceMode === "custom"; }

    // ── one card at a time ──
    // Each card is recorded ONCE, when you move past it: "good" = Got it on
    // the first try, "again" = needed Again at least once, "skip" = neither.
    function settle(c) {
      if (!c || c._settled) return;
      c._settled = true;
      var result = c._again ? "again" : (c._good ? "good" : "skip");
      tally[result]++;
      recordSession({ result: result, answer: c.answer, category: c.category, hint: c.hint, fullRaw: c.fullRaw, fullSani: c.fullSani, meta: c.meta });
    }
    function atLatest() { return pos >= seen.length - 1; }
    function showCard(c) { card = c; if (c) { seen.push(c); pos = seen.length - 1; } flipped = false; render({ enter: true }); }
    // Back: re-show the previous card you saw (read-only history).
    function back() { if (pos > 0) { pos--; card = seen[pos]; flipped = false; render({ enter: true }); } }
    // Forward through already-seen cards, then a new one.
    function advance() {
      if (pos < seen.length - 1) { pos++; card = seen[pos]; flipped = false; render({ enter: true }); return; }
      nextCard();
    }

    function prefetchKey() { return filtersToQuery(activeFilters(), 1); }
    function fetchRandom(key) { return ctx.api.get("/api/tossups/query?" + key).then(function (res) { return (res && res.rows && res.rows[0]) || null; }); }
    function primeNext() {
      if (sourceMode !== "random") return;
      var key = prefetchKey();
      if (prefetched && prefetched.key === key) return;
      var pr = fetchRandom(key); pr.catch(function () {});
      prefetched = { key: key, promise: pr };
    }

    async function nextCard() {
      if (!body || loading) return;
      if (card && atLatest()) settle(card);
      loading = true; flipped = false; exhausted = false;
      if (card) { var ce = body.querySelector("#fc-card"); if (ce) ce.classList.add("fc-wait"); } else render();
      var next = null;
      try {
        if (finiteMode()) {
          if (!pool) {
            if (sourceMode === "review") await buildReviewPool();
            else if (sourceMode === "starred") buildStarredPool();
          }
          if (!pool || !pool.length) {
            // no starred card matches the filters: back to random cards
            if (sourceMode === "starred") { sourceMode = "random"; pool = null; loading = false; seen = []; pos = -1; card = null; return nextCard(); }
            card = null; loading = false; render(); return;
          }
          if (poolIdx >= pool.length) { finishDeck(); return; }
          next = Object.assign({}, pool[poolIdx++], { _settled: false, _again: false, _good: false });
        } else {
          var key = prefetchKey(), q;
          if (prefetched && prefetched.key === key) { q = await prefetched.promise.catch(function () { return null; }); prefetched = null; }
          else { prefetched = null; q = await fetchRandom(key); }
          next = q ? cardFromTossup(q) : null;
        }
      } catch (e) { next = null; }
      loading = false;
      if (!next) { card = null; render(); return; }
      showCard(next);
      primeNext();
    }
    function finishDeck() {
      loading = false; card = null; exhausted = true;
      bumpLife(function (st) { st.decks = (st.decks || 0) + 1; });
      render({ enter: true });
    }
    function restartPool() {
      seen = []; pos = -1; exhausted = false; card = null; tally = { good: 0, again: 0, skip: 0 };
      if (sourceMode === "review") { pool = null; nextCard(); }
      else if (sourceMode === "custom") { pool = shuffle(pool || []); poolIdx = 0; nextCard(); }   // re-run the same custom deck
      else { pool = null; nextCard(); }
    }
    function setSource(mode) {
      if (mode === sourceMode || loading) return;
      if (card && atLatest()) settle(card);
      sourceMode = mode; pool = null; poolIdx = 0; seen = []; pos = -1; card = null; exhausted = false;
      if (mode === "random") reviewPoolIds = [];
      tally = { good: 0, again: 0, skip: 0 };
      nextCard();
    }

    // Categories match by tree path: a card is in the selection when its
    // category_path is a selected path or lies under one. A card without a
    // path (saved before the tree and not resolvable) matches only when no
    // category is selected. Older bases send names, not paths.
    function filteredStarred() {
      var f = activeFilters();
      var paths = Array.isArray(f.categoryPaths) ? f.categoryPaths : null;
      return starredList().filter(function (c) {
        if (paths) {
          if (paths.length) {
            var cp = c.category_path ? String(c.category_path) : "";
            if (!cp || !paths.some(function (p) { return cp === p || cp.indexOf(p + " > ") === 0; })) return false;
          }
        } else {
          if (f.categories && f.categories.length && c.category && f.categories.indexOf(c.category) < 0) return false;
          if (f.subcategories && f.subcategories.length && c.subcategory && f.subcategories.indexOf(c.subcategory) < 0) return false;
        }
        if (f.difficulties && f.difficulties.length && c.difficulty != null && f.difficulties.indexOf(parseInt(c.difficulty, 10)) < 0) return false;
        if (f.yearMin != null && c.year && c.year < f.yearMin) return false;
        if (f.yearMax != null && c.year && c.year > f.yearMax) return false;
        return true;
      });
    }
    // Starred cards saved before the category tree carry only old names.
    // Each is re-resolved ONCE by its question id (category, subcategory,
    // category_path); one that can't be resolved is kept, marked pathTried so
    // it isn't retried, and matches only when no category is selected.
    var _resolving = null;
    function resolveStarredPaths() {
      if (_resolving) return _resolving;
      if (!(ctx.host && ctx.host.getCategoryTree)) return Promise.resolve(false);   // older base: no paths to find
      var todo = starredList().filter(function (c) { return c && c.qid && !c.category_path && !c.pathTried; });
      if (!todo.length) return Promise.resolve(false);
      _resolving = (async function () {
        var found = {};
        for (var i = 0; i < todo.length; i++) {
          var qid = String(todo[i].qid);
          if (Object.prototype.hasOwnProperty.call(found, qid)) continue;
          // A failed request leaves the card for the next visit; only an
          // answered lookup ("no such tossup" included) settles it.
          try { var d = await ctx.api.get("/api/tossups/" + encodeURIComponent(qid)); var t = d && d.tossup; found[qid] = t && t.category_path ? t : null; } catch (e) {}
        }
        // Merge into the CURRENT list: it may have changed while fetching.
        var list = starredList(), changed = false;
        list.forEach(function (c) {
          if (!c || !c.qid || c.category_path || c.pathTried || !Object.prototype.hasOwnProperty.call(found, String(c.qid))) return;
          var t = found[String(c.qid)];
          if (t) { c.category = t.category || ""; c.subcategory = t.subcategory || ""; c.category_path = t.category_path; }
          else c.pathTried = true;
          changed = true;
        });
        if (changed) ctx.storage.set("starred", list);
        return changed;
      })().catch(function () { return false; }).then(function (ch) { _resolving = null; return ch; });
      return _resolving;
    }

    // ── the practice setup panel, borrowed as this page's Setup drawer ──
    // CRITICAL: the panel goes home (returnPanel) BEFORE anything wipes the
    // page with innerHTML, or the settings menu is detached for good.
    function hintRangeLabel(lo, hi) { return lo <= 0 && hi >= 100 ? "All clues" : lo + "% – " + hi + "%"; }
    function hintSectionHtml() {
      var r = hintRange();
      return '<div class="filter-section fc-injected" id="fc-sec-hint">' +
        '<div class="filter-label">Hint from <span class="range-values" id="fc-hr-val">' + esc(hintRangeLabel(r.lo, r.hi)) + "</span></div>" +
        '<div class="dual-range fc-dual"><div class="dual-range-track"><div class="dual-range-fill" id="fc-hr-fill"></div></div>' +
          '<input type="range" id="fc-hr-lo" min="0" max="100" step="5" value="' + r.lo + '" aria-label="Earliest clue">' +
          '<input type="range" id="fc-hr-hi" min="0" max="100" step="5" value="' + r.hi + '" aria-label="Latest clue"></div>' +
        '<div class="fc-hr-ends"><span>Lead-in</span><span>Giveaway</span></div>' +
      "</div>";
    }
    function wireHintSlider(root) {
      var lo = root.querySelector("#fc-hr-lo"), hi = root.querySelector("#fc-hr-hi");
      if (!lo || !hi) return;
      function update() {
        var a = parseInt(lo.value, 10), b = parseInt(hi.value, 10);
        var mn = Math.min(a, b), mx = Math.max(a, b);
        var prev = hintRange();
        ctx.storage.set("hintRange", { lo: mn, hi: mx });
        var v = root.querySelector("#fc-hr-val"); if (v) v.textContent = hintRangeLabel(mn, mx);
        var fill = root.querySelector("#fc-hr-fill");
        if (fill) { fill.style.left = mn + "%"; fill.style.right = (100 - mx) + "%"; }
        // Changing the range rebuilds a handed-over deck (its cards are made
        // from the range); starred cards keep the clue that was starred.
        if ((mn !== prev.lo || mx !== prev.hi) && sourceMode === "review") { pool = null; poolIdx = 0; }
      }
      lo.addEventListener("input", update);
      hi.addEventListener("input", update);
      update();
    }
    function borrowPanel() {
      var host = body && body.querySelector(".fc-layout");
      if (!host) return;
      try { if (ctx.host && ctx.host.ensureFiltersLoaded) ctx.host.ensureFiltersLoaded(); } catch (e) {}
      var panel = document.getElementById("filters-panel") || borrowedPanel;
      if (!panel) return;
      // No set/packet selection here — cards always come from the category /
      // difficulty filters (a running custom list is left alone).
      var ms = document.getElementById("mode-select");
      if (ms && ms.value === "set") { ms.value = "random"; ms.dispatchEvent(new Event("change", { bubbles: true })); }
      if (panel.parentNode === host) return;
      if (!panelHome) panelHome = { parent: panel.parentNode, next: panel.nextSibling };
      panel.classList.remove("open");
      panel.classList.add("fc-borrowed");
      host.insertBefore(panel, host.firstChild);
      borrowedPanel = panel;
      var ft = panel.querySelector(".fp-title"); if (ft) ft.textContent = "Setup";
      var fs = panel.querySelector("#btn-drawer-start"); if (fs) fs.textContent = "Done";
      var cnt = panel.querySelector("#fp-count"); if (cnt) cnt.textContent = "";
      var holder = document.createElement("div"); holder.innerHTML = hintSectionHtml();
      var head = panel.querySelector(":scope > .fp-head"), at = head ? head.nextSibling : panel.firstChild;
      while (holder.firstChild) panel.insertBefore(holder.firstChild, at);
      wireHintSlider(panel);
      try {
        panelObserver = new MutationObserver(syncSetupBtn);
        panelObserver.observe(panel, { attributes: true, attributeFilter: ["class"] });
      } catch (e) { panelObserver = null; }
      syncSetupBtn();
    }
    function returnPanel() {
      if (!borrowedPanel || !panelHome) return;
      if (panelObserver) { try { panelObserver.disconnect(); } catch (e) {} panelObserver = null; }
      borrowedPanel.querySelectorAll(".fc-injected").forEach(function (n) { n.remove(); });
      borrowedPanel.classList.remove("fc-borrowed");
      borrowedPanel.classList.remove("open");
      var ft = borrowedPanel.querySelector(".fp-title"); if (ft) ft.textContent = "Practice setup";
      var fs = borrowedPanel.querySelector("#btn-drawer-start"); if (fs) fs.textContent = "Start";
      try { panelHome.parent.insertBefore(borrowedPanel, panelHome.next); } catch (e) {}
      borrowedPanel = null;
      syncSetupBtn();
    }
    function setupOpen() { return !!(borrowedPanel && borrowedPanel.classList.contains("open")); }
    function toggleSetup(on) {
      if (!borrowedPanel) borrowPanel();
      if (!borrowedPanel) return;
      var want = on == null ? !setupOpen() : !!on;
      borrowedPanel.classList.toggle("open", want);
      if (want) refreshCount();
      syncSetupBtn();
    }
    function setupBtn() { return page && page.screenEl && page.screenEl.querySelector(".fc-setup-btn"); }
    function syncSetupBtn() { var b = setupBtn(); if (b) b.setAttribute("aria-expanded", String(setupOpen())); }
    // How many tossups the setup matches, in the drawer's footer.
    var _countTimer = null, _countSeq = 0;
    function refreshCount() {
      clearTimeout(_countTimer);
      _countTimer = setTimeout(function () {
        if (!setupOpen()) return;
        var el = borrowedPanel && borrowedPanel.querySelector("#fp-count"); if (!el) return;
        var seq = ++_countSeq;
        var q = filtersToQuery(activeFilters(), 1).replace(/(^|&)(random|limit)=[^&]*/g, "").replace(/^&/, "");
        ctx.api.get("/api/tossups/count?" + q).then(function (d) {
          if (seq !== _countSeq || !setupOpen()) return;
          var n = d && typeof d.count === "number" ? d.count : null;
          el.textContent = n == null ? "" : n.toLocaleString() + (n === 1 ? " tossup" : " tossups");
        }).catch(function () { if (seq === _countSeq) el.textContent = ""; });
      }, 250);
    }
    // the page head gets a Setup button, like the practice page
    function addSetupButton() {
      var right = page && page.screenEl && page.screenEl.querySelector(".top-bar-right");
      if (!right || right.querySelector(".fc-setup-btn")) return;
      var b = document.createElement("button");
      b.type = "button"; b.className = "btn fc-setup-btn"; b.setAttribute("aria-expanded", "false");
      b.innerHTML = SVG(IC.sliders) + "Setup";
      b.addEventListener("click", function () { toggleSetup(); });
      right.insertBefore(b, right.firstChild);
    }

    // ── saved sessions (view + delete from the Statistics section) ──
    // Each entry stores the result + the FRONT (hint) and BACK (answer +
    // answer line) so the session window can show the card again.
    var sessId = null;
    function sessionsAll() { return ctx.storage.get("sessions") || []; }
    function recordSession(entry) {
      var all = sessionsAll();
      var cur = null;
      if (sessId) for (var i = 0; i < all.length; i++) if (all[i].id === sessId) { cur = all[i]; break; }
      if (!cur) { sessId = Date.now(); cur = { id: sessId, entries: [] }; all.unshift(cur); if (all.length > 60) all.length = 60; }
      cur.entries.push(entry);
      ctx.storage.set("sessions", all);
    }
    function fmtWhen(ts) {
      try { return new Date(ts).toLocaleString(undefined, { month: "short", day: "numeric", year: new Date(ts).getFullYear() === new Date().getFullYear() ? undefined : "numeric", hour: "numeric", minute: "2-digit" }); }
      catch (e) { return new Date(ts).toLocaleString(); }
    }

    // ── category badge, like the app's (root colour + "Root › Leaf") ──
    var ROOT_COLOR = { "Literature": "#bc8cff", "Science and Math": "#58a6ff", "Fine Arts": "#f778ba", "History": "#e3b341", "Geography": "#56d364", "Mythology": "#ffa657", "Pop Culture Sports": "#ff7b72", "Social Science": "#3dd6a3", "Philosophy": "#39c5cf", "Theology": "#8e9bff", "Current Events": "#c9d16b", "Miscellaneous": "#8b949e" };
    // Sessions recorded before the category tree name old roots.
    var OLD_ROOT = { "Science": "Science and Math", "Religion": "Theology", "Pop Culture": "Pop Culture Sports", "Trash": "Pop Culture Sports", "Other Academic": "Miscellaneous" };
    var DIFF_FULL = ["Unrated", "Middle school", "Easy high school", "Regular high school", "Hard high school", "National high school", "Easy college", "Medium college", "Regionals college", "Nationals college", "Open"];
    function catBadge(c) {
      var parts = c.category_path ? String(c.category_path).split(" > ") : [c.category, c.subcategory].filter(Boolean);
      if (!parts.length) return "";
      var root = OLD_ROOT[parts[0]] || parts[0];
      var short = parts.length > 1 ? parts[0] + " › " + parts[parts.length - 1] : parts[0];
      return '<span class="badge cat-badge" style="--c:' + (ROOT_COLOR[root] || "#8b949e") + '" title="' + esc(parts.join(" › ")) + '"><span class="dot"></span><span class="t">' + esc(short) + "</span></span>";
    }
    function metaBadges(c) {
      var h = catBadge(c);
      if (c.difficulty != null && c.difficulty !== "") h += '<span class="badge diff-badge" title="' + esc(DIFF_FULL[parseInt(c.difficulty, 10)] || "") + '">Diff ' + esc(String(c.difficulty)) + "</span>";
      if (c.year) h += '<span class="badge year-badge">' + esc(String(c.year)) + "</span>";
      if (!h && c.meta) h = '<span class="fc-meta-txt">' + esc(c.meta) + "</span>";
      return h;
    }
    // Which sentence(s) of the tossup the hint is: "4/9" or "2–3/9".
    function clueSpot(c) {
      var m = /^(\d+)(?:[–-](\d+))?\/(\d+)$/.exec(String(c.hintNo || ""));
      if (!m) return null;
      var a = parseInt(m[1], 10), b = parseInt(m[2] || m[1], 10), n = parseInt(m[3], 10);
      return n > 0 ? { a: a, b: b, n: n } : null;
    }
    function clueSpotHtml(c) {
      var s = clueSpot(c); if (!s) return "";
      var dots = "";
      if (s.n <= 16) for (var i = 1; i <= s.n; i++) dots += '<i class="' + (i >= s.a && i <= s.b ? "on" : "") + '"></i>';
      else dots = '<span class="fc-spot-bar"><b style="left:' + ((s.a - 1) / s.n * 100) + "%;width:" + Math.max(4, (s.b - s.a + 1) / s.n * 100) + '%"></b></span>';
      return '<div class="fc-spot" title="Clue ' + (s.a === s.b ? s.a : s.a + "–" + s.b) + " of " + s.n + '"><span class="fc-dots">' + dots + '</span><span class="fc-spot-l num">Clue ' + (s.a === s.b ? s.a : s.a + "–" + s.b) + " / " + s.n + "</span></div>";
    }

    // ── per-session window (from the Statistics section) ──────────────────
    function resultMark(r) {
      if (r === "good") return '<span class="fc-res good">' + SVG(IC.check, 13) + "Got it</span>";
      if (r === "again") return '<span class="fc-res again">Again</span>';
      return '<span class="fc-res skip">Skipped</span>';
    }
    function byCategory(entries) {
      var map = {}, order = [];
      entries.forEach(function (e) {
        var k = (e.category && String(e.category).trim()) || "Other";
        if (Object.prototype.hasOwnProperty.call(OLD_ROOT, k)) k = OLD_ROOT[k];
        if (!map[k]) { map[k] = { good: 0, again: 0, skip: 0, total: 0 }; order.push(k); }
        var g = map[k]; g.total++;
        if (e.result === "good") g.good++; else if (e.result === "again") g.again++; else g.skip++;
      });
      return order.map(function (k) { return { name: k, g: map[k] }; });
    }
    function closeOverlay(el) { if (!el) return; if (ctx.host && ctx.host.animateRemove) ctx.host.animateRemove(el); else el.remove(); }
    function modalShell(cls, title, sub, bodyHtml) {
      var el = document.createElement("div");
      el.className = "qb-overlay app-ovl fc-ovl " + cls;
      el.setAttribute("role", "dialog"); el.setAttribute("aria-modal", "true");
      el.innerHTML =
        '<div class="settings-modal fc-modal" tabindex="-1">' +
          '<div class="modal-head"><h2>' + esc(title) + "</h2>" + (sub ? '<span class="fc-modal-sub">' + esc(sub) + "</span>" : "") +
            '<span class="spacer"></span><button type="button" class="btn btn-ghost btn-icon fc-modal-x" aria-label="Close">' + SVG(IC.x, 18) + "</button></div>" +
          '<div class="fc-modal-body">' + bodyHtml + "</div>" +
        "</div>";
      el.addEventListener("click", function (ev) { if (ev.target === el || ev.target.closest(".fc-modal-x")) closeOverlay(el); });
      document.body.appendChild(el);
      return el;
    }
    function openSessionModal(sess) {
      var entries = sess.entries || [];
      var total = entries.length;
      var good = entries.filter(function (e) { return e.result === "good"; }).length;
      var agains = entries.filter(function (e) { return e.result === "again"; }).length;
      var skips = entries.filter(function (e) { return e.result !== "good" && e.result !== "again"; }).length;
      var rate = total ? Math.round((good / total) * 100) : 0;
      var summary =
        '<div class="fc-sum">' +
          '<div class="stat-card"><div class="stat-card-value">' + total + '</div><div class="stat-card-label">Cards</div></div>' +
          '<div class="stat-card"><div class="stat-card-value fc-c-good">' + good + '</div><div class="stat-card-label">Got it</div></div>' +
          '<div class="stat-card"><div class="stat-card-value fc-c-again">' + agains + '</div><div class="stat-card-label">Again</div></div>' +
          '<div class="stat-card"><div class="stat-card-value">' + skips + '</div><div class="stat-card-label">Skipped</div></div>' +
          '<div class="stat-card"><div class="stat-card-value">' + rate + '%</div><div class="stat-card-label">First try</div></div>' +
        "</div>";
      var strip = total ? '<section class="fc-msec"><div class="eyebrow">Results</div><div class="fc-strip">' + entries.map(function (e, i) {
        var cls = e.result === "good" ? "good" : e.result === "again" ? "again" : "skip";
        return '<span class="' + cls + '" title="' + esc((i + 1) + ". " + (e.answer || "")) + '"></span>';
      }).join("") + "</div></section>" : "";
      var cats = byCategory(entries);
      var catBlock = cats.length ? '<section class="fc-msec"><div class="eyebrow">By category</div>' + cats.map(function (c) {
        var g = c.g;
        return '<div class="fc-catrow"><span class="fc-catname" title="' + esc(c.name) + '"><i style="background:' + (ROOT_COLOR[c.name] || "#8b949e") + '"></i>' + esc(c.name) + "</span>" +
          '<span class="fc-stack"><b class="good" style="width:' + (g.good / g.total * 100) + '%"></b><b class="again" style="width:' + (g.again / g.total * 100) + '%"></b></span>' +
          '<span class="fc-catcount num">' + g.good + "/" + g.total + "</span></div>";
      }).join("") + "</section>" : "";
      var list = entries.map(function (e, i) {
        var backLine = ansHtml(e.fullRaw, e.fullSani);
        return '<div class="fc-hrow">' +
          '<div class="fc-hrow-head"><span class="fc-hidx num">' + (i + 1) + "</span>" + resultMark(e.result) + '<span class="spacer"></span>' +
            (e.meta || e.category ? '<span class="fc-hmeta">' + esc(e.meta || e.category) + "</span>" : "") + "</div>" +
          (e.hint ? '<div class="fc-hclue">' + esc(e.hint) + "</div>" : "") +
          '<div class="fc-hans"><b>' + esc(e.answer || "") + "</b>" + (backLine && backLine !== esc(e.answer || "") ? '<span class="fc-hline">' + backLine + "</span>" : "") + "</div>" +
        "</div>";
      }).join("");
      modalShell("fc-stm-overlay", "Flashcard session", fmtWhen(sess.id),
        summary + strip + catBlock + '<section class="fc-msec"><div class="eyebrow">Cards</div><div class="fc-hist">' + (list || '<div class="fc-empty">No cards yet</div>') + "</div></section>");
    }

    function sessionsHtml() {
      var all = sessionsAll();
      if (!all.length) return "";
      var rows = all.map(function (sess, i) {
        var n = sess.entries.length, ok = sess.entries.filter(function (e) { return e.result === "good"; }).length;
        return '<tr class="session-row" data-view="' + i + '" style="cursor:pointer">' +
          "<td>" + esc(fmtWhen(sess.id)) + '</td><td class="num">' + n + '</td><td class="num">' + ok + "</td>" +
          '<td style="text-align:right"><button type="button" class="btn btn-sm btn-ghost btn-icon session-delete" data-del="' + i + '" aria-label="Delete session">' + SVG(IC.x, 14) + "</button></td></tr>";
      }).join("");
      return '<div class="fc-stats-h eyebrow">Sessions</div>' +
        '<table class="stats-table fc-sess-table"><thead><tr><th>Session</th><th>Cards</th><th>Got it</th><th></th></tr></thead><tbody>' + rows + "</tbody></table>" +
        '<button type="button" class="btn btn-sm btn-ghost" id="fc-sess-clear">Delete all sessions</button>';
    }
    function wireSessions(el, rerender) {
      el.querySelectorAll("[data-view]").forEach(function (b) {
        b.onclick = function (ev) {
          if (ev.target.closest(".session-delete")) return;
          var sess = sessionsAll()[parseInt(b.dataset.view, 10)];
          if (sess) openSessionModal(sess);
        };
      });
      el.querySelectorAll("[data-del]").forEach(function (b) {
        b.onclick = function () {
          var doDel = function () { var all = sessionsAll(); all.splice(parseInt(b.dataset.del, 10), 1); ctx.storage.set("sessions", all); rerender(); };
          if (ctx.host && ctx.host.confirm) ctx.host.confirm("Delete this flashcard session?", doDel);
          else doDel();
        };
      });
      var ca = el.querySelector("#fc-sess-clear");
      if (ca) ca.onclick = function () {
        var doClear = function () { ctx.storage.set("sessions", []); rerender(); };
        if (ctx.host && ctx.host.confirm) ctx.host.confirm("Delete all flashcard sessions?", doClear);
        else doClear();
      };
    }

    page = ctx.registerPage({
      id: "cards", navLabel: "Flashcards", title: "Flashcards",
      onShow: function (el, info) {
        body = el;
        el.classList.add("fc-host");
        addSetupButton();
        // A list handed over by another screen (Review, Starred, Buzz Words …)
        // replaces the card on screen: that card is settled into the session
        // it belongs to first.
        var cc = null, handoff = null, handed = false;
        try {
          // Custom cards (e.g. Buzz Words / Keyword Frequency "review as
          // flashcards"): each card is a {front, back} pair — no question id.
          cc = JSON.parse(localStorage.getItem("qb-flashcards-cards") || "null");
          if (cc && cc.cards && cc.cards.length) localStorage.removeItem("qb-flashcards-cards"); else cc = null;
          if (!cc) {
            handoff = JSON.parse(localStorage.getItem("qb-flashcards-handoff") || "null");
            if (handoff && handoff.ids && handoff.ids.length) localStorage.removeItem("qb-flashcards-handoff"); else handoff = null;
          }
        } catch (e) { cc = null; handoff = null; }
        if ((cc || handoff) && card && atLatest()) settle(card);
        // Back returns you to the card you left mid-session; only a fresh
        // entry starts a new recorded session.
        if (!(info && info.back)) {
          sessId = null; tally = { good: 0, again: 0, skip: 0 };
          seen = card ? [card] : []; pos = seen.length - 1;
        }
        // Old starred cards learn their tree path (once); the Starred button
        // then reflects them.
        resolveStarredPaths().then(function (ch) { if (ch) syncSourceSeg(); });
        if (cc) {
          pool = shuffle(cc.cards.slice(0, 500).map(function (x) {
            return { qid: null, answer: x.back || "", fullRaw: x.back || "", fullSani: "", hint: x.front || "", hintNo: x.label || "", category: "", subcategory: "", difficulty: null, year: null, meta: x.meta || "" };
          }));
          poolIdx = 0; sourceMode = "custom"; card = null; seen = []; pos = -1; exhausted = false; handed = true;
        } else if (handoff) {
          reviewPoolIds = handoff.ids.slice(0, 200);
          card = null; pool = null; sourceMode = "review"; seen = []; pos = -1; exhausted = false; handed = true;
        }
        if (handed) tally = { good: 0, again: 0, skip: 0 };
        // Back: the page the user left is still in the DOM, so don't wipe and
        // rebuild it — onHide only sent the borrowed panel home, so take it
        // back and leave the card exactly as it was.
        if (!handed && info && info.back && body.querySelector(".fc-layout > .fc-main")) { borrowPanel(); return; }
        if (!card && !exhausted) nextCard();
        else render();
      },
      onHide: function () { returnPanel(); },
    });
    addSetupButton();
    function active() { return page && page.screenEl && page.screenEl.classList.contains("active"); }
    ctx.on("screen:change", function () { setTimeout(function () { if (!active()) returnPanel(); }, 0); });

    // Right-click "View full question": the card's tossup in a window.
    async function viewFullQuestion(c) {
      if (!c || !c.qid) return;
      var d = null;
      try { d = await ctx.api.get("/api/tossups/" + encodeURIComponent(c.qid)); } catch (e) {}
      var q = d && d.tossup;
      document.querySelector(".fc-viewer")?.remove();
      // A tossup that is gone (a starred card after a database update) still
      // shows what the card holds.
      var meta = q ? metaBadges(makeCard(q, "", "")) + (q.set_name ? '<span class="fc-meta-txt">' + esc(q.set_name) + "</span>" : "") : metaBadges(c);
      modalShell("fc-viewer", "Question", "",
        '<div class="fc-v-meta qmeta-row">' + meta + "</div>" +
        '<div class="fc-v-q">' + esc(q ? readText(q) : c.hint || "").replace(/\(\*\)/g, '<span class="fc-pm">(*)</span>') + "</div>" +
        '<div class="fc-v-a"><span class="eyebrow">Answer</span><div>' + (q ? ansHtml(q.answer, q.answer_sanitized) : ansHtml(c.fullRaw, c.fullSani)) + "</div></div>");
    }

    function cardContextMenu(e) {
      if (!card) return;
      e.preventDefault();
      var c = card;
      var items = [];
      if (c.qid) items.push({ label: "View full question", onClick: function () { viewFullQuestion(c); } });
      items.push({ label: flipped ? "Show the clue" : "Show the answer", onClick: flip });
      if (ctx.host && ctx.host.searchDatabase && c.answer) items.push({ label: "Find questions with this answer", onClick: function () { ctx.host.searchDatabase({ query: c.answer, field: "answer", exact: false }); } });
      items.push({ sep: true });
      if (c.qid) items.push({ label: isCardStarred(c) ? "Unstar card" : "Star card", onClick: function () { toggleCardStar(c); } });
      items.push({ label: "Copy clue", onClick: function () { try { navigator.clipboard.writeText(c.hint); } catch (err) {} } });
      items.push({ label: "Copy answer", onClick: function () { try { navigator.clipboard.writeText(c.answer); } catch (err) {} } });
      ctx.contextMenu(e.clientX, e.clientY, items, { title: flipped ? c.answer : "Flashcard" });
    }

    function starredList() { return ctx.storage.get("starred") || []; }
    function isCardStarred(c) { return !!c && starredList().some(function (x) { return x.qid === c.qid && x.hint === c.hint; }); }
    function toggleCardStar(c) {
      if (!c || !c.qid) return;
      var list = starredList();
      var i = list.findIndex(function (x) { return x.qid === c.qid && x.hint === c.hint; });
      if (i >= 0) list.splice(i, 1);
      else list.push({ qid: c.qid, answer: c.answer, fullRaw: c.fullRaw, fullSani: c.fullSani, hint: c.hint, meta: c.meta, hintNo: c.hintNo, category: c.category || "", subcategory: c.subcategory || "", category_path: c.category_path || "", difficulty: c.difficulty != null ? c.difficulty : null, year: c.year || null });
      ctx.storage.set("starred", list);
      ctx.playSound("star");
      syncStars(); syncSourceSeg();
    }
    function syncStars() {
      if (!body) return;
      var on = isCardStarred(card);
      body.querySelectorAll(".fc-star").forEach(function (s) {
        s.classList.toggle("on", on); s.textContent = on ? "★" : "☆";
        s.setAttribute("aria-pressed", String(on)); s.title = on ? "Unstar card" : "Star card";
      });
    }

    // The page is built once; renders replace only .fc-main, so the borrowed
    // panel (a sibling of .fc-main) is never inside an innerHTML wipe — and an
    // open Setup drawer stays open, without replaying its animation.
    function ensureShell() {
      if (body.querySelector(".fc-layout > .fc-main")) { borrowPanel(); return body.querySelector(".fc-main"); }
      // CRITICAL: give the borrowed panel back BEFORE innerHTML wipes the body
      // (otherwise the panel is detached from the DOM and the settings menu
      // disappears for good). Re-borrow right after.
      returnPanel();
      body.innerHTML = '<div class="fc-layout fc-page"><div class="fc-main"></div></div>';
      borrowPanel();
      return body.querySelector(".fc-main");
    }

    function sourceSegHtml() {
      var nStar = filteredStarred().length;
      var b = function (mode, label, n, disabled) {
        return '<button type="button" data-src="' + mode + '" aria-pressed="' + (sourceMode === mode) + '"' + (disabled ? " disabled" : "") + ">" + label + (n != null ? '<span class="btn-num num">' + n + "</span>" : "") + "</button>";
      };
      var h = b("random", "Random", null, false) + b("starred", "Starred", nStar, !nStar && sourceMode !== "starred");
      if (sourceMode === "review") h += b("review", "Deck", pool ? pool.length : reviewPoolIds.length, false);
      if (sourceMode === "custom") h += b("custom", "Deck", pool ? pool.length : 0, false);
      return '<div class="seg fc-src" role="group" aria-label="Cards">' + h + "</div>";
    }
    function syncSourceSeg() {
      var seg = body && body.querySelector(".fc-src"); if (!seg) return;
      var t = document.createElement("div"); t.innerHTML = sourceSegHtml();
      seg.replaceWith(t.firstChild);
      wireSourceSeg();
    }
    function wireSourceSeg() {
      body.querySelectorAll(".fc-src [data-src]").forEach(function (b) {
        b.onclick = function () { if (!b.disabled) setSource(b.dataset.src); };
      });
    }
    function tallyHtml() {
      var n = finiteMode() && pool ? (card ? (pos + 1) + " / " + pool.length : "") : (card ? "Card " + (pos + 1) : "");
      return '<div class="fc-tally num">' +
        (n ? '<span class="fc-t-n">' + n + "</span>" : "") +
        '<span class="fc-t-good" title="Got it">' + SVG(IC.check, 13) + tally.good + "</span>" +
        '<span class="fc-t-again" title="Again">↻ ' + tally.again + "</span>" +
      "</div>";
    }
    function progressHtml() {
      if (!(finiteMode() && pool && pool.length)) return "";
      var done = exhausted ? pool.length : Math.max(0, pos + 1);
      return '<div class="fc-prog" aria-hidden="true"><i style="width:' + Math.min(100, done / pool.length * 100) + '%"></i></div>';
    }

    function faceHead(c) {
      var st = isCardStarred(c);
      return '<header class="fc-face-head"><div class="qmeta-row">' + metaBadges(c) + "</div>" +
        (c.qid ? '<span class="star-toggle fc-star' + (st ? " on" : "") + '" role="button" aria-pressed="' + st + '" title="' + (st ? "Unstar card" : "Star card") + '">' + (st ? "★" : "☆") + "</span>" : "") +
      "</header>";
    }
    function cardHtml(c, enter) {
      var line = ansHtml(c.fullRaw, c.fullSani);
      var showLine = line && line.replace(/<[^>]+>/g, "").trim() !== String(c.answer || "").trim();
      return '<div class="fc-card' + (flipped ? " flipped" : "") + (enter ? " fc-enter" : "") + '" id="fc-card">' +
        '<div class="fc-inner">' +
          '<section class="fc-face fc-front" aria-hidden="' + flipped + '">' + faceHead(c) +
            '<div class="fc-face-body"><div class="fc-clue">' + esc(c.hint) + "</div></div>" +
            '<footer class="fc-face-foot">' + clueSpotHtml(c) + "</footer>" +
          "</section>" +
          '<section class="fc-face fc-back" aria-hidden="' + !flipped + '">' + faceHead(c) +
            '<div class="fc-face-body"><div class="eyebrow fc-ans-k">Answer</div><div class="fc-ans">' + esc(c.answer || "") + "</div>" +
              (showLine ? '<div class="fc-ansline">' + line + "</div>" : "") + "</div>" +
            '<footer class="fc-face-foot"><div class="fc-back-clue">' + esc(c.hint) + "</div></footer>" +
          "</section>" +
        "</div>" +
      "</div>";
    }
    function statusCardHtml(inner, enter) {
      return '<div class="fc-card fc-status' + (enter ? " fc-enter" : "") + '" id="fc-card-status"><div class="fc-face fc-solo">' + inner + "</div></div>";
    }
    function actionsHtml() {
      if (!card) return "";
      var prev = pos > 0 ? '<button type="button" class="btn btn-icon fc-prev" id="fc-back" aria-label="Previous card" title="Previous card">' + SVG(IC.left, 18) + "</button>" : "";
      if (!atLatest()) {
        return prev + '<button type="button" class="btn btn-primary" id="fc-flip">' + (flipped ? "Show clue" : "Flip") + kbd("flip") + "</button>" +
          '<button type="button" class="btn" id="fc-skip">Next' + kbd("skip") + "</button>";
      }
      if (flipped) {
        return prev + '<button type="button" class="btn" id="fc-again">Again' + kbd("again") + "</button>" +
          '<button type="button" class="btn btn-go" id="fc-good">Got it' + kbd("good") + "</button>" +
          '<button type="button" class="btn btn-ghost" id="fc-skip">Skip' + kbd("skip") + "</button>";
      }
      return prev + '<button type="button" class="btn btn-primary" id="fc-flip">Flip' + kbd("flip") + "</button>" +
        '<button type="button" class="btn" id="fc-skip">Skip' + kbd("skip") + "</button>";
    }
    function wireActions() {
      var on = function (sel, fn) { var b = body.querySelector(sel); if (b) b.onclick = fn; };
      on("#fc-flip", function () { flip(); });
      on("#fc-again", function () { again(); });
      on("#fc-good", function () { good(); });
      on("#fc-back", function () { back(); });
      on("#fc-skip", function () { advance(); });
    }
    function syncActions() {
      var bar = body && body.querySelector(".fc-actions"); if (!bar) return;
      bar.innerHTML = actionsHtml();
      wireActions();
    }

    function render(opts) {
      if (!body) return;
      var enter = !!(opts && opts.enter);
      var main;
      if (exhausted) {
        var tot = tally.good + tally.again + tally.skip;
        main = statusCardHtml(
          '<div class="fc-done-ico">' + SVG(IC.check, 26) + "</div>" +
          '<div class="fc-status-t">Deck finished</div>' +
          (tot ? '<div class="fc-done-sum num"><span>' + tot + (tot === 1 ? " card" : " cards") + "</span><span class=\"fc-c-good\">" + tally.good + " got it</span><span class=\"fc-c-again\">" + tally.again + " again</span></div>" : "") +
          '<div class="fc-status-btns"><button type="button" class="btn btn-primary" id="fc-restart">Study again</button><button type="button" class="btn" id="fc-random">Random cards</button></div>', enter);
      } else if (!card) {
        main = statusCardHtml(loading
          ? '<div class="fc-loading">' + (ctx.loadingBarHtml ? ctx.loadingBarHtml("Loading") : "Loading…") + "</div>"
          : '<div class="fc-status-ico">' + SVG(IC.cards, 26) + '</div><div class="fc-status-t">No cards match</div>' +
            '<div class="fc-status-btns"><button type="button" class="btn" id="fc-open-setup">' + SVG(IC.sliders) + "Setup</button>" +
              (sourceMode === "random" ? '<button type="button" class="btn btn-primary" id="fc-retry">Try again</button>' : '<button type="button" class="btn btn-primary" id="fc-random">Random cards</button>') + "</div>", enter);
      } else {
        main = cardHtml(card, enter);
      }
      ensureShell().innerHTML =
        '<div class="fc-bar">' + sourceSegHtml() + '<span class="spacer"></span>' + (card || exhausted ? tallyHtml() : "") + "</div>" +
        progressHtml() +
        main +
        '<div class="practice-actions fc-actions">' + actionsHtml() + "</div>";
      var cardEl = body.querySelector("#fc-card");
      if (cardEl) {
        cardEl.addEventListener("click", function (e) { if (e.target.closest(".fc-star, a, button")) return; flip(); });
        cardEl.addEventListener("contextmenu", cardContextMenu);
      }
      body.querySelectorAll(".fc-star").forEach(function (s) { s.addEventListener("click", function (e) { e.stopPropagation(); toggleCardStar(card); }); });
      wireSourceSeg();
      wireActions();
      var rs = body.querySelector("#fc-restart"); if (rs) rs.onclick = restartPool;
      var rnd = body.querySelector("#fc-random"); if (rnd) rnd.onclick = function () { exhausted = false; setSource("random"); };
      var rt = body.querySelector("#fc-retry"); if (rt) rt.onclick = function () { nextCard(); };
      var os = body.querySelector("#fc-open-setup"); if (os) os.onclick = function () { toggleSetup(true); };
    }

    function setFlipped(v) {
      flipped = !!v;
      var el = body && body.querySelector("#fc-card");
      if (!el) { render(); return; }
      el.classList.remove("fc-enter");
      el.classList.toggle("flipped", flipped);
      var fr = el.querySelector(".fc-front"), bk = el.querySelector(".fc-back");
      if (fr) fr.setAttribute("aria-hidden", String(flipped));
      if (bk) bk.setAttribute("aria-hidden", String(!flipped));
      syncActions();
    }
    function flip() {
      if (!card || !body) return;
      ctx.playSound("toggle");
      setFlipped(!flipped);
    }
    // Again = flip BACK to the clue of the SAME card (no new card).
    function again() {
      if (!card) return;
      if (!atLatest()) { advance(); return; }   // Again only applies to the live card
      card._again = true;
      ctx.playSound("skip");
      bumpLife(function (st) { st.agains++; });
      setFlipped(false);
    }
    function good() {
      if (!card) return;
      if (!atLatest()) { advance(); return; }   // grading only on the live card
      ctx.playSound("correct");
      bumpLife(function (st) { st.studied++; if (!card._again) st.firstTry++; });
      card._good = true;
      advance();
    }

    // Rebindable hotkeys (Settings > Keybinds). Handlers no-op off-page.
    function quiet() { return document.querySelector("#cat-ovl:not(.hidden), .fc-ovl"); }
    ctx.onHotkey("flip", function () { if (active() && card && !quiet()) flip(); });
    ctx.onHotkey("again", function () { if (active() && flipped && !quiet()) again(); });
    ctx.onHotkey("good", function () { if (active() && flipped && !quiet()) good(); });
    ctx.onHotkey("skip", function () { if (active() && !quiet() && !exhausted) advance(); });
    // Enter flips too (fixed convenience alias); Esc closes the Setup drawer.
    function onKey(e) {
      if (!active()) return;
      var t = e.target && e.target.tagName; if (t === "INPUT" || t === "TEXTAREA" || t === "SELECT" || t === "BUTTON") return;
      if (e.key === "Enter" && card && !quiet()) { e.preventDefault(); flip(); }
    }
    document.addEventListener("keydown", onKey);
    function onEsc(e) {
      if (e.key !== "Escape" || !active() || !setupOpen()) return;
      if (document.querySelector('#cat-ovl:not(.hidden), .qb-select[data-open="true"], .pop:not([hidden]), .qb-overlay:not(.hidden):not(.settings-ovl)')) return;
      e.preventDefault(); e.stopPropagation(); toggleSetup(false);
    }
    window.addEventListener("keydown", onEsc, true);
    // The Starred count follows filter edits made in the drawer, and the
    // footer counts what matches.
    function onFilterEdit(e) {
      if (!active() || !(e.target && e.target.closest && e.target.closest("#filters-panel"))) return;
      if (e.target.closest(".fc-injected")) return;
      setTimeout(syncSourceSeg, 0);
      refreshCount();
    }
    document.addEventListener("change", onFilterEdit, true);
    document.addEventListener("input", onFilterEdit, true);
    ctx._cleanup = function () {
      returnPanel();
      document.removeEventListener("keydown", onKey);
      window.removeEventListener("keydown", onEsc, true);
      document.removeEventListener("change", onFilterEdit, true);
      document.removeEventListener("input", onFilterEdit, true);
      document.querySelectorAll(".fc-ovl").forEach(function (o) { o.remove(); });
    };

    // ── starred flashcards: kept in plugin storage; their own Starred tab ──
    //    Styled like the normal Starred tab (question cards, star toggle);
    //    unstarring keeps the card on screen (toggle back to re-star) — it
    //    only drops off the list the next time the tab renders.
    function cardKey(c) { return c.qid + "" + c.hint; }
    // Button on the base Starred screen: study the starred TOSSUPS as flashcards.
    if (ctx.registerStarredAction) ctx.registerStarredAction({
      id: "run-flashcards", label: "Flashcards",
      run: function (items) {
        var ids = (items || []).filter(function (it) { return it.type === "tossup" && it.question && it.question.id; }).map(function (it) { return it.question.id; });
        if (!ids.length) return;
        ctx.launchQuestions("flashcards", ids);
      },
    });
    ctx.registerStarredProvider({
      id: "flashcards",
      title: "Starred Flashcards",
      render: function (container) {
        var list = starredList();
        if (!list.length) { container.innerHTML = '<div class="fc-empty">No starred flashcards yet</div>'; return; }
        container.innerHTML = list.map(function (c) {
          return '<div class="qcard expanded fc-scard">' +
            '<div class="qcard-head"><span class="qcard-chev" aria-hidden="true"></span>' +
              '<span class="qcard-meta">' + metaBadges(c) + "</span>" +
              '<span class="qcard-side">' + (((ctx.host && ctx.host.openItemSaveMenu) || window.QBFolders) ? '<span class="star-btn save-plus fc-foldx" data-key="' + esc(cardKey(c)) + '" title="Save to review / folders">+</span>' : "") +
                '<span class="star-toggle fc-sstar on" data-key="' + esc(cardKey(c)) + '" title="Unstar">★</span></span></div>' +
            '<div class="qcard-answer"><span class="ra-k">Answer</span><span class="ans">' + esc(c.answer || c.front || "") + "</span></div>" +
            '<div class="qcard-body"><div class="qcard-text">' + esc(c.hint) + "</div>" +
            '<div class="qcard-foot">' + ansHtml(c.fullRaw || c.full, c.fullSani || "") + "</div></div></div>";
        }).join("");
        container.querySelectorAll(".fc-foldx").forEach(function (s) {
          s.addEventListener("click", function (ev) {
            ev.stopPropagation();
            var c = starredList().find(function (x) { return cardKey(x) === s.dataset.key; });
            if (!c) return;
            var cd = { front: c.hint || c.front || "", back: c.answer || "", meta: c.meta || "flashcard" };
            var spec = { review: { kind: "flashcard", front: cd.front, back: cd.back, meta: cd.meta }, folder: { type: "flashcards", item: { card: cd } } };
            if (ctx.host && ctx.host.openItemSaveMenu) ctx.host.openItemSaveMenu(spec, s);
            else if (window.QBFolders) window.QBFolders.pick("flashcards", spec.folder.item, s);
          });
        });
        container.querySelectorAll(".fc-sstar").forEach(function (st) {
          st.addEventListener("click", function (ev) {
            ev.stopPropagation();
            var key = st.dataset.key;
            var list2 = starredList();
            var i = list2.findIndex(function (c) { return cardKey(c) === key; });
            if (i >= 0) {
              // unstar — but KEEP the card visible so it can be re-starred
              st._removed = list2.splice(i, 1)[0];
              ctx.storage.set("starred", list2);
              st.textContent = "☆"; st.classList.remove("on"); st.title = "Star";
            } else if (st._removed) {
              list2.push(st._removed);
              ctx.storage.set("starred", list2);
              st.textContent = "★"; st.classList.add("on"); st.title = "Unstar";
            }
          });
        });
      },
    });

    // ── Statistics screen section ──
    ctx.registerStatsProvider({
      id: "flashcards",
      title: "Flashcards",
      render: function renderStats(el) {
        var st = lifeStats();
        if (!st.studied && !st.agains && !sessionsAll().length) { el.innerHTML = '<div class="fc-empty">No flashcards yet</div>'; return; }
        var rate = st.studied ? Math.round((st.firstTry / st.studied) * 100) : 0;
        el.innerHTML =
          '<div class="stats-grid fc-stats-grid">' +
            '<div class="stat-card"><div class="stat-card-value">' + st.studied + '</div><div class="stat-card-label">Got it</div></div>' +
            '<div class="stat-card"><div class="stat-card-value">' + rate + '%</div><div class="stat-card-label">First try</div></div>' +
            '<div class="stat-card"><div class="stat-card-value">' + st.agains + '</div><div class="stat-card-label">Agains</div></div>' +
            '<div class="stat-card"><div class="stat-card-value">' + (st.decks || 0) + '</div><div class="stat-card-label">Decks finished</div></div>' +
            '<div class="stat-card"><div class="stat-card-value">' + starredList().length + '</div><div class="stat-card-label">Starred</div></div>' +
          "</div>" + sessionsHtml();
        wireSessions(el, function () { renderStats(el); });
        // Session list pages with "Show more" (base helper; older bases skip).
        try { if (ctx.host && ctx.host.limitList) ctx.host.limitList(el.querySelector(".fc-sess-table"), "tbody > tr", "fc:sessions", 10, 25); } catch (e) {}
      },
    });
  }
