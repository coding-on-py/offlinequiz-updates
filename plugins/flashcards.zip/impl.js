function __qbMain(ctx) {
    var body = null, page = null;
    var card = null, flipped = false, loading = false;
    var reviewPoolIds = []; // the review ids backing the current review pool
    var seen = [], pos = -1; // history of shown cards (for the Back button)
    var cardHadAgain = false; // current card needed an Again before Got-it
    var sourceMode = "random";  // "random" (filtered) | "starred" | "review"
    var pool = null, poolIdx = 0, exhausted = false;

    // ── lifetime stats (persisted in plugin storage) ──
    function lifeStats() {
      return ctx.storage.get("stats") || { studied: 0, firstTry: 0, agains: 0, decks: 0 };
    }
    function bumpLife(fn) { var st = lifeStats(); fn(st); ctx.storage.set("stats", st); }
    var borrowedPanel = null, panelHome = null;
    var DECK_SIZE = 20; // limit token reused by filtersToQuery; fetches are limit=1

    function esc(s) { return (s == null ? "" : String(s)).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"); }
    var KEY_DEFAULTS = { flip: "Space", again: "1", good: "2", skip: "S" };
    function keyLabel(id) {
      try { var v = ctx.keyLabel && ctx.keyLabel(id); if (v && v !== "?") return v; } catch (e) {}
      return KEY_DEFAULTS[id] || "?";
    }
    function ansHtml(raw, fallback) {
      var src = (raw && String(raw).trim()) ? String(raw) : String(fallback || "");
      return esc(src).replace(/&lt;(\/?)(b|u|i|em|strong)&gt;/gi, "<$1$2>");
    }
    function mainAnswer(sani) { return (sani || "").split(/[\[(]/)[0].trim().replace(/[;:,.]+$/, ""); }
    function shuffle(a) { for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)); var t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
    // Quote-aware sentence split: 'love." At' ends the sentence at the quote.
    // Abbreviation-aware: a naive period split broke "the Michipicoten and
    // St. Ignace islands" (and "The St. Mary's river") into fragments. A chunk
    // ending in a known abbreviation or a single initial is glued to the next
    // one, as is any chunk the split left starting with a lowercase letter.
    var SENT_ABBR = /(?:\b(?:St|Ste|Mt|Mts|Dr|Mr|Mrs|Ms|Messrs|Mme|Mlle|Prof|Sr|Jr|Rev|Fr|Gen|Col|Capt|Lt|Sgt|Maj|Adm|Hon|Pres|Gov|Sen|Rep|Supt|Msgr|vs|etc|cf|ca|al|Inc|Co|Corp|Ltd|Bros|approx|No|Nos|Op|op|no|Vol|vol|Ch|ch|Fig|fig|Ft|Pt|pt|Rte|Ave|Blvd|[A-Za-z])\.["\u201d\u2019']?)$/;
    function mergeAbbrevChunks(parts) {
      var out = [], cur = "";
      for (var i = 0; i < parts.length; i++) {
        cur = cur ? cur + " " + parts[i] : parts[i];
        if (i < parts.length - 1 && SENT_ABBR.test(cur.trim())) continue;
        out.push(cur.trim());
        cur = "";
      }
      if (cur.trim()) out.push(cur.trim());
      return out;
    }
    function splitSentences(text) {
      var chunks = (text || "").replace(/\(\*\)/g, "")
        .split(/(?<=[.!?…]["”’']?)\s+(?=["“‘']?[A-Z0-9(])/);
      return mergeAbbrevChunks(chunks)
        .map(function (c) { return c.trim(); })
        .filter(Boolean);
    }

    function hintRange() {
      var r = ctx.storage.get("hintRange") || { lo: 0, hi: 100 };
      return { lo: Math.min(r.lo, r.hi), hi: Math.max(r.lo, r.hi) };
    }

    function filtersToQuery(f) {
      f = f || {}; var p = ["random=1", "limit=" + DECK_SIZE];
      if (f.standard) p.push("standard=1");
      if (f.categories && f.categories.length) p.push("categories=" + encodeURIComponent(f.categories.join(",")));
      if (f.subcategories && f.subcategories.length) p.push("subcategories=" + encodeURIComponent(f.subcategories.join(",")));
      if (f.alternateSubcategories && f.alternateSubcategories.length) p.push("alternateSubcategories=" + encodeURIComponent(f.alternateSubcategories.join(",")));
      if (f.difficulties && f.difficulties.length) p.push("difficulties=" + f.difficulties.join(","));
      if (f.setNames && f.setNames.length) p.push("setNames=" + encodeURIComponent(f.setNames.join(",")));
      if (f.packetNumbers && f.packetNumbers.length) p.push("packetNumbers=" + f.packetNumbers.join(","));
      if (f.yearMin != null) p.push("yearMin=" + f.yearMin);
      if (f.yearMax != null) p.push("yearMax=" + f.yearMax);
      if (f.powermarkOnly) p.push("powermarkOnly=true");
      return p.join("&");
    }

    // A USEFUL hint names what the question wants: "this man…",
    // "these particles…", "For 10 points, name this…". Sentences without a
    // referent ("Two answers required.") make worthless flashcards.
    function goodHint(t) {
      return /\b(this|these)\s+[a-z]/i.test(t) ||
             /for\s+(10|ten)\s+points/i.test(t) ||
             /\b(name|identify|give)\s+(this|these|the)\b/i.test(t);
    }

    function cardFromTossup(q) {
      var sents = splitSentences(q.question_sanitized || "");
      if (!sents.length) return null;
      var r = hintRange();
      var n = sents.length;
      var loIdx = Math.max(0, Math.min(n - 1, Math.floor((r.lo / 100) * n)));
      var hiIdx = Math.max(loIdx, Math.min(n - 1, Math.ceil((r.hi / 100) * n) - 1));
      // Prefer referent sentences inside the range; else the nearest referent
      // sentence outside it; else fall back to anything in range.
      var good = [];
      for (var gi = 0; gi < n; gi++) if (goodHint(sents[gi])) good.push(gi);
      var inRange = good.filter(function (i) { return i >= loIdx && i <= hiIdx; });
      var idx;
      if (inRange.length) idx = inRange[Math.floor(Math.random() * inRange.length)];
      else if (good.length) {
        var mid = (loIdx + hiIdx) / 2;
        idx = good.reduce(function (best, i) { return Math.abs(i - mid) < Math.abs(best - mid) ? i : best; }, good[0]);
      } else {
        idx = loIdx + Math.floor(Math.random() * (hiIdx - loIdx + 1));
      }
      // Too short to be a clue? Pull in the neighbouring sentence too.
      var hint = sents[idx];
      try {
        var cfg = ctx.host.getPracticeConfig && ctx.host.getPracticeConfig();
        if (cfg && cfg.hidePron && ctx.host.stripPronunciations) hint = ctx.host.stripPronunciations(hint);
      } catch (e) {}
      var hintNo = (idx + 1) + "/" + n;
      if (hint.length < 60) {
        if (idx + 1 < n) { hint = hint + " " + sents[idx + 1]; hintNo = (idx + 1) + "–" + (idx + 2) + "/" + n; }
        else if (idx > 0) { hint = sents[idx - 1] + " " + hint; hintNo = idx + "–" + (idx + 1) + "/" + n; }
      }
      return {
        qid: q.id,
        answer: mainAnswer(q.answer_sanitized),
        fullRaw: q.answer || "",
        fullSani: q.answer_sanitized || "",
        hint: hint,
        hintNo: hintNo,
        category: q.category || "",
        subcategory: q.subcategory || "",
        difficulty: q.difficulty != null ? q.difficulty : null,
        year: q.set_year || null,
        meta: (q.category || "") + (q.subcategory ? " / " + q.subcategory : "") + " · diff " + (q.difficulty != null ? q.difficulty : "?"),
      };
    }

    function makeCard(q, hint, hintNo) {
      try { var cfg = ctx.host.getPracticeConfig && ctx.host.getPracticeConfig(); if (cfg && cfg.hidePron && ctx.host.stripPronunciations) hint = ctx.host.stripPronunciations(hint); } catch (e) {}
      return { qid: q.id, answer: mainAnswer(q.answer_sanitized), fullRaw: q.answer || "", fullSani: q.answer_sanitized || "",
        hint: hint, hintNo: hintNo, category: q.category || "", subcategory: q.subcategory || "",
        difficulty: q.difficulty != null ? q.difficulty : null, year: q.set_year || null,
        meta: (q.category || "") + (q.subcategory ? " / " + q.subcategory : "") + " · diff " + (q.difficulty != null ? q.difficulty : "?") };
    }
    // Every referent ("good") hint sentence within the hint range becomes its
    // own card, so review/starred study covers EVERY hint, not just one.
    function allHintCards(q) {
      var sents = splitSentences(q.question_sanitized || "");
      var n = sents.length; if (!n) return [];
      var r = hintRange();
      var loIdx = Math.max(0, Math.min(n - 1, Math.floor((r.lo / 100) * n)));
      var hiIdx = Math.max(loIdx, Math.min(n - 1, Math.ceil((r.hi / 100) * n) - 1));
      var out = [];
      for (var i = loIdx; i <= hiIdx; i++) { if (goodHint(sents[i])) out.push(makeCard(q, sents[i], (i + 1) + "/" + n)); }
      if (!out.length) { var c = cardFromTossup(q); if (c) out.push(c); }
      return out;
    }
    async function buildReviewPool() {
      var cards = [];
      for (var i = 0; i < reviewPoolIds.length; i++) {
        try { var d = await ctx.api.get("/api/tossups/" + encodeURIComponent(reviewPoolIds[i])); if (d.tossup) allHintCards(d.tossup).forEach(function (c) { cards.push(c); }); } catch (e) {}
      }
      pool = shuffle(cards); poolIdx = 0; exhausted = false;
    }
    function buildStarredPool() {
      pool = shuffle(filteredStarred().slice()); poolIdx = 0; exhausted = false;
    }

    // One card at a time. Filters are read when the NEXT card is fetched, so
    // changing categories mid-card affects future cards only.
    function pushCard(c) { card = c; if (c) { seen.push(c); pos = seen.length - 1; } flipped = false; render(); }
    function atLatest() { return pos >= seen.length - 1; }
    // Back: re-show the previous card you saw (read-only history).
    function back() { if (pos > 0) { pos--; card = seen[pos]; flipped = false; render(); } }
    // Advance: walk forward through already-seen cards, then fetch a new one.
    function advance() { if (pos < seen.length - 1) { pos++; card = seen[pos]; flipped = false; render(); } else nextCard(); }

    async function nextCard() {
      if (!body || loading) return;
      if (card && atLatest() && !_graded) recordSession({ result: "skip", answer: card.answer, category: card.category, hint: card.hint, fullRaw: card.fullRaw, fullSani: card.fullSani, meta: card.meta });
      _graded = false;
      loading = true; flipped = false; cardHadAgain = false; exhausted = false;
      var next = null;
      try {
        if (sourceMode === "review" || sourceMode === "starred" || sourceMode === "custom") {
          if (!pool) { if (sourceMode === "review") { await buildReviewPool(); } else if (sourceMode === "starred") { buildStarredPool(); } else { card = null; exhausted = true; loading = false; render(); return; } }
          if (!pool || !pool.length) {
            if (sourceMode === "starred") { ctx.toast("No starred cards match the filters", "error"); sourceMode = "random"; loading = false; return nextCard(); }
            card = null; exhausted = true; loading = false; render(); return;
          }
          if (poolIdx >= pool.length) { card = null; exhausted = true; loading = false; render(); return; }
          next = pool[poolIdx++];
        } else {
          var f = (ctx.host.getActiveFilters && ctx.host.getActiveFilters()) || {};
          var res = await ctx.api.get("/api/tossups/query?" + filtersToQuery(f).replace("limit=" + DECK_SIZE, "limit=1"));
          var q = (res.rows || [])[0];
          next = q ? cardFromTossup(q) : null;
        }
      } catch (e) { next = null; }
      loading = false;
      pushCard(next);
    }
    function restartPool() {
      seen = []; pos = -1; exhausted = false;
      if (sourceMode === "review") { buildReviewPool().then(function () { poolIdx = 0; nextCard(); }); }
      else if (sourceMode === "custom") { pool = shuffle(pool || []); poolIdx = 0; nextCard(); }   // re-run the same custom deck
      else { buildStarredPool(); poolIdx = 0; nextCard(); }
    }

    function filteredStarred() {
      var f = (ctx.host.getActiveFilters && ctx.host.getActiveFilters()) || {};
      return starredList().filter(function (c) {
        if (f.categories && f.categories.length && c.category && f.categories.indexOf(c.category) < 0) return false;
        if (f.subcategories && f.subcategories.length && c.subcategory && f.subcategories.indexOf(c.subcategory) < 0) return false;
        if (f.difficulties && f.difficulties.length && c.difficulty != null && f.difficulties.indexOf(parseInt(c.difficulty, 10)) < 0) return false;
        if (f.yearMin != null && c.year && c.year < f.yearMin) return false;
        if (f.yearMax != null && c.year && c.year > f.yearMax) return false;
        return true;
      });
    }

    function borrowPanel() {
      var layout = body && body.querySelector(".fc-layout");
      if (!layout) return;
      try { if (ctx.host && ctx.host.ensureFiltersLoaded) ctx.host.ensureFiltersLoaded(); } catch (e) {}
      var panel = document.getElementById("filters-panel") || borrowedPanel;
      if (!panel) return;
      // No set/packet selection here — these pages always draw from the
      // category/difficulty filters, so force MODE back to random.
      var ms = document.getElementById("mode-select");
      if (ms && ms.value !== "random") { ms.value = "random"; ms.dispatchEvent(new Event("change", { bubbles: true })); }
      if (panel.parentNode === layout) return;
      if (!panelHome) panelHome = { parent: panel.parentNode, next: panel.nextSibling };
      panel.classList.add("fc-borrowed");
      layout.insertBefore(panel, layout.firstChild);
      borrowedPanel = panel;
    }
    function returnPanel() {
      if (!borrowedPanel || !panelHome) return;
      borrowedPanel.classList.remove("fc-borrowed");
      try { panelHome.parent.insertBefore(borrowedPanel, panelHome.next); } catch (e) {}
      borrowedPanel = null;
    }
    // ── saved sessions (view + delete from the Statistics section) ──
    // Each entry stores result + the full FRONT (hint) and BACK (answer +
    // answer line) so the per-session stats menu can reproduce the card.
    var sessId = null, _graded = false;
    function sessionsAll() { return ctx.storage.get("sessions") || []; }
    function recordSession(entry) {
      var all = sessionsAll();
      var cur = null;
      if (sessId) for (var i = 0; i < all.length; i++) if (all[i].id === sessId) { cur = all[i]; break; }
      if (!cur) { sessId = Date.now(); cur = { id: sessId, entries: [] }; all.unshift(cur); if (all.length > 60) all.length = 60; }
      cur.entries.push(entry);
      ctx.storage.set("sessions", all);
    }

    // ── per-session STATS MENU (modal overlay) ──────────────────────────
    function glyphHtml(r) {
      if (r === "good") return '<span style="color:var(--green)">✓ Got it</span>';
      if (r === "again") return '<span style="color:var(--yellow)">↻ Again</span>';
      return '<span class="text-muted">→ Skip</span>';
    }
    function bar(pct, cls) {
      var w = Math.max(0, Math.min(100, pct));
      return '<div class="fc-stm-bar"><div class="fc-stm-bar-fill ' + (cls || "") + '" style="width:' + w + '%"></div></div>';
    }
    // group entries by category, count good/again/skip per group
    function byCategory(entries) {
      var map = {}, order = [];
      entries.forEach(function (e) {
        var k = (e.category && String(e.category).trim()) || "(uncategorized)";
        if (!map[k]) { map[k] = { good: 0, again: 0, skip: 0, total: 0 }; order.push(k); }
        var g = map[k]; g.total++;
        if (e.result === "good") g.good++; else if (e.result === "again") g.again++; else g.skip++;
      });
      return order.map(function (k) { return { name: k, g: map[k] }; });
    }
    function openSessionModal(sess) {
      var entries = sess.entries || [];
      var total = entries.length;
      var good = entries.filter(function (e) { return e.result === "good"; }).length;
      var agains = entries.filter(function (e) { return e.result === "again"; }).length;
      var skips = entries.filter(function (e) { return e.result === "skip"; }).length;
      var accuracy = total ? Math.round((good / total) * 100) : 0;

      // (1) summary grid
      var summary =
        '<div class="fc-stm-grid">' +
          '<div class="fc-stm-card"><div class="fc-stm-val">' + total + '</div><div class="fc-stm-lbl">Cards</div></div>' +
          '<div class="fc-stm-card"><div class="fc-stm-val" style="color:var(--green)">' + good + '</div><div class="fc-stm-lbl">Got it</div></div>' +
          '<div class="fc-stm-card"><div class="fc-stm-val" style="color:var(--yellow)">' + agains + '</div><div class="fc-stm-lbl">Again</div></div>' +
          '<div class="fc-stm-card"><div class="fc-stm-val">' + skips + '</div><div class="fc-stm-lbl">Skipped</div></div>' +
          '<div class="fc-stm-card"><div class="fc-stm-val" style="color:var(--accent)">' + accuracy + '%</div><div class="fc-stm-lbl">Accuracy</div></div>' +
        '</div>';

      // (2a) results-over-the-session timeline — one slim bar per card
      var timeline = entries.map(function (e, i) {
        var cls = e.result === "good" ? "good" : e.result === "again" ? "again" : "skip";
        var t = (i + 1) + ". " + (e.result || "skip") + " — " + (e.answer || "");
        return '<span class="fc-stm-tick ' + cls + '" title="' + esc(t) + '"></span>';
      }).join("");
      var timelineBlock = total
        ? '<div class="fc-stm-section"><div class="fc-stm-h">Results over the session</div>' +
          '<div class="fc-stm-timeline">' + timeline + '</div>' +
          '<div class="fc-stm-legend">' +
            '<span><i class="sw good"></i>Got it</span>' +
            '<span><i class="sw again"></i>Again</span>' +
            '<span><i class="sw skip"></i>Skip</span>' +
          '</div></div>'
        : "";

      // (2b) per-category good-vs-again/skip bar chart
      var cats = byCategory(entries);
      var catRows = cats.map(function (c) {
        var g = c.g;
        var goodPct = g.total ? (g.good / g.total) * 100 : 0;
        var againPct = g.total ? (g.again / g.total) * 100 : 0;
        var skipPct = g.total ? (g.skip / g.total) * 100 : 0;
        return '<div class="fc-stm-catrow">' +
          '<div class="fc-stm-catname" title="' + esc(c.name) + '">' + esc(c.name) + '</div>' +
          '<div class="fc-stm-stack">' +
            '<div class="seg good" style="width:' + goodPct + '%"></div>' +
            '<div class="seg again" style="width:' + againPct + '%"></div>' +
            '<div class="seg skip" style="width:' + skipPct + '%"></div>' +
          '</div>' +
          '<div class="fc-stm-catcount">' + g.good + '/' + g.total + '</div>' +
        '</div>';
      }).join("");
      var catBlock = cats.length
        ? '<div class="fc-stm-section"><div class="fc-stm-h">Per-category breakdown</div>' + catRows + '</div>'
        : "";

      // (3) full per-question history — FRONT + BACK for each card
      var histRows = entries.map(function (e, i) {
        var front = e.hint != null ? e.hint : "";
        var back = e.answer || "";
        var backLine = ansHtml(e.fullRaw, e.fullSani);
        var hasFront = front && String(front).trim();
        return '<div class="fc-stm-item">' +
          '<div class="fc-stm-item-head">' +
            '<span class="fc-stm-idx">' + (i + 1) + '</span>' +
            glyphHtml(e.result) +
            (e.meta ? '<span class="fc-stm-itemmeta">' + esc(e.meta) + '</span>' : (e.category ? '<span class="fc-stm-itemmeta">' + esc(e.category) + '</span>' : "")) +
          '</div>' +
          (hasFront
            ? '<div class="fc-stm-qa"><span class="fc-stm-qa-lbl">FRONT</span><span class="fc-stm-qa-txt">' + esc(front) + '</span></div>'
            : '<div class="fc-stm-qa"><span class="fc-stm-qa-lbl">FRONT</span><span class="fc-stm-qa-txt text-muted">(not recorded)</span></div>') +
          '<div class="fc-stm-qa"><span class="fc-stm-qa-lbl">BACK</span><span class="fc-stm-qa-txt"><strong>' + esc(back) + '</strong>' +
            (backLine && backLine !== esc(back) ? ' <span class="fc-stm-ansline">' + backLine + '</span>' : "") + '</span></div>' +
        '</div>';
      }).join("");
      var histBlock =
        '<div class="fc-stm-section"><div class="fc-stm-h">Session history (' + total + ')</div>' +
          '<div class="fc-stm-hist">' + (histRows || '<div class="text-muted" style="padding:8px">No cards in this session.</div>') + '</div>' +
        '</div>';

      var overlay = document.createElement("div");
      overlay.className = "qb-overlay fc-stm-overlay";
      overlay.innerHTML =
        '<div class="fc-stm-box">' +
          '<div class="fc-stm-head">' +
            '<div><div class="fc-stm-title">Flashcard session</div>' +
              '<div class="fc-stm-sub">' + esc(new Date(sess.id).toLocaleString()) + '</div></div>' +
            '<button class="btn btn-sm btn-ghost fc-stm-close" title="Close">✕</button>' +
          '</div>' +
          '<div class="fc-stm-body">' + summary + timelineBlock + catBlock + histBlock + '</div>' +
        '</div>';
      function close() { try { document.removeEventListener("keydown", onEsc); } catch (e) {} if (overlay.parentNode) overlay.parentNode.removeChild(overlay); }
      function onEsc(ev) { if (ev.key === "Escape") { ev.preventDefault(); close(); } }
      overlay.addEventListener("click", function (ev) { if (ev.target === overlay) close(); });
      overlay.querySelector(".fc-stm-close").onclick = close;
      document.addEventListener("keydown", onEsc);
      document.body.appendChild(overlay);
    }

    function sessionsHtml() {
      var all = sessionsAll();
      if (!all.length) return "";
      var rows = all.map(function (sess, i) {
        var n = sess.entries.length, ok = sess.entries.filter(function (e) { return e.result === "good"; }).length;
        return '<tr class="session-row" data-view="' + i + '" title="Open session stats" style="cursor:pointer">' +
          "<td>" + new Date(sess.id).toLocaleString() + "</td><td>" + n + "</td><td>" + ok + " good</td>" +
          '<td><button class="btn btn-sm btn-ghost session-delete" data-del="' + i + '" title="Delete session">&times;</button></td></tr>';
      }).join("");
      return '<div class="filter-label" style="margin:14px 0 6px">FLASHCARD SESSIONS</div>' +
        '<table class="stats-table"><thead><tr><th>Session</th><th>Cards</th><th>Result</th><th></th></tr></thead><tbody>' + rows + "</tbody></table>" +
        '<button class="btn btn-sm btn-ghost" id="fc-sess-clear" style="margin-top:8px">Delete all sessions</button>';
    }
    function wireSessions(el, rerender) {
      el.querySelectorAll("[data-view]").forEach(function (b) {
        b.onclick = function (ev) {
          if (ev.target.closest(".session-delete")) return;
          var all = sessionsAll();
          var sess = all[parseInt(b.dataset.view, 10)];
          if (sess) openSessionModal(sess);
        };
      });
      el.querySelectorAll("[data-del]").forEach(function (b) {
        b.onclick = function () {
          var doDel = function () { var all = sessionsAll(); all.splice(parseInt(b.dataset.del), 1); ctx.storage.set("sessions", all); rerender(); };
          if (ctx.host && ctx.host.confirm) ctx.host.confirm("Delete this flashcard session? Its stats are removed permanently.", doDel);
          else doDel();
        };
      });
      var ca = el.querySelector("#fc-sess-clear");
      if (ca) ca.onclick = function () {
        var doClear = function () { ctx.storage.set("sessions", []); rerender(); };
        if (ctx.host && ctx.host.confirm) ctx.host.confirm("Delete ALL flashcard sessions? This cannot be undone.", doClear);
        else doClear();
      };
    }

    page = ctx.registerPage({
      id: "cards", navLabel: "Flashcards", title: "FLASHCARDS",
      onShow: function (el, info) {
        body = el;
        // Back returns you to the card you left mid-session; only a fresh
        // entry starts a new recorded session.
        if (!(info && info.back)) { sessId = null; _graded = false; }
        try {
          // Custom cards handoff (e.g. Buzz Words / Keyword Frequency "review as
          // flashcards"): each card is a {front, back} pair — no question id.
          var cc = JSON.parse(localStorage.getItem("qb-flashcards-cards") || "null");
          if (cc && cc.cards && cc.cards.length) {
            localStorage.removeItem("qb-flashcards-cards");
            pool = shuffle(cc.cards.slice(0, 500).map(function (x) {
              return { qid: null, answer: x.back || "", fullRaw: x.back || "", fullSani: "", hint: x.front || "", hintNo: x.label || "", category: "", subcategory: "", difficulty: null, year: null, meta: x.meta || "review" };
            }));
            poolIdx = 0; sourceMode = "custom"; card = null; seen = []; pos = -1; exhausted = false;
          } else {
            var handoff = JSON.parse(localStorage.getItem("qb-flashcards-handoff") || "null");
            if (handoff && handoff.ids && handoff.ids.length) {
              reviewPoolIds = handoff.ids.slice(0, 200);
              localStorage.removeItem("qb-flashcards-handoff");
              card = null; pool = null; sourceMode = "review"; seen = []; pos = -1;
            }
          }
        } catch (e) {}
        if (!card) nextCard();
        // Back: the shell the user left is still in the DOM, so don't wipe and
        // rebuild it — onHide only sent the borrowed filters panel home, so
        // just take it back and leave the card exactly as it was.
        else if (info && info.back && body.querySelector("#fc-card")) borrowPanel();
        else render();
      },
      onHide: function () { returnPanel(); },
    });
    function active() { return page && page.screenEl && page.screenEl.classList.contains("active"); }
    ctx.on("screen:change", function () { setTimeout(function () { if (!active()) returnPanel(); }, 0); });

    function hintSliderHtml() {
      var r = ctx.storage.get("hintRange") || { lo: 0, hi: 100 };
      return '<div class="fc-hintrange"><span class="fc-hr-label">Hint from</span>' +
        '<div class="dual-range fc-dual"><div class="dual-range-track"><div class="dual-range-fill" id="fc-hr-fill"></div></div>' +
        '<input type="range" id="fc-hr-lo" min="0" max="100" step="5" value="' + r.lo + '">' +
        '<input type="range" id="fc-hr-hi" min="0" max="100" step="5" value="' + r.hi + '"></div>' +
        '<span class="fc-hr-val" id="fc-hr-val"></span></div>';
    }
    function wireHintSlider() {
      var lo = body.querySelector("#fc-hr-lo"), hi = body.querySelector("#fc-hr-hi");
      if (!lo || !hi) return;
      function update() {
        var a = parseInt(lo.value), b = parseInt(hi.value);
        var mn = Math.min(a, b), mx = Math.max(a, b);
        var prev = hintRange();
        ctx.storage.set("hintRange", { lo: mn, hi: mx });
        var v = body.querySelector("#fc-hr-val"); if (v) v.textContent = mn + "% – " + mx + "%";
        var fill = body.querySelector("#fc-hr-fill");
        if (fill) { fill.style.left = mn + "%"; fill.style.right = (100 - mx) + "%"; }
        // Changing the range rebuilds the review/starred pool from scratch.
        if ((mn !== prev.lo || mx !== prev.hi) && (sourceMode === "review" || sourceMode === "starred")) { pool = null; poolIdx = 0; }
      }
      lo.addEventListener("input", update);
      hi.addEventListener("input", update);
      update();
    }

    // Right-click "View full question" — fetch the card's source tossup and
    // show it in a closeable overlay (Esc works via the app's .qb-overlay rule).
    async function viewFullQuestion(c) {
      if (!c || !c.qid) return;
      var d = null;
      try { d = await ctx.api.get("/api/tossups/" + encodeURIComponent(c.qid)); } catch (e) {}
      var q = d && d.tossup;
      if (!q) { QB.toast("Couldn't load the full question", "error"); return; }
      document.querySelector(".fc-viewer")?.remove();
      var el = document.createElement("div");
      el.className = "qb-overlay fc-viewer";
      el.innerHTML =
        '<div class="fc-viewer-card">' +
          '<div class="fc-viewer-meta">' + esc(q.category || "") + (q.subcategory ? " / " + esc(q.subcategory) : "") + (q.set_name ? " · " + esc(q.set_name) : "") + "</div>" +
          '<div class="fc-viewer-q">' + esc(q.question_sanitized || "") + "</div>" +
          '<div class="fc-viewer-a">ANSWER: ' + ansHtml(q.answer, q.answer_sanitized) + "</div>" +
          '<div style="text-align:right"><button class="btn btn-sm fc-viewer-close">Close</button></div>' +
        "</div>";
      el.addEventListener("click", function (ev) { if (ev.target === el || ev.target.closest(".fc-viewer-close")) el.remove(); });
      document.body.appendChild(el);
    }

    function cardContextMenu(e) {
      if (!card || !window.QB || !QB.contextMenu) return;
      e.preventDefault();
      var c = card;
      var items = [
        { label: "View full question", onClick: function () { viewFullQuestion(c); } },
        { label: flipped ? "Show hint" : "Show answer", onClick: flip },
      ];
      if (ctx.host && ctx.host.searchDatabase) items.push({ label: "Find questions with this answer", onClick: function () { ctx.host.searchDatabase({ query: c.answer, field: "answer", exact: false }); } });
      items.push({ sep: true });
      items.push({ label: isCardStarred(c) ? "Unstar card" : "Star card", onClick: function () { toggleCardStar(c); } });
      items.push({ label: "Copy hint", onClick: function () { try { navigator.clipboard.writeText(c.hint); QB.toast("Copied"); } catch (err) {} } });
      items.push({ label: "Copy answer", onClick: function () { try { navigator.clipboard.writeText(c.answer); QB.toast("Copied"); } catch (err) {} } });
      QB.contextMenu(e.clientX, e.clientY, items, { title: flipped ? c.answer : "Flashcard" });
    }

    function starredList() { return ctx.storage.get("starred") || []; }
    function isCardStarred(c) { return starredList().some(function (x) { return x.qid === c.qid && x.hint === c.hint; }); }
    function toggleCardStar(c) {
      var list = starredList();
      var i = list.findIndex(function (x) { return x.qid === c.qid && x.hint === c.hint; });
      if (i >= 0) list.splice(i, 1);
      else list.push({ qid: c.qid, answer: c.answer, fullRaw: c.fullRaw, fullSani: c.fullSani, hint: c.hint, meta: c.meta, hintNo: c.hintNo, category: c.category || "", subcategory: c.subcategory || "", difficulty: c.difficulty != null ? c.difficulty : null, year: c.year || null });
      ctx.storage.set("starred", list);
      ctx.playSound("star");
      render();
    }

    function renderShell(inner) {
      // CRITICAL: give the borrowed panel back BEFORE innerHTML wipes the body
      // (otherwise the panel is detached from the DOM and the settings menu
      // disappears for good). Re-borrow right after.
      returnPanel();
      body.innerHTML = '<div class="practice-layout fc-layout"><main class="question-area"><div class="fc-wrap">' + inner + "</div></main></div>";
      borrowPanel();
    }

    function render() {
      if (!body) return;
      var inner;
      var lifeLine = lifeStats().studied ? "all-time " + lifeStats().studied + " studied" : "";
      if (exhausted) {
        inner = '<div class="fc-progress">' + lifeLine + "</div>" +
          '<div class="fc-card fc-start"><div class="fc-done">✓ You’ve seen every ' + (sourceMode === "starred" ? "starred" : sourceMode === "custom" ? "saved" : "review") + ' card in this range.</div>' +
          '<div class="text-muted" style="font-size:12px">Restart to go through them again, change the hint range to surface new hints, or exit.</div>' +
          '<div class="fc-actions"><button class="btn btn-primary" id="fc-restart">Restart</button><button class="btn btn-ghost" id="fc-exit">Exit</button></div></div>' +
          hintSliderHtml();
      } else if (loading || !card) {
        inner = '<div class="fc-progress">' + lifeLine + "</div>" +
          '<div class="fc-card fc-start"><div class="text-muted">' + (loading ? "Loading…" : "No card matched the filters — broaden them on the left.") + "</div>" +
          (!loading ? '<div class="fc-actions"><button class="btn btn-primary" id="fc-skip">Try again</button></div>' : "") + "</div>" +
          hintSliderHtml();
      } else {
        var c = card;
        var starred = isCardStarred(c);
        var viewingPast = !atLatest();
        var backBtn = (pos > 0) ? '<button class="btn btn-ghost" id="fc-back">← Back</button>' : "";
        inner =
          '<div class="fc-progress">' + (sourceMode === "review" ? "review · " : sourceMode === "starred" ? "★ starred cards · " : "") + (seen.length ? (pos + 1) + "/" + seen.length + " seen · " : "") + lifeLine + "</div>" +
          '<div class="fc-card' + (flipped ? " flipped" : "") + '" id="fc-card">' +
            '<span class="star-toggle fc-star' + (starred ? " on" : "") + '" id="fc-star">' + (starred ? "★" : "☆") + "</span>" +
            (flipped
              ? '<div class="fc-side-label">ANSWER · ' + esc(c.meta) + '</div>' +
                '<div class="fc-front">' + esc(c.answer) + '</div>' +
                '<div class="fc-full">' + ansHtml(c.fullRaw, c.fullSani) + "</div>"
              : '<div class="fc-side-label">HINT ' + esc(c.hintNo) + ' · ' + esc(c.meta) + '</div>' +
                '<div class="fc-back">' + esc(c.hint) + "</div>") +
          "</div>" +
          '<div class="fc-actions">' + backBtn +
            (viewingPast
              ? '<button class="btn btn-primary" id="fc-flip">[' + esc(keyLabel("flip")) + '] Flip</button><button class="btn" id="fc-skip">Next →</button>'
              : (flipped
                  ? '<button class="btn" id="fc-again">[' + esc(keyLabel("again")) + '] Again</button><button class="btn btn-primary" id="fc-good">[' + esc(keyLabel("good")) + '] Got it</button>'
                  : '<button class="btn btn-primary" id="fc-flip">[' + esc(keyLabel("flip")) + '] Flip</button>') +
                '<button class="btn" id="fc-skip">[' + esc(keyLabel("skip")) + '] Skip</button>' +
                '<button class="btn btn-ghost" id="fc-source">' + (sourceMode === "random" ? "★ Starred cards" : "Random cards") + "</button>") +
          "</div>" + hintSliderHtml();
      }
      renderShell(inner);
      var cardEl = body.querySelector("#fc-card"); if (cardEl) cardEl.onclick = function (e) { if (e.target.closest("#fc-star")) return; flip(); };
      if (cardEl) cardEl.oncontextmenu = cardContextMenu;
      var st = body.querySelector("#fc-star"); if (st) st.onclick = function (e) { e.stopPropagation(); toggleCardStar(card); };
      var f = body.querySelector("#fc-flip"); if (f) f.onclick = flip;
      var a = body.querySelector("#fc-again"); if (a) a.onclick = again;
      var g = body.querySelector("#fc-good"); if (g) g.onclick = good;
      var bk = body.querySelector("#fc-back"); if (bk) bk.onclick = back;
      var sk = body.querySelector("#fc-skip"); if (sk) sk.onclick = function () { advance(); };
      var src = body.querySelector("#fc-source");
      if (src) src.onclick = function () { pool = null; poolIdx = 0; seen = []; pos = -1; sourceMode = sourceMode === "random" ? "starred" : "random"; reviewPoolIds = []; nextCard(); };
      var rs = body.querySelector("#fc-restart"); if (rs) rs.onclick = restartPool;
      var ex = body.querySelector("#fc-exit"); if (ex) ex.onclick = function () { sourceMode = "random"; pool = null; poolIdx = 0; seen = []; pos = -1; reviewPoolIds = []; try { ctx.host && ctx.host.goHome && ctx.host.goHome(); } catch (e) {} };
      wireHintSlider();
    }

    function flip() { flipped = !flipped; ctx.playSound("toggle"); render(); }
    // Again = flip BACK to the hint of the SAME card (no new card).
    function again() {
      if (!atLatest()) { advance(); return; }   // Again only applies to the live card
      flipped = false;
      cardHadAgain = true;
      ctx.playSound("skip");
      bumpLife(function (st) { st.agains++; });
      if (card) recordSession({ result: "again", answer: card.answer, category: card.category, hint: card.hint, fullRaw: card.fullRaw, fullSani: card.fullSani, meta: card.meta });
      render();
    }
    function good() {
      if (!atLatest()) { advance(); return; }   // grading only on the live card
      ctx.playSound("correct");
      bumpLife(function (st) { st.studied++; if (!cardHadAgain) st.firstTry++; });
      cardHadAgain = false;
      if (card) { recordSession({ result: "good", answer: card.answer, category: card.category, hint: card.hint, fullRaw: card.fullRaw, fullSani: card.fullSani, meta: card.meta }); _graded = true; }
      advance();
    }

    // Rebindable hotkeys (Settings > Keybinds). Handlers no-op off-page.
    ctx.onHotkey("flip", function () { if (active() && card) flip(); });
    ctx.onHotkey("again", function () { if (active() && flipped) again(); });
    ctx.onHotkey("good", function () { if (active() && flipped) good(); });
    ctx.onHotkey("skip", function () { if (active()) advance(); });
    // Enter keeps flipping too (fixed convenience alias).
    function onKey(e) {
      if (!active()) return;
      var t = e.target.tagName; if (t === "INPUT" || t === "TEXTAREA") return;
      if (e.key === "Enter") { e.preventDefault(); if (card) flip(); }
    }
    document.addEventListener("keydown", onKey);
    ctx._cleanup = function () {
      returnPanel();
      document.removeEventListener("keydown", onKey);
      var ov = document.querySelector(".fc-stm-overlay"); if (ov && ov.parentNode) ov.parentNode.removeChild(ov);
    };

    // ── starred flashcards: stored in PLUGIN storage; own Database tab.
    //    Styled like the normal Starred tab (collapsible qcards, star toggle);
    //    unstarring keeps the card on screen (toggle back to re-star) — it
    //    only drops off the list the next time the tab renders. ──
    function cardKey(c) { return c.qid + "" + c.hint; }
    // Button on the base Starred screen: study the starred TOSSUPS as flashcards.
    if (ctx.registerStarredAction) ctx.registerStarredAction({
      id: "run-flashcards", label: "▶ Flashcards",
      run: function (items) {
        var ids = (items || []).filter(function (it) { return it.type === "tossup" && it.question && it.question.id; }).map(function (it) { return it.question.id; });
        if (!ids.length) { ctx.toast("No starred tossups to study as flashcards", "error"); return; }
        ctx.launchQuestions("flashcards", ids);
      },
    });
    ctx.registerStarredProvider({
      id: "flashcards",
      title: "Starred Flashcards",
      render: function (container) {
        var list = starredList();
        if (!list.length) { container.innerHTML = '<div class="text-muted" style="padding:16px">No starred flashcards yet — star cards while studying.</div>'; return; }
        container.innerHTML = list.map(function (c) {
          return '<div class="qcard expanded">' +
            '<div class="qcard-head"><span class="qcard-chev" aria-hidden="true"></span>' +
              '<span class="qcard-meta"><span>' + esc(c.meta || "") + "</span>" + (c.year ? "<span>" + esc(String(c.year)) + "</span>" : "") + "</span>" +
              '<span class="qcard-side"><span class="pill">CARD</span><span class="star-toggle fc-sstar on" data-key="' + esc(cardKey(c)) + '" title="Unstar">★</span>' + (((ctx.host && ctx.host.openItemSaveMenu) || window.QBFolders) ? '<span class="fc-foldx" data-key="' + esc(cardKey(c)) + '" title="Add to review / folder">+</span>' : "") + "</span></div>" +
            '<div class="qcard-answer">Answer: <span class="ans">' + esc(c.answer || c.front || "") + "</span></div>" +
            '<div class="qcard-body"><div class="qcard-text">' + esc(c.hint) + '</div>' +
            '<div class="qcard-foot">' + ansHtml(c.fullRaw || c.full, c.fullSani || "") + "</div></div></div>";
        }).join("");
        container.querySelectorAll(".fc-foldx").forEach(function (s) {
          s.addEventListener("click", function (ev) {
            ev.stopPropagation();
            var c = starredList().find(function (x) { return cardKey(x) === s.dataset.key; });
            if (!c) return;
            var card = { front: c.hint || c.front || "", back: c.answer || "", meta: c.meta || "flashcard" };
            var spec = { review: { kind: "flashcard", front: card.front, back: card.back, meta: card.meta }, folder: { type: "flashcards", item: { card: card } } };
            if (ctx.host && ctx.host.openItemSaveMenu) ctx.host.openItemSaveMenu(spec, s);
            else if (window.QBFolders) window.QBFolders.pick("flashcards", spec.folder.item, s);
          });
        });
        container.querySelectorAll(".fc-sstar").forEach(function (st) {
          st.addEventListener("click", function (ev) {
            ev.stopPropagation();
            var key = st.dataset.key;
            var list2 = starredList();
            var i = list2.findIndex(function (c) { return cardKey(c) === key; });
            if (i >= 0) {
              // unstar — but KEEP the card visible so it can be re-starred
              st._removed = list2.splice(i, 1)[0];
              ctx.storage.set("starred", list2);
              st.textContent = "☆"; st.classList.remove("on"); st.title = "Star";
            } else if (st._removed) {
              list2.push(st._removed);
              ctx.storage.set("starred", list2);
              st.textContent = "★"; st.classList.add("on"); st.title = "Unstar";
            }
          });
        });
      },
    });

    // ── STATISTICS screen section ──
    ctx.registerStatsProvider({
      id: "flashcards",
      title: "Flashcards",
      render: function renderStats(el) {
        var st = lifeStats();
        if (!st.studied && !st.agains && !sessionsAll().length) { el.innerHTML = '<div class="text-muted" style="font-size:12px">No flashcards studied yet — open Flashcards from the title menu (Extra).</div>'; return; }
        var rate = st.studied ? Math.round((st.firstTry / st.studied) * 100) : 0;
        el.innerHTML =
          '<div class="stats-grid">' +
            '<div class="stat-card"><div class="stat-card-value">' + st.studied + '</div><div class="stat-card-label">Cards Studied</div></div>' +
            '<div class="stat-card"><div class="stat-card-value">' + rate + '%</div><div class="stat-card-label">First-Try Rate</div></div>' +
            '<div class="stat-card"><div class="stat-card-value">' + st.agains + '</div><div class="stat-card-label">Again Presses</div></div>' +
            '<div class="stat-card"><div class="stat-card-value">' + st.decks + '</div><div class="stat-card-label">Decks Finished</div></div>' +
            '<div class="stat-card"><div class="stat-card-value">' + (ctx.storage.get("starred") || []).length + '</div><div class="stat-card-label">Starred Cards</div></div>' +
          "</div>" + sessionsHtml();
        wireSessions(el, function () { renderStats(el); });
      },
    });

    ctx.toast("Flashcards enabled");
  }
