/**
 * OfflineQuiz plugin: Layout Customizer
 *
 * Pick a page and its parts become boxes you drag and resize, right on the page, with guides that line
 * them up like Canva. The page moves with them, and Done keeps the layout.
 */
QB.registerPlugin({
  id: "layout-customizer",
  name: "Layout Customizer",
  version: "2.0.0",
  author: "OfflineQuiz",
  description: "Arrange the parts of the site's pages by dragging them, right on the pages, with Auto align to line them up.",
  onEnable: __qbMain,
  onDisable: function (ctx) { if (ctx._cleanup) ctx._cleanup(); },
});
