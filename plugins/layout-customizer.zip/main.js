/**
 * OfflineQuiz plugin: Layout Customizer
 *
 * A preview of each page of the site, its parts as boxes you drag and resize, with guides that line them up
 * like Canva. Layouts are kept per page, and Copy layout gives one as text.
 */
QB.registerPlugin({
  id: "layout-customizer",
  name: "Layout Customizer",
  version: "1.0.0",
  author: "OfflineQuiz",
  description: "Every page of the site as a wireframe. Drag its parts around, with Auto align to line them up.",
  onEnable: __qbMain,
  onDisable: function (ctx) { if (ctx._cleanup) ctx._cleanup(); },
});
