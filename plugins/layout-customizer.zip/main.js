/**
 * OfflineQuiz plugin: Layout Customizer
 *
 * Press Shift L on any page and every part of it gets a box. Drag a box anywhere, size it by its corner,
 * and open its gear for what it shows and in what order, its size, floating it anywhere, splitting or hiding it.
 */
QB.registerPlugin({
  id: "layout-customizer",
  name: "Layout Customizer",
  version: "3.0.1",
  author: "OfflineQuiz",
  description: "Edit any page's layout right on it. Drag every part anywhere, and its gear sets what it shows and in what order.",
  hotkeys: [{"id":"edit","label":"Edit this page's layout","default":"Shift+L"}],
  onEnable: __qbMain,
  onDisable: function (ctx) { if (ctx._cleanup) ctx._cleanup(); },
});
