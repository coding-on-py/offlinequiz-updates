function __qbMain(ctx) {
  // ── the kit the 15.62 plugins share (text, icons, questions, judging, history) ──
  function esc(s) { return (s == null ? "" : String(s)).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
  var IC = {
    play: '<path d="M7 4l13 8-13 8z"/>',
    pause: '<path d="M8 5v14M16 5v14"/>',
    left: '<path d="M15 6l-6 6 6 6"/>',
    right: '<path d="M9 6l6 6-6 6"/>',
    next: '<path d="M6 5l9 7-9 7zM18 5v14"/>',
    refresh: '<path d="M20 11a8 8 0 10-2.3 5.7M20 4v7h-7"/>',
    x: '<path d="M6 6l12 12M18 6L6 18"/>',
    check: '<path d="M5 12l5 5 9-10"/>',
    mic: '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
    volume: '<path d="M4 9v6h4l5 4V5L8 9z"/><path d="M16 9a4 4 0 0 1 0 6M19 6a8 8 0 0 1 0 12"/>',
    copy: '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h3"/>',
    edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="M13.5 6.5l4 4"/>',
    bolt: '<path d="M13 3L5 14h6l-1 7 8-11h-6z"/>',
    flag: '<path d="M5 21V4M5 4h11l-2 4 2 4H5"/>',
    users: '<circle cx="9" cy="8" r="3"/><path d="M3 20a6 6 0 0 1 12 0M16 4a3 3 0 0 1 0 6M21 20a6 6 0 0 0-4-5.6"/>',
    target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
    down: '<path d="M6 9l6 6 6-6"/>',
    up: '<path d="M6 15l6-6 6 6"/>',
    quote: '<path d="M7 7h4v4c0 3-1.5 5-4 6M15 7h4v4c0 3-1.5 5-4 6"/>',
    grid: '<rect x="3" y="3" width="8" height="10" rx="2"/><rect x="13" y="3" width="8" height="6" rx="2"/><rect x="13" y="11" width="8" height="10" rx="2"/><rect x="3" y="15" width="8" height="6" rx="2"/>',
    ear: '<path d="M7 9a5 5 0 0 1 10 0c0 3-3 4-3 7a3 3 0 0 1-6 0"/><path d="M10 9a2 2 0 0 1 4 0"/>',
  };
  function ic(name, size) {
    var s = size || 16;
    return '<svg width="' + s + '" height="' + s + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (IC[name] || "") + "</svg>";
  }
  function loading(label) { return '<div class="pk-loading">' + (ctx.loadingBarHtml ? ctx.loadingBarHtml(label) : esc(label)) + "</div>"; }
  function norm(s) { return String(s || "").toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[^a-z0-9]+/g, " ").trim(); }
  function pct(a, n) { return n ? Math.round(100 * a / n) : 0; }
  function fmt(n) { return Number(n || 0).toLocaleString(); }
  function plural(n, one, many) { return fmt(n) + " " + (n === 1 ? one : (many || one + "s")); }
  function shuffle(a) { for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)), t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
  function inField(e) { var t = e && e.target; return !!t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT" || t.isContentEditable); }
  function dayKey(t) { var d = new Date(t || Date.now()); return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0"); }
  var DAY = 86400000;

  // the practice setup (Setup panel): its filters and reading settings
  function cfg() { try { return (ctx.host && ctx.host.getPracticeConfig && ctx.host.getPracticeConfig()) || {}; } catch (e) { return {}; } }
  // filters → query parameters, the ones the app sends for a random question
  function filtersQuery(f, extra) {
    f = f || {}; var p = [];
    var add = function (k, v) { p.push(k + "=" + encodeURIComponent(v)); };
    if (f.categories && f.categories.length) add("categories", f.categories.join(","));
    if (f.categoryIds && f.categoryIds.length) add("categoryIds", f.categoryIds.join(","));
    if (f.difficulties && f.difficulties.length) add("difficulties", f.difficulties.join(","));
    if (f.setNames && f.setNames.length) add("setNames", f.setNames.join(","));
    if (f.packetNumbers && f.packetNumbers.length) add("packetNumbers", f.packetNumbers.join(","));
    if (f.yearMin != null) add("yearMin", f.yearMin);
    if (f.yearMax != null) add("yearMax", f.yearMax);
    if (f.powermarkOnly) add("powermarkOnly", "true");
    if (f.canon && f.canon.length) add("canon", f.canon.join(","));
    add("cleanOnly", "1");
    Object.keys(extra || {}).forEach(function (k) { if (extra[k] != null && extra[k] !== false) add(k, extra[k]); });
    return p.join("&");
  }
  // the practice filters without a set (a drill draws from everything the player picked)
  function practiceFilters() { var f = Object.assign({}, cfg().filters || {}); delete f.setNames; delete f.packetNumbers; delete f.setIds; return f; }
  async function getTossups(n, f, extra) {
    try { var d = await ctx.api.get("/api/tossups/query?" + filtersQuery(f || practiceFilters(), Object.assign({ random: 1, limit: n }, extra || {}))); return (d && d.rows) || []; } catch (e) { return []; }
  }
  async function getBonuses(n, f, extra) {
    try { var d = await ctx.api.get("/api/bonuses/query?" + filtersQuery(f || practiceFilters(), Object.assign({ random: 1, limit: n }, extra || {}))); return (d && d.rows) || []; } catch (e) { return []; }
  }
  async function getTossup(id) { try { return (await ctx.api.get("/api/tossups/" + encodeURIComponent(id))).tossup || null; } catch (e) { return null; } }
  async function getBonus(id) { try { return (await ctx.api.get("/api/bonuses/" + encodeURIComponent(id))).bonus || null; } catch (e) { return null; } }
  async function searchTossups(query, limit, f) {
    try { var d = await ctx.api.get("/api/tossups/search?query=" + encodeURIComponent(query) + "&limit=" + (limit || 20) + (f ? "&" + filtersQuery(f) : "")); return { rows: (d && d.rows) || [], total: (d && d.total) || 0 }; } catch (e) { return { rows: [], total: 0 }; }
  }
  // tossups whose answer line names an answer
  async function tossupsOn(answer, limit) { return (await searchTossups('answer_sanitized : ("' + String(answer).replace(/"/g, "") + '")', limit || 20)).rows; }

  // a record's text as practice reads it (notes and pronunciation guides per the player's settings)
  function readText(q) {
    try { if (ctx.host && ctx.host.questionText) { var t = ctx.host.questionText(q, "question"); if (t != null) return String(t).replace(/\(\*\)/g, "").replace(/\s{2,}/g, " ").trim(); } } catch (e) {}
    return String((q && q.question_sanitized) || "").replace(/\(\*\)/g, "").trim();
  }
  function powerAt(q) { return String((q && q.question_sanitized) || "").indexOf("(*)"); }
  // sentences, without breaking at "St." or an initial ("J. R. R. Tolkien")
  var ABBR = /(?:\b(?:St|Ste|Mt|Mts|Dr|Mr|Mrs|Ms|Mme|Prof|Sr|Jr|Rev|Fr|Gen|Col|Capt|Lt|Sgt|Maj|Adm|Hon|Pres|Gov|Sen|Rep|vs|etc|cf|ca|al|Inc|Co|Corp|Ltd|Bros|approx|No|Nos|Op|op|no|Vol|vol|Ch|ch|Fig|fig|Ft|Pt|pt|Ave|[A-Za-z])\.["”’']?)$/;
  function sentences(text) {
    var parts = String(text || "").split(/(?<=[.?!]["”’)]*)\s+(?=["“(]?[A-Z0-9])/), out = [], cur = "";
    for (var i = 0; i < parts.length; i++) {
      cur = cur ? cur + " " + parts[i] : parts[i];
      if (i < parts.length - 1 && ABBR.test(cur.trim())) continue;
      out.push(cur.trim()); cur = "";
    }
    if (cur.trim()) out.push(cur.trim());
    return out.filter(Boolean);
  }
  // where each sentence of a text ends (indexes into it)
  function sentenceEnds(text) {
    var at = 0, out = []; text = String(text || "");
    sentences(text).forEach(function (x) { var i = text.indexOf(x, at); if (i < 0) return; at = i + x.length; out.push(at); });
    return out;
  }
  // ── categories (15.63): the app's own picker, its picks kept under `key` ([] = every category) ──
  // mountCats(root, key, onChange) puts it in root's [data-cats] (made once, moved into each new render);
  // inCats(pk, e): a history entry or question in the picks; with no picks, all are
  var PICKERS = {};
  // opts.label: "" for just the picks, in a row that has its own label
  function catPicker(key, onChange, opts) {
    if (PICKERS[key]) return PICKERS[key];
    if (!ctx.host || !ctx.host.categoryPicker) return null;
    var o = { selected: ctx.storage.get(key) || [], onChange: function (ids) { ctx.storage.set(key, ids); if (onChange) onChange(ids); } };
    if (opts && opts.label != null) o.label = opts.label;
    var pk = ctx.host.categoryPicker(null, o);
    PICKERS[key] = pk;
    // the picks match nothing until the tree is in: draw again once it is
    if (pk.ready && (ctx.storage.get(key) || []).length) pk.ready.then(function () { if (onChange) onChange(pk.get()); });
    return pk;
  }
  function mountCats(root, key, onChange, opts) {
    var pk = catPicker(key, onChange, opts), host = root && root.querySelector("[data-cats]");
    if (pk && host) host.appendChild(pk.el);
    return pk;
  }
  function inCats(pk, e) {
    if (!pk || !pk.get().length) return true;
    return pk.matches(String((e && (e.category_path || e.path || e.category || e.root)) || ""));
  }
  // ── the app's reader on a page titled for the plugin (15.63: ctx.host.playPractice). Its Setup picks the categories ──
  function canRead() { return !!(ctx.host && ctx.host.playPractice); }
  function onReader() { return !!(ctx.host && ctx.host.onPracticePage && ctx.host.onPracticePage()); }
  // a plugin's start page: an icon, what it is, a Start button (data-pk="start"), a note under it
  function heroHtml(icon, title, text, start, note) {
    return '<div class="pk-hero"><span class="pk-hero-ico">' + ic(icon, 26) + "</span><h2>" + esc(title) + "</h2><p>" + esc(text) + "</p>" +
      '<div class="pk-actions pk-center"><button type="button" class="btn btn-primary" data-pk="start">' + ic("play", 14) + esc(start || "Start") + "</button></div>" +
      (note ? '<div class="pk-muted pk-small">' + note + "</div>" : "") + "</div>";
  }
  // the answer line, with its bold and underlining (nothing else of the HTML)
  function answerHtml(q) {
    var h = String((q && q.answer) || "");
    if (!/<\/?(b|u|strong|em|i)\b/i.test(h)) return esc((q && q.answer_sanitized) || h);
    return h.replace(/<(\/?)(b|u|strong|em|i)\b[^>]*>/gi, "\u0001$1$2\u0002").replace(/<[^>]*>/g, "").replace(/&(?!(?:amp|lt|gt|quot|#\d+);)/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/\u0001(\/?)(\w+)\u0002/g, "<$1$2>");
  }
  function primary(q) {
    var a = "";
    try { if (ctx.host && ctx.host.extractPrimaryAnswer) a = ctx.host.extractPrimaryAnswer((q && q.answer) || "", (q && q.answer_sanitized) || ""); } catch (e) {}
    return a || String((q && q.answer_sanitized) || "").replace(/\s*[\[(].*$/, "").trim();
  }
  // judged right here, like practice (judge.js); { status: "accept" | "prompt" | "reject", prompt }
  async function judge(q, answer, opts) {
    opts = opts || {};
    try {
      if (ctx.host && ctx.host.judgeTossup) return (await ctx.host.judgeTossup(q, answer, { strictness: opts.strictness != null ? opts.strictness : (cfg().strictness || 10), buzzPosition: opts.buzzPosition, previous: opts.previous || null })) || { status: "reject" };
      return (await ctx.api.post("/api/evaluate-tossup", { questionId: q.id, answer: answer, strictness: cfg().strictness || 10, buzzPosition: opts.buzzPosition, previous: opts.previous || null })) || { status: "reject" };
    } catch (e) { return { status: "reject" }; }
  }
  async function judgePart(b, part, answer, opts) {
    opts = opts || {};
    try {
      if (ctx.host && ctx.host.judgeBonusPart) return (await ctx.host.judgeBonusPart(b, part, answer, { strictness: cfg().strictness || 10, previous: opts.previous || null })) || { status: "reject" };
      return (await ctx.api.post("/api/evaluate-bonus-part", { questionId: b.id, part: part, answer: answer, strictness: cfg().strictness || 10 })) || { status: "reject" };
    } catch (e) { return { status: "reject" }; }
  }
  async function judgeLine(line, sani, answer, opts) {
    opts = opts || {};
    try {
      if (ctx.host && ctx.host.judgeAnswerLine) return (await ctx.host.judgeAnswerLine(line, sani, answer, { strictness: cfg().strictness || 10, previous: opts.previous || null })) || { status: "reject" };
      return (await ctx.api.post("/api/evaluate-answer", { answerline: line, answer: answer, strictness: cfg().strictness || 10 })) || { status: "reject" };
    } catch (e) { return { status: "reject" }; }
  }
  function bonusParts(b) { try { return JSON.parse((b && (b.parts_sanitized || b.parts)) || "[]"); } catch (e) { return []; } }
  function bonusAnswers(b) { try { return JSON.parse((b && b.answers) || "[]"); } catch (e) { return []; } }
  function bonusAnswersSani(b) { try { return JSON.parse((b && b.answers_sanitized) || "[]"); } catch (e) { return []; } }

  // the player's answers (Stats' history), only the fields asked for
  async function history(fields) {
    try { return ((await ctx.api.get("/api/sessions/all-entries?" + (/\banswer\b/.test(fields || "") ? "answers=1&" : "") + "fields=" + encodeURIComponent(fields || ""))).entries) || []; } catch (e) { return []; }
  }
  // record a tossup answered on a plugin's page into the player's stats (the path Coach Mode uses)
  function record(q, r) {
    try {
      ctx.api.post("/api/check-tossup", { questionId: q.id, answer: r.answer || "", buzzPosition: r.buzzPosition || 0, sessionId: r.session, overriding: true,
        correct: !!r.correct, isPower: !!r.power, points: r.points || 0, celerity: r.celerity != null ? r.celerity : 1 }).catch(function () {});
    } catch (e) {}
  }

  var ROOT_COLOR = { "Literature": "#bc8cff", "Science": "#58a6ff", "Math": "#a5e05b", "Pop Culture": "#ff7b72", "Sports": "#ff6f91", "Fine Arts": "#f778ba", "History": "#e3b341", "Geography": "#56d364", "Mythology": "#ffa657", "Social Science": "#3dd6a3", "Philosophy": "#39c5cf", "Theology": "#8e9bff", "Current Events": "#c9d16b", "Miscellaneous": "#8b949e" };
  // NAQT's high school distribution, per 24 tossups / bonuses (naqt.com/hs/distribution.jsp)
  var NAQT = [["Literature", 3.9, 3.8], ["Science", 4.5, 4.3], ["Math", 1.0, 1.0], ["Fine Arts", 2.0, 2.0], ["History", 4.6, 4.5], ["Geography", 1.9, 1.9], ["Mythology", 0.6, 0.7],
    ["Pop Culture", 1.0, 0.9], ["Sports", 0.7, 0.7], ["Social Science", 0.6, 0.6], ["Philosophy", 0.3, 0.3], ["Theology", 0.4, 0.4], ["Current Events", 1.5, 1.4], ["Miscellaneous", 1.0, 1.5]];
  function rootOf(e) { return String((e && (e.category_path || e.category)) || "").split(" > ")[0] || "Miscellaneous"; }
  function dot(root) { return '<span class="pk-dot" style="--c:' + (ROOT_COLOR[root] || "#8b949e") + '"></span>'; }
  var _roots = null;
  async function roots() {
    if (_roots) return _roots;
    try { var t = ctx.host && ctx.host.getCategoryTree ? await ctx.host.getCategoryTree("tossups") : (await ctx.api.get("/api/category-tree?type=tossups")).tree; _roots = (t || []).map(function (n) { return { id: n.id, name: n.name, count: n.count }; }); }
    catch (e) { _roots = []; }
    return _roots;
  }
  var DIFF_NAME = { 0: "Unrated", 1: "Middle school", 2: "Easy high school", 3: "Regular high school", 4: "Hard high school", 5: "National high school", 6: "Easy college", 7: "Medium college", 8: "Regionals college", 9: "Nationals college", 10: "Open" };

  function tile(value, label, cls) { return '<div class="pk-tile' + (cls ? " " + cls : "") + '"><b class="num">' + value + "</b><span>" + esc(label) + "</span></div>"; }
  function segHtml(name, items, on) {
    return '<div class="seg pk-seg" role="group">' + items.map(function (it) {
      return '<button type="button" data-' + name + '="' + esc(it[0]) + '" aria-pressed="' + (String(on) === String(it[0])) + '">' + esc(it[1]) + "</button>";
    }).join("") + "</div>";
  }
  function emptyHtml(text) { return '<div class="db-empty pk-empty">' + esc(text) + "</div>"; }
  // square toggles 0 to 10, Setup's difficulty look (the app's .diff-toggles), `on` the ones picked; diffsIn reads them
  function diffHtml(name, on) {
    var h = '<div class="diff-toggles pk-diffs" role="group" aria-label="Difficulty">';
    for (var d = 0; d <= 10; d++) h += '<label title="' + esc(DIFF_NAME[d]) + '"><input type="checkbox" data-' + name + '="' + d + '"' + ((on || []).indexOf(d) >= 0 ? " checked" : "") + "><span>" + d + "</span></label>";
    return h + "</div>";
  }
  function diffsIn(root, name) { return [].slice.call(root.querySelectorAll("[data-" + name + "]")).filter(function (i) { return i.checked; }).map(function (i) { return Number(i.getAttribute("data-" + name)); }); }
  // a list of difficulties in a few words: [2, 3, 4, 5] → "2 to 5"
  function diffWords(ds) {
    ds = (ds || []).slice().sort(function (a, b) { return a - b; });
    if (!ds.length) return "any difficulty";
    var run = ds.every(function (d, i) { return !i || d === ds[i - 1] + 1; });
    return ds.length === 1 ? "difficulty " + ds[0] : run ? "difficulty " + ds[0] + " to " + ds[ds.length - 1] : "difficulty " + ds.join(", ");
  }
  function playList(kind, ids, title) {
    if (!ids || !ids.length) return false;
    try { return !!(ctx.host && ctx.host.launchQuestions && ctx.host.launchQuestions(kind, ids, { title: title })); } catch (e) { return false; }
  }

  // a reader: shows `text` a character at a time at the practice reading speed. start(), pause(), go(), stop();
  // at() is how far it is; onEnd once it's all shown
  function Reader(el, text, opts) {
    opts = opts || {};
    var ms = opts.ms != null ? opts.ms : (Number(cfg().revealSpeed) || 25), idx = 0, raf = 0, last = 0, on = false;
    var paint = function () { el.innerHTML = '<span class="pk-read">' + esc(text.slice(0, idx)) + '</span><span class="pk-unread" aria-hidden="true">' + esc(text.slice(idx)) + "</span>"; };
    var step = function (t) {
      raf = 0; if (!on) return;
      if (!last) last = t;
      var n = ms > 0 ? Math.floor((t - last) / ms) : text.length;
      if (n > 0) { idx = Math.min(text.length, idx + n); last += n * ms; paint(); if (opts.onTick) opts.onTick(idx); }
      if (idx >= text.length) { on = false; if (opts.onEnd) opts.onEnd(); return; }
      raf = requestAnimationFrame(step);
    };
    paint();
    return {
      start: function () { if (on) return; on = true; last = 0; raf = requestAnimationFrame(step); },
      pause: function () { on = false; if (raf) cancelAnimationFrame(raf); raf = 0; },
      stop: function () { on = false; if (raf) cancelAnimationFrame(raf); raf = 0; },
      showAll: function () { this.stop(); idx = text.length; el.textContent = text; },
      at: function () { return idx; },
      running: function () { return on; },
    };
  }
  // a reader's position in the displayed text → the record's question_sanitized (what judging and stats count)
  function serverPos(q, display, pos) {
    try { if (ctx.host && ctx.host.mapDisplayPos) return ctx.host.mapDisplayPos(display, (q && q.question_sanitized) || "", pos); } catch (e) {}
    return pos;
  }

  // ── Layout Customizer 3.0 (15.68): edit any page's layout right on the page, like a game's HUD editor ──
  // Shift L (or a page picked on the plugin's page) covers each part of the page with a box. Drag a box to move it, its
  // corner to size it, and its gear for that part's own settings: what it shows (its pieces, switched on or off and
  // dragged into an order, each one opened for its own pieces or pulled out to float anywhere on the window), its size,
  // how it sits in its space, staying in view while the page scrolls, splitting it into boxes of its own, hiding it.
  // A page's layout is a grid of 24 columns on the page itself (the screen, or Home's column): the wrappers between it
  // and the parts become display:contents, so the page head's title and buttons, the cards and the side panel's parts
  // each go anywhere. The question column stays one part (the app adds its answer box, timers and bonus parts to it as
  // it goes); its pieces are ordered, hidden or pulled out instead. Parts are found on the page, so every page works,
  // the ones the plugin knows with better names. Elements are keyed by their place on the page (an id, else their class
  // and heading under their parent's key) and tagged data-lc, which one style sheet reads. The grid and floating parts
  // apply where the window is 900 px wide or more; what a part shows, its order and size apply everywhere.
  // 2.0 arranged a few parts of ten pages on a grid of 12; its layouts move over the first time their page is seen.
  var KEY = "layouts";
  var saved = ctx.storage.get(KEY) || {};          // screen id → layout (below)
  var legacy = ctx.storage.get("grids") || null;    // 2.0's layouts, by its page ids
  var align = ctx.storage.get("align") !== false;
  var COLS = 24, GAP = 16, VGAP = 18, MIN_W = 900, SIZES = [[0.85, "Small"], [1, "Normal"], [1.15, "Large"], [1.3, "Larger"]];
  // a layout: { grid: { key: [col from, col to, row from, row to, how it sits] }, h: { key: min height }, split: [keys],
  // join: [keys], hide: [keys], order: { parent key: { ids: [keys], col } }, size: { key: n }, align: { key: v },
  // sticky: { key: 1 }, float: { key: { ax: l|c|r, x, ay: t|c|b, y, w } } }
  function nav(name) {
    try { if (ctx.host && ctx.host.openScreen) return ctx.host.openScreen(name); if (typeof window.goTo === "function") { window.goTo(name); return true; } } catch (e) {}
    return false;
  }

  // ── the pages the plugin knows: better names, and what's one part or many ──
  // the page head opens into its title and its row of buttons (which stays a row: split it to move each button)
  var HEAD = [".top-bar", ".top-bar-left"];
  var CONF = {
    "title-screen": { n: "Home", box: ".home-inner", flat: [".home-cards"], w: "1040px", pad: "var(--gutter)", extra: "align-content:safe center!important;",
      names: { ".hero": "Logo and greeting", ".home-dl": "App download", ".home-foot": "Footer links", ".wordmark": "Logo", ".greet": "Greeting" } },
    "practice-screen": { n: "Tossups and bonuses", flat: HEAD.concat([".practice-layout", "#live-stats"]), solid: ["#question-area"], w: "var(--practice-w)", pad: "clamp(20px, 3vw, 48px)",
      names: { "#practice-title": "Title", "#btn-voice": "Voice", "#btn-open-setup": "Setup", "#btn-end-session": "End", "#btn-home": "Back", "#question-area": "Question",
        "#plugin-side": "Plugin box", ".side-stats": "Scoreboard", ".side-hist": "This session", "#question-placeholder": "Before you start", "#question-content": "Question text",
        "#question-meta": "Question info", "#question-text": "Text", "#read-box": "Reading box", "#power-mark": "Power mark", "#buzz-area": "Answer box",
        "#result-area": "Result", "#result-banner": "Verdict", "#result-answer": "Answer line", "#result-tags": "Tags", "#result-actions": "Next button",
        "#practice-actions": "Buzz, skip and pause", "#pa-buzz": "Buzz", "#pa-main": "Start, skip or next", "#pa-pause": "Pause", ".sb-head": "Points and heard",
        ".sb-score": "Points", ".sb-heard": "Heard", ".sb-bar": "Answers bar", ".sb-legend": "Bar key", ".sb-rates": "Rates", "#session-mini": "Recent answers", "#history-panel": "Session history" } },
    "stats-screen": { n: "Statistics", names: { "#stats-period": "Time period", "#stats-cat-btn": "Categories" } },
    "player-screen": { n: "Profile", names: { ".ev-card": "Event", ".pf-card": "Profile card", ".pf-tiles": "Tiles", ".pf-ach": "Achievements" } },
    "trials-screen": { n: "Trials", names: { ".tr-intro": "What trials are", ".tr-subs": "Subject trials" } },
    "leaderboards-screen": { n: "Leaderboards", names: { ".lb-kind-bar": "Boards", ".lb-board": "Table" } },
    "database-screen": { n: "Question database", names: { ".db-tabs": "Tabs", "#db-searchbar": "Search box", ".qrow": "Filters", "#db-rhead": "Count and pages", "#db-results": "Results",
      "#db-pager-bottom": "Pages", ".freq-toolbar": "Categories and types", "#freq-rhead": "Count and pages", "#freq-results": "Answers" } },
    "ext-page-multiplayer-lobby": { n: "Multiplayer", names: { ".mp-who": "Playing as", ".mp-join-card": "Join or make a room", ".mp-recent": "Recent rooms" } },
  };
  // the plugin page's list (any other page: the key, on it)
  var LIST = [
    ["title-screen", "Home", "home"], ["practice-screen", "Tossups and bonuses", "practice-tossups"], ["stats-screen", "Statistics", "stats"], ["player-screen", "Profile", "player"],
    ["trials-screen", "Trials", "trials"], ["leaderboards-screen", "Leaderboards", "leaderboards"], ["database-screen", "Search", "db-search"], ["database-screen", "Frequency", "db-frequency"],
    ["ext-page-multiplayer-lobby", "Multiplayer", function () { if (window.QB && QB.showPage) QB.showPage("multiplayer::lobby"); }], ["clubs-screen", "Clubs", "clubs"], ["store-screen", "Store", "store"],
  ];
  var NAMES = { ".top-bar": "Page head", ".top-bar-left": "Title", ".top-bar-right": "Buttons", ".top-bar-title": "Title", "[id$=-home]": "Back", ".ext-page-home": "Home",
    ".acct-panel": "Sign in", "[class*=pager], [id*=pager]": "Pages", ".db-tabs": "Tabs" };
  function cfg(id) {
    var c = CONF[id] || {}, scr = document.getElementById(id);
    var t = scr && scr.querySelector(".top-bar-title");
    return { id: id, n: c.n || (t ? String(t.textContent).trim() : "This page"), box: c.box || null, flat: c.flat || HEAD, solid: c.solid || [], w: c.w || "var(--page-w)",
      pad: c.pad || "var(--gutter)", extra: c.extra || "", names: Object.assign({}, NAMES, c.names || {}) };
  }
  function screenOf(P) { var s = document.getElementById(P.id); return s && s.classList.contains("active") ? s : null; }
  function boxOf(P) { var s = screenOf(P); return s ? (P.box ? s.querySelector(P.box) : s) : null; }

  // ── keys: an element's place on the page ──
  var STATE = /^(hidden|active|on|off|open|show|shown|sel|selected|disabled|live|in|out|web-only|topics-only|packet-disable|pending|loading|empty|hb-in|qb-leaving|btn-(sm|md|lg|ghost|primary|go|icon|full)|(is|has|lc)-.*)$/;
  function base(el) {
    var cl = el.classList;
    for (var i = 0; i < cl.length; i++) if (!STATE.test(cl[i]) && /^[a-zA-Z][\w-]*$/.test(cl[i])) return "." + cl[i];
    return el.tagName.toLowerCase();
  }
  function textOf(el) { return String((el && el.textContent) || "").replace(/\s+/g, " ").trim(); }
  var HEADS = "h1,h2,h3,h4,h5,legend,.eyebrow,.stats-section-title,.section-title,.card-title,.fp-title";
  function headOf(el) { for (var c = el.firstElementChild, i = 0; c && i < 3; c = c.nextElementSibling, i++) if (c.matches(HEADS)) return c; return null; }
  function label(el) {
    var a = el.getAttribute("aria-label"); if (a) return a;
    var lb = el.getAttribute("aria-labelledby"); if (lb) { var t = document.getElementById(lb.split(" ")[0]); if (t) return textOf(t); }
    if (/^(BUTTON|A|LABEL|H[1-6]|LEGEND)$/.test(el.tagName)) return textOf(el);
    var h = headOf(el); return h ? textOf(h) : "";
  }
  // a label's words without the numbers that change ("Tossups: 1461" is Tossups, "Session history (3)" Session history)
  function words(s) { return String(s || "").replace(/[\d,.%:·()/+−–—-]+/g, " ").replace(/\s+/g, " ").trim(); }
  function slugOf(s) { return norm(words(s)).replace(/ /g, "-").slice(0, 24); }
  function local(el) {
    var b = base(el), s = slugOf(label(el)), k = 0;
    for (var c = el.parentElement && el.parentElement.firstElementChild; c && c !== el; c = c.nextElementSibling) if (!c.id && base(c) === b && slugOf(label(c)) === s) k++;
    return b + (s ? "(" + s + ")" : "") + (k ? "~" + k : "");
  }
  function keyOf(el, box) {
    if (el.id) return "#" + el.id;
    var p = el.parentElement;
    return (p && p !== box && box.contains(p) ? keyOf(p, box) + ">" : "") + local(el);
  }
  function resolve(key, box) {
    var segs = String(key).split(">"), cur = box;
    for (var i = 0; i < segs.length && cur; i++) {
      var s = segs[i];
      if (s.charAt(0) === "#") { cur = document.getElementById(s.slice(1)); if (cur && !box.contains(cur)) cur = null; continue; }
      var next = null;
      for (var c = cur.firstElementChild; c; c = c.nextElementSibling) if (!c.id && local(c) === s) { next = c; break; }
      cur = next;
    }
    return cur === box ? null : cur;
  }
  function humanize(b) {
    var s = String(b).replace(/^[.#]/, "").replace(/^[a-z]{1,3}-(?=[a-z]{3})/, "").replace(/[-_]+/g, " ").trim();
    return s ? s.charAt(0).toUpperCase() + s.slice(1) : "Box";
  }
  function nameOf(P, el) {
    if (!el) return "Part";
    var keys = Object.keys(P.names);
    for (var i = 0; i < keys.length; i++) if (el.matches(keys[i])) return P.names[keys[i]];
    var own = function (c) { return words(label(c) || c.getAttribute("title") || (c.children.length <= 2 && textOf(c).length < 30 ? textOf(c) : "")); };
    var s = words(label(el) || el.getAttribute("title") || "");
    // a group without a name of its own: its pieces' names ("Tossups and bonuses")
    if (!s) {
      var ps = pieces(el), ns = ps.length >= 2 && ps.length <= 4 ? ps.map(own) : [];
      if (ns.length && ns.every(Boolean)) { ns = ns.map(function (n, i) { return i ? n.toLowerCase() : n; }); s = ns.length === 2 ? ns.join(" and ") : ns.slice(0, -1).join(", ") + " and " + ns[ns.length - 1]; }
    }
    if (!s && textOf(el).length < 30) s = words(textOf(el));
    if (!s) { var h = el.querySelector(HEADS); if (h) s = words(textOf(h)); }
    if (s) {
      if (s === s.toUpperCase() && /[A-Z]{2}/.test(s)) s = s.toLowerCase();   // headings set in capitals read in sentence case
      s = s.length > 32 ? s.slice(0, 30).trim() + "…" : s; return s.charAt(0).toUpperCase() + s.slice(1);
    }
    var b = el.id ? "#" + el.id : base(el);
    if (/(^|[.#-])(body|content|inner|main)$/.test(b)) return "Content";
    return /^[.#]/.test(b) ? humanize(b) : "Box";
  }

  // ── a page's parts: walking from its box, through the wrappers that become display:contents ──
  var looks = new WeakMap();
  function look(el) {
    var v = looks.get(el); if (v) return v;
    var cs = getComputedStyle(el), clear = cs.backgroundColor === "rgba(0, 0, 0, 0)" || cs.backgroundColor === "transparent";
    v = { pos: cs.position, disp: cs.display, plain: clear && cs.backgroundImage === "none" && !parseFloat(cs.borderTopWidth) && !parseFloat(cs.borderBottomWidth) && !parseFloat(cs.borderLeftWidth) && cs.boxShadow === "none" };
    looks.set(el, v); return v;
  }
  var SKIP = /^(SCRIPT|STYLE|TEMPLATE|LINK|META|svg|SVG|BR|WBR)$/;
  function kids(el) {
    var out = [];
    for (var c = el.firstElementChild; c; c = c.nextElementSibling) {
      if (SKIP.test(c.tagName) || /(^|\s)lc-/.test(c.getAttribute("class") || "")) continue;
      if (!c.hasAttribute("data-lc-fl")) { var p = look(c).pos; if (p === "fixed" || p === "absolute") continue; }
      out.push(c);
    }
    return out;
  }
  function hasText(el) { for (var n = el.firstChild; n; n = n.nextSibling) if (n.nodeType === 3 && n.nodeValue.trim()) return true; return false; }
  // a row of buttons (a tab bar, even with a menu in it) stays one part
  function isToolbar(el) {
    var k = el.children, n = 0; if (k.length < 2) return false;
    for (var i = 0; i < k.length; i++) if (/^(BUTTON|A|INPUT|SELECT|LABEL|KBD|SPAN|svg)$/.test(k[i].tagName) || (k[i].firstElementChild && k[i].firstElementChild.tagName === "BUTTON")) n++;
    return n >= k.length * 2 / 3;
  }
  function shown(el) { return el.hasAttribute("data-lc-flat") || el.getClientRects().length > 0; }
  function isSolid(P, el) { return P.solid.some(function (s) { return el.matches(s); }); }
  function has(list, k) { return !!list && list.indexOf(k) >= 0; }
  function flatHere(P, L, el, k, depth) {
    if (has(L.join, k) || isSolid(P, el)) return false;
    if (has(L.split, k)) return true;
    if (depth < 4 && P.flat.some(function (s) { return el.matches(s); })) return true;
    if (depth > 2 || !el.firstElementChild || !/^(DIV|SECTION|MAIN|ARTICLE|ASIDE)$/.test(el.tagName) || !look(el).plain || headOf(el) || isToolbar(el) || hasText(el)) return false;
    if (depth === 0) return true;   // the page's content containers
    // further in, only a wrapper that's the one thing in its parent and holds sections (a page inside its container,
    // not a "nothing here yet" note)
    var secs = kids(el).filter(function (c) { return !look(c).plain || pieces(c).length >= 1; }).length;
    return secs >= 2 && kids(el.parentElement).filter(shown).length === 1;
  }
  function walk(P, L, box, fn) {
    (function go(parent, depth) {
      kids(parent).forEach(function (el) {
        var k = keyOf(el, box), f = flatHere(P, L, el, k, depth);
        fn(el, k, f);
        if (f) go(el, depth + 1);
      });
    })(box, 0);
  }
  // what a part or piece is made of, for its gear: its element children, minus text formatting and icons
  var INLINE = /^(I|B|STRONG|EM|KBD|SMALL|SUP|SUB|ABBR|U|S|MARK|IMG|svg|SVG|BR|WBR)$/;
  function pieces(el) { return kids(el).filter(function (c) { return !INLINE.test(c.tagName); }); }

  // ── tagging: data-lc on what the layout names, data-lc-flat / data-lc-i on the wrappers and the grid's parts ──
  function refs(L) {
    var out = [];
    ["hide", "split", "join"].forEach(function (f) { (L[f] || []).forEach(function (k) { out.push(k); }); });
    ["size", "align", "sticky", "float", "h", "grid"].forEach(function (f) { Object.keys(L[f] || {}).forEach(function (k) { out.push(k); }); });
    Object.keys(L.order || {}).forEach(function (k) { out.push(k); out.push.apply(out, L.order[k].ids); });
    return out;
  }
  function layoutOf(id) { return E && E.P.id === id ? E.L : saved[id]; }
  function hasGrid(L) { return !!(L && L.grid && Object.keys(L.grid).length); }
  function tagPage(P) {
    var L = layoutOf(P.id), box = boxOf(P);
    if (!box || !L) return;
    var seen = new Set();
    if (hasGrid(L) || (E && E.P.id === P.id)) walk(P, L, box, function (el, k, f) {
      seen.add(el);
      if (el.getAttribute("data-lc") !== k) el.setAttribute("data-lc", k);
      if (f) { if (!el.hasAttribute("data-lc-flat")) el.setAttribute("data-lc-flat", ""); if (el.hasAttribute("data-lc-i")) el.removeAttribute("data-lc-i"); }
      else { if (!el.hasAttribute("data-lc-i")) el.setAttribute("data-lc-i", ""); if (el.hasAttribute("data-lc-flat")) el.removeAttribute("data-lc-flat"); }
    });
    if (hasGrid(L)) {
      var loose = [].some.call(box.querySelectorAll("[data-lc-i]"), function (el) { var k = el.getAttribute("data-lc"); return !L.grid[k] && !(L.float && L.float[k]) && !has(L.hide, k) && el.getClientRects().length; });
      if (loose !== box.hasAttribute("data-lc-loose")) { if (loose) box.setAttribute("data-lc-loose", ""); else box.removeAttribute("data-lc-loose"); }
    } else if (box.hasAttribute("data-lc-loose")) box.removeAttribute("data-lc-loose");
    refs(L).forEach(function (k) {
      var el = resolve(k, box); if (!el) return;
      seen.add(el);
      if (el.getAttribute("data-lc") !== k) el.setAttribute("data-lc", k);
    });
    Object.keys(L.float || {}).forEach(function (k) { var el = resolve(k, box); if (el && !el.hasAttribute("data-lc-fl")) el.setAttribute("data-lc-fl", ""); });
    box.querySelectorAll("[data-lc],[data-lc-i],[data-lc-flat],[data-lc-fl]").forEach(function (el) {
      if (!seen.has(el)) { el.removeAttribute("data-lc"); el.removeAttribute("data-lc-i"); el.removeAttribute("data-lc-flat"); }
      if (el.hasAttribute("data-lc-fl") && !(L.float && L.float[el.getAttribute("data-lc")])) el.removeAttribute("data-lc-fl");
    });
    // a part shown in a new order: what the app adds to it later stays with the piece it was put before
    var ordered = new Set();
    Object.keys(L.order || {}).forEach(function (pk) {
      var p = resolve(pk, box); if (!p) return;
      ordered.add(p);
      var ids = L.order[pk].ids, next = (ids.length + 1) * 10;
      for (var c = p.lastElementChild; c; c = c.previousElementSibling) {
        var i = ids.indexOf(keyOf(c, box));
        if (i >= 0) { next = (i + 1) * 10; if (c.hasAttribute("data-lc-o")) { c.style.order = ""; c.removeAttribute("data-lc-o"); } continue; }
        if (c.style.order !== String(next)) { c.style.order = next; c.setAttribute("data-lc-o", ""); }
      }
    });
    box.querySelectorAll("[data-lc-o]").forEach(function (c) { if (!ordered.has(c.parentElement)) { c.style.order = ""; c.removeAttribute("data-lc-o"); } });
  }
  function untag(root) {
    (root || document).querySelectorAll("[data-lc-loose]").forEach(function (el) { el.removeAttribute("data-lc-loose"); });
    if (root && root.removeAttribute) root.removeAttribute("data-lc-loose");
    (root || document).querySelectorAll("[data-lc],[data-lc-i],[data-lc-flat],[data-lc-fl],[data-lc-o]").forEach(function (el) {
      el.removeAttribute("data-lc"); el.removeAttribute("data-lc-i"); el.removeAttribute("data-lc-flat"); el.removeAttribute("data-lc-fl");
      if (el.hasAttribute("data-lc-o")) { el.style.order = ""; el.removeAttribute("data-lc-o"); }
    });
  }
  function activeId() { var s = document.querySelector("#app > .screen.active") || document.querySelector(".screen.active"); return s ? s.id : ""; }
  function tagActive() {
    var id = activeId(); if (!id) return;
    if (legacy) migrate(id);
    if (layoutOf(id)) tagPage(cfg(id));
  }
  // tagged the moment the app changes a page (a MutationObserver runs before the next paint, so nothing shows untagged)
  var busy = false;
  var mo = new MutationObserver(function () { if (busy) return; busy = true; try { tagActive(); } catch (e) { console.error("[layout]", e); } busy = false; });
  mo.observe(document.body, { childList: true, subtree: true });

  // ── the style sheet: every page's layout ──
  var styleEl = null;
  function sel(P, k) { return "#" + CSS.escape(P.id) + '.active [data-lc="' + k + '"]'; }
  function cssFor(P, L) {
    var all = "", wide = "", sz = L.size || {};
    (L.hide || []).forEach(function (k) { all += sel(P, k) + "{display:none!important}"; });
    Object.keys(L.order || {}).forEach(function (pk) {
      var o = L.order[pk];
      if (o.col === "row") all += sel(P, pk) + "{display:flex!important;flex-wrap:wrap!important;align-items:center!important}";
      else if (o.col) all += sel(P, pk) + "{display:flex!important;flex-direction:column!important}";
      o.ids.forEach(function (k, i) { all += sel(P, k) + "{order:" + (i + 1) * 10 + "!important}"; });
    });
    Object.keys(sz).forEach(function (k) { if (!(L.float && L.float[k])) all += sel(P, k) + "{zoom:" + sz[k] + "}"; });
    if (hasGrid(L)) {
      var S = "#" + CSS.escape(P.id) + ".active", B = P.box ? S + " " + P.box : S;
      var T = "calc((min(" + P.w + ", 100%) - 2 * " + P.pad + " - " + (COLS - 1) * GAP + "px) / " + COLS + ")";
      wide += B + "{display:grid!important;grid-template-columns:minmax(0,1fr) repeat(" + COLS + ",minmax(0," + T + ")) minmax(0,1fr)!important;grid-auto-rows:auto!important;column-gap:" + GAP + "px!important;row-gap:0!important;" +
        "align-items:start!important;align-content:start!important;justify-content:stretch!important;padding-left:0!important;padding-right:0!important;" + (P.box ? "" : "padding-top:20px!important;padding-bottom:40px!important;") + P.extra + "}";
      wide += B + " [data-lc-flat]{display:contents!important}";
      wide += B + " [data-lc-i]{grid-column:2/-2;grid-row:auto;margin:0 0 " + VGAP + "px!important;min-width:0!important;max-width:none!important;width:auto!important;justify-self:stretch;align-self:start;float:none!important;flex:none!important}";
      var R = 0, ends = false;
      Object.keys(L.grid).forEach(function (k) { var v = L.grid[k]; if (v[3] < 0) { ends = true; R = Math.max(R, v[2]); } else R = Math.max(R, v[3] - 1); });
      // (a part the layout doesn't place yet goes after the rows: then there's no stretching row, which would push it out of sight)
      if (ends) wide += B + ":not([data-lc-loose]){grid-template-rows:repeat(" + R + ",auto) minmax(0,1fr)!important}";
      Object.keys(L.grid).forEach(function (k) {
        var v = L.grid[k], j = (L.align && L.align[k]) || v[4] || "stretch", it = B + ' [data-lc-i][data-lc="' + k + '"]';
        wide += it + "{grid-column:" + (v[0] + 1) + "/" + (v[1] + 1) + ";grid-row:" + v[2] + "/" + (v[3] < 0 ? "-1" : v[3]) + ";justify-self:" + j + (j !== "stretch" ? ";width:max-content!important;max-width:100%!important" : "") + "}";
        if (v[3] < 0) wide += B + "[data-lc-loose]" + it.slice(B.length) + "{grid-row:" + v[2] + "/span " + (R + 1 - v[2]) + "}";
      });
    }
    Object.keys(L.h || {}).forEach(function (k) { wide += sel(P, k) + "{min-height:" + L.h[k] + "px!important}"; });
    Object.keys(L.sticky || {}).forEach(function (k) { wide += sel(P, k) + "{position:sticky!important;top:12px!important;z-index:2}"; });
    Object.keys(L.float || {}).forEach(function (k) {
      var f = L.float[k], z = sz[k] || 1, ax = f.ax === "c" ? "center" : f.ax === "r" ? "right" : "left", ay = f.ay === "c" ? "center" : f.ay === "b" ? "bottom" : "top";
      var c = "position:fixed!important;z-index:30!important;margin:0!important;width:" + Math.round(f.w) + "px!important;max-width:calc(100vw - 16px)!important;";
      c += f.ax === "r" ? "left:auto!important;right:" + Math.round(f.x) + "px!important;" : f.ax === "c" ? "right:auto!important;left:calc(50% + " + Math.round(f.x) + "px)!important;" : "right:auto!important;left:" + Math.round(f.x) + "px!important;";
      c += f.ay === "b" ? "top:auto!important;bottom:" + Math.round(f.y) + "px!important;" : f.ay === "c" ? "bottom:auto!important;top:calc(50% + " + Math.round(f.y) + "px)!important;" : "bottom:auto!important;top:" + Math.round(f.y) + "px!important;";
      c += "translate:" + (f.ax === "c" ? "-50%" : "0") + " " + (f.ay === "c" ? "-50%" : "0") + "!important;scale:" + z + ";transform-origin:" + ay + " " + ax + ";";
      wide += sel(P, k) + "{" + c + "}";
    });
    return { all: all, wide: wide };
  }
  function applyCss() {
    looks = new WeakMap();
    if (!styleEl) { styleEl = document.createElement("style"); styleEl.id = "lc-layouts"; document.head.appendChild(styleEl); }
    var ids = Object.keys(saved); if (E && ids.indexOf(E.P.id) < 0) ids.push(E.P.id);
    var all = "", wide = "";
    ids.forEach(function (id) { var L = layoutOf(id); if (!L) return; var c = cssFor(cfg(id), L); all += c.all; wide += c.wide; });
    styleEl.textContent = all + (wide ? "@media (min-width:" + MIN_W + "px){" + wide + "}" : "");
    busy = true; try { tagActive(); } finally { busy = false; }
  }
  function save() { ctx.storage.set(KEY, saved); }

  // ── 2.0's layouts (a grid of 12 on a few parts of each page): moved over the first time their page is seen ──
  var OLD = {
    home: ["title-screen", "#title-screen .home-inner", { hero: ".hero", play: ".home-cards > .hcard:nth-of-type(1)", db: ".home-cards > .hcard:nth-of-type(2)", foot: ".home-foot" }],
    stats: ["stats-screen", "#stats-container", null],
    profile: ["player-screen", "#player-container .pf-page", { event: ".ev-card", card: ".pf-card", tiles: ".pf-tiles", ach: ".pf-ach" }],
    trials: ["trials-screen", "#trials-container .tr-page", { intro: ".tr-intro", trials: ".pf-trials:not(.tr-subs)", subs: ".tr-subs" }],
    leaderboards: ["leaderboards-screen", "#lb-container .lb-page", { kinds: ".lb-kind-bar", tabs: ".lb-bar:not(.lb-kind-bar)", board: ".lb-board" }],
    search: ["database-screen", "#db-content .db-search", { box: "#db-searchbar", filters: ".qrow", head: "#db-rhead", results: "#db-results", pages: "#db-pager-bottom" }],
    frequency: ["database-screen", "#db-content .db-freq", { tools: ".freq-toolbar", head: "#freq-rhead", results: "#freq-results" }],
    multiplayer: ["ext-page-multiplayer-lobby", ".screen.active .mp-lobby-main", { who: ".mp-who", join: ".mp-join-card", recent: ".mp-recent" }],
  };
  function migrate(id) {
    var changed = false;
    Object.keys(legacy).forEach(function (oid) {
      var o = OLD[oid], g = legacy[oid];
      if (!o || !g || !Object.keys(g).length) { delete legacy[oid]; changed = true; return; }
      if (o[0] !== id) return;
      var old = document.querySelector(o[1]), P = cfg(id), box = boxOf(P); if (!old || !box) return;
      var parts = {};
      if (o[2]) Object.keys(o[2]).forEach(function (pid) { var el = old.querySelector(o[2][pid]); if (el) parts[pid] = el; });
      else [].slice.call(old.children).forEach(function (el) { var t = old.querySelector && el.querySelector(".stats-section-title"); var s = t ? norm(words(textOf(t))).replace(/ /g, "-").slice(0, 30) : ""; if (s) parts[s] = el; });
      var L = saved[id] || (saved[id] = {}), head = box.querySelector(":scope > .top-bar");
      L.grid = L.grid || {};
      // the page head stays one part, and whatever came before the old parts (the database's tabs) keeps a row above them
      if (head) { L.join = (L.join || []).concat([keyOf(head, box)]); }
      var first = Object.keys(parts).map(function (p) { return parts[p]; })[0], top = 0;
      walk(P, L, box, function (el, k, f) {
        if (f || !first || !(el.compareDocumentPosition(first) & Node.DOCUMENT_POSITION_FOLLOWING) || el.contains(first)) return;
        if (!L.grid[k]) { top++; L.grid[k] = [1, COLS + 1, top, top + 1]; }
      });
      Object.keys(parts).forEach(function (pid) { var v = g[pid]; if (v) L.grid[keyOf(parts[pid], box)] = [2 * v[0] - 1, 2 * v[1] - 1, v[2] + top, v[3] + top]; });
      delete legacy[oid]; changed = true;
    });
    if (changed) {
      if (!Object.keys(legacy).length) legacy = null;
      ctx.storage.set("grids", legacy); save(); applyCss();
    }
  }

  // ── editing a page, on the page ──
  var E = null;
  // E: { P, scr, box, host (what scrolls: the overlay goes in it), L (the draft), before, ovl, fly, bar, b: { key: box }, cx, cw, gear }
  function el(tag, cls, html) { var x = document.createElement(tag); if (cls) x.className = cls; if (html != null) x.innerHTML = html; return x; }
  function clone(o) { return JSON.parse(JSON.stringify(o || {})); }
  function hostXY(r) {
    var hr = E.host.getBoundingClientRect();
    return { x: r.left - hr.left - E.host.clientLeft + E.host.scrollLeft, y: r.top - hr.top - E.host.clientTop + E.host.scrollTop };
  }
  // the page's content column (where the 24 columns go), as the grid makes it: a probe with the same width and padding
  function contentArea() {
    var pr = el("div", "lc-probe");
    pr.style.cssText = "position:absolute;top:0;left:0;right:0;height:1px;margin:0 auto;visibility:hidden;pointer-events:none;box-sizing:border-box;max-width:" + E.P.w + ";padding:0 " + E.P.pad;
    E.host.appendChild(pr);
    var r = pr.getBoundingClientRect(), cs = getComputedStyle(pr), pl = parseFloat(cs.paddingLeft) || 0, pw = parseFloat(cs.paddingRight) || 0, xy = hostXY(r);
    pr.remove();
    return { x: xy.x + pl, w: Math.max(100, r.width - pl - pw) };
  }
  async function startEdit(go) {
    if (E || innerWidth < MIN_W) return;
    if (go) {
      if (typeof go[2] === "function") go[2](); else nav(go[2]);
      for (var i = 0; i < 40 && activeId() !== go[0]; i++) await new Promise(function (r) { setTimeout(r, 100); });
      await new Promise(function (r) { setTimeout(r, 600); });
    }
    var id = activeId(); if (!id || E) return;
    var P = cfg(id), box = boxOf(P); if (!box) return;
    var scr = screenOf(P);
    E = { P: P, scr: scr, box: box, host: P.box ? box : scr, L: clone(saved[id]), before: JSON.stringify(saved[id] || {}), b: {}, gear: null };
    E.host.classList.add("lc-host");
    document.documentElement.classList.add("lc-editing");
    E.ovl = el("div", "lc-ovl"); E.host.appendChild(E.ovl);
    E.ovl.innerHTML = '<span class="lc-frame"></span><span class="lc-guide lc-gv" hidden></span><span class="lc-guide lc-gh" hidden></span>';
    E.fly = el("div", "lc-fly", '<span class="lc-guide lc-gv" hidden></span><span class="lc-guide lc-gh" hidden></span>'); document.body.appendChild(E.fly);
    E.bar = el("div", "lc-editbar"); E.bar.setAttribute("role", "toolbar"); E.bar.setAttribute("aria-label", "Layout");
    document.body.appendChild(E.bar);
    E.host.addEventListener("scroll", onHostScroll, { passive: true });
    // a question being read waits while its page is edited (the app's own Pause button, pressed again after)
    var pb = document.getElementById("pa-pause");
    if (scr.contains(pb) && !pb.hidden && /pause/i.test(textOf(pb))) { pb.click(); E.paused = true; }
    applyCss(); renderBar(); measure();
  }
  function endEdit() {
    if (!E) return;
    closeGear(); closeHidden();
    E.host.classList.remove("lc-host"); document.documentElement.classList.remove("lc-editing");
    E.host.removeEventListener("scroll", onHostScroll);
    E.ovl.remove(); E.fly.remove(); E.bar.remove();
    var box = E.box, paused = E.paused; E = null; drag = null;
    applyCss();
    var pb = document.getElementById("pa-pause");
    if (paused && pb && !pb.hidden && /resume/i.test(textOf(pb))) pb.click();
    if (!saved[activeId()]) untag(box);
  }
  function cancelEdit() { endEdit(); }
  function doneEdit() {
    if (!E) return;
    var L = tidy(E.L);
    if (Object.keys(L).length) saved[E.P.id] = L; else delete saved[E.P.id];
    save(); endEdit(); render();
  }
  function resetPage() { if (!E) return; E.L = {}; closeGear(); applyCss(); renderBar(); settle(); }
  // drop what's empty, so a page with nothing changed has no layout at all
  function tidy(L) {
    var out = {};
    Object.keys(L).forEach(function (f) {
      var v = L[f];
      if (Array.isArray(v)) { if (v.length) out[f] = v; }
      else if (v && typeof v === "object") { if (Object.keys(v).length) out[f] = v; }
    });
    return out;
  }

  // where every part is now: a box over each one (the floating ones in a layer fixed to the window)
  function measure() {
    if (!E) return;
    var ca = contentArea(); E.cx = ca.x; E.cw = ca.w;
    E.ovl.style.height = "0px"; E.ovl.style.height = Math.max(E.host.scrollHeight, E.host.clientHeight) + "px";
    var fr = E.ovl.querySelector(".lc-frame"); fr.style.left = E.cx + "px"; fr.style.width = E.cw + "px";
    var live = {};
    walk(E.P, E.L, E.box, function (node, k, f) {
      if (f) return;
      var r = node.getBoundingClientRect(); if (r.width < 2 || r.height < 2) return;
      var fl = !!(E.L.float && E.L.float[k]), b = E.b[k];
      if (!b || b.fl !== fl) { if (b) b.el.remove(); b = E.b[k] = mkBox(k, node, fl); }
      b.node = node; b.n = nameOf(E.P, node);
      if (fl) { b.x = r.left; b.y = r.top; } else { var xy = hostXY(r); b.x = xy.x - E.cx; b.y = xy.y; }
      b.w = r.width; b.h = r.height; live[k] = 1;
      b.el.querySelector(".lc-name").textContent = b.n; b.el.setAttribute("aria-label", b.n);
      paintBox(k);
    });
    // pieces pulled out of a part float too: a box for each of those
    Object.keys(E.L.float || {}).forEach(function (k) {
      if (live[k]) return;
      var node = resolve(k, E.box); if (!node) return;
      var r = node.getBoundingClientRect(); if (r.width < 2 || r.height < 2) return;
      var b = E.b[k]; if (!b || !b.fl) { if (b) b.el.remove(); b = E.b[k] = mkBox(k, node, true); }
      b.node = node; b.n = nameOf(E.P, node); b.x = r.left; b.y = r.top; b.w = r.width; b.h = r.height; live[k] = 1;
      b.el.querySelector(".lc-name").textContent = b.n; paintBox(k);
    });
    Object.keys(E.b).forEach(function (k) { if (!live[k]) { E.b[k].el.remove(); delete E.b[k]; } });
    if (E.gear) placeGear();
  }
  function mkBox(k, node, fl) {
    var b = el("div", "lc-block" + (fl ? " lc-floating" : ""));
    b.dataset.b = k; b.tabIndex = 0; b.setAttribute("role", "button");
    b.innerHTML = '<span class="lc-name"></span><button type="button" class="lc-gear-btn" data-lce="gear" aria-label="Settings" title="Settings">' + GEAR + '</button><span class="lc-size" data-size="1" aria-hidden="true"></span>';
    (fl ? E.fly : E.ovl).appendChild(b);
    return { el: b, fl: fl };
  }
  var GEAR = '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09a1.65 1.65 0 0 0-1-1.51 1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09a1.65 1.65 0 0 0 1.51-1 1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33h.08a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82v.08a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>';
  function paintBox(k) {
    var b = E.b[k], s = b.el.style;
    s.left = (b.fl ? b.x : b.x + E.cx) + "px"; s.top = b.y + "px"; s.width = b.w + "px"; s.height = b.h + "px";
    b.el.classList.toggle("lc-small", b.w < 120 || b.h < 44);
    b.el.classList.toggle("on", !!(E.gear && E.gear.path[0] === k) || sel0 === k);
  }
  // after the page lays out again, the boxes glide to where the parts went
  function settle() {
    requestAnimationFrame(function () { requestAnimationFrame(function () {
      if (!E) return;
      E.ovl.classList.add("lc-settle"); E.fly.classList.add("lc-settle"); measure();
      setTimeout(function () { if (E) { E.ovl.classList.remove("lc-settle"); E.fly.classList.remove("lc-settle"); } }, 260);
    }); });
  }
  function onHostScroll() { if (E && E.gear) placeGear(); }

  // boxes → the grid: columns from where each box's edges fall on the 24, rows from the order of their tops
  function toGrid() {
    var ids = Object.keys(E.b).filter(function (k) { return !E.b[k].fl; }), pitch = (E.cw + GAP) / COLS, g = {};
    var col = function (v) { return Math.max(0, Math.min(COLS, Math.round(v / pitch))); };
    var tops = ids.map(function (k) { return E.b[k].y; }).sort(function (a, b) { return a - b; }), rows = [];
    tops.forEach(function (t) { if (!rows.length || t - rows[rows.length - 1] > 24) rows.push(t); });
    var rowAt = function (y) { var r = 0; rows.forEach(function (t, i) { if (t <= y + 24) r = i; }); return r; };
    // never fewer columns than the part is wide (a button keeps its label)
    var need = function (b) { return Math.max(1, Math.ceil((b.w + GAP) / pitch - 0.2)); };
    ids.forEach(function (k) {
      var b = E.b[k], c0 = Math.min(COLS - 1, col(b.x)), c1 = Math.min(COLS, Math.max(c0 + need(b), col(b.x + b.w + GAP)));
      if (c1 - c0 < need(b)) c0 = Math.max(0, c1 - need(b));
      var r0 = rowAt(b.y), r1 = rows.length;
      for (var i = r0 + 1; i < rows.length; i++) if (rows[i] >= b.y + b.h - 24) { r1 = i; break; }
      g[k] = [c0 + 1, c1 + 1, r0 + 1, Math.max(r0 + 2, r1 + 1)];
    });
    // parts side by side in a row: each after the one on its left with its own width, and a row that's too full
    // pulled back from the right
    var byRow = {};
    ids.forEach(function (k) { (byRow[g[k][2]] = byRow[g[k][2]] || []).push(k); });
    Object.keys(byRow).forEach(function (r) {
      var row = byRow[r].sort(function (a, b) { return E.b[a].x - E.b[b].x; });
      for (var i = 1; i < row.length; i++) {
        var p = g[row[i - 1]], c = g[row[i]], A = E.b[row[i - 1]], B = E.b[row[i]];
        var px = Math.min(A.x + A.w, B.x + B.w) - Math.max(A.x, B.x);
        if (c[0] < p[1] && px < Math.min(A.w, B.w) * 0.5) { var w = c[1] - c[0]; c[0] = p[1]; c[1] = c[0] + w; }
      }
      var lim = COLS + 1;
      for (var j = row.length - 1; j >= 0; j--) {
        var v = g[row[j]];
        if (v[1] > lim) { var w2 = v[1] - v[0]; v[1] = Math.max(2, lim); v[0] = Math.max(1, Math.min(v[1] - 1, lim - w2)); }
        // only a part beside this one (not one it was dropped on) has to end where this one starts
        var L0 = j > 0 && E.b[row[j - 1]], B0 = E.b[row[j]];
        lim = L0 && Math.min(L0.x + L0.w, B0.x + B0.w) - Math.max(L0.x, B0.x) < Math.min(L0.w, B0.w) * 0.5 ? Math.max(2, v[0]) : COLS + 1;
      }
    });
    var over = function (a, b) { return a[0] < b[1] && b[0] < a[1] && a[2] < b[3] && b[2] < a[3]; };
    for (var pass = 0; pass < 60; pass++) {
      var moved = false;
      for (var i = 0; i < ids.length && !moved; i++) for (var j = i + 1; j < ids.length && !moved; j++) {
        var a = ids[i], b = ids[j]; if (!over(g[a], g[b])) continue;
        var A = E.b[a], B = E.b[b], l = A.x <= B.x ? a : b, r = l === a ? b : a, BL = E.b[l], BR = E.b[r];
        var px = Math.min(BL.x + BL.w, BR.x + BR.w) - Math.max(BL.x, BR.x);
        // still overlapping side by side (a row too full for everyone's width): the columns between them shared out
        if (g[a][2] === g[b][2] && px < Math.min(BL.w, BR.w) * 0.5 && g[r][1] - g[l][0] >= 2) {
          var mid = Math.round((BL.x + BL.w + BR.x) / 2 / pitch) + 1;
          mid = Math.max(g[l][0] + 1, Math.min(g[r][1] - 1, mid));
          g[l][1] = Math.min(g[l][1], mid); g[r][0] = Math.max(g[r][0], mid);
          moved = true; continue;
        }
        // one dropped on a side of another in its row takes that side, and the other keeps the rest
        var m = a === E.moved ? a : b === E.moved ? b : null, o = m === a ? b : a;
        if (m && g[m][2] === g[o][2]) {
          var left = g[m][0] - g[o][0], right = g[o][1] - g[m][1];
          if (left >= 2 && left >= right) { g[o][1] = g[m][0]; moved = true; continue; }
          if (right >= 2) { g[o][0] = g[m][1]; moved = true; continue; }
        }
        // otherwise the lower one goes under
        var low = A.y <= B.y ? b : a, high = low === a ? b : a, span = g[low][3] - g[low][2];
        g[low][2] = g[high][3]; g[low][3] = g[low][2] + span; moved = true;
      }
      if (!moved) break;
    }
    // a tall part with nothing under it (the question beside the side panel's parts) runs to the end of the grid, into
    // a last row that stretches: a part that spans a flexible row gives its height to that row alone, so the rows beside
    // it fit the parts in them, as the app's own two columns did
    ids.forEach(function (k) {
      var v = g[k]; if (v[3] - v[2] < 2) return;
      var under = ids.some(function (o) { var w = g[o]; return o !== k && w[0] < v[1] && v[0] < w[1] && w[2] >= v[3]; });
      if (!under) v[3] = -1;
    });
    // a part narrower than its columns keeps its own width, on the side it was put
    ids.forEach(function (k) {
      var b = E.b[k], v = g[k], x0 = (v[0] - 1) * pitch, x1 = (v[1] - 1) * pitch - GAP;
      if (x1 - x0 - b.w > pitch * 0.5) { var l = b.x - x0, r = x1 - (b.x + b.w); v[4] = Math.abs(l - r) < pitch * 0.5 ? "center" : l < r ? "start" : "end"; }
    });
    return g;
  }
  function commit() {
    if (!E) return;
    E.L.grid = toGrid();
    applyCss(); settle();
  }

  // ── moving and sizing ──
  var drag = null, sel0 = null;
  function snap(vals, targets, reach) {
    var best = null;
    vals.forEach(function (v) { targets.forEach(function (t) { var d = t - v; if (Math.abs(d) <= reach && (!best || Math.abs(d) < Math.abs(best.d))) best = { d: d, at: t }; }); });
    return best;
  }
  function targetsFor(k) {
    var me = E.b[k], xs, ys;
    if (me.fl) { xs = [12, innerWidth / 2, innerWidth - 12]; ys = [12, innerHeight / 2, innerHeight - 12]; }
    else { xs = [0, E.cw / 2, E.cw]; ys = [0]; }
    Object.keys(E.b).forEach(function (o) {
      var b = E.b[o]; if (o === k || b.fl !== me.fl) return;
      xs.push(b.x, b.x + b.w / 2, b.x + b.w); ys.push(b.y, b.y + b.h / 2, b.y + b.h);
    });
    return { xs: xs, ys: ys };
  }
  function guides(fl, gx, gy) {
    var layer = fl ? E.fly : E.ovl, v = layer.querySelector(".lc-gv"), h = layer.querySelector(".lc-gh");
    v.hidden = gx == null; if (gx != null) v.style.left = (fl ? gx : gx + E.cx) + "px";
    h.hidden = gy == null; if (gy != null) h.style.top = gy + "px";
  }
  function select(k) {
    sel0 = k;
    Object.keys(E.b).forEach(function (o) { E.b[o].el.classList.toggle("on", o === k); });
  }
  function onDown(e) {
    if (!E || e.button) return;
    var t = e.target, bEl = t.closest && t.closest(".lc-block");
    if (!bEl || !(E.ovl.contains(bEl) || E.fly.contains(bEl))) return;
    var k = bEl.dataset.b, b = E.b[k]; if (!b) return;
    if (t.closest("[data-lce=gear]")) return;
    e.preventDefault();
    select(k); bEl.focus({ preventScroll: true });
    if (E.gear && E.gear.path[0] !== k) closeGear();
    drag = { k: k, el: bEl, o: { x: b.x, y: b.y, w: b.w, h: b.h }, sx: e.clientX, sy: e.clientY, size: !!t.closest("[data-size]"), t: targetsFor(k), moved: false };
    if (bEl.setPointerCapture) try { bEl.setPointerCapture(e.pointerId); } catch (er) {}
  }
  function onMove(e) {
    if (!drag || !E) { if (E && E.list) listMove(e); return; }
    var d = drag, o = d.o, b = E.b[d.k], dx = e.clientX - d.sx, dy = e.clientY - d.sy, reach = 8, gx = null, gy = null;
    if (!d.moved && Math.abs(dx) + Math.abs(dy) < 3) return;
    if (!d.moved) { d.moved = true; d.el.classList.add("moving"); if (E.gear) closeGear(); }
    if (d.size) {
      var maxW = b.fl ? innerWidth - o.x - 8 : E.cw - o.x;
      var w = Math.max(40, Math.min(maxW, o.w + dx)), h = Math.max(24, o.h + dy);
      if (align) { var sx = snap([o.x + w], d.t.xs, reach); if (sx) { w += sx.d; gx = sx.at; } var sy = snap([o.y + h], d.t.ys, reach); if (sy) { h += sy.d; gy = sy.at; } }
      b.w = w; b.h = h;
    } else {
      // a grid box may hang over an edge while it moves; dropped there, it's cut to fit (a full-width part dragged right is the right half)
      var x = b.fl ? Math.max(0, Math.min(innerWidth - o.w, o.x + dx)) : Math.max(-o.w * 0.75, Math.min(E.cw - o.w * 0.25, o.x + dx));
      var y = b.fl ? Math.max(0, Math.min(innerHeight - o.h, o.y + dy)) : Math.max(0, o.y + dy);
      if (align) { var ax = snap([x, x + o.w / 2, x + o.w], d.t.xs, reach); if (ax) { x += ax.d; gx = ax.at; } var ay = snap([y, y + o.h / 2, y + o.h], d.t.ys, reach); if (ay) { y += ay.d; gy = ay.at; } }
      b.x = x; b.y = y;
    }
    paintBox(d.k); guides(b.fl, gx, gy);
  }
  function onUp() {
    if (E && E.list) { listUp(); return; }
    if (!drag) return;
    var d = drag, b = E.b[d.k]; drag = null;
    d.el.classList.remove("moving"); guides(b.fl, null, null);
    if (!d.moved) return;
    if (b.fl) { setFloat(d.k, b); return; }
    var minW = E.cw / COLS;
    if (b.x < 0) { b.w = Math.max(minW, b.w + b.x); b.x = 0; }
    if (b.x + b.w > E.cw) b.w = Math.max(minW, E.cw - b.x);
    if (b.x + b.w > E.cw) b.x = E.cw - b.w;
    paintBox(d.k);
    if (d.size && Math.abs(b.h - d.o.h) > 4) { E.L.h = E.L.h || {}; E.L.h[d.k] = Math.round(b.h); }
    E.moved = d.k;
    commit();
  }
  // a floating part's place: kept from the corner, edge or middle of the window it's nearest, so it stays there as the window changes
  function setFloat(k, b) {
    var W = innerWidth, H = innerHeight, cxm = b.x + b.w / 2, cym = b.y + b.h / 2, z = (E.L.size && E.L.size[k]) || 1;
    var ax = cxm < W / 3 ? "l" : cxm > W * 2 / 3 ? "r" : "c", ay = cym < H / 3 ? "t" : cym > H * 2 / 3 ? "b" : "c";
    E.L.float = E.L.float || {};
    E.L.float[k] = { ax: ax, x: ax === "l" ? b.x : ax === "r" ? W - b.x - b.w : cxm - W / 2, ay: ay, y: ay === "t" ? b.y : ay === "b" ? H - b.y - b.h : cym - H / 2, w: b.w / z };
    applyCss(); settle();
  }
  var nudgeT = 0;
  function onKey(e) {
    if (!E) return;
    if (e.key === "Escape") {
      e.preventDefault(); e.stopPropagation();
      if (hiddenEl) closeHidden(); else if (E.gear) closeGear(); else cancelEdit();
      return;
    }
    var a = document.activeElement;
    if (E.gear && a && a.closest && a.closest(".lc-g-row") && e.altKey && (e.key === "ArrowUp" || e.key === "ArrowDown")) { e.preventDefault(); e.stopPropagation(); moveRow(a.closest(".lc-g-row"), e.key === "ArrowUp" ? -1 : 1); return; }
    var quiet = function () { if (!e.ctrlKey && !e.metaKey && !e.altKey && !e.shiftKey && e.key !== "Tab" && !inField(e)) e.stopPropagation(); };
    if (!sel0 || !a || !a.closest || !a.closest(".lc-block")) { quiet(); return; }
    if (e.key === "Enter" || e.key === " ") { e.preventDefault(); e.stopPropagation(); openGear(sel0); return; }
    var step = e.shiftKey ? 40 : 8, mv = { ArrowLeft: [-step, 0], ArrowRight: [step, 0], ArrowUp: [0, -step], ArrowDown: [0, step] }[e.key];
    if (!mv) { quiet(); return; }
    e.preventDefault(); e.stopPropagation();
    var b = E.b[sel0]; if (!b) return;
    b.x = b.fl ? Math.max(0, Math.min(innerWidth - b.w, b.x + mv[0])) : Math.max(0, Math.min(E.cw - b.w, b.x + mv[0]));
    b.y = Math.max(0, b.y + mv[1]); paintBox(sel0);
    var k = sel0; clearTimeout(nudgeT);
    nudgeT = setTimeout(function () { if (!E || !E.b[k]) return; if (E.b[k].fl) setFloat(k, E.b[k]); else { E.moved = k; commit(); } }, 350);
  }

  // ── the bar while editing: the page, Auto align, what's hidden, Reset, Cancel, Done ──
  function renderBar() {
    if (!E) return;
    var n = (E.L.hide || []).length;
    E.bar.innerHTML = '<b class="lc-eb-title">' + esc(E.P.n) + '</b><span class="qb-info" data-tip="Drag a box to move it, or its corner to size it. Its gear sets what it shows. Arrow keys nudge the box you picked. Esc cancels.">i</span>' +
      '<label class="lc-eb-align"><span class="ext-switch"><input type="checkbox" data-lce="align"' + (align ? " checked" : "") + '><span class="ext-slider"></span></span>Auto align</label><span class="lc-eb-sp"></span>' +
      (n ? '<button type="button" class="btn btn-sm" data-lce="hidden" aria-haspopup="menu">' + ic("eye", 14) + "Hidden " + n + "</button>" : "") +
      '<button type="button" class="btn btn-sm btn-ghost" data-lce="reset">' + ic("refresh", 13) + 'Reset</button><button type="button" class="btn btn-sm" data-lce="cancel">Cancel</button><button type="button" class="btn btn-sm btn-primary" data-lce="done">Done</button>';
  }
  var hiddenEl = null;
  function openHidden(btn) {
    closeHidden();
    var list = E.L.hide || []; if (!list.length) return;
    hiddenEl = el("div", "lc-hidden");
    hiddenEl.setAttribute("role", "menu");
    hiddenEl.innerHTML = '<div class="lc-g-label">Hidden</div>' + list.map(function (k) {
      var node = resolve(k, E.box);
      return '<div class="lc-h-row"><span>' + esc(node ? nameOf(E.P, node) : humanize(k.split(">").pop().replace(/\(.*$/, ""))) + '</span><button type="button" class="btn btn-sm" data-lce="unhide" data-k="' + esc(k) + '">Show</button></div>';
    }).join("");
    document.body.appendChild(hiddenEl);
    var r = btn.getBoundingClientRect();
    hiddenEl.style.left = Math.max(12, Math.min(innerWidth - 260, r.left)) + "px";
    hiddenEl.style.bottom = (innerHeight - r.top + 8) + "px";
  }
  function closeHidden() { if (hiddenEl) { hiddenEl.remove(); hiddenEl = null; } }

  // ── each part's gear: what it shows (and in what order), its size, where it sits, floating, splitting, hiding ──
  function partKey(k) { return E.gear ? E.gear.path[0] : k; }
  function openGear(k) {
    if (!E || !E.b[k]) return;
    closeHidden();
    if (E.gear && E.gear.path[0] === k) { closeGear(); return; }
    closeGear();
    E.gear = { path: [k], el: el("div", "lc-gear") };
    E.gear.el.setAttribute("role", "dialog"); E.gear.el.setAttribute("aria-label", "Settings");
    document.body.appendChild(E.gear.el);
    select(k); renderGear(); placeGear();
  }
  function closeGear() { if (E && E.gear) { E.gear.el.remove(); E.gear = null; E.list = null; } }
  function placeGear() {
    var G = E.gear, b = E.b[G.path[0]]; if (!b) { closeGear(); return; }
    var r = b.el.getBoundingClientRect(), w = 316, h = G.el.offsetHeight || 300;
    var x = r.right + 12 + w <= innerWidth - 8 ? r.right + 12 : r.left - 12 - w >= 8 ? r.left - 12 - w : Math.min(innerWidth - w - 8, Math.max(8, r.left));
    var y = Math.max(64, Math.min(innerHeight - h - 12, r.top));
    G.el.style.left = Math.round(x) + "px"; G.el.style.top = Math.round(y) + "px";
  }
  function canSplit(node) { return !isSolid(E.P, node) && pieces(node).filter(shown).length >= 2; }
  function parentWrapper(node) {
    var p = node.parentElement;
    return p && p !== E.box && E.box.contains(p) && p.hasAttribute("data-lc-flat") ? p : null;
  }
  function seg(name, opts, cur) {
    return '<div class="lc-g-seg" role="group" aria-label="' + esc(name) + '">' + opts.map(function (o) {
      return '<button type="button" data-g="' + o[0] + '" data-v="' + o[1] + '" aria-pressed="' + (String(o[1]) === String(cur)) + '">' + esc(o[2]) + "</button>";
    }).join("") + "</div>";
  }
  function sw(g, on, text, tip) {
    return '<label class="lc-g-sw"><span class="ext-switch"><input type="checkbox" data-g="' + g + '"' + (on ? " checked" : "") + '><span class="ext-slider"></span></span><span>' + esc(text) + "</span>" +
      (tip ? '<span class="qb-info" data-tip="' + esc(tip) + '">i</span>' : "") + "</label>";
  }
  function renderGear() {
    var G = E.gear; if (!G) return;
    var k = G.path[G.path.length - 1], node = resolve(k, E.box), part = G.path.length === 1, L = E.L;
    if (!node) { closeGear(); return; }
    var pcs = pieces(node), list = pcs.length >= 2 && pcs.length <= 16;
    var canOrder = !/^(inline|contents|none|table.*)$/.test(getComputedStyle(node).display);
    var h = '<div class="lc-g-head">' + (part ? "" : '<button type="button" class="btn btn-ghost btn-icon lc-g-back" data-g="back" aria-label="Back">' + ic("left", 16) + "</button>") +
      '<b class="lc-g-title">' + esc(nameOf(E.P, node)) + '</b><button type="button" class="btn btn-ghost btn-icon lc-g-x" data-g="close" aria-label="Close">' + ic("x", 16) + "</button></div>";
    if (!part) h += '<div class="lc-g-crumb">' + G.path.slice(0, -1).map(function (p) { var n = resolve(p, E.box); return esc(n ? nameOf(E.P, n) : ""); }).join(" › ") + "</div>";
    if (list) {
      var ord = (L.order && L.order[k] && L.order[k].ids) || [];
      var rows = pcs.map(function (c) { return { c: c, k: keyOf(c, E.box) }; });
      rows.sort(function (a, b) { var i = ord.indexOf(a.k), j = ord.indexOf(b.k); return (i < 0 ? 999 : i) - (j < 0 ? 999 : j); });
      h += '<div class="lc-g-sec"><div class="lc-g-label">What it shows</div><div class="lc-g-list" data-list="' + esc(k) + '">' + rows.map(function (r) {
        var hid = has(L.hide, r.k), fl = !!(L.float && L.float[r.k]), now = !hid && !shown(r.c), sub = pieces(r.c).length >= 2;
        return '<div class="lc-g-row' + (hid ? " off" : "") + '" data-k="' + esc(r.k) + '" tabindex="0">' +
          (canOrder ? '<span class="lc-g-grip" data-g="grip" title="Drag to change the order" aria-hidden="true"><i></i><i></i><i></i></span>' : '<span class="lc-g-grip lc-g-nogrip" aria-hidden="true"></span>') +
          '<span class="lc-g-name">' + esc(nameOf(E.P, r.c)) + (now ? "<small>Not on screen now</small>" : fl ? "<small>Floating</small>" : "") + "</span>" +
          (sub ? '<button type="button" class="lc-g-ic" data-g="in" title="Its pieces" aria-label="Its pieces">' + ic("right", 15) + "</button>" : "") +
          '<button type="button" class="lc-g-ic lc-g-fl" data-g="pull" aria-pressed="' + fl + '" title="' + (fl ? "Put it back" : "Pull it out and place it anywhere") + '" aria-label="Float it">' + PULL + "</button>" +
          '<label class="ext-switch" title="' + (hid ? "Show it" : "Hide it") + '"><input type="checkbox" data-g="show"' + (hid ? "" : " checked") + ' aria-label="Show ' + esc(nameOf(E.P, r.c)) + '"><span class="ext-slider"></span></label></div>';
      }).join("") + "</div></div>";
    } else if (pcs.length > 16) {
      h += '<div class="lc-g-sec lc-g-note">It holds a list of ' + pcs.length + " entries.</div>";
    }
    var z = (L.size && L.size[k]) || 1;
    h += '<div class="lc-g-sec"><div class="lc-g-line"><span class="lc-g-label">Size</span>' + seg("Size", SIZES.map(function (s) { return ["size", s[0], s[1]]; }), z) + "</div>";
    if (part && !(L.float && L.float[k])) {
      var j = (L.align && L.align[k]) || (L.grid && L.grid[k] && L.grid[k][4]) || "stretch";
      h += '<div class="lc-g-line"><span class="lc-g-label">Width</span>' + seg("Width", [["align", "stretch", "Fill"], ["align", "start", "Left"], ["align", "center", "Middle"], ["align", "end", "Right"]], j) + "</div>";
    }
    h += sw("float", !!(L.float && L.float[k]), "Float anywhere", "Takes it out of the page so you can put it anywhere on the window. It stays put while the page scrolls.");
    if (part && !(L.float && L.float[k])) h += sw("sticky", !!(L.sticky && L.sticky[k]), "Stay in view", "Keeps it on screen while the page scrolls.");
    h += "</div>";
    var pw = part && parentWrapper(node);
    var sp = part && canSplit(node);
    if (sp || pw) h += '<div class="lc-g-foot">' +
      (sp ? '<button type="button" class="btn btn-sm" data-g="split" title="Each of its pieces gets a box of its own, without the card around them">' + ic("grid", 13) + "Split into pieces</button>" : "") +
      (pw ? '<button type="button" class="btn btn-sm" data-g="join" title="Back in one box with the parts around it">Join its group</button>' : "") + "</div>";
    h += '<div class="lc-g-foot"><button type="button" class="btn btn-sm btn-ghost" data-g="reset">' + ic("refresh", 13) + 'Reset</button><span class="lc-eb-sp"></span><button type="button" class="btn btn-sm" data-g="hide">' + ic("eye", 13) + "Hide</button></div>";
    G.el.innerHTML = h;
  }
  var PULL = '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="9" width="12" height="12" rx="2"/><path d="M13 3h8v8M21 3l-9 9"/></svg>';
  // after a change in the gear: the page, the boxes and the gear all show it
  function changed() { applyCss(); renderBar(); renderGear(); settle(); }
  function ensureGrid() { if (!hasGrid(E.L)) { measure(); E.L.grid = toGrid(); applyCss(); } }
  function onGear(e) {
    if (!E || !E.gear || !E.gear.el.contains(e.target)) return false;
    var t = e.target.closest("[data-g]"); if (!t || t.tagName === "INPUT" || t.dataset.g === "grip") return true;
    var G = E.gear, k = G.path[G.path.length - 1], L = E.L, row = t.closest(".lc-g-row"), rk = row && row.dataset.k, a = t.dataset.g;
    if (a === "close") { closeGear(); return true; }
    if (a === "back") { G.path.pop(); renderGear(); return true; }
    if (a === "in" && rk) { G.path.push(rk); renderGear(); return true; }
    if (a === "pull" && rk) { toggleFloat(rk); changed(); return true; }
    if (a === "size") { var v = parseFloat(t.dataset.v); L.size = L.size || {}; if (v === 1) delete L.size[k]; else L.size[k] = v; changed(); return true; }
    if (a === "align") { ensureGrid(); L.align = L.align || {}; L.align[k] = t.dataset.v; changed(); return true; }
    if (a === "split") { split(k); return true; }
    if (a === "join") { var pw = parentWrapper(resolve(k, E.box)); if (pw) join(keyOf(pw, E.box)); return true; }
    if (a === "hide") { L.hide = (L.hide || []).concat([k]); if (G.path.length > 1) { G.path.pop(); changed(); } else { closeGear(); changed(); } return true; }
    if (a === "reset") { resetNode(k); changed(); return true; }
    return true;
  }
  function onGearChange(e) {
    if (!E || !E.gear || !E.gear.el.contains(e.target)) return;
    var t = e.target, a = t.dataset.g, G = E.gear, k = G.path[G.path.length - 1], L = E.L, row = t.closest(".lc-g-row");
    if (a === "show" && row) {
      var rk = row.dataset.k; L.hide = (L.hide || []).filter(function (x) { return x !== rk; });
      if (!t.checked) L.hide.push(rk);
      changed();
    } else if (a === "float") { toggleFloat(k); changed(); }
    else if (a === "sticky") { L.sticky = L.sticky || {}; if (t.checked) L.sticky[k] = 1; else delete L.sticky[k]; changed(); }
  }
  function toggleFloat(k) {
    var L = E.L; L.float = L.float || {};
    if (L.float[k]) { delete L.float[k]; return; }
    var node = resolve(k, E.box); if (!node) return;
    var r = node.getBoundingClientRect(), z = (L.size && L.size[k]) || 1;
    if (r.width < 2) return;
    // it starts where it is now, so nothing jumps; then it's dragged where it goes
    setFloatRect(k, { x: r.left, y: r.top, w: r.width, h: r.height }, z);
  }
  function setFloatRect(k, b, z) {
    var W = innerWidth, H = innerHeight, cxm = b.x + b.w / 2, cym = b.y + b.h / 2;
    var ax = cxm < W / 3 ? "l" : cxm > W * 2 / 3 ? "r" : "c", ay = cym < H / 3 ? "t" : cym > H * 2 / 3 ? "b" : "c";
    E.L.float[k] = { ax: ax, x: ax === "l" ? b.x : ax === "r" ? W - b.x - b.w : cxm - W / 2, ay: ay, y: ay === "t" ? b.y : ay === "b" ? H - b.y - b.h : cym - H / 2, w: b.w / z };
  }
  // its pieces become parts of their own, each where it is now
  function split(k) {
    var L = E.L, node = resolve(k, E.box); if (!node) return;
    measure();
    var b = E.b[k], before = {};
    pieces(node).filter(shown).forEach(function (c) { var r = c.getBoundingClientRect(), xy = hostXY(r); before[keyOf(c, E.box)] = { x: xy.x - E.cx, y: xy.y, w: r.width, h: r.height }; });
    L.join = (L.join || []).filter(function (x) { return x !== k; });
    if (!flatHere(E.P, L, node, k, 9)) L.split = (L.split || []).concat([k]);
    if (b) { b.el.remove(); delete E.b[k]; }
    Object.keys(before).forEach(function (pk) { var r = before[pk], nb = E.b[pk] = mkBox(pk, null, false); nb.x = r.x; nb.y = r.y; nb.w = r.w; nb.h = r.h; });
    if (L.grid) delete L.grid[k];
    E.L.grid = toGrid(); closeGear(); applyCss(); renderBar(); settle();
  }
  // a split group back in one box, where its pieces were
  function join(wk) {
    var L = E.L, w = resolve(wk, E.box); if (!w) return;
    var x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
    Object.keys(E.b).forEach(function (k) {
      var b = E.b[k]; if (b.fl || !b.node || !w.contains(b.node)) return;
      x0 = Math.min(x0, b.x); y0 = Math.min(y0, b.y); x1 = Math.max(x1, b.x + b.w); y1 = Math.max(y1, b.y + b.h);
      b.el.remove(); delete E.b[k]; if (L.grid) delete L.grid[k];
    });
    L.split = (L.split || []).filter(function (x) { return x !== wk; });
    if (flatHere(E.P, L, w, wk, 0)) L.join = (L.join || []).concat([wk]);
    if (x1 > x0) { var nb = E.b[wk] = mkBox(wk, w, false); nb.x = x0; nb.y = y0; nb.w = x1 - x0; nb.h = y1 - y0; }
    E.L.grid = toGrid(); closeGear(); applyCss(); renderBar(); settle();
  }
  function resetNode(k) {
    var L = E.L, node = resolve(k, E.box);
    var inside = function (x) { if (x === k) return true; var n = resolve(x, E.box); return !!(n && node && node.contains(n)); };
    ["size", "align", "sticky", "float", "h", "order"].forEach(function (f) { Object.keys(L[f] || {}).forEach(function (x) { if (inside(x)) delete L[f][x]; }); });
    L.hide = (L.hide || []).filter(function (x) { return x === k || !inside(x); });
  }
  // the pieces' order: dragged by their grip, or Alt and an arrow key
  function listDown(e) {
    var g = e.target.closest && e.target.closest("[data-g=grip]"); if (!g || !E || !E.gear) return false;
    var row = g.closest(".lc-g-row"), list = row.parentElement;
    e.preventDefault();
    E.list = { row: row, list: list, y0: e.clientY, rows: [].slice.call(list.children) };
    row.classList.add("dragging");
    return true;
  }
  function listMove(e) {
    var D = E.list; if (!D) return;
    var dy = e.clientY - D.y0; D.row.style.transform = "translateY(" + dy + "px)";
    var at = D.rows.indexOf(D.row), target = at;
    D.rows.forEach(function (r, i) { if (r === D.row) return; var rr = r.getBoundingClientRect(), mid = rr.top + rr.height / 2; if (i > at && e.clientY > mid) target = i; if (i < at && e.clientY < mid && target === at) target = i; });
    D.target = target;
    D.rows.forEach(function (r, i) { if (r === D.row) return; var shift = 0, hgt = D.row.offsetHeight + 4; if (at < target && i > at && i <= target) shift = -hgt; if (at > target && i < at && i >= target) shift = hgt; r.style.transform = shift ? "translateY(" + shift + "px)" : ""; });
  }
  function listUp() {
    var D = E.list; E.list = null;
    D.rows.forEach(function (r) { r.style.transform = ""; }); D.row.classList.remove("dragging");
    if (D.target == null || D.target === D.rows.indexOf(D.row)) return;
    var ids = D.rows.map(function (r) { return r.dataset.k; }), from = ids.indexOf(D.row.dataset.k);
    ids.splice(D.target, 0, ids.splice(from, 1)[0]);
    setOrder(D.list.dataset.list, ids);
  }
  function moveRow(row, dir) {
    var list = row.parentElement, ids = [].slice.call(list.children).map(function (r) { return r.dataset.k; }), i = ids.indexOf(row.dataset.k), j = i + dir;
    if (j < 0 || j >= ids.length) return;
    ids.splice(j, 0, ids.splice(i, 1)[0]);
    setOrder(list.dataset.list, ids);
    var again = E.gear && E.gear.el.querySelector('.lc-g-row[data-k="' + CSS.escape(row.dataset.k) + '"]'); if (again) again.focus();
  }
  function setOrder(pk, ids) {
    var node = resolve(pk, E.box); if (!node) return;
    var d = getComputedStyle(node).display, prev = E.L.order && E.L.order[pk];
    // a block isn't ordered by CSS: it becomes a column of its pieces, or a wrapping row when they sit in a line
    var col = prev ? prev.col : /flex|grid/.test(d) ? 0 : pieces(node).every(function (c) { return /^inline/.test(getComputedStyle(c).display); }) ? "row" : "col";
    E.L.order = E.L.order || {};
    E.L.order[pk] = { ids: ids, col: col };
    changed();
  }

  // ── the clicks while editing ──
  function onClick(e) {
    var t = e.target;
    if (E && E.gear && E.gear.el.contains(t)) { onGear(e); return; }
    var pg = t.closest && t.closest("[data-page]");
    if (pg && body && body.contains(pg)) { startEdit(LIST[+pg.dataset.page]); return; }
    if (!E) return;
    if (hiddenEl && hiddenEl.contains(t)) {
      var u = t.closest("[data-lce=unhide]");
      if (u) { E.L.hide = (E.L.hide || []).filter(function (x) { return x !== u.dataset.k; }); closeHidden(); changed(); }
      return;
    }
    var gb = t.closest("[data-lce=gear]");
    if (gb) { e.preventDefault(); openGear(gb.closest(".lc-block").dataset.b); return; }
    var c = t.closest("[data-lce]");
    if (c && E.bar.contains(c)) {
      var a = c.dataset.lce;
      if (a === "done") doneEdit(); else if (a === "cancel") cancelEdit(); else if (a === "reset") resetPage();
      else if (a === "hidden") { if (hiddenEl) closeHidden(); else openHidden(c); }
      return;
    }
    if (hiddenEl) closeHidden();
    if (E.gear && !t.closest(".lc-block")) closeGear();
  }
  function onDblClick(e) { if (!E) return; var b = e.target.closest && e.target.closest(".lc-block"); if (b && (E.ovl.contains(b) || E.fly.contains(b))) openGear(b.dataset.b); }
  function onChange(e) {
    if (E && E.gear && E.gear.el.contains(e.target)) { onGearChange(e); return; }
    if (e.target && e.target.dataset && e.target.dataset.lce === "align") { align = e.target.checked; ctx.storage.set("align", align); }
  }
  function onPointerDown(e) { if (E && E.gear && E.gear.el.contains(e.target)) { listDown(e); return; } onDown(e); }
  var onResize = function () { if (E) { measure(); if (E.gear) placeGear(); } };
  document.addEventListener("pointerdown", onPointerDown);
  document.addEventListener("pointermove", onMove);
  document.addEventListener("pointerup", onUp);
  document.addEventListener("pointercancel", onUp);
  document.addEventListener("keydown", onKey, true);
  document.addEventListener("click", onClick);
  document.addEventListener("dblclick", onDblClick);
  document.addEventListener("change", onChange);
  window.addEventListener("resize", onResize);
  ctx.on("screen:change", function () { if (E && activeId() !== E.P.id) cancelEdit(); setTimeout(function () { busy = true; try { tagActive(); } finally { busy = false; } }, 0); });
  ctx.onHotkey("edit", function () { if (E) doneEdit(); else startEdit(); });
  ctx._cleanup = function () {
    cancelEdit(); mo.disconnect(); if (styleEl) styleEl.remove(); untag();
    document.removeEventListener("pointerdown", onPointerDown); document.removeEventListener("pointermove", onMove); document.removeEventListener("pointerup", onUp);
    document.removeEventListener("pointercancel", onUp); document.removeEventListener("keydown", onKey, true); document.removeEventListener("click", onClick);
    document.removeEventListener("dblclick", onDblClick); document.removeEventListener("change", onChange); window.removeEventListener("resize", onResize);
  };
  applyCss();

  // ── the plugin's page: every page you can arrange, with a small picture of its layout ──
  var body = null;
  function thumbHtml(id) {
    var L = saved[id], g = L && L.grid;
    if (!g || !Object.keys(g).length) return '<span class="lc-tb" style="left:6%;top:8%;width:88%;height:12%"></span><span class="lc-tb" style="left:6%;top:26%;width:58%;height:64%"></span><span class="lc-tb lc-tb2" style="left:68%;top:26%;width:26%;height:40%"></span>';
    var rows = 0; Object.keys(g).forEach(function (k) { rows = Math.max(rows, g[k][3] - 1); });
    var rh = 84 / Math.max(1, rows);
    return Object.keys(g).map(function (k, i) { var v = g[k]; return '<span class="lc-tb' + (i % 3 === 1 ? " lc-tb2" : "") + '" style="left:' + (4 + (v[0] - 1) * 92 / COLS) + "%;top:" + (8 + (v[2] - 1) * rh) + "%;width:" + Math.max(2, (v[1] - v[0]) * 92 / COLS - 1) + "%;height:" + Math.max(2, (v[3] - v[2]) * rh - 2) + '%"></span>'; }).join("");
  }
  function render() {
    if (!body) return;
    var narrow = innerWidth < MIN_W, key = esc(ctx.keyLabel ? ctx.keyLabel("edit") : "Shift L");
    body.innerHTML = '<div class="pk-wrap lc">' +
      '<div class="pk-hero lc-hero"><span class="pk-hero-ico">' + ic("grid", 26) + "</span><h2>Lay out any page your way</h2>" +
        "<p>Every part of a page gets a box. Drag it anywhere, size it, and open its gear to pick what it shows and in what order.</p>" +
        '<p class="lc-key">On any page, press <kbd>' + key + "</kbd> to edit it. Or pick one here.</p>" +
        (narrow ? '<div class="pk-muted pk-small">Make the window wider to edit a page. Layouts apply on wide screens, phones keep their own.</div>' : "") + "</div>" +
      '<div class="lc-pages">' + LIST.map(function (x, i) {
        var ch = !!saved[x[0]];
        return '<button type="button" class="lc-page" data-page="' + i + '"' + (narrow ? " disabled" : "") + '><span class="lc-thumb" aria-hidden="true">' + thumbHtml(x[0]) + "</span>" +
          '<span class="lc-pn"><b>' + esc(x[1]) + "</b>" + (ch ? '<small class="pk-chip pk-on">Changed</small>' : "") + "</span></button>";
      }).join("") + "</div></div>";
  }
  ctx.registerPage({
    id: "layout", navLabel: "Layout", title: "Layout Customizer",
    onShow: function (elx) { body = elx; render(); },
  });

}
