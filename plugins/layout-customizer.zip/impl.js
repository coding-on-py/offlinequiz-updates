function __qbMain(ctx) {
  // ── the kit the 15.62 plugins share (text, icons, questions, judging, history) ──
  function esc(s) { return (s == null ? "" : String(s)).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
  var IC = {
    play: '<path d="M7 4l13 8-13 8z"/>',
    pause: '<path d="M8 5v14M16 5v14"/>',
    left: '<path d="M15 6l-6 6 6 6"/>',
    right: '<path d="M9 6l6 6-6 6"/>',
    next: '<path d="M6 5l9 7-9 7zM18 5v14"/>',
    refresh: '<path d="M20 11a8 8 0 10-2.3 5.7M20 4v7h-7"/>',
    x: '<path d="M6 6l12 12M18 6L6 18"/>',
    check: '<path d="M5 12l5 5 9-10"/>',
    mic: '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
    volume: '<path d="M4 9v6h4l5 4V5L8 9z"/><path d="M16 9a4 4 0 0 1 0 6M19 6a8 8 0 0 1 0 12"/>',
    copy: '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h3"/>',
    edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="M13.5 6.5l4 4"/>',
    bolt: '<path d="M13 3L5 14h6l-1 7 8-11h-6z"/>',
    flag: '<path d="M5 21V4M5 4h11l-2 4 2 4H5"/>',
    users: '<circle cx="9" cy="8" r="3"/><path d="M3 20a6 6 0 0 1 12 0M16 4a3 3 0 0 1 0 6M21 20a6 6 0 0 0-4-5.6"/>',
    target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
    down: '<path d="M6 9l6 6 6-6"/>',
    up: '<path d="M6 15l6-6 6 6"/>',
    quote: '<path d="M7 7h4v4c0 3-1.5 5-4 6M15 7h4v4c0 3-1.5 5-4 6"/>',
    grid: '<rect x="3" y="3" width="8" height="10" rx="2"/><rect x="13" y="3" width="8" height="6" rx="2"/><rect x="13" y="11" width="8" height="10" rx="2"/><rect x="3" y="15" width="8" height="6" rx="2"/>',
    ear: '<path d="M7 9a5 5 0 0 1 10 0c0 3-3 4-3 7a3 3 0 0 1-6 0"/><path d="M10 9a2 2 0 0 1 4 0"/>',
  };
  function ic(name, size) {
    var s = size || 16;
    return '<svg width="' + s + '" height="' + s + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (IC[name] || "") + "</svg>";
  }
  function loading(label) { return '<div class="pk-loading">' + (ctx.loadingBarHtml ? ctx.loadingBarHtml(label) : esc(label)) + "</div>"; }
  function norm(s) { return String(s || "").toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[^a-z0-9]+/g, " ").trim(); }
  function pct(a, n) { return n ? Math.round(100 * a / n) : 0; }
  function fmt(n) { return Number(n || 0).toLocaleString(); }
  function plural(n, one, many) { return fmt(n) + " " + (n === 1 ? one : (many || one + "s")); }
  function shuffle(a) { for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)), t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
  function inField(e) { var t = e && e.target; return !!t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT" || t.isContentEditable); }
  function dayKey(t) { var d = new Date(t || Date.now()); return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0"); }
  var DAY = 86400000;

  // the practice setup (Setup panel): its filters and reading settings
  function cfg() { try { return (ctx.host && ctx.host.getPracticeConfig && ctx.host.getPracticeConfig()) || {}; } catch (e) { return {}; } }
  // filters → query parameters, the ones the app sends for a random question
  function filtersQuery(f, extra) {
    f = f || {}; var p = [];
    var add = function (k, v) { p.push(k + "=" + encodeURIComponent(v)); };
    if (f.categories && f.categories.length) add("categories", f.categories.join(","));
    if (f.categoryIds && f.categoryIds.length) add("categoryIds", f.categoryIds.join(","));
    if (f.difficulties && f.difficulties.length) add("difficulties", f.difficulties.join(","));
    if (f.setNames && f.setNames.length) add("setNames", f.setNames.join(","));
    if (f.packetNumbers && f.packetNumbers.length) add("packetNumbers", f.packetNumbers.join(","));
    if (f.yearMin != null) add("yearMin", f.yearMin);
    if (f.yearMax != null) add("yearMax", f.yearMax);
    if (f.powermarkOnly) add("powermarkOnly", "true");
    if (f.canon && f.canon.length) add("canon", f.canon.join(","));
    add("cleanOnly", "1");
    Object.keys(extra || {}).forEach(function (k) { if (extra[k] != null && extra[k] !== false) add(k, extra[k]); });
    return p.join("&");
  }
  // the practice filters without a set (a drill draws from everything the player picked)
  function practiceFilters() { var f = Object.assign({}, cfg().filters || {}); delete f.setNames; delete f.packetNumbers; delete f.setIds; return f; }
  async function getTossups(n, f, extra) {
    try { var d = await ctx.api.get("/api/tossups/query?" + filtersQuery(f || practiceFilters(), Object.assign({ random: 1, limit: n }, extra || {}))); return (d && d.rows) || []; } catch (e) { return []; }
  }
  async function getBonuses(n, f, extra) {
    try { var d = await ctx.api.get("/api/bonuses/query?" + filtersQuery(f || practiceFilters(), Object.assign({ random: 1, limit: n }, extra || {}))); return (d && d.rows) || []; } catch (e) { return []; }
  }
  async function getTossup(id) { try { return (await ctx.api.get("/api/tossups/" + encodeURIComponent(id))).tossup || null; } catch (e) { return null; } }
  async function getBonus(id) { try { return (await ctx.api.get("/api/bonuses/" + encodeURIComponent(id))).bonus || null; } catch (e) { return null; } }
  async function searchTossups(query, limit, f) {
    try { var d = await ctx.api.get("/api/tossups/search?query=" + encodeURIComponent(query) + "&limit=" + (limit || 20) + (f ? "&" + filtersQuery(f) : "")); return { rows: (d && d.rows) || [], total: (d && d.total) || 0 }; } catch (e) { return { rows: [], total: 0 }; }
  }
  // tossups whose answer line names an answer
  async function tossupsOn(answer, limit) { return (await searchTossups('answer_sanitized : ("' + String(answer).replace(/"/g, "") + '")', limit || 20)).rows; }

  // a record's text as practice reads it (notes and pronunciation guides per the player's settings)
  function readText(q) {
    try { if (ctx.host && ctx.host.questionText) { var t = ctx.host.questionText(q, "question"); if (t != null) return String(t).replace(/\(\*\)/g, "").replace(/\s{2,}/g, " ").trim(); } } catch (e) {}
    return String((q && q.question_sanitized) || "").replace(/\(\*\)/g, "").trim();
  }
  function powerAt(q) { return String((q && q.question_sanitized) || "").indexOf("(*)"); }
  // sentences, without breaking at "St." or an initial ("J. R. R. Tolkien")
  var ABBR = /(?:\b(?:St|Ste|Mt|Mts|Dr|Mr|Mrs|Ms|Mme|Prof|Sr|Jr|Rev|Fr|Gen|Col|Capt|Lt|Sgt|Maj|Adm|Hon|Pres|Gov|Sen|Rep|vs|etc|cf|ca|al|Inc|Co|Corp|Ltd|Bros|approx|No|Nos|Op|op|no|Vol|vol|Ch|ch|Fig|fig|Ft|Pt|pt|Ave|[A-Za-z])\.["”’']?)$/;
  function sentences(text) {
    var parts = String(text || "").split(/(?<=[.?!]["”’)]*)\s+(?=["“(]?[A-Z0-9])/), out = [], cur = "";
    for (var i = 0; i < parts.length; i++) {
      cur = cur ? cur + " " + parts[i] : parts[i];
      if (i < parts.length - 1 && ABBR.test(cur.trim())) continue;
      out.push(cur.trim()); cur = "";
    }
    if (cur.trim()) out.push(cur.trim());
    return out.filter(Boolean);
  }
  // where each sentence of a text ends (indexes into it)
  function sentenceEnds(text) {
    var at = 0, out = []; text = String(text || "");
    sentences(text).forEach(function (x) { var i = text.indexOf(x, at); if (i < 0) return; at = i + x.length; out.push(at); });
    return out;
  }
  // ── categories (15.63): the app's own picker, its picks kept under `key` ([] = every category) ──
  // mountCats(root, key, onChange) puts it in root's [data-cats] (made once, moved into each new render);
  // inCats(pk, e): a history entry or question in the picks; with no picks, all are
  var PICKERS = {};
  function catPicker(key, onChange) {
    if (PICKERS[key]) return PICKERS[key];
    if (!ctx.host || !ctx.host.categoryPicker) return null;
    var pk = ctx.host.categoryPicker(null, { selected: ctx.storage.get(key) || [], onChange: function (ids) { ctx.storage.set(key, ids); if (onChange) onChange(ids); } });
    PICKERS[key] = pk;
    // the picks match nothing until the tree is in: draw again once it is
    if (pk.ready && (ctx.storage.get(key) || []).length) pk.ready.then(function () { if (onChange) onChange(pk.get()); });
    return pk;
  }
  function mountCats(root, key, onChange) {
    var pk = catPicker(key, onChange), host = root && root.querySelector("[data-cats]");
    if (pk && host) host.appendChild(pk.el);
    return pk;
  }
  function inCats(pk, e) {
    if (!pk || !pk.get().length) return true;
    return pk.matches(String((e && (e.category_path || e.path || e.category || e.root)) || ""));
  }
  // ── the app's reader on a page titled for the plugin (15.63: ctx.host.playPractice). Its Setup picks the categories ──
  function canRead() { return !!(ctx.host && ctx.host.playPractice); }
  function onReader() { return !!(ctx.host && ctx.host.onPracticePage && ctx.host.onPracticePage()); }
  // a plugin's start page: an icon, what it is, a Start button (data-pk="start"), a note under it
  function heroHtml(icon, title, text, start, note) {
    return '<div class="pk-hero"><span class="pk-hero-ico">' + ic(icon, 26) + "</span><h2>" + esc(title) + "</h2><p>" + esc(text) + "</p>" +
      '<div class="pk-actions pk-center"><button type="button" class="btn btn-primary" data-pk="start">' + ic("play", 14) + esc(start || "Start") + "</button></div>" +
      (note ? '<div class="pk-muted pk-small">' + note + "</div>" : "") + "</div>";
  }
  // the answer line, with its bold and underlining (nothing else of the HTML)
  function answerHtml(q) {
    var h = String((q && q.answer) || "");
    if (!/<\/?(b|u|strong|em|i)\b/i.test(h)) return esc((q && q.answer_sanitized) || h);
    return h.replace(/<(\/?)(b|u|strong|em|i)\b[^>]*>/gi, "\u0001$1$2\u0002").replace(/<[^>]*>/g, "").replace(/&(?!(?:amp|lt|gt|quot|#\d+);)/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/\u0001(\/?)(\w+)\u0002/g, "<$1$2>");
  }
  function primary(q) {
    var a = "";
    try { if (ctx.host && ctx.host.extractPrimaryAnswer) a = ctx.host.extractPrimaryAnswer((q && q.answer) || "", (q && q.answer_sanitized) || ""); } catch (e) {}
    return a || String((q && q.answer_sanitized) || "").replace(/\s*[\[(].*$/, "").trim();
  }
  // judged right here, like practice (judge.js); { status: "accept" | "prompt" | "reject", prompt }
  async function judge(q, answer, opts) {
    opts = opts || {};
    try {
      if (ctx.host && ctx.host.judgeTossup) return (await ctx.host.judgeTossup(q, answer, { strictness: opts.strictness != null ? opts.strictness : (cfg().strictness || 10), buzzPosition: opts.buzzPosition, previous: opts.previous || null })) || { status: "reject" };
      return (await ctx.api.post("/api/evaluate-tossup", { questionId: q.id, answer: answer, strictness: cfg().strictness || 10, buzzPosition: opts.buzzPosition, previous: opts.previous || null })) || { status: "reject" };
    } catch (e) { return { status: "reject" }; }
  }
  async function judgePart(b, part, answer, opts) {
    opts = opts || {};
    try {
      if (ctx.host && ctx.host.judgeBonusPart) return (await ctx.host.judgeBonusPart(b, part, answer, { strictness: cfg().strictness || 10, previous: opts.previous || null })) || { status: "reject" };
      return (await ctx.api.post("/api/evaluate-bonus-part", { questionId: b.id, part: part, answer: answer, strictness: cfg().strictness || 10 })) || { status: "reject" };
    } catch (e) { return { status: "reject" }; }
  }
  async function judgeLine(line, sani, answer, opts) {
    opts = opts || {};
    try {
      if (ctx.host && ctx.host.judgeAnswerLine) return (await ctx.host.judgeAnswerLine(line, sani, answer, { strictness: cfg().strictness || 10, previous: opts.previous || null })) || { status: "reject" };
      return (await ctx.api.post("/api/evaluate-answer", { answerline: line, answer: answer, strictness: cfg().strictness || 10 })) || { status: "reject" };
    } catch (e) { return { status: "reject" }; }
  }
  function bonusParts(b) { try { return JSON.parse((b && (b.parts_sanitized || b.parts)) || "[]"); } catch (e) { return []; } }
  function bonusAnswers(b) { try { return JSON.parse((b && b.answers) || "[]"); } catch (e) { return []; } }
  function bonusAnswersSani(b) { try { return JSON.parse((b && b.answers_sanitized) || "[]"); } catch (e) { return []; } }

  // the player's answers (Stats' history), only the fields asked for
  async function history(fields) {
    try { return ((await ctx.api.get("/api/sessions/all-entries?" + (/\banswer\b/.test(fields || "") ? "answers=1&" : "") + "fields=" + encodeURIComponent(fields || ""))).entries) || []; } catch (e) { return []; }
  }
  // record a tossup answered on a plugin's page into the player's stats (the path Coach Mode uses)
  function record(q, r) {
    try {
      ctx.api.post("/api/check-tossup", { questionId: q.id, answer: r.answer || "", buzzPosition: r.buzzPosition || 0, sessionId: r.session, overriding: true,
        correct: !!r.correct, isPower: !!r.power, points: r.points || 0, celerity: r.celerity != null ? r.celerity : 1 }).catch(function () {});
    } catch (e) {}
  }

  var ROOT_COLOR = { "Literature": "#bc8cff", "Science": "#58a6ff", "Math": "#a5e05b", "Pop Culture": "#ff7b72", "Sports": "#ff6f91", "Fine Arts": "#f778ba", "History": "#e3b341", "Geography": "#56d364", "Mythology": "#ffa657", "Social Science": "#3dd6a3", "Philosophy": "#39c5cf", "Theology": "#8e9bff", "Current Events": "#c9d16b", "Miscellaneous": "#8b949e" };
  // NAQT's high school distribution, per 24 tossups / bonuses (naqt.com/hs/distribution.jsp)
  var NAQT = [["Literature", 3.9, 3.8], ["Science", 4.5, 4.3], ["Math", 1.0, 1.0], ["Fine Arts", 2.0, 2.0], ["History", 4.6, 4.5], ["Geography", 1.9, 1.9], ["Mythology", 0.6, 0.7],
    ["Pop Culture", 1.0, 0.9], ["Sports", 0.7, 0.7], ["Social Science", 0.6, 0.6], ["Philosophy", 0.3, 0.3], ["Theology", 0.4, 0.4], ["Current Events", 1.5, 1.4], ["Miscellaneous", 1.0, 1.5]];
  function rootOf(e) { return String((e && (e.category_path || e.category)) || "").split(" > ")[0] || "Miscellaneous"; }
  function dot(root) { return '<span class="pk-dot" style="--c:' + (ROOT_COLOR[root] || "#8b949e") + '"></span>'; }
  var _roots = null;
  async function roots() {
    if (_roots) return _roots;
    try { var t = ctx.host && ctx.host.getCategoryTree ? await ctx.host.getCategoryTree("tossups") : (await ctx.api.get("/api/category-tree?type=tossups")).tree; _roots = (t || []).map(function (n) { return { id: n.id, name: n.name, count: n.count }; }); }
    catch (e) { _roots = []; }
    return _roots;
  }
  var DIFF_NAME = { 0: "Unrated", 1: "Middle school", 2: "Easy high school", 3: "Regular high school", 4: "Hard high school", 5: "National high school", 6: "Easy college", 7: "Medium college", 8: "Regionals college", 9: "Nationals college", 10: "Open" };

  function tile(value, label, cls) { return '<div class="pk-tile' + (cls ? " " + cls : "") + '"><b class="num">' + value + "</b><span>" + esc(label) + "</span></div>"; }
  function segHtml(name, items, on) {
    return '<div class="seg pk-seg" role="group">' + items.map(function (it) {
      return '<button type="button" data-' + name + '="' + esc(it[0]) + '" aria-pressed="' + (String(on) === String(it[0])) + '">' + esc(it[1]) + "</button>";
    }).join("") + "</div>";
  }
  function emptyHtml(text) { return '<div class="db-empty pk-empty">' + esc(text) + "</div>"; }
  function playList(kind, ids, title) {
    if (!ids || !ids.length) return false;
    try { return !!(ctx.host && ctx.host.launchQuestions && ctx.host.launchQuestions(kind, ids, { title: title })); } catch (e) { return false; }
  }

  // a reader: shows `text` a character at a time at the practice reading speed. start(), pause(), go(), stop();
  // at() is how far it is; onEnd once it's all shown
  function Reader(el, text, opts) {
    opts = opts || {};
    var ms = opts.ms != null ? opts.ms : (Number(cfg().revealSpeed) || 25), idx = 0, raf = 0, last = 0, on = false;
    var paint = function () { el.innerHTML = '<span class="pk-read">' + esc(text.slice(0, idx)) + '</span><span class="pk-unread" aria-hidden="true">' + esc(text.slice(idx)) + "</span>"; };
    var step = function (t) {
      raf = 0; if (!on) return;
      if (!last) last = t;
      var n = ms > 0 ? Math.floor((t - last) / ms) : text.length;
      if (n > 0) { idx = Math.min(text.length, idx + n); last += n * ms; paint(); if (opts.onTick) opts.onTick(idx); }
      if (idx >= text.length) { on = false; if (opts.onEnd) opts.onEnd(); return; }
      raf = requestAnimationFrame(step);
    };
    paint();
    return {
      start: function () { if (on) return; on = true; last = 0; raf = requestAnimationFrame(step); },
      pause: function () { on = false; if (raf) cancelAnimationFrame(raf); raf = 0; },
      stop: function () { on = false; if (raf) cancelAnimationFrame(raf); raf = 0; },
      showAll: function () { this.stop(); idx = text.length; el.textContent = text; },
      at: function () { return idx; },
      running: function () { return on; },
    };
  }
  // a reader's position in the displayed text → the record's question_sanitized (what judging and stats count)
  function serverPos(q, display, pos) {
    try { if (ctx.host && ctx.host.mapDisplayPos) return ctx.host.mapDisplayPos(display, (q && q.question_sanitized) || "", pos); } catch (e) {}
    return pos;
  }

  // ── Layout Customizer: every page of the site as a wireframe, its parts moved by dragging ──
  // A page of buttons, one for each page of the site (with a small picture of its layout). Each opens a preview: the
  // page's parts as rounded boxes, a name and a few blank lines of text in each. Drag a box to move it, its corner to
  // size it. With Auto align on, a box snaps to the page's edges and center and to the other boxes' edges and centers
  // (pink guide lines show what it lines up with), like Canva. Arrow keys nudge the chosen box. Layouts are kept per
  // page; Reset puts one back, Copy layout copies it as text.
  var body = null;
  var W = 1000, H = 625;                                  // the page, in its own units (16:10)
  var saved = ctx.storage.get("layouts") || {}, align = ctx.storage.get("align") !== false;
  var open = null, sel = null, zTop = 10;

  // a part: id, name, where (x, y, w, h in page units), how many blank lines, a tint
  function B(id, n, x, y, w, h, lines, tint) { return { id: id, n: n, x: x, y: y, w: w, h: h, lines: lines == null ? 2 : lines, tint: tint || "" }; }
  var TOP = function () { return B("top", "Top bar", 0, 0, 1000, 46, 0, "bar"); };
  var HEAD = function (right) { return [TOP(), B("title", "Page title", 30, 62, 200, 30, 0), B("tools", right || "Back", right ? 640 : 860, 62, right ? 330 : 110, 32, 0)]; };
  var PAGES = [
    { id: "home", n: "Home", parts: [TOP(), B("logo", "Logo", 330, 86, 340, 74, 0, "accent"), B("greet", "Greeting", 400, 172, 200, 22, 1),
      B("play", "Play", 150, 214, 340, 236, 4, "go"), B("db", "Question database", 510, 214, 340, 236, 4), B("foot", "Footer links", 320, 566, 360, 30, 1)] },
    { id: "tossups", n: "Tossups", parts: HEAD("Voice, Setup and Back").concat([B("question", "Question", 30, 110, 600, 300, 6), B("answer", "Answer box", 30, 424, 600, 44, 1),
      B("keys", "Buzz, Skip and Pause", 30, 560, 380, 46, 0, "go"), B("score", "Scoreboard", 660, 110, 310, 170, 3), B("session", "This session", 660, 300, 310, 210, 4)]) },
    { id: "bonuses", n: "Bonuses", parts: HEAD("Voice, Setup and Back").concat([B("leadin", "Lead-in", 30, 110, 600, 70, 2), B("p1", "Part 1", 30, 194, 600, 90, 2), B("p2", "Part 2", 30, 298, 600, 90, 2),
      B("p3", "Part 3", 30, 402, 600, 90, 2), B("keys", "Skip and Pause", 30, 560, 260, 46, 0, "go"), B("score", "Scoreboard", 660, 110, 310, 170, 3), B("session", "This session", 660, 300, 310, 210, 4)]) },
    { id: "setup", n: "Practice setup", parts: HEAD("Voice, Setup and Back").concat([B("question", "Question", 30, 110, 520, 300, 6), B("mode", "Mode", 600, 110, 370, 56, 1, "panel"),
      B("cats", "Categories", 600, 176, 370, 56, 1, "panel"), B("diff", "Difficulty", 600, 242, 370, 50, 1, "panel"), B("years", "Years", 600, 302, 370, 50, 1, "panel"),
      B("opts", "Options", 600, 362, 370, 130, 4, "panel"), B("timers", "Reading and timers", 600, 502, 370, 76, 2, "panel"), B("start", "Start", 840, 586, 130, 30, 0, "go")]) },
    { id: "multiplayer", n: "Multiplayer", parts: HEAD().concat([B("who", "Playing as", 30, 110, 300, 120, 2), B("make", "Make a room", 30, 246, 300, 110, 2, "go"),
      B("code", "Join with a code", 30, 372, 300, 80, 1), B("rooms", "Rooms", 360, 110, 610, 470, 7)]) },
    { id: "room", n: "A room", parts: [TOP(), B("roomhead", "Room name and code", 30, 62, 420, 30, 0), B("tools", "Setup and Leave", 760, 62, 210, 32, 0), B("question", "Question", 30, 110, 600, 320, 6),
      B("buzz", "Buzz", 30, 560, 180, 46, 0, "go"), B("players", "Players and scores", 660, 110, 310, 260, 5), B("chat", "Chat", 660, 386, 310, 200, 4)] },
    { id: "search", n: "Search", parts: HEAD().concat([B("tabs", "Tabs", 30, 106, 520, 34, 0), B("box", "Search box", 30, 152, 640, 44, 1), B("filters", "Filters", 690, 152, 280, 44, 1),
      B("results", "Results", 30, 210, 940, 340, 7), B("pages", "Pages", 380, 566, 240, 30, 0)]) },
    { id: "sets", n: "Browse sets", parts: HEAD().concat([B("tabs", "Tabs", 30, 106, 520, 34, 0), B("list", "Sets", 30, 152, 300, 440, 8), B("packets", "Packets", 350, 152, 200, 440, 7),
      B("qs", "Packet questions", 570, 152, 400, 440, 7)]) },
    { id: "frequency", n: "Frequency", parts: HEAD().concat([B("tabs", "Tabs", 30, 106, 520, 34, 0), B("filters", "Categories and difficulty", 30, 152, 940, 44, 1),
      B("answers", "Answers", 30, 210, 940, 340, 7), B("pages", "Pages", 380, 566, 240, 30, 0)]) },
    { id: "review", n: "Review", parts: HEAD().concat([B("start", "Start a review", 30, 110, 300, 110, 2, "go"), B("queue", "Your misses", 350, 110, 620, 470, 8)]) },
    { id: "stats", n: "Statistics", parts: HEAD().concat([B("periods", "Periods", 30, 106, 360, 34, 0), B("tiles", "Tiles", 30, 152, 940, 90, 2), B("chart", "Points over time", 30, 256, 600, 200, 3),
      B("cats", "By category", 650, 256, 320, 330, 6), B("sessions", "Sessions", 30, 470, 600, 116, 3)]) },
    { id: "profile", n: "Profile", parts: [TOP(), B("card", "Profile card", 30, 62, 940, 130, 2, "accent"), B("tiles", "Tiles", 30, 206, 940, 90, 2), B("ach", "Achievements", 30, 310, 940, 290, 6)] },
    { id: "trials", n: "Trials", parts: HEAD().concat([B("xp", "XP and level", 30, 106, 940, 70, 1, "accent"), B("cards", "Trials", 30, 190, 940, 400, 8)]) },
    { id: "clubs", n: "Clubs", parts: HEAD("Invites and New").concat([B("orgs", "Your organizations", 30, 110, 300, 470, 7), B("teams", "Teams", 350, 110, 620, 300, 6), B("dx", "Diagnostics", 350, 426, 620, 160, 3)]) },
    { id: "leaderboards", n: "Leaderboards", parts: HEAD().concat([B("boards", "Boards", 30, 106, 520, 34, 0), B("periods", "Periods", 760, 106, 210, 34, 0),
      B("you", "Your place", 30, 152, 940, 60, 1, "accent"), B("table", "Table", 30, 226, 940, 360, 8)]) },
    { id: "plugins", n: "Plugins", parts: HEAD().concat([B("tabs", "Tabs", 30, 106, 360, 34, 0), B("search", "Search plugins", 30, 152, 420, 40, 1), B("cards", "Plugin cards", 30, 206, 940, 390, 6)]) },
    { id: "settings", n: "Settings", parts: [B("nav", "Sections", 150, 70, 200, 480, 7, "panel"), B("body", "Settings", 360, 70, 490, 480, 9, "panel"), B("close", "Close", 760, 76, 80, 28, 0)] },
  ];
  function pageOf(id) { return PAGES.find(function (p) { return p.id === id; }); }
  // a page's parts where they are now (its saved places over the default ones)
  function partsOf(p) {
    var s = saved[p.id] || {};
    return p.parts.map(function (b) { var v = s[b.id]; return v ? Object.assign({}, b, { x: v[0], y: v[1], w: v[2], h: v[3] }) : Object.assign({}, b); });
  }
  function save() { ctx.storage.set("layouts", saved); }

  // ── drawing ──
  var pctX = function (v) { return (100 * v / W).toFixed(3) + "%"; }, pctY = function (v) { return (100 * v / H).toFixed(3) + "%"; };
  function linesHtml(b) {
    var out = "", widths = [92, 78, 86, 64, 90, 72, 82, 58, 88];
    for (var i = 0; i < b.lines; i++) out += '<i style="width:' + widths[(i + b.id.length) % widths.length] + '%"></i>';
    return out;
  }
  function blockHtml(b, mini) {
    var style = "left:" + pctX(b.x) + ";top:" + pctY(b.y) + ";width:" + pctX(b.w) + ";height:" + pctY(b.h);
    return '<div class="lc-block' + (b.tint ? " lc-" + b.tint : "") + (sel === b.id && !mini ? " on" : "") + '" data-b="' + esc(b.id) + '" style="' + style + '"' + (mini ? "" : ' tabindex="0" role="button" aria-label="' + esc(b.n) + '"') + ">" +
      (mini ? "" : '<span class="lc-name">' + esc(b.n) + "</span>") + '<span class="lc-lines">' + linesHtml(b) + "</span>" + (mini ? "" : '<span class="lc-size" data-size="' + esc(b.id) + '" aria-hidden="true"></span>') + "</div>";
  }
  function render() {
    if (!body) return;
    if (open) return renderPreview();
    body.innerHTML = '<div class="pk-wrap lc">' +
      '<div class="pk-hero lc-hero"><span class="pk-hero-ico">' + ic("grid", 26) + "</span><h2>Lay out the site your way</h2><p>Pick a page. Its parts are boxes you can drag around and resize, and Auto align lines them up as you go.</p></div>" +
      '<div class="lc-pages">' + PAGES.map(function (p) {
        var moved = !!saved[p.id] && Object.keys(saved[p.id]).length;
        return '<button type="button" class="lc-page" data-page="' + p.id + '"><span class="lc-thumb">' + partsOf(p).map(function (b) { return blockHtml(b, true); }).join("") + "</span>" +
          '<span class="lc-pn"><b>' + esc(p.n) + "</b>" + (moved ? '<small class="pk-muted">Changed</small>' : "") + "</span></button>";
      }).join("") + "</div></div>";
  }
  function renderPreview() {
    var p = pageOf(open), parts = partsOf(p);
    body.innerHTML = '<div class="pk-wrap lc lc-wide">' +
      '<div class="lc-bar"><button type="button" class="btn btn-ghost" data-lc="pages">' + ic("left", 15) + "Pages</button><b class=\"lc-title\">" + esc(p.n) + "</b>" +
        '<span class="spacer"></span><label class="checkbox-row lc-align"><input type="checkbox" data-lc="align"' + (align ? " checked" : "") + "> Auto align</label>" +
        '<button type="button" class="btn" data-lc="copy">' + ic("copy", 14) + '<span>Copy layout</span></button><button type="button" class="btn" data-lc="reset">' + ic("refresh", 14) + "Reset</button></div>" +
      '<div class="lc-stage"><div class="lc-canvas" id="lc-canvas">' + parts.map(function (b) { return blockHtml(b); }).join("") +
        '<span class="lc-guide lc-gv" hidden></span><span class="lc-guide lc-gh" hidden></span></div></div>' +
      '<div class="pk-muted pk-small lc-hint">Drag a box to move it and its corner to resize it. Arrow keys nudge the one you picked, Shift for bigger steps.</div></div>';
  }

  // ── moving and sizing ──
  var drag = null;
  function canvasRect() { var c = body && body.querySelector("#lc-canvas"); return c ? c.getBoundingClientRect() : null; }
  function setPart(id, x, y, w, h) {
    var p = pageOf(open); if (!p) return;
    (saved[open] = saved[open] || {})[id] = [Math.round(x), Math.round(y), Math.round(w), Math.round(h)];
    var el = body.querySelector('.lc-block[data-b="' + id + '"]');
    if (el) { el.style.left = pctX(x); el.style.top = pctY(y); el.style.width = pctX(w); el.style.height = pctY(h); }
  }
  // the nearest line within reach: { v, at } (v the moved value, at the guide's place), or null
  function snap(vals, targets, reach) {
    var best = null;
    vals.forEach(function (v, k) { targets.forEach(function (t) { var d = t - v; if (Math.abs(d) <= reach && (!best || Math.abs(d) < Math.abs(best.d))) best = { d: d, at: t, k: k }; }); });
    return best;
  }
  function targetsFor(id) {
    var xs = [0, W / 2, W], ys = [0, H / 2, H];
    partsOf(pageOf(open)).forEach(function (b) { if (b.id === id) return; xs.push(b.x, b.x + b.w / 2, b.x + b.w); ys.push(b.y, b.y + b.h / 2, b.y + b.h); });
    return { xs: xs, ys: ys };
  }
  function guides(gx, gy) {
    var v = body.querySelector(".lc-gv"), h = body.querySelector(".lc-gh");
    if (v) { v.hidden = gx == null; if (gx != null) v.style.left = pctX(gx); }
    if (h) { h.hidden = gy == null; if (gy != null) h.style.top = pctY(gy); }
  }
  function onDown(e) {
    if (!open || e.button) return;
    var el = e.target.closest && e.target.closest(".lc-block"); if (!el || !body.contains(el)) return;
    var id = el.dataset.b, b = partsOf(pageOf(open)).find(function (x) { return x.id === id; }), r = canvasRect(); if (!b || !r) return;
    e.preventDefault();
    sel = id; body.querySelectorAll(".lc-block").forEach(function (x) { x.classList.toggle("on", x === el); });
    el.style.zIndex = ++zTop; el.focus({ preventScroll: true });
    drag = { id: id, el: el, b: b, sx: e.clientX, sy: e.clientY, k: W / r.width, size: !!e.target.closest(".lc-size"), t: targetsFor(id) };
    el.setPointerCapture && el.setPointerCapture(e.pointerId);
    el.classList.add("moving");
  }
  function onMove(e) {
    if (!drag) return;
    var d = drag, b = d.b, dx = (e.clientX - d.sx) * d.k, dy = (e.clientY - d.sy) * d.k, reach = 7 * d.k, gx = null, gy = null;
    if (d.size) {
      var w = Math.max(60, Math.min(W - b.x, b.w + dx)), h = Math.max(28, Math.min(H - b.y, b.h + dy));
      if (align) {
        var sx = snap([b.x + w], d.t.xs, reach); if (sx) { w += sx.d; gx = sx.at; }
        var sy = snap([b.y + h], d.t.ys, reach); if (sy) { h += sy.d; gy = sy.at; }
      }
      setPart(d.id, b.x, b.y, w, h);
    } else {
      var x = Math.max(0, Math.min(W - b.w, b.x + dx)), y = Math.max(0, Math.min(H - b.h, b.y + dy));
      if (align) {
        var ax = snap([x, x + b.w / 2, x + b.w], d.t.xs, reach); if (ax) { x += ax.d; gx = ax.at; }
        var ay = snap([y, y + b.h / 2, y + b.h], d.t.ys, reach); if (ay) { y += ay.d; gy = ay.at; }
      }
      setPart(d.id, x, y, b.w, b.h);
    }
    guides(gx, gy);
  }
  function onUp() {
    if (!drag) return;
    drag.el.classList.remove("moving"); drag = null;
    guides(null, null); save();
  }
  function onKey(e) {
    if (!open || !sel || !body || !document.activeElement || !document.activeElement.closest || !document.activeElement.closest(".lc-canvas")) return;
    var step = e.shiftKey ? 10 : 1, mv = { ArrowLeft: [-step, 0], ArrowRight: [step, 0], ArrowUp: [0, -step], ArrowDown: [0, step] }[e.key];
    if (!mv) return;
    e.preventDefault(); e.stopPropagation();
    var b = partsOf(pageOf(open)).find(function (x) { return x.id === sel; }); if (!b) return;
    setPart(sel, Math.max(0, Math.min(W - b.w, b.x + mv[0])), Math.max(0, Math.min(H - b.h, b.y + mv[1])), b.w, b.h);
    save();
  }
  function onClick(e) {
    var t = e.target.closest && e.target.closest("[data-page], [data-lc]"); if (!t || !body || !body.contains(t)) return;
    if (t.dataset.page) { open = t.dataset.page; sel = null; render(); window.scrollTo(0, 0); return; }
    var a = t.dataset.lc;
    if (a === "pages") { open = null; render(); }
    else if (a === "reset") {
      var go = function () { delete saved[open]; save(); sel = null; render(); };
      if (ctx.host && ctx.host.confirm) ctx.host.confirm("Put " + pageOf(open).n + " back the way it was?", go, { yes: "Reset" }); else go();
    } else if (a === "copy") {
      var p = pageOf(open), text = p.n + " layout (x, y, width, height on a 1000 by 625 page)\n" + partsOf(p).map(function (b) { return b.n + ": " + [b.x, b.y, b.w, b.h].map(Math.round).join(", "); }).join("\n");
      try { navigator.clipboard.writeText(text); var s = t.querySelector("span"); if (s) { s.textContent = "Copied"; setTimeout(function () { if (s.isConnected) s.textContent = "Copy layout"; }, 1400); } } catch (x) {}
    }
  }
  function onChange(e) { if (e.target && e.target.dataset && e.target.dataset.lc === "align" && body && body.contains(e.target)) { align = e.target.checked; ctx.storage.set("align", align); } }
  document.addEventListener("pointerdown", onDown);
  document.addEventListener("pointermove", onMove);
  document.addEventListener("pointerup", onUp);
  document.addEventListener("pointercancel", onUp);
  document.addEventListener("keydown", onKey, true);
  document.addEventListener("click", onClick);
  document.addEventListener("change", onChange);
  ctx._cleanup = function () {
    document.removeEventListener("pointerdown", onDown); document.removeEventListener("pointermove", onMove); document.removeEventListener("pointerup", onUp);
    document.removeEventListener("pointercancel", onUp); document.removeEventListener("keydown", onKey, true); document.removeEventListener("click", onClick); document.removeEventListener("change", onChange);
  };
  ctx.registerPage({
    id: "layout", navLabel: "Layout", title: "Layout Customizer",
    onShow: function (el) { body = el; render(); },
  });

}
