function __qbMain(ctx) {
  // ── the kit the 15.62 plugins share (text, icons, questions, judging, history) ──
  function esc(s) { return (s == null ? "" : String(s)).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
  var IC = {
    play: '<path d="M7 4l13 8-13 8z"/>',
    pause: '<path d="M8 5v14M16 5v14"/>',
    left: '<path d="M15 6l-6 6 6 6"/>',
    right: '<path d="M9 6l6 6-6 6"/>',
    next: '<path d="M6 5l9 7-9 7zM18 5v14"/>',
    refresh: '<path d="M20 11a8 8 0 10-2.3 5.7M20 4v7h-7"/>',
    x: '<path d="M6 6l12 12M18 6L6 18"/>',
    check: '<path d="M5 12l5 5 9-10"/>',
    mic: '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
    volume: '<path d="M4 9v6h4l5 4V5L8 9z"/><path d="M16 9a4 4 0 0 1 0 6M19 6a8 8 0 0 1 0 12"/>',
    copy: '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h3"/>',
    edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="M13.5 6.5l4 4"/>',
    bolt: '<path d="M13 3L5 14h6l-1 7 8-11h-6z"/>',
    flag: '<path d="M5 21V4M5 4h11l-2 4 2 4H5"/>',
    users: '<circle cx="9" cy="8" r="3"/><path d="M3 20a6 6 0 0 1 12 0M16 4a3 3 0 0 1 0 6M21 20a6 6 0 0 0-4-5.6"/>',
    target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
    down: '<path d="M6 9l6 6 6-6"/>',
    up: '<path d="M6 15l6-6 6 6"/>',
    quote: '<path d="M7 7h4v4c0 3-1.5 5-4 6M15 7h4v4c0 3-1.5 5-4 6"/>',
    grid: '<rect x="3" y="3" width="8" height="10" rx="2"/><rect x="13" y="3" width="8" height="6" rx="2"/><rect x="13" y="11" width="8" height="10" rx="2"/><rect x="3" y="15" width="8" height="6" rx="2"/>',
    ear: '<path d="M7 9a5 5 0 0 1 10 0c0 3-3 4-3 7a3 3 0 0 1-6 0"/><path d="M10 9a2 2 0 0 1 4 0"/>',
  };
  function ic(name, size) {
    var s = size || 16;
    return '<svg width="' + s + '" height="' + s + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (IC[name] || "") + "</svg>";
  }
  function loading(label) { return '<div class="pk-loading">' + (ctx.loadingBarHtml ? ctx.loadingBarHtml(label) : esc(label)) + "</div>"; }
  function norm(s) { return String(s || "").toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[^a-z0-9]+/g, " ").trim(); }
  function pct(a, n) { return n ? Math.round(100 * a / n) : 0; }
  function fmt(n) { return Number(n || 0).toLocaleString(); }
  function plural(n, one, many) { return fmt(n) + " " + (n === 1 ? one : (many || one + "s")); }
  function shuffle(a) { for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)), t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
  function inField(e) { var t = e && e.target; return !!t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT" || t.isContentEditable); }
  function dayKey(t) { var d = new Date(t || Date.now()); return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0"); }
  var DAY = 86400000;

  // the practice setup (Setup panel): its filters and reading settings
  function cfg() { try { return (ctx.host && ctx.host.getPracticeConfig && ctx.host.getPracticeConfig()) || {}; } catch (e) { return {}; } }
  // filters → query parameters, the ones the app sends for a random question
  function filtersQuery(f, extra) {
    f = f || {}; var p = [];
    var add = function (k, v) { p.push(k + "=" + encodeURIComponent(v)); };
    if (f.categories && f.categories.length) add("categories", f.categories.join(","));
    if (f.categoryIds && f.categoryIds.length) add("categoryIds", f.categoryIds.join(","));
    if (f.difficulties && f.difficulties.length) add("difficulties", f.difficulties.join(","));
    if (f.setNames && f.setNames.length) add("setNames", f.setNames.join(","));
    if (f.packetNumbers && f.packetNumbers.length) add("packetNumbers", f.packetNumbers.join(","));
    if (f.yearMin != null) add("yearMin", f.yearMin);
    if (f.yearMax != null) add("yearMax", f.yearMax);
    if (f.powermarkOnly) add("powermarkOnly", "true");
    if (f.canon && f.canon.length) add("canon", f.canon.join(","));
    add("cleanOnly", "1");
    Object.keys(extra || {}).forEach(function (k) { if (extra[k] != null && extra[k] !== false) add(k, extra[k]); });
    return p.join("&");
  }
  // the practice filters without a set (a drill draws from everything the player picked)
  function practiceFilters() { var f = Object.assign({}, cfg().filters || {}); delete f.setNames; delete f.packetNumbers; delete f.setIds; return f; }
  async function getTossups(n, f, extra) {
    try { var d = await ctx.api.get("/api/tossups/query?" + filtersQuery(f || practiceFilters(), Object.assign({ random: 1, limit: n }, extra || {}))); return (d && d.rows) || []; } catch (e) { return []; }
  }
  async function getBonuses(n, f, extra) {
    try { var d = await ctx.api.get("/api/bonuses/query?" + filtersQuery(f || practiceFilters(), Object.assign({ random: 1, limit: n }, extra || {}))); return (d && d.rows) || []; } catch (e) { return []; }
  }
  async function getTossup(id) { try { return (await ctx.api.get("/api/tossups/" + encodeURIComponent(id))).tossup || null; } catch (e) { return null; } }
  async function getBonus(id) { try { return (await ctx.api.get("/api/bonuses/" + encodeURIComponent(id))).bonus || null; } catch (e) { return null; } }
  async function searchTossups(query, limit, f) {
    try { var d = await ctx.api.get("/api/tossups/search?query=" + encodeURIComponent(query) + "&limit=" + (limit || 20) + (f ? "&" + filtersQuery(f) : "")); return { rows: (d && d.rows) || [], total: (d && d.total) || 0 }; } catch (e) { return { rows: [], total: 0 }; }
  }
  // tossups whose answer line names an answer
  async function tossupsOn(answer, limit) { return (await searchTossups('answer_sanitized : ("' + String(answer).replace(/"/g, "") + '")', limit || 20)).rows; }

  // a record's text as practice reads it (notes and pronunciation guides per the player's settings)
  function readText(q) {
    try { if (ctx.host && ctx.host.questionText) { var t = ctx.host.questionText(q, "question"); if (t != null) return String(t).replace(/\(\*\)/g, "").replace(/\s{2,}/g, " ").trim(); } } catch (e) {}
    return String((q && q.question_sanitized) || "").replace(/\(\*\)/g, "").trim();
  }
  function powerAt(q) { return String((q && q.question_sanitized) || "").indexOf("(*)"); }
  // sentences, without breaking at "St." or an initial ("J. R. R. Tolkien")
  var ABBR = /(?:\b(?:St|Ste|Mt|Mts|Dr|Mr|Mrs|Ms|Mme|Prof|Sr|Jr|Rev|Fr|Gen|Col|Capt|Lt|Sgt|Maj|Adm|Hon|Pres|Gov|Sen|Rep|vs|etc|cf|ca|al|Inc|Co|Corp|Ltd|Bros|approx|No|Nos|Op|op|no|Vol|vol|Ch|ch|Fig|fig|Ft|Pt|pt|Ave|[A-Za-z])\.["”’']?)$/;
  function sentences(text) {
    var parts = String(text || "").split(/(?<=[.?!]["”’)]*)\s+(?=["“(]?[A-Z0-9])/), out = [], cur = "";
    for (var i = 0; i < parts.length; i++) {
      cur = cur ? cur + " " + parts[i] : parts[i];
      if (i < parts.length - 1 && ABBR.test(cur.trim())) continue;
      out.push(cur.trim()); cur = "";
    }
    if (cur.trim()) out.push(cur.trim());
    return out.filter(Boolean);
  }
  // where each sentence of a text ends (indexes into it)
  function sentenceEnds(text) {
    var at = 0, out = []; text = String(text || "");
    sentences(text).forEach(function (x) { var i = text.indexOf(x, at); if (i < 0) return; at = i + x.length; out.push(at); });
    return out;
  }
  // ── categories (15.63): the app's own picker, its picks kept under `key` ([] = every category) ──
  // mountCats(root, key, onChange) puts it in root's [data-cats] (made once, moved into each new render);
  // inCats(pk, e): a history entry or question in the picks; with no picks, all are
  var PICKERS = {};
  // opts.label: "" for just the picks, in a row that has its own label
  function catPicker(key, onChange, opts) {
    if (PICKERS[key]) return PICKERS[key];
    if (!ctx.host || !ctx.host.categoryPicker) return null;
    var o = { selected: ctx.storage.get(key) || [], onChange: function (ids) { ctx.storage.set(key, ids); if (onChange) onChange(ids); } };
    if (opts && opts.label != null) o.label = opts.label;
    var pk = ctx.host.categoryPicker(null, o);
    PICKERS[key] = pk;
    // the picks match nothing until the tree is in: draw again once it is
    if (pk.ready && (ctx.storage.get(key) || []).length) pk.ready.then(function () { if (onChange) onChange(pk.get()); });
    return pk;
  }
  function mountCats(root, key, onChange, opts) {
    var pk = catPicker(key, onChange, opts), host = root && root.querySelector("[data-cats]");
    if (pk && host) host.appendChild(pk.el);
    return pk;
  }
  function inCats(pk, e) {
    if (!pk || !pk.get().length) return true;
    return pk.matches(String((e && (e.category_path || e.path || e.category || e.root)) || ""));
  }
  // ── the app's reader on a page titled for the plugin (15.63: ctx.host.playPractice). Its Setup picks the categories ──
  function canRead() { return !!(ctx.host && ctx.host.playPractice); }
  function onReader() { return !!(ctx.host && ctx.host.onPracticePage && ctx.host.onPracticePage()); }
  // a plugin's start page: an icon, what it is, a Start button (data-pk="start"), a note under it
  function heroHtml(icon, title, text, start, note) {
    return '<div class="pk-hero"><span class="pk-hero-ico">' + ic(icon, 26) + "</span><h2>" + esc(title) + "</h2><p>" + esc(text) + "</p>" +
      '<div class="pk-actions pk-center"><button type="button" class="btn btn-primary" data-pk="start">' + ic("play", 14) + esc(start || "Start") + "</button></div>" +
      (note ? '<div class="pk-muted pk-small">' + note + "</div>" : "") + "</div>";
  }
  // the answer line, with its bold and underlining (nothing else of the HTML)
  function answerHtml(q) {
    var h = String((q && q.answer) || "");
    if (!/<\/?(b|u|strong|em|i)\b/i.test(h)) return esc((q && q.answer_sanitized) || h);
    return h.replace(/<(\/?)(b|u|strong|em|i)\b[^>]*>/gi, "\u0001$1$2\u0002").replace(/<[^>]*>/g, "").replace(/&(?!(?:amp|lt|gt|quot|#\d+);)/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/\u0001(\/?)(\w+)\u0002/g, "<$1$2>");
  }
  function primary(q) {
    var a = "";
    try { if (ctx.host && ctx.host.extractPrimaryAnswer) a = ctx.host.extractPrimaryAnswer((q && q.answer) || "", (q && q.answer_sanitized) || ""); } catch (e) {}
    return a || String((q && q.answer_sanitized) || "").replace(/\s*[\[(].*$/, "").trim();
  }
  // judged right here, like practice (judge.js); { status: "accept" | "prompt" | "reject", prompt }
  async function judge(q, answer, opts) {
    opts = opts || {};
    try {
      if (ctx.host && ctx.host.judgeTossup) return (await ctx.host.judgeTossup(q, answer, { strictness: opts.strictness != null ? opts.strictness : (cfg().strictness || 10), buzzPosition: opts.buzzPosition, previous: opts.previous || null })) || { status: "reject" };
      return (await ctx.api.post("/api/evaluate-tossup", { questionId: q.id, answer: answer, strictness: cfg().strictness || 10, buzzPosition: opts.buzzPosition, previous: opts.previous || null })) || { status: "reject" };
    } catch (e) { return { status: "reject" }; }
  }
  async function judgePart(b, part, answer, opts) {
    opts = opts || {};
    try {
      if (ctx.host && ctx.host.judgeBonusPart) return (await ctx.host.judgeBonusPart(b, part, answer, { strictness: cfg().strictness || 10, previous: opts.previous || null })) || { status: "reject" };
      return (await ctx.api.post("/api/evaluate-bonus-part", { questionId: b.id, part: part, answer: answer, strictness: cfg().strictness || 10 })) || { status: "reject" };
    } catch (e) { return { status: "reject" }; }
  }
  async function judgeLine(line, sani, answer, opts) {
    opts = opts || {};
    try {
      if (ctx.host && ctx.host.judgeAnswerLine) return (await ctx.host.judgeAnswerLine(line, sani, answer, { strictness: cfg().strictness || 10, previous: opts.previous || null })) || { status: "reject" };
      return (await ctx.api.post("/api/evaluate-answer", { answerline: line, answer: answer, strictness: cfg().strictness || 10 })) || { status: "reject" };
    } catch (e) { return { status: "reject" }; }
  }
  function bonusParts(b) { try { return JSON.parse((b && (b.parts_sanitized || b.parts)) || "[]"); } catch (e) { return []; } }
  function bonusAnswers(b) { try { return JSON.parse((b && b.answers) || "[]"); } catch (e) { return []; } }
  function bonusAnswersSani(b) { try { return JSON.parse((b && b.answers_sanitized) || "[]"); } catch (e) { return []; } }

  // the player's answers (Stats' history), only the fields asked for
  async function history(fields) {
    try { return ((await ctx.api.get("/api/sessions/all-entries?" + (/\banswer\b/.test(fields || "") ? "answers=1&" : "") + "fields=" + encodeURIComponent(fields || ""))).entries) || []; } catch (e) { return []; }
  }
  // record a tossup answered on a plugin's page into the player's stats (the path Coach Mode uses)
  function record(q, r) {
    try {
      ctx.api.post("/api/check-tossup", { questionId: q.id, answer: r.answer || "", buzzPosition: r.buzzPosition || 0, sessionId: r.session, overriding: true,
        correct: !!r.correct, isPower: !!r.power, points: r.points || 0, celerity: r.celerity != null ? r.celerity : 1 }).catch(function () {});
    } catch (e) {}
  }

  var ROOT_COLOR = { "Literature": "#bc8cff", "Science": "#58a6ff", "Math": "#a5e05b", "Pop Culture": "#ff7b72", "Sports": "#ff6f91", "Fine Arts": "#f778ba", "History": "#e3b341", "Geography": "#56d364", "Mythology": "#ffa657", "Social Science": "#3dd6a3", "Philosophy": "#39c5cf", "Theology": "#8e9bff", "Current Events": "#c9d16b", "Miscellaneous": "#8b949e" };
  // NAQT's high school distribution, per 24 tossups / bonuses (naqt.com/hs/distribution.jsp)
  var NAQT = [["Literature", 3.9, 3.8], ["Science", 4.5, 4.3], ["Math", 1.0, 1.0], ["Fine Arts", 2.0, 2.0], ["History", 4.6, 4.5], ["Geography", 1.9, 1.9], ["Mythology", 0.6, 0.7],
    ["Pop Culture", 1.0, 0.9], ["Sports", 0.7, 0.7], ["Social Science", 0.6, 0.6], ["Philosophy", 0.3, 0.3], ["Theology", 0.4, 0.4], ["Current Events", 1.5, 1.4], ["Miscellaneous", 1.0, 1.5]];
  function rootOf(e) { return String((e && (e.category_path || e.category)) || "").split(" > ")[0] || "Miscellaneous"; }
  function dot(root) { return '<span class="pk-dot" style="--c:' + (ROOT_COLOR[root] || "#8b949e") + '"></span>'; }
  var _roots = null;
  async function roots() {
    if (_roots) return _roots;
    try { var t = ctx.host && ctx.host.getCategoryTree ? await ctx.host.getCategoryTree("tossups") : (await ctx.api.get("/api/category-tree?type=tossups")).tree; _roots = (t || []).map(function (n) { return { id: n.id, name: n.name, count: n.count }; }); }
    catch (e) { _roots = []; }
    return _roots;
  }
  var DIFF_NAME = { 0: "Unrated", 1: "Middle school", 2: "Easy high school", 3: "Regular high school", 4: "Hard high school", 5: "National high school", 6: "Easy college", 7: "Medium college", 8: "Regionals college", 9: "Nationals college", 10: "Open" };

  function tile(value, label, cls) { return '<div class="pk-tile' + (cls ? " " + cls : "") + '"><b class="num">' + value + "</b><span>" + esc(label) + "</span></div>"; }
  function segHtml(name, items, on) {
    return '<div class="seg pk-seg" role="group">' + items.map(function (it) {
      return '<button type="button" data-' + name + '="' + esc(it[0]) + '" aria-pressed="' + (String(on) === String(it[0])) + '">' + esc(it[1]) + "</button>";
    }).join("") + "</div>";
  }
  function emptyHtml(text) { return '<div class="db-empty pk-empty">' + esc(text) + "</div>"; }
  // square toggles 0 to 10, Setup's difficulty look (the app's .diff-toggles), `on` the ones picked; diffsIn reads them
  function diffHtml(name, on) {
    var h = '<div class="diff-toggles pk-diffs" role="group" aria-label="Difficulty">';
    for (var d = 0; d <= 10; d++) h += '<label title="' + esc(DIFF_NAME[d]) + '"><input type="checkbox" data-' + name + '="' + d + '"' + ((on || []).indexOf(d) >= 0 ? " checked" : "") + "><span>" + d + "</span></label>";
    return h + "</div>";
  }
  function diffsIn(root, name) { return [].slice.call(root.querySelectorAll("[data-" + name + "]")).filter(function (i) { return i.checked; }).map(function (i) { return Number(i.getAttribute("data-" + name)); }); }
  // a list of difficulties in a few words: [2, 3, 4, 5] → "2 to 5"
  function diffWords(ds) {
    ds = (ds || []).slice().sort(function (a, b) { return a - b; });
    if (!ds.length) return "any difficulty";
    var run = ds.every(function (d, i) { return !i || d === ds[i - 1] + 1; });
    return ds.length === 1 ? "difficulty " + ds[0] : run ? "difficulty " + ds[0] + " to " + ds[ds.length - 1] : "difficulty " + ds.join(", ");
  }
  function playList(kind, ids, title) {
    if (!ids || !ids.length) return false;
    try { return !!(ctx.host && ctx.host.launchQuestions && ctx.host.launchQuestions(kind, ids, { title: title })); } catch (e) { return false; }
  }

  // a reader: shows `text` a character at a time at the practice reading speed. start(), pause(), go(), stop();
  // at() is how far it is; onEnd once it's all shown
  function Reader(el, text, opts) {
    opts = opts || {};
    var ms = opts.ms != null ? opts.ms : (Number(cfg().revealSpeed) || 25), idx = 0, raf = 0, last = 0, on = false;
    var paint = function () { el.innerHTML = '<span class="pk-read">' + esc(text.slice(0, idx)) + '</span><span class="pk-unread" aria-hidden="true">' + esc(text.slice(idx)) + "</span>"; };
    var step = function (t) {
      raf = 0; if (!on) return;
      if (!last) last = t;
      var n = ms > 0 ? Math.floor((t - last) / ms) : text.length;
      if (n > 0) { idx = Math.min(text.length, idx + n); last += n * ms; paint(); if (opts.onTick) opts.onTick(idx); }
      if (idx >= text.length) { on = false; if (opts.onEnd) opts.onEnd(); return; }
      raf = requestAnimationFrame(step);
    };
    paint();
    return {
      start: function () { if (on) return; on = true; last = 0; raf = requestAnimationFrame(step); },
      pause: function () { on = false; if (raf) cancelAnimationFrame(raf); raf = 0; },
      stop: function () { on = false; if (raf) cancelAnimationFrame(raf); raf = 0; },
      showAll: function () { this.stop(); idx = text.length; el.textContent = text; },
      at: function () { return idx; },
      running: function () { return on; },
    };
  }
  // a reader's position in the displayed text → the record's question_sanitized (what judging and stats count)
  function serverPos(q, display, pos) {
    try { if (ctx.host && ctx.host.mapDisplayPos) return ctx.host.mapDisplayPos(display, (q && q.question_sanitized) || "", pos); } catch (e) {}
    return pos;
  }

  // ── Layout Customizer: arrange the parts of the site's pages, on the pages themselves ──
  // 2.0 (15.65). Pick a page and it opens with each of its parts covered by a rounded box: its name and blank lines of
  // text. Drag a box to move it and its corner to size it. Auto align snaps it to the page's edges and center and to
  // the other boxes, with pink guides like Canva. Each drop lays the real page out that way at once (a grid of twelve
  // columns on the page's container, each part placed in it by column and row), and the boxes settle where the parts
  // went, so what you see is what the page does. Done keeps it; Reset puts the page back as the app made it. Layouts
  // apply where the window is 900 px wide or more (phones keep their own). On Tossups, the question and the side panel
  // use the app's own side panel position (Settings, Appearance): right, left or below.
  // 1.0 drew made-up wireframes and changed nothing.
  var body = null;
  var saved = ctx.storage.get("grids") || {};          // page id → { part id: [col from, col to, row from, row to] }
  var align = ctx.storage.get("align") !== false;
  var COLS = 12, GAP = 18, MIN_W = 900;
  function nav(name) {
    try { if (ctx.host && ctx.host.openScreen) return ctx.host.openScreen(name); if (typeof window.goTo === "function") { window.goTo(name); return true; } } catch (e) {}
    return false;
  }
  function titleIn(el, sel) { var t = el && el.querySelector(sel); return t ? String(t.textContent).replace(/\s+/g, " ").trim().slice(0, 40) : ""; }
  function slug(s) { return norm(s).replace(/ /g, "-").slice(0, 30) || "part"; }

  // each page: where it is (go), its container (box) and its parts [id, name, selector inside the box] (auto: found
  // on the page). flat: wrappers whose children are parts of their own. width: how wide the container may get.
  var PAGES = [
    { id: "home", n: "Home", go: function () { nav("home"); }, box: "#title-screen .home-inner", flat: [".home-cards"], width: 1040, extra: "align-content:safe center!important;",
      parts: [["hero", "Logo and greeting", ".hero"], ["play", "Play", ".home-cards > .hcard:nth-of-type(1)"], ["db", "Question database", ".home-cards > .hcard:nth-of-type(2)"], ["foot", "Footer links", ".home-foot"]] },
    { id: "tossups", n: "Tossups and bonuses", go: function () { nav("practice-tossups"); }, kind: "practice", box: "#practice-screen .practice-layout",
      parts: [["question", "Question", "main.question-area"], ["side", "Score and session", "aside.practice-side"]] },
    { id: "side", n: "Practice side panel", go: function () { nav("practice-tossups"); }, box: "#live-stats",
      parts: [["plugin", "Plugin box", "#plugin-side"], ["score", "Scoreboard", ".side-stats"], ["hist", "This session", ".side-hist"]] },
    { id: "stats", n: "Statistics", go: function () { nav("stats"); }, box: "#stats-container", inner: "{box} [data-lc] .stats-grid{grid-template-columns:repeat(auto-fit,minmax(150px,1fr))!important}",
      // its sections by title, without the counts in some ("Tossups: 1461" is Tossups, whatever the number)
      auto: function (box) { return [].slice.call(box.children).map(function (el) { var t = titleIn(el, ".stats-section-title").replace(/[:·(]?\s*[\d,.%]+[\s\d,.%·:)-]*$/, "").trim(); t = t.charAt(0).toUpperCase() + t.slice(1).toLowerCase(); return t ? [slug(t), t, el] : null; }).filter(Boolean); } },
    { id: "profile", n: "Profile", go: function () { nav("player"); }, box: "#player-container .pf-page",
      parts: [["event", "Event", ".ev-card"], ["card", "Profile card", ".pf-card"], ["tiles", "Tiles", ".pf-tiles"], ["ach", "Achievements", ".pf-ach"]] },
    { id: "trials", n: "Trials", go: function () { nav("trials"); }, box: "#trials-container .tr-page",
      parts: [["intro", "What trials are", ".tr-intro"], ["trials", "Trials", ".pf-trials:not(.tr-subs)"], ["subs", "Subject trials", ".tr-subs"]] },
    { id: "leaderboards", n: "Leaderboards", go: function () { nav("leaderboards"); }, box: "#lb-container .lb-page",
      parts: [["kinds", "Boards", ".lb-kind-bar"], ["tabs", "Tabs and periods", ".lb-bar:not(.lb-kind-bar)"], ["board", "Table", ".lb-board"]] },
    { id: "search", n: "Search", go: function () { nav("db-search"); }, box: "#db-content .db-search",
      parts: [["box", "Search box", "#db-searchbar"], ["filters", "Filters", ".qrow"], ["head", "Count and pages", "#db-rhead"], ["results", "Results", "#db-results"], ["pages", "Pages", "#db-pager-bottom"]] },
    { id: "frequency", n: "Frequency", go: function () { nav("db-frequency"); }, box: "#db-content .db-freq",
      parts: [["tools", "Categories and types", ".freq-toolbar"], ["head", "Count and pages", "#freq-rhead"], ["results", "Answers", "#freq-results"]] },
    { id: "multiplayer", n: "Multiplayer", go: function () { if (window.QB && QB.showPage) QB.showPage("multiplayer::lobby"); }, box: ".screen.active .mp-lobby-main",
      parts: [["who", "Playing as", ".mp-who"], ["join", "Join or make a room", ".mp-join-card"], ["recent", "Recent rooms", ".mp-recent"]] },
  ];
  function pageOf(id) { return PAGES.find(function (p) { return p.id === id; }); }
  function boxOf(P) { var b = document.querySelector(P.box); return b && b.closest(".screen.active") ? b : null; }
  // the page's parts on screen now: [id, name, element]
  function partsIn(P, box) {
    box = box || boxOf(P); if (!box) return [];
    var list = P.auto ? P.auto(box) : P.parts.map(function (p) { return [p[0], p[1], box.querySelector(p[2])]; });
    return list.filter(function (x) { return x[2] && x[2].getClientRects().length; });
  }

  // ── the layouts, on the pages: each part tagged (data-lc), one style sheet placing them ──
  var styleEl = null;
  function cssFor(P, g) {
    if (P.kind === "practice" || !g || !Object.keys(g).length) return "";
    var b = P.box, out = b + "{display:grid!important;grid-template-columns:repeat(" + COLS + ",minmax(0,1fr))!important;column-gap:" + GAP + "px!important;row-gap:" + GAP + "px!important;align-items:start!important;align-content:start!important;" +
      (P.width ? "width:100%!important;max-width:" + P.width + "px!important;margin-left:auto!important;margin-right:auto!important;" : "") + (P.extra || "") + "}";
    (P.flat || []).forEach(function (f) { out += b + " " + f + "{display:contents!important}"; });
    out += b + ">*:not([data-lc]){grid-column:1/-1!important}";   // anything else on the page goes full width after
    if (P.inner) out += P.inner.split("{box}").join(b);   // what's inside a part, made to fit a narrower one (rows of tiles wrap)
    Object.keys(g).forEach(function (id) {
      var v = g[id];
      out += b + ' [data-lc="' + P.id + ":" + id + '"]{grid-column:' + v[0] + "/" + v[1] + "!important;grid-row:" + v[2] + "/" + v[3] + "!important;margin:0!important;width:auto!important;max-width:none!important;min-width:0!important;justify-self:stretch!important}";
    });
    return "@media (min-width:" + MIN_W + "px){" + out + "}";
  }
  function applyAll(draftFor, draft) {
    if (!styleEl) { styleEl = document.createElement("style"); styleEl.id = "lc-layouts"; document.head.appendChild(styleEl); }
    styleEl.textContent = PAGES.map(function (P) { return cssFor(P, P.id === draftFor ? draft : saved[P.id]); }).join("\n");
  }
  function tagAll() {
    PAGES.forEach(function (P) { partsIn(P).forEach(function (x) { var v = P.id + ":" + x[0]; if (x[2].getAttribute("data-lc") !== v) x[2].setAttribute("data-lc", v); }); });
  }
  var tagRaf = 0;
  var mo = new MutationObserver(function () { if (!tagRaf) tagRaf = requestAnimationFrame(function () { tagRaf = 0; tagAll(); }); });
  mo.observe(document.body, { childList: true, subtree: true });
  ctx.on("screen:change", function () { setTimeout(tagAll, 0); if (E) cancelEdit(); });
  tagAll(); applyAll();

  // ── editing a page, on the page ──
  var E = null;   // { P, box, ovl, bar, b: { id: { x, y, w, h, n, el } }, W, draft, before }
  function contentRect(box) {
    var r = box.getBoundingClientRect(), cs = getComputedStyle(box), pl = parseFloat(cs.paddingLeft) || 0, pr = parseFloat(cs.paddingRight) || 0, pt = parseFloat(cs.paddingTop) || 0;
    return { left: r.left + pl + scrollX, top: r.top + pt + scrollY, width: Math.max(1, r.width - pl - pr), height: Math.max(1, r.height - pt) };
  }
  function linesHtml(h, k) {
    var out = "", widths = [92, 78, 86, 64, 90, 72, 82, 58, 88, 70], n = Math.max(0, Math.min(10, Math.floor((h - 38) / 17)));
    for (var i = 0; i < n; i++) out += '<i style="width:' + widths[(i + k) % widths.length] + '%"></i>';
    return out;
  }
  function paintBox(id) {
    var b = E.b[id], el = b.el;
    el.style.left = b.x + "px"; el.style.top = b.y + "px"; el.style.width = b.w + "px"; el.style.height = b.h + "px";
    el.querySelector(".lc-lines").innerHTML = linesHtml(b.h, id.length);
  }
  // where every part is now, in px within the container
  function measure() {
    var cr = contentRect(E.box);
    // a page laid out in a column of its own width (Home): the boxes are placed within that column, centered
    if (E.P.width && cr.width > E.P.width) { cr.left += (cr.width - E.P.width) / 2; cr.width = E.P.width; }
    E.W = cr.width;
    E.ovl.style.left = cr.left + "px"; E.ovl.style.top = cr.top + "px"; E.ovl.style.width = cr.width + "px";
    var bottom = 0;
    partsIn(E.P, E.box).forEach(function (x) {
      var r = x[2].getBoundingClientRect(), b = E.b[x[0]];
      if (!b) {
        var el = document.createElement("div");
        el.className = "lc-block"; el.dataset.b = x[0]; el.tabIndex = 0; el.setAttribute("role", "button"); el.setAttribute("aria-label", x[1]);
        el.innerHTML = '<span class="lc-name">' + esc(x[1]) + '</span><span class="lc-lines"></span><span class="lc-size" data-size="1" aria-hidden="true"></span>';
        E.ovl.appendChild(el);
        b = E.b[x[0]] = { n: x[1], el: el };
      }
      b.x = r.left + scrollX - cr.left; b.y = r.top + scrollY - cr.top; b.w = r.width; b.h = r.height;
      bottom = Math.max(bottom, b.y + b.h);
      paintBox(x[0]);
    });
    E.ovl.style.height = Math.max(cr.height, bottom + 40) + "px";
  }
  async function startEdit(id) {
    var P = pageOf(id); if (!P) return;
    if (innerWidth < MIN_W) return;
    P.go();
    var box = null;
    for (var i = 0; i < 40 && !(box = boxOf(P)) ; i++) await new Promise(function (r) { setTimeout(r, 100); });
    await new Promise(function (r) { setTimeout(r, 500); });
    box = boxOf(P);
    if (!box || !partsIn(P, box).length) return;
    tagAll();
    E = { P: P, box: box, b: {}, draft: saved[P.id] ? JSON.parse(JSON.stringify(saved[P.id])) : null, before: P.kind === "practice" ? statsPos() : null };
    box.classList.add("lc-editing");
    E.ovl = document.createElement("div"); E.ovl.className = "lc-ovl"; document.body.appendChild(E.ovl);
    E.ovl.innerHTML = '<span class="lc-guide lc-gv" hidden></span><span class="lc-guide lc-gh" hidden></span>';
    E.bar = document.createElement("div"); E.bar.className = "lc-editbar"; E.bar.setAttribute("role", "toolbar");
    E.bar.innerHTML = '<b class="lc-eb-title">' + esc(P.n) + '</b><label class="lc-eb-align"><span class="ext-switch"><input type="checkbox" data-lce="align"' + (align ? " checked" : "") + '><span class="ext-slider"></span></span>Auto align</label>' +
      '<span class="lc-eb-sp"></span><button type="button" class="btn btn-sm btn-ghost" data-lce="reset">' + ic("refresh", 13) + 'Reset</button><button type="button" class="btn btn-sm" data-lce="cancel">Cancel</button><button type="button" class="btn btn-sm btn-primary" data-lce="done">Done</button>';
    document.body.appendChild(E.bar);
    measure();
    window.scrollTo(0, Math.max(0, contentRect(box).top - 140));
  }
  function endEdit() {
    if (!E) return;
    E.box.classList.remove("lc-editing");
    E.ovl.remove(); E.bar.remove(); E = null; sel = null;
    applyAll(); tagAll();
  }
  function cancelEdit() {
    if (!E) return;
    if (E.P.kind === "practice" && E.before) setStatsPos(E.before);
    endEdit();
  }
  function doneEdit() {
    if (!E) return;
    if (E.P.kind !== "practice") { if (E.draft && Object.keys(E.draft).length) saved[E.P.id] = E.draft; else delete saved[E.P.id]; ctx.storage.set("grids", saved); }
    endEdit(); render();
  }
  function resetEdit() {
    if (!E) return;
    if (E.P.kind === "practice") setStatsPos("right"); else { E.draft = null; applyAll(E.P.id, null); }
    settle();
  }
  // after the page lays out again: the boxes glide to where the parts are now
  function settle() {
    requestAnimationFrame(function () { requestAnimationFrame(function () {
      if (!E) return;
      E.ovl.classList.add("lc-settle"); measure();
      setTimeout(function () { if (E) E.ovl.classList.remove("lc-settle"); }, 260);
    }); });
  }

  // the side panel's place on Tossups is the app's own setting (Settings, Appearance)
  function statsPos() { var s = document.getElementById("app-stats-pos"); return (s && s.value) || document.documentElement.getAttribute("data-stats-pos") || "right"; }
  function setStatsPos(v) { var s = document.getElementById("app-stats-pos"); if (!s) return; s.value = v; s.dispatchEvent(new Event("change", { bubbles: true })); }

  // boxes → the grid: columns from where each box's edges fall on the twelve, rows from the order of their tops
  function toGrid() {
    var ids = Object.keys(E.b), W = E.W, pitch = (W + GAP) / COLS, g = {};
    var tops = ids.map(function (id) { return E.b[id].y; }).sort(function (a, b) { return a - b; }), rows = [];
    tops.forEach(function (t) { if (!rows.length || t - rows[rows.length - 1] > 28) rows.push(t); });
    var rowAt = function (y) { var k = 0; rows.forEach(function (t, i) { if (t <= y + 28) k = i; }); return k; };
    ids.forEach(function (id) {
      var b = E.b[id], c0 = Math.max(0, Math.min(COLS - 1, Math.round(b.x / pitch))), c1 = Math.max(c0 + 1, Math.min(COLS, Math.round((b.x + b.w + GAP) / pitch)));
      var r0 = rowAt(b.y), r1 = rows.length;
      for (var i = r0 + 1; i < rows.length; i++) if (rows[i] >= b.y + b.h - 28) { r1 = i; break; }
      g[id] = [c0 + 1, c1 + 1, r0 + 1, Math.max(r0 + 2, r1 + 1)];
    });
    // two parts in the same cells. The one just dropped on a side of another in its row takes that side, and the other
    // keeps the rest (Bonuses dropped on Tossups' right half: side by side). Otherwise the lower one moves under
    var overlap = function (a, b) { return a[0] < b[1] && b[0] < a[1] && a[2] < b[3] && b[2] < a[3]; };
    for (var pass = 0; pass < 20; pass++) {
      var moved = false;
      ids.forEach(function (a) { ids.forEach(function (b) {
        if (a >= b || !overlap(g[a], g[b])) return;
        var m = a === E.moved ? a : b === E.moved ? b : null, o = m === a ? b : a;
        if (m && g[m][2] === g[o][2]) {
          var left = g[m][0] - g[o][0], right = g[o][1] - g[m][1];
          if (left >= 2 && left >= right) { g[o][1] = g[m][0]; moved = true; return; }
          if (right >= 2) { g[o][0] = g[m][1]; moved = true; return; }
        }
        var low = E.b[a].y <= E.b[b].y ? b : a, high = low === a ? b : a, span = g[low][3] - g[low][2];
        g[low][2] = g[high][3]; g[low][3] = g[low][2] + span; moved = true;
      }); });
      if (!moved) break;
    }
    return g;
  }
  function commit() {
    if (!E) return;
    if (E.P.kind === "practice") {
      var q = E.b.question, s = E.b.side; if (!q || !s) return;
      var v = s.y > q.y + q.h * 0.6 ? "below" : s.x + s.w / 2 < q.x + q.w / 2 ? "left" : "right";
      setStatsPos(v);
    } else { E.draft = toGrid(); applyAll(E.P.id, E.draft); }
    settle();
  }

  // ── moving and sizing ──
  var drag = null, sel = null;
  function snap(vals, targets, reach) {
    var best = null;
    vals.forEach(function (v) { targets.forEach(function (t) { var d = t - v; if (Math.abs(d) <= reach && (!best || Math.abs(d) < Math.abs(best.d))) best = { d: d, at: t }; }); });
    return best;
  }
  function targetsFor(id) {
    var xs = [0, E.W / 2, E.W], ys = [0];
    Object.keys(E.b).forEach(function (k) { if (k === id) return; var b = E.b[k]; xs.push(b.x, b.x + b.w / 2, b.x + b.w); ys.push(b.y, b.y + b.h / 2, b.y + b.h); });
    return { xs: xs, ys: ys };
  }
  function guides(gx, gy) {
    var v = E.ovl.querySelector(".lc-gv"), h = E.ovl.querySelector(".lc-gh");
    v.hidden = gx == null; if (gx != null) v.style.left = gx + "px";
    h.hidden = gy == null; if (gy != null) h.style.top = gy + "px";
  }
  function onDown(e) {
    if (!E || e.button) return;
    var el = e.target.closest && e.target.closest(".lc-block"); if (!el || !E.ovl.contains(el)) return;
    e.preventDefault();
    var id = el.dataset.b, b = E.b[id];
    sel = id; E.ovl.querySelectorAll(".lc-block").forEach(function (x) { x.classList.toggle("on", x === el); });
    el.focus({ preventScroll: true });
    drag = { id: id, el: el, o: { x: b.x, y: b.y, w: b.w, h: b.h }, sx: e.clientX, sy: e.clientY, size: !!e.target.closest("[data-size]"), t: targetsFor(id) };
    el.setPointerCapture && el.setPointerCapture(e.pointerId);
    el.classList.add("moving");
  }
  function onMove(e) {
    if (!drag || !E) return;
    var d = drag, o = d.o, b = E.b[d.id], dx = e.clientX - d.sx, dy = e.clientY - d.sy, reach = 8, gx = null, gy = null;
    if (d.size) {
      var w = Math.max(80, Math.min(E.W - o.x, o.w + dx)), h = Math.max(40, o.h + dy);
      if (align) { var sx = snap([o.x + w], d.t.xs, reach); if (sx) { w += sx.d; gx = sx.at; } var sy = snap([o.y + h], d.t.ys, reach); if (sy) { h += sy.d; gy = sy.at; } }
      b.w = w; b.h = h;
    } else {
      // it may hang over an edge while it moves; dropped there, it's cut to fit (a full-width part dragged right is the right half)
      var x = Math.max(-o.w * 0.75, Math.min(E.W - o.w * 0.25, o.x + dx)), y = Math.max(0, o.y + dy);
      if (align) { var ax = snap([x, x + o.w / 2, x + o.w], d.t.xs, reach); if (ax) { x += ax.d; gx = ax.at; } var ay = snap([y, y + o.h / 2, y + o.h], d.t.ys, reach); if (ay) { y += ay.d; gy = ay.at; } }
      b.x = x; b.y = y;
    }
    paintBox(d.id); guides(gx, gy);
  }
  function onUp() {
    if (!drag) return;
    drag.el.classList.remove("moving");
    var bb = E.b[drag.id], minW = E.W / COLS;
    if (bb.x < 0) { bb.w = Math.max(minW, bb.w + bb.x); bb.x = 0; }
    if (bb.x + bb.w > E.W) bb.w = Math.max(minW, E.W - bb.x);
    if (bb.x + bb.w > E.W) bb.x = E.W - bb.w;
    paintBox(drag.id);
    E.moved = drag.id;
    var moved = Math.abs(E.b[drag.id].x - drag.o.x) + Math.abs(E.b[drag.id].y - drag.o.y) + Math.abs(E.b[drag.id].w - drag.o.w) + Math.abs(E.b[drag.id].h - drag.o.h) > 2;
    drag = null; guides(null, null);
    if (moved) commit();
  }
  var nudgeT = 0;
  function onKey(e) {
    if (!E) return;
    if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); cancelEdit(); return; }
    if (!sel || !document.activeElement || !document.activeElement.closest || !document.activeElement.closest(".lc-ovl")) return;
    var step = e.shiftKey ? 40 : 8, mv = { ArrowLeft: [-step, 0], ArrowRight: [step, 0], ArrowUp: [0, -step], ArrowDown: [0, step] }[e.key];
    if (!mv) return;
    e.preventDefault(); e.stopPropagation();
    var b = E.b[sel]; b.x = Math.max(0, Math.min(E.W - b.w, b.x + mv[0])); b.y = Math.max(0, b.y + mv[1]); paintBox(sel);
    clearTimeout(nudgeT); nudgeT = setTimeout(commit, 350);
  }
  function onClick(e) {
    var t = e.target.closest && e.target.closest("[data-lce], [data-page]"); if (!t) return;
    if (t.dataset.page && body && body.contains(t)) { startEdit(t.dataset.page); return; }
    if (!E || !E.bar.contains(t)) return;
    var a = t.dataset.lce;
    if (a === "done") doneEdit(); else if (a === "cancel") cancelEdit(); else if (a === "reset") resetEdit();
  }
  function onChange(e) { if (e.target && e.target.dataset && e.target.dataset.lce === "align") { align = e.target.checked; ctx.storage.set("align", align); } }
  var onResize = function () { if (E) measure(); };
  document.addEventListener("pointerdown", onDown);
  document.addEventListener("pointermove", onMove);
  document.addEventListener("pointerup", onUp);
  document.addEventListener("pointercancel", onUp);
  document.addEventListener("keydown", onKey, true);
  document.addEventListener("click", onClick);
  document.addEventListener("change", onChange);
  window.addEventListener("resize", onResize);
  ctx._cleanup = function () {
    cancelEdit(); mo.disconnect(); if (styleEl) styleEl.remove();
    document.querySelectorAll("[data-lc]").forEach(function (el) { if (el.closest(".screen")) el.removeAttribute("data-lc"); });
    document.removeEventListener("pointerdown", onDown); document.removeEventListener("pointermove", onMove); document.removeEventListener("pointerup", onUp);
    document.removeEventListener("pointercancel", onUp); document.removeEventListener("keydown", onKey, true); document.removeEventListener("click", onClick);
    document.removeEventListener("change", onChange); window.removeEventListener("resize", onResize);
  };

  // ── the plugin's page: every page you can arrange, with a small picture of its layout ──
  function thumbHtml(P) {
    var g = saved[P.id];
    if (P.kind === "practice") {
      var v = statsPos(), q = '<span class="lc-tb" style="left:4%;top:8%;width:62%;height:84%"></span>', s = '<span class="lc-tb lc-tb2" style="left:70%;top:8%;width:26%;height:60%"></span>';
      if (v === "left") { q = '<span class="lc-tb" style="left:34%;top:8%;width:62%;height:84%"></span>'; s = '<span class="lc-tb lc-tb2" style="left:4%;top:8%;width:26%;height:60%"></span>'; }
      if (v === "below") { q = '<span class="lc-tb" style="left:4%;top:8%;width:92%;height:52%"></span>'; s = '<span class="lc-tb lc-tb2" style="left:4%;top:66%;width:92%;height:26%"></span>'; }
      return q + s;
    }
    if (!g) return '<span class="lc-tb" style="left:8%;top:10%;width:84%;height:16%"></span><span class="lc-tb" style="left:8%;top:32%;width:84%;height:24%"></span><span class="lc-tb" style="left:8%;top:62%;width:84%;height:28%"></span>';
    var rows = 0; Object.keys(g).forEach(function (k) { rows = Math.max(rows, g[k][3] - 1); });
    var rh = 84 / Math.max(1, rows);
    return Object.keys(g).map(function (k, i) { var v = g[k]; return '<span class="lc-tb' + (i % 2 ? " lc-tb2" : "") + '" style="left:' + (4 + (v[0] - 1) * 92 / COLS) + "%;top:" + (8 + (v[2] - 1) * rh) + "%;width:" + ((v[1] - v[0]) * 92 / COLS - 1.5) + "%;height:" + ((v[3] - v[2]) * rh - 3) + '%"></span>'; }).join("");
  }
  function render() {
    if (!body) return;
    var narrow = innerWidth < MIN_W;
    body.innerHTML = '<div class="pk-wrap lc">' +
      '<div class="pk-hero lc-hero"><span class="pk-hero-ico">' + ic("grid", 26) + "</span><h2>Lay out the site your way</h2>" +
        "<p>Pick a page. It opens with its parts as boxes you can drag around and resize, and the page moves with them. Auto align lines them up as you go.</p>" +
        (narrow ? '<div class="pk-muted pk-small">Make the window wider to arrange a page. Layouts apply on wide screens, phones keep their own.</div>' : "") + "</div>" +
      '<div class="lc-pages">' + PAGES.map(function (P) {
        var changed = P.kind === "practice" ? statsPos() !== "right" : !!saved[P.id];
        return '<button type="button" class="lc-page" data-page="' + P.id + '"' + (narrow ? " disabled" : "") + '><span class="lc-thumb" aria-hidden="true">' + thumbHtml(P) + "</span>" +
          '<span class="lc-pn"><b>' + esc(P.n) + "</b>" + (changed ? '<small class="pk-chip pk-on">Changed</small>' : "") + "</span></button>";
      }).join("") + "</div></div>";
  }
  ctx.registerPage({
    id: "layout", navLabel: "Layout", title: "Layout Customizer",
    onShow: function (el) { body = el; render(); },
  });

}
