function __qbMain(ctx) {
  // ── the kit the 15.62 plugins share (text, icons, questions, judging, history) ──
  function esc(s) { return (s == null ? "" : String(s)).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
  var IC = {
    play: '<path d="M7 4l13 8-13 8z"/>',
    pause: '<path d="M8 5v14M16 5v14"/>',
    left: '<path d="M15 6l-6 6 6 6"/>',
    right: '<path d="M9 6l6 6-6 6"/>',
    next: '<path d="M6 5l9 7-9 7zM18 5v14"/>',
    refresh: '<path d="M20 11a8 8 0 10-2.3 5.7M20 4v7h-7"/>',
    x: '<path d="M6 6l12 12M18 6L6 18"/>',
    check: '<path d="M5 12l5 5 9-10"/>',
    mic: '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
    volume: '<path d="M4 9v6h4l5 4V5L8 9z"/><path d="M16 9a4 4 0 0 1 0 6M19 6a8 8 0 0 1 0 12"/>',
    copy: '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h3"/>',
    edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="M13.5 6.5l4 4"/>',
    bolt: '<path d="M13 3L5 14h6l-1 7 8-11h-6z"/>',
    flag: '<path d="M5 21V4M5 4h11l-2 4 2 4H5"/>',
    users: '<circle cx="9" cy="8" r="3"/><path d="M3 20a6 6 0 0 1 12 0M16 4a3 3 0 0 1 0 6M21 20a6 6 0 0 0-4-5.6"/>',
    target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
    down: '<path d="M6 9l6 6 6-6"/>',
    up: '<path d="M6 15l6-6 6 6"/>',
  };
  function ic(name, size) {
    var s = size || 16;
    return '<svg width="' + s + '" height="' + s + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (IC[name] || "") + "</svg>";
  }
  function loading(label) { return '<div class="pk-loading">' + (ctx.loadingBarHtml ? ctx.loadingBarHtml(label) : esc(label)) + "</div>"; }
  function norm(s) { return String(s || "").toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[^a-z0-9]+/g, " ").trim(); }
  function pct(a, n) { return n ? Math.round(100 * a / n) : 0; }
  function fmt(n) { return Number(n || 0).toLocaleString(); }
  function plural(n, one, many) { return fmt(n) + " " + (n === 1 ? one : (many || one + "s")); }
  function shuffle(a) { for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)), t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
  function inField(e) { var t = e && e.target; return !!t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT" || t.isContentEditable); }
  function dayKey(t) { var d = new Date(t || Date.now()); return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0"); }
  var DAY = 86400000;

  // the practice setup (Setup panel): its filters and reading settings
  function cfg() { try { return (ctx.host && ctx.host.getPracticeConfig && ctx.host.getPracticeConfig()) || {}; } catch (e) { return {}; } }
  // filters → query parameters, the ones the app sends for a random question
  function filtersQuery(f, extra) {
    f = f || {}; var p = [];
    var add = function (k, v) { p.push(k + "=" + encodeURIComponent(v)); };
    if (f.categories && f.categories.length) add("categories", f.categories.join(","));
    if (f.categoryIds && f.categoryIds.length) add("categoryIds", f.categoryIds.join(","));
    if (f.difficulties && f.difficulties.length) add("difficulties", f.difficulties.join(","));
    if (f.setNames && f.setNames.length) add("setNames", f.setNames.join(","));
    if (f.packetNumbers && f.packetNumbers.length) add("packetNumbers", f.packetNumbers.join(","));
    if (f.yearMin != null) add("yearMin", f.yearMin);
    if (f.yearMax != null) add("yearMax", f.yearMax);
    if (f.powermarkOnly) add("powermarkOnly", "true");
    if (f.canon && f.canon.length) add("canon", f.canon.join(","));
    add("cleanOnly", "1");
    Object.keys(extra || {}).forEach(function (k) { if (extra[k] != null && extra[k] !== false) add(k, extra[k]); });
    return p.join("&");
  }
  // the practice filters without a set (a drill draws from everything the player picked)
  function practiceFilters() { var f = Object.assign({}, cfg().filters || {}); delete f.setNames; delete f.packetNumbers; delete f.setIds; return f; }
  async function getTossups(n, f, extra) {
    try { var d = await ctx.api.get("/api/tossups/query?" + filtersQuery(f || practiceFilters(), Object.assign({ random: 1, limit: n }, extra || {}))); return (d && d.rows) || []; } catch (e) { return []; }
  }
  async function getBonuses(n, f, extra) {
    try { var d = await ctx.api.get("/api/bonuses/query?" + filtersQuery(f || practiceFilters(), Object.assign({ random: 1, limit: n }, extra || {}))); return (d && d.rows) || []; } catch (e) { return []; }
  }
  async function getTossup(id) { try { return (await ctx.api.get("/api/tossups/" + encodeURIComponent(id))).tossup || null; } catch (e) { return null; } }
  async function getBonus(id) { try { return (await ctx.api.get("/api/bonuses/" + encodeURIComponent(id))).bonus || null; } catch (e) { return null; } }
  async function searchTossups(query, limit, f) {
    try { var d = await ctx.api.get("/api/tossups/search?query=" + encodeURIComponent(query) + "&limit=" + (limit || 20) + (f ? "&" + filtersQuery(f) : "")); return { rows: (d && d.rows) || [], total: (d && d.total) || 0 }; } catch (e) { return { rows: [], total: 0 }; }
  }
  // tossups whose answer line names an answer
  async function tossupsOn(answer, limit) { return (await searchTossups('answer_sanitized : ("' + String(answer).replace(/"/g, "") + '")', limit || 20)).rows; }

  // a record's text as practice reads it (notes and pronunciation guides per the player's settings)
  function readText(q) {
    try { if (ctx.host && ctx.host.questionText) { var t = ctx.host.questionText(q, "question"); if (t != null) return String(t).replace(/\(\*\)/g, "").replace(/\s{2,}/g, " ").trim(); } } catch (e) {}
    return String((q && q.question_sanitized) || "").replace(/\(\*\)/g, "").trim();
  }
  function powerAt(q) { return String((q && q.question_sanitized) || "").indexOf("(*)"); }
  // sentences, without breaking at "St." or an initial ("J. R. R. Tolkien")
  var ABBR = /(?:\b(?:St|Ste|Mt|Mts|Dr|Mr|Mrs|Ms|Mme|Prof|Sr|Jr|Rev|Fr|Gen|Col|Capt|Lt|Sgt|Maj|Adm|Hon|Pres|Gov|Sen|Rep|vs|etc|cf|ca|al|Inc|Co|Corp|Ltd|Bros|approx|No|Nos|Op|op|no|Vol|vol|Ch|ch|Fig|fig|Ft|Pt|pt|Ave|[A-Za-z])\.["”’']?)$/;
  function sentences(text) {
    var parts = String(text || "").split(/(?<=[.?!]["”’)]*)\s+(?=["“(]?[A-Z0-9])/), out = [], cur = "";
    for (var i = 0; i < parts.length; i++) {
      cur = cur ? cur + " " + parts[i] : parts[i];
      if (i < parts.length - 1 && ABBR.test(cur.trim())) continue;
      out.push(cur.trim()); cur = "";
    }
    if (cur.trim()) out.push(cur.trim());
    return out.filter(Boolean);
  }
  // the answer line, with its bold and underlining (nothing else of the HTML)
  function answerHtml(q) {
    var h = String((q && q.answer) || "");
    if (!/<\/?(b|u|strong|em|i)\b/i.test(h)) return esc((q && q.answer_sanitized) || h);
    return h.replace(/<(\/?)(b|u|strong|em|i)\b[^>]*>/gi, "\u0001$1$2\u0002").replace(/<[^>]*>/g, "").replace(/&(?!(?:amp|lt|gt|quot|#\d+);)/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/\u0001(\/?)(\w+)\u0002/g, "<$1$2>");
  }
  function primary(q) {
    var a = "";
    try { if (ctx.host && ctx.host.extractPrimaryAnswer) a = ctx.host.extractPrimaryAnswer((q && q.answer) || "", (q && q.answer_sanitized) || ""); } catch (e) {}
    return a || String((q && q.answer_sanitized) || "").replace(/\s*[\[(].*$/, "").trim();
  }
  // judged right here, like practice (judge.js); { status: "accept" | "prompt" | "reject", prompt }
  async function judge(q, answer, opts) {
    opts = opts || {};
    try {
      if (ctx.host && ctx.host.judgeTossup) return (await ctx.host.judgeTossup(q, answer, { strictness: opts.strictness != null ? opts.strictness : (cfg().strictness || 10), buzzPosition: opts.buzzPosition, previous: opts.previous || null })) || { status: "reject" };
      return (await ctx.api.post("/api/evaluate-tossup", { questionId: q.id, answer: answer, strictness: cfg().strictness || 10, buzzPosition: opts.buzzPosition, previous: opts.previous || null })) || { status: "reject" };
    } catch (e) { return { status: "reject" }; }
  }
  async function judgePart(b, part, answer, opts) {
    opts = opts || {};
    try {
      if (ctx.host && ctx.host.judgeBonusPart) return (await ctx.host.judgeBonusPart(b, part, answer, { strictness: cfg().strictness || 10, previous: opts.previous || null })) || { status: "reject" };
      return (await ctx.api.post("/api/evaluate-bonus-part", { questionId: b.id, part: part, answer: answer, strictness: cfg().strictness || 10 })) || { status: "reject" };
    } catch (e) { return { status: "reject" }; }
  }
  async function judgeLine(line, sani, answer, opts) {
    opts = opts || {};
    try {
      if (ctx.host && ctx.host.judgeAnswerLine) return (await ctx.host.judgeAnswerLine(line, sani, answer, { strictness: cfg().strictness || 10, previous: opts.previous || null })) || { status: "reject" };
      return (await ctx.api.post("/api/evaluate-answer", { answerline: line, answer: answer, strictness: cfg().strictness || 10 })) || { status: "reject" };
    } catch (e) { return { status: "reject" }; }
  }
  function bonusParts(b) { try { return JSON.parse((b && (b.parts_sanitized || b.parts)) || "[]"); } catch (e) { return []; } }
  function bonusAnswers(b) { try { return JSON.parse((b && b.answers) || "[]"); } catch (e) { return []; } }
  function bonusAnswersSani(b) { try { return JSON.parse((b && b.answers_sanitized) || "[]"); } catch (e) { return []; } }

  // the player's answers (Stats' history), only the fields asked for
  async function history(fields) {
    try { return ((await ctx.api.get("/api/sessions/all-entries?" + (/\banswer\b/.test(fields || "") ? "answers=1&" : "") + "fields=" + encodeURIComponent(fields || ""))).entries) || []; } catch (e) { return []; }
  }
  // record a tossup answered on a plugin's page into the player's stats (the path Coach Mode uses)
  function record(q, r) {
    try {
      ctx.api.post("/api/check-tossup", { questionId: q.id, answer: r.answer || "", buzzPosition: r.buzzPosition || 0, sessionId: r.session, overriding: true,
        correct: !!r.correct, isPower: !!r.power, points: r.points || 0, celerity: r.celerity != null ? r.celerity : 1 }).catch(function () {});
    } catch (e) {}
  }

  var ROOT_COLOR = { "Literature": "#bc8cff", "Science": "#58a6ff", "Math": "#a5e05b", "Pop Culture": "#ff7b72", "Sports": "#ff6f91", "Fine Arts": "#f778ba", "History": "#e3b341", "Geography": "#56d364", "Mythology": "#ffa657", "Social Science": "#3dd6a3", "Philosophy": "#39c5cf", "Theology": "#8e9bff", "Current Events": "#c9d16b", "Miscellaneous": "#8b949e" };
  // NAQT's high school distribution, per 24 tossups / bonuses (naqt.com/hs/distribution.jsp)
  var NAQT = [["Literature", 3.9, 3.8], ["Science", 4.5, 4.3], ["Math", 1.0, 1.0], ["Fine Arts", 2.0, 2.0], ["History", 4.6, 4.5], ["Geography", 1.9, 1.9], ["Mythology", 0.6, 0.7],
    ["Pop Culture", 1.0, 0.9], ["Sports", 0.7, 0.7], ["Social Science", 0.6, 0.6], ["Philosophy", 0.3, 0.3], ["Theology", 0.4, 0.4], ["Current Events", 1.5, 1.4], ["Miscellaneous", 1.0, 1.5]];
  function rootOf(e) { return String((e && (e.category_path || e.category)) || "").split(" > ")[0] || "Miscellaneous"; }
  function dot(root) { return '<span class="pk-dot" style="--c:' + (ROOT_COLOR[root] || "#8b949e") + '"></span>'; }
  var _roots = null;
  async function roots() {
    if (_roots) return _roots;
    try { var t = ctx.host && ctx.host.getCategoryTree ? await ctx.host.getCategoryTree("tossups") : (await ctx.api.get("/api/category-tree?type=tossups")).tree; _roots = (t || []).map(function (n) { return { id: n.id, name: n.name, count: n.count }; }); }
    catch (e) { _roots = []; }
    return _roots;
  }
  var DIFF_NAME = { 0: "Unrated", 1: "Middle school", 2: "Easy high school", 3: "Regular high school", 4: "Hard high school", 5: "National high school", 6: "Easy college", 7: "Medium college", 8: "Regionals college", 9: "Nationals college", 10: "Open" };

  function tile(value, label, cls) { return '<div class="pk-tile' + (cls ? " " + cls : "") + '"><b class="num">' + value + "</b><span>" + esc(label) + "</span></div>"; }
  function segHtml(name, items, on) {
    return '<div class="seg pk-seg" role="group">' + items.map(function (it) {
      return '<button type="button" data-' + name + '="' + esc(it[0]) + '" aria-pressed="' + (String(on) === String(it[0])) + '">' + esc(it[1]) + "</button>";
    }).join("") + "</div>";
  }
  function emptyHtml(text) { return '<div class="db-empty pk-empty">' + esc(text) + "</div>"; }
  function playList(kind, ids, title) {
    if (!ids || !ids.length) return false;
    try { return !!(ctx.host && ctx.host.launchQuestions && ctx.host.launchQuestions(kind, ids, { title: title })); } catch (e) { return false; }
  }

  // a reader: shows `text` a character at a time at the practice reading speed. start(), pause(), go(), stop();
  // at() is how far it is; onEnd once it's all shown
  function Reader(el, text, opts) {
    opts = opts || {};
    var ms = opts.ms != null ? opts.ms : (Number(cfg().revealSpeed) || 25), idx = 0, raf = 0, last = 0, on = false;
    var paint = function () { el.innerHTML = '<span class="pk-read">' + esc(text.slice(0, idx)) + '</span><span class="pk-unread" aria-hidden="true">' + esc(text.slice(idx)) + "</span>"; };
    var step = function (t) {
      raf = 0; if (!on) return;
      if (!last) last = t;
      var n = ms > 0 ? Math.floor((t - last) / ms) : text.length;
      if (n > 0) { idx = Math.min(text.length, idx + n); last += n * ms; paint(); if (opts.onTick) opts.onTick(idx); }
      if (idx >= text.length) { on = false; if (opts.onEnd) opts.onEnd(); return; }
      raf = requestAnimationFrame(step);
    };
    paint();
    return {
      start: function () { if (on) return; on = true; last = 0; raf = requestAnimationFrame(step); },
      pause: function () { on = false; if (raf) cancelAnimationFrame(raf); raf = 0; },
      stop: function () { on = false; if (raf) cancelAnimationFrame(raf); raf = 0; },
      showAll: function () { this.stop(); idx = text.length; el.textContent = text; },
      at: function () { return idx; },
      running: function () { return on; },
    };
  }
  // a reader's position in the displayed text → the record's question_sanitized (what judging and stats count)
  function serverPos(q, display, pos) {
    try { if (ctx.host && ctx.host.mapDisplayPos) return ctx.host.mapDisplayPos(display, (q && q.question_sanitized) || "", pos); } catch (e) {}
    return pos;
  }

  // ── Missed Clues: the clue you should have known, from each neg, late buzz and missed tossup, as review cards ──
  // A card's clue: for a neg, the sentence you buzzed in (you read it wrong); for a late buzz or a tossup nobody got,
  // the sentence that ends at the power mark (knowing it earns the power). Cards come back after 1, 3, 7, 16 and 35
  // days; a miss sends one back to the start, and one you get after 35 days is learned.
  var body = null, page = null;
  var deck = ctx.storage.get("deck") || {};          // qid → { kind, box, due, added, root, answer, learned }
  var meta = Object.assign({ scanAt: 0, filter: "all" }, ctx.storage.get("meta") || {});
  function save() { ctx.storage.set("deck", deck); ctx.storage.set("meta", meta); }
  var GAPS = [1, 3, 7, 16, 35], KINDS = { neg: "You negged", late: "You got it late", missed: "Nobody got it" };
  var review = null, scanning = false;

  // new misses since the last look (the first look takes the last 30 days)
  async function scan() {
    scanning = true;
    var since = meta.scanAt || Date.now() - 30 * DAY, added = 0, fresh = [];
    var es = await history("type,question_id,correct,points,celerity,buzz_position,category_path,category,timestamp,answer");
    es.forEach(function (e) {
      if (e.type !== "tossup" || !e.question_id || e.timestamp <= since || e.skipped) return;
      var kind = (e.points || 0) < 0 ? "neg" : e.correct && (e.points || 0) === 10 ? "late" : !e.correct && (e.points || 0) === 0 && (e.celerity == null || e.celerity >= 0.97) ? "missed" : null;
      var d = deck[e.question_id];
      if (e.correct && (e.points || 0) >= 15 && d && !d.learned) { d.box = Math.min(GAPS.length, d.box + 1); return; }   // powered it since
      if (!kind || d || fresh.some(function (f) { return f.id === e.question_id; })) return;
      fresh.push({ id: e.question_id, card: { kind: kind, box: 0, due: 0, added: e.timestamp, root: rootOf(e), answer: e.answer || "", buzz: e.buzz_position != null ? e.buzz_position : null } });
    });
    // newest first, and no more than 20 new cards come due a day (a first look can find hundreds)
    var queued = cards().filter(function (c) { return !c.learned && c.box === 0 && c.due > Date.now(); }).length;
    fresh.sort(function (a, b) { return b.card.added - a.card.added; }).forEach(function (f, i) {
      if (deck[f.id]) return;
      f.card.due = Math.max(f.card.added + DAY / 2, Date.now() - 60000) + Math.floor((queued + i) / 20) * DAY;
      deck[f.id] = f.card; added++;
    });
    meta.scanAt = Date.now(); scanning = false; save();
    return added;
  }
  function cards() { return Object.keys(deck).map(function (id) { return Object.assign({ id: id }, deck[id]); }); }
  function due() { var now = Date.now(); return cards().filter(function (c) { return !c.learned && c.due <= now; }).sort(function (a, b) { return a.due - b.due; }); }
  function whenText(t) { var d = Math.round((t - Date.now()) / DAY); return d <= 0 ? "Due now" : d === 1 ? "Tomorrow" : "In " + d + " days"; }

  // the clue for a card, out of its tossup's text
  function clueFor(q, kind, e) {
    var raw = String(q.question_sanitized || ""), lines = sentences(raw), pos = 0, at;
    var pIdx = raw.indexOf("(*)");
    if (kind === "neg" && e && e.buzz != null) at = e.buzz + 1; else at = pIdx >= 0 ? pIdx : Math.max(0, raw.length - (lines[lines.length - 1] || "").length - 2);
    for (var i = 0; i < lines.length; i++) { var end = raw.indexOf(lines[i], pos) + lines[i].length; if (end >= at - 1) return lines[i].replace(/\(\*\)/g, "").trim(); pos = end; }
    return (lines[0] || raw).replace(/\(\*\)/g, "").trim();
  }

  function render() {
    if (!body) return;
    if (review) return renderReview();
    var all = cards(), live = all.filter(function (c) { return !c.learned; }), d = due(), learned = all.length - live.length;
    var shown = live.filter(function (c) { return meta.filter === "all" || c.kind === meta.filter; }).sort(function (a, b) { return a.due - b.due; });
    body.innerHTML = '<div class="pk-wrap mc">' +
      '<div class="pk-card mc-head"><div class="pk-grow"><div class="pk-strong">' + (d.length ? plural(d.length, "card") + " to review" : "Nothing to review right now") + '</div><div class="pk-muted pk-small">' +
        (scanning ? "Looking for new misses…" : "Your negs, late buzzes and missed tossups become cards. Each one is the clue to learn.") + "</div></div>" +
        '<button type="button" class="btn btn-primary" id="mc-go"' + (d.length ? "" : " disabled") + ">" + ic("play", 14) + 'Review<span class="pk-kbd">S</span></button></div>' +
      '<div class="pk-tiles">' + tile(fmt(d.length), "Due now", "pk-bad") + tile(fmt(live.length), "In your deck") + tile(fmt(learned), "Learned", "pk-good") + "</div>" +
      (live.length ? '<div class="pk-sechead"><span class="eyebrow">Your deck</span>' + segHtml("kind", [["all", "All"], ["neg", "Negs"], ["late", "Late"], ["missed", "Missed"]], meta.filter) + "</div>" +
        '<div class="list pk-list">' + shown.slice(0, 200).map(function (c) {
          return '<div class="list-row mc-row">' + dot(c.root) + '<span class="pk-grow mc-ans"><b>' + esc(c.answer || "?") + '</b><small class="pk-muted">' + esc(KINDS[c.kind] || "") + " · box " + (c.box + 1) + " of " + GAPS.length + '</small></span><span class="pk-muted pk-small">' + whenText(c.due) + '</span><button type="button" class="btn btn-ghost btn-icon btn-sm" data-drop="' + esc(c.id) + '" title="Take it out of the deck" aria-label="Take it out of the deck">' + ic("trash", 14) + "</button></div>";
        }).join("") + (shown.length > 200 ? '<div class="list-row pk-muted pk-small">And ' + (shown.length - 200) + " more</div>" : "") + "</div>"
      : emptyHtml(scanning ? "" : "No cards yet. Practice some tossups and your misses will show up here.")) + "</div>";
    var go = body.querySelector("#mc-go"); if (go) go.onclick = startReview;
    body.querySelectorAll("[data-kind]").forEach(function (b) { b.onclick = function () { meta.filter = b.dataset.kind; save(); render(); }; });
    body.querySelectorAll("[data-drop]").forEach(function (b) { b.onclick = function () { delete deck[b.dataset.drop]; save(); render(); }; });
  }

  async function startReview() {
    var d = due(); if (!d.length) return;
    review = { list: d.slice(0, 40), i: 0, right: 0, cur: null };
    await loadCard();
  }
  async function loadCard() {
    if (!review) return;
    if (review.i >= review.list.length) { var r = review; review = null; render(); body.querySelector(".mc-head").insertAdjacentHTML("afterend", '<div class="pk-card mc-done">Done. You knew <b>' + r.right + "</b> of " + r.list.length + ".</div>"); return; }
    renderReview(true);
    var c = review.list[review.i], q = await getTossup(c.id);
    if (!review) return;
    if (!q) { delete deck[c.id]; save(); review.i++; return loadCard(); }
    review.cur = { c: c, q: q, clue: clueFor(q, c.kind, { buzz: c.buzz }), phase: "answering", prompt: null };
    renderReview();
  }
  function renderReview(wait) {
    var R = review, cur = R && R.cur;
    body.innerHTML = '<div class="pk-wrap mc"><div class="pk-bar-top"><span class="pk-chip">Card ' + (R.i + 1) + " of " + R.list.length + '</span><span class="pk-chip">' + R.right + ' known</span><span class="spacer"></span><button type="button" class="btn btn-ghost" id="mc-stop">Stop</button></div>' +
      '<div class="pk-card mc-card">' + (wait || !cur ? loading("Getting the card…") :
        '<div class="pk-meta">' + dot(cur.c.root) + esc(cur.c.root) + " · " + esc(KINDS[cur.c.kind]) + "</div>" +
        '<div class="pk-q mc-clue">' + esc(cur.clue) + "</div>" +
        (cur.phase === "done"
          ? "<div>" + cur.verdict + '</div><div class="pk-answer"><span class="pk-muted">Answer </span>' + answerHtml(cur.q) + "</div>" +
            (cur.self ? '<div class="pk-actions"><button type="button" class="btn btn-primary" data-grade="1">I knew it</button><button type="button" class="btn" data-grade="0">I didn\'t</button></div>'
              : '<div class="pk-actions"><button type="button" class="btn btn-primary" id="mc-next">Next<span class="pk-kbd">N</span></button></div>')
          : (cur.prompt != null ? '<div class="pk-prompt">Prompt' + (cur.promptAsk ? ": " + esc(cur.promptAsk) : "") + "</div>" : "") +
            '<div class="pk-input"><input id="mc-ans" autocomplete="off" spellcheck="false" placeholder="What does this clue point to?" aria-label="Your answer"><button type="button" class="btn btn-primary" id="mc-send">Answer</button></div>' +
            '<div class="pk-actions"><button type="button" class="btn btn-ghost" id="mc-show">Show the answer</button></div>')) + "</div></div>";
    body.querySelector("#mc-stop").onclick = function () { review = null; render(); };
    var inp = body.querySelector("#mc-ans");
    if (inp) {
      inp.focus();
      inp.addEventListener("keydown", function (e) { if (e.key === "Enter") { e.preventDefault(); answer(inp.value.trim()); } e.stopPropagation(); });
      body.querySelector("#mc-send").onclick = function () { answer(inp.value.trim()); };
      body.querySelector("#mc-show").onclick = function () { cur.phase = "done"; cur.self = true; cur.verdict = '<span class="pk-muted">Did you know it?</span>'; renderReview(); };
    }
    body.querySelectorAll("[data-grade]").forEach(function (b) { b.onclick = function () { grade(b.dataset.grade === "1"); review.i++; loadCard(); }; });
    var nx = body.querySelector("#mc-next"); if (nx) nx.onclick = function () { review.i++; loadCard(); };
  }
  async function answer(a) {
    var cur = review && review.cur; if (!cur || cur.phase !== "answering" || !a) return;
    cur.phase = "judging";
    var r = await judge(cur.q, a, { buzzPosition: (cur.q.question_sanitized || "").length, previous: cur.prompt });
    if (!review || review.cur !== cur) return;
    if (r.status === "prompt" && cur.prompt == null) { cur.prompt = a; cur.promptAsk = (r.prompt && r.prompt.ask) || ""; cur.phase = "answering"; renderReview(); return; }
    var right = r.status === "accept";
    grade(right);
    ctx.playSound(right ? "correct" : "incorrect");
    cur.phase = "done";
    var d = deck[cur.c.id];
    cur.verdict = right ? '<span class="pk-verdict pk-ok">' + ic("check", 15) + (d && d.learned ? "Right. It's learned" : "Right. Back " + whenText(d ? d.due : 0).toLowerCase()) + "</span>" : '<span class="pk-verdict pk-no">' + ic("x", 15) + "Not “" + esc(a) + "”. It comes back tomorrow</span>";
    renderReview();
  }
  function grade(knew) {
    var cur = review && review.cur, d = cur && deck[cur.c.id]; if (!d) return;
    if (knew) {
      review.right++;
      if (d.box >= GAPS.length - 1) { d.learned = Date.now(); }
      else { d.box++; d.due = Date.now() + GAPS[d.box] * DAY; }
    } else { d.box = 0; d.due = Date.now() + GAPS[0] * DAY; }
    save();
  }

  function active() { return page && page.screenEl && page.screenEl.classList.contains("active"); }
  function onKey(e) {
    if (!active() || inField(e) || e.metaKey || e.ctrlKey || e.altKey) return;
    if ((e.key === "n" || e.key === "N") && review && review.cur && review.cur.phase === "done" && !review.cur.self) { e.preventDefault(); review.i++; loadCard(); }
    else if ((e.key === "s" || e.key === "S") && !review && due().length) { e.preventDefault(); startReview(); }
  }
  document.addEventListener("keydown", onKey);
  ctx._cleanup = function () { document.removeEventListener("keydown", onKey); };
  page = ctx.registerPage({
    id: "missed-clues", navLabel: "Missed Clues", title: "Missed Clues",
    onShow: function (el) { body = el; if (review) { renderReview(); return; } render(); scan().then(render); },
  });

}
