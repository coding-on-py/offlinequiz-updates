/**
 * OfflineQuiz plugin: Missed Clues
 *
 * Every neg, late buzz and missed tossup becomes a card with the clue you should have known: the
 * sentence you negged on, or the one that ends at the power mark. Cards come back on a spaced
 * schedule until you know them.
 */
QB.registerPlugin({
  id: "missed-clues",
  name: "Missed Clues",
  version: "1.1.0",
  author: "OfflineQuiz",
  description: "Turn your negs, late buzzes and missed tossups into review cards of the exact clue to learn.",
  onEnable: __qbMain,
  onDisable: function (ctx) { if (ctx._cleanup) ctx._cleanup(); },
});
