/**
 * OfflineQuiz plugin: Voice Answers
 *
 * Answer by voice, the way you do at a tournament. After you buzz, it listens, writes what you say
 * into the answer box and sends it when you stop talking. It can also buzz when you say "buzz".
 */
QB.registerPlugin({
  id: "voice-answers",
  name: "Voice Answers",
  version: "4.3.1",
  author: "OfflineQuiz",
  description: "Say your answer out loud after you buzz, like in a real game.",
  settings: [
    {
      "key": "enabled",
      "label": "Answer by voice",
      "type": "toggle",
      "default": true,
      "location": "voice"
    },
    {
      "key": "autoSend",
      "label": "Send when I stop talking",
      "type": "toggle",
      "default": true,
      "location": "voice"
    },
    {
      "key": "bonuses",
      "label": "Bonus parts too",
      "type": "toggle",
      "default": false,
      "location": "voice"
    },
    {
      "key": "bySound",
      "label": "Judge by how it sounds",
      "type": "toggle",
      "default": true,
      "location": "voice"
    },
    {
      "key": "loudBuzz",
      "label": "Clap or shout to buzz",
      "type": "toggle",
      "default": false,
      "location": "voice"
    },
    {
      "key": "loudLevel",
      "label": "How loud",
      "type": "select",
      "default": "louder",
      "location": "voice",
      "options": [
        {
          "value": "loud",
          "label": "Loud"
        },
        {
          "value": "louder",
          "label": "Louder"
        },
        {
          "value": "very",
          "label": "Very loud"
        }
      ]
    }
  ],
  onEnable: __qbMain,
  onDisable: function (ctx) { if (ctx._cleanup) ctx._cleanup(); },
});
