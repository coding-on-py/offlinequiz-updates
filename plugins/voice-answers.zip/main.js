/**
 * OfflineQuiz plugin: Voice Answers
 *
 * Answer by voice, the way you do at a tournament. After you buzz, it listens, writes what you say
 * into the answer box and sends it when you stop talking. It can also buzz when you say "buzz".
 */
QB.registerPlugin({
  id: "voice-answers",
  name: "Voice Answers",
  version: "1.0.0",
  author: "OfflineQuiz",
  description: "Say your answer out loud after you buzz, like in a real game. Works in Chrome and Edge.",
  settings: [
    {
      "key": "enabled",
      "label": "Answer by voice",
      "type": "toggle",
      "default": true,
      "location": "practice"
    },
    {
      "key": "autoSend",
      "label": "Send when I stop talking",
      "type": "toggle",
      "default": true,
      "location": "practice"
    },
    {
      "key": "bonuses",
      "label": "Bonus parts too",
      "type": "toggle",
      "default": false,
      "location": "practice"
    },
    {
      "key": "sayBuzz",
      "label": "Say \"buzz\" to buzz",
      "type": "toggle",
      "default": false,
      "location": "practice"
    }
  ],
  onEnable: __qbMain,
  onDisable: function (ctx) { if (ctx._cleanup) ctx._cleanup(); },
});
