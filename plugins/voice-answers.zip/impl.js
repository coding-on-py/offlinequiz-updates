function __qbMain(ctx) {
  // ── the kit the 15.62 plugins share (text, icons, questions, judging, history) ──
  function esc(s) { return (s == null ? "" : String(s)).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
  var IC = {
    play: '<path d="M7 4l13 8-13 8z"/>',
    pause: '<path d="M8 5v14M16 5v14"/>',
    left: '<path d="M15 6l-6 6 6 6"/>',
    right: '<path d="M9 6l6 6-6 6"/>',
    next: '<path d="M6 5l9 7-9 7zM18 5v14"/>',
    refresh: '<path d="M20 11a8 8 0 10-2.3 5.7M20 4v7h-7"/>',
    x: '<path d="M6 6l12 12M18 6L6 18"/>',
    check: '<path d="M5 12l5 5 9-10"/>',
    mic: '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
    volume: '<path d="M4 9v6h4l5 4V5L8 9z"/><path d="M16 9a4 4 0 0 1 0 6M19 6a8 8 0 0 1 0 12"/>',
    copy: '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h3"/>',
    edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="M13.5 6.5l4 4"/>',
    bolt: '<path d="M13 3L5 14h6l-1 7 8-11h-6z"/>',
    flag: '<path d="M5 21V4M5 4h11l-2 4 2 4H5"/>',
    users: '<circle cx="9" cy="8" r="3"/><path d="M3 20a6 6 0 0 1 12 0M16 4a3 3 0 0 1 0 6M21 20a6 6 0 0 0-4-5.6"/>',
    target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
    down: '<path d="M6 9l6 6 6-6"/>',
    up: '<path d="M6 15l6-6 6 6"/>',
    quote: '<path d="M7 7h4v4c0 3-1.5 5-4 6M15 7h4v4c0 3-1.5 5-4 6"/>',
    grid: '<rect x="3" y="3" width="8" height="10" rx="2"/><rect x="13" y="3" width="8" height="6" rx="2"/><rect x="13" y="11" width="8" height="10" rx="2"/><rect x="3" y="15" width="8" height="6" rx="2"/>',
    ear: '<path d="M7 9a5 5 0 0 1 10 0c0 3-3 4-3 7a3 3 0 0 1-6 0"/><path d="M10 9a2 2 0 0 1 4 0"/>',
  };
  function ic(name, size) {
    var s = size || 16;
    return '<svg width="' + s + '" height="' + s + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (IC[name] || "") + "</svg>";
  }
  function loading(label) { return '<div class="pk-loading">' + (ctx.loadingBarHtml ? ctx.loadingBarHtml(label) : esc(label)) + "</div>"; }
  function norm(s) { return String(s || "").toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[^a-z0-9]+/g, " ").trim(); }
  function pct(a, n) { return n ? Math.round(100 * a / n) : 0; }
  function fmt(n) { return Number(n || 0).toLocaleString(); }
  function plural(n, one, many) { return fmt(n) + " " + (n === 1 ? one : (many || one + "s")); }
  function shuffle(a) { for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)), t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
  function inField(e) { var t = e && e.target; return !!t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT" || t.isContentEditable); }
  function dayKey(t) { var d = new Date(t || Date.now()); return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0"); }
  var DAY = 86400000;

  // the practice setup (Setup panel): its filters and reading settings
  function cfg() { try { return (ctx.host && ctx.host.getPracticeConfig && ctx.host.getPracticeConfig()) || {}; } catch (e) { return {}; } }
  // filters → query parameters, the ones the app sends for a random question
  function filtersQuery(f, extra) {
    f = f || {}; var p = [];
    var add = function (k, v) { p.push(k + "=" + encodeURIComponent(v)); };
    if (f.categories && f.categories.length) add("categories", f.categories.join(","));
    if (f.categoryIds && f.categoryIds.length) add("categoryIds", f.categoryIds.join(","));
    if (f.difficulties && f.difficulties.length) add("difficulties", f.difficulties.join(","));
    if (f.setNames && f.setNames.length) add("setNames", f.setNames.join(","));
    if (f.packetNumbers && f.packetNumbers.length) add("packetNumbers", f.packetNumbers.join(","));
    if (f.yearMin != null) add("yearMin", f.yearMin);
    if (f.yearMax != null) add("yearMax", f.yearMax);
    if (f.powermarkOnly) add("powermarkOnly", "true");
    if (f.canon && f.canon.length) add("canon", f.canon.join(","));
    add("cleanOnly", "1");
    Object.keys(extra || {}).forEach(function (k) { if (extra[k] != null && extra[k] !== false) add(k, extra[k]); });
    return p.join("&");
  }
  // the practice filters without a set (a drill draws from everything the player picked)
  function practiceFilters() { var f = Object.assign({}, cfg().filters || {}); delete f.setNames; delete f.packetNumbers; delete f.setIds; return f; }
  async function getTossups(n, f, extra) {
    try { var d = await ctx.api.get("/api/tossups/query?" + filtersQuery(f || practiceFilters(), Object.assign({ random: 1, limit: n }, extra || {}))); return (d && d.rows) || []; } catch (e) { return []; }
  }
  async function getBonuses(n, f, extra) {
    try { var d = await ctx.api.get("/api/bonuses/query?" + filtersQuery(f || practiceFilters(), Object.assign({ random: 1, limit: n }, extra || {}))); return (d && d.rows) || []; } catch (e) { return []; }
  }
  async function getTossup(id) { try { return (await ctx.api.get("/api/tossups/" + encodeURIComponent(id))).tossup || null; } catch (e) { return null; } }
  async function getBonus(id) { try { return (await ctx.api.get("/api/bonuses/" + encodeURIComponent(id))).bonus || null; } catch (e) { return null; } }
  async function searchTossups(query, limit, f) {
    try { var d = await ctx.api.get("/api/tossups/search?query=" + encodeURIComponent(query) + "&limit=" + (limit || 20) + (f ? "&" + filtersQuery(f) : "")); return { rows: (d && d.rows) || [], total: (d && d.total) || 0 }; } catch (e) { return { rows: [], total: 0 }; }
  }
  // tossups whose answer line names an answer
  async function tossupsOn(answer, limit) { return (await searchTossups('answer_sanitized : ("' + String(answer).replace(/"/g, "") + '")', limit || 20)).rows; }

  // ── the voice plugins' files (15.69: Kokoro Voice, Voice Answers) ──
  // Worker code: a plugin's worker source starts with "(" + voiceFilesWorker + ")(cfg);". fetch() in that worker then
  // serves the model, voice and code files from IndexedDB once they've been fetched, so they load in a moment and work
  // offline. The first time, each comes from our server (onlinequiz.net/voice/, a copy of Hugging Face's and
  // jsDelivr's files by the same paths: server.js, scripts/publish-voice.mjs) or else its own host, in 4 MB ranges six at a time, each range kept as
  // it arrives: one long download over a slow line kept breaking off and starting again, so Kokoro never got ready.
  // cfg: { mirror: our copy's address (the website's own /voice/; the app's www.onlinequiz.net/voice/), db: the IndexedDB name (1.x/2.x kept whole files there by their address, and those are used), sizes: { url:
  // bytes } }. self.voiceFiles: plan(urls) totals what's still to fetch (progress goes to the page as { t: "progress",
  // loaded, total }), file(url), has(url) (kept already), blobUrl(url, type), importCode(url, fallback), route(fn) (fn(url)
  // → a Response promise for a file it makes itself, or null).
  // where our copy is: the website's own, else the live site's
  function voiceMirror() { return (window.QB_WEB && /^https?:/.test(location.origin) ? location.origin : "https://www.onlinequiz.net") + "/voice/"; }
  function voiceFilesWorker(cfg) {
    var MIRROR = cfg.mirror || "https://www.onlinequiz.net/voice/", HOSTS = [["https://huggingface.co/", "hf/"], ["https://cdn.jsdelivr.net/npm/", "npm/"]];
    var CHUNK = 4 << 20, LANES = 6, real = self.fetch.bind(self), sizes = cfg.sizes || {}, got = 0, want = 0, inflight = {};
    var dbp = null;
    function db() {
      return dbp || (dbp = new Promise(function (res, rej) { var r = indexedDB.open(cfg.db, 1); r.onupgradeneeded = function () { r.result.createObjectStore("files"); }; r.onsuccess = function () { res(r.result); }; r.onerror = function () { rej(r.error); }; }));
    }
    function get(k) { return db().then(function (d) { return new Promise(function (res) { try { var g = d.transaction("files").objectStore("files").get(k); g.onsuccess = function () { res(g.result); }; g.onerror = function () { res(undefined); }; } catch (e) { res(undefined); } }); }); }
    function put(k, v) { return db().then(function (d) { return new Promise(function (res) { try { var tx = d.transaction("files", "readwrite"); tx.objectStore("files").put(v, k); tx.oncomplete = function () { res(true); }; tx.onerror = tx.onabort = function () { res(false); }; } catch (e) { res(false); } }); }); }
    function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
    function mirrorOf(url) { for (var i = 0; i < HOSTS.length; i++) if (url.indexOf(HOSTS[i][0]) === 0) return MIRROR + HOSTS[i][1] + url.slice(HOSTS[i][0].length); return null; }
    function report() { if (want) postMessage({ t: "progress", loaded: Math.min(got, want), total: want }); }
    // kept: a small file whole, a big one as its ranges
    async function kept(url) {
      var whole = await get(url); if (whole) return whole;
      var meta = await get(url + "#meta"); if (!meta || !meta.done) return null;
      var all = new Uint8Array(meta.total), o = 0;
      for (var i = 0; i < meta.n; i++) { var p = await get(url + "#" + i); if (!p) return null; all.set(new Uint8Array(p), o); o += p.byteLength; }
      return all.buffer;
    }
    async function sizeAt(src) {
      var r = await real(src, { headers: { Range: "bytes=0-0" } });
      var m = /\/(\d+)\s*$/.exec(r.headers.get("Content-Range") || ""), n = m ? +m[1] : r.status === 200 ? +(r.headers.get("Content-Length") || 0) : 0;
      try { if (r.body) await r.body.cancel(); } catch (e) {}
      if (!n) throw new Error("HTTP " + r.status);
      return n;
    }
    async function pull(src, url, total) {
      // in one piece: a small file, and jsDelivr's (served compressed, so its ranges aren't the file's)
      if (total <= 2 * CHUNK || /^https:\/\/cdn\.jsdelivr\.net\//.test(src)) {
        var r = await real(src); if (!r.ok) throw new Error("HTTP " + r.status);
        var b = await r.arrayBuffer(); if (sizes[url] && b.byteLength !== sizes[url]) throw new Error("cut short");
        got += b.byteLength; report(); await put(url, b); return b;
      }
      var n = Math.ceil(total / CHUNK), parts = new Array(n), meta = await get(url + "#meta");
      if (meta && meta.total === total) { for (var i = 0; i < n; i++) { var p = await get(url + "#" + i); if (p && p.byteLength === Math.min(total, (i + 1) * CHUNK) - i * CHUNK) { parts[i] = p; got += p.byteLength; } } }
      else await put(url + "#meta", { total: total, n: n, done: false });
      report();
      var next = 0;
      async function lane() {
        for (;;) {
          var k = -1; while (next < n) { if (!parts[next]) { k = next++; break; } next++; }
          if (k < 0) return;
          var a = k * CHUNK, z = Math.min(total, a + CHUNK) - 1;
          for (var t = 0; ; t++) {
            try {
              var rr = await real(src, { headers: { Range: "bytes=" + a + "-" + z } });
              if (rr.status !== 206) throw new Error("HTTP " + rr.status);
              var buf = await rr.arrayBuffer(); if (buf.byteLength !== z - a + 1) throw new Error("cut short");
              await put(url + "#" + k, buf); parts[k] = buf; got += buf.byteLength; report(); break;
            } catch (e) { if (t >= 6) throw e; await sleep(700 * (t + 1)); }
          }
        }
      }
      var lanes = []; for (var j = 0; j < Math.min(LANES, n); j++) lanes.push(lane());
      await Promise.all(lanes);
      await put(url + "#meta", { total: total, n: n, done: true });
      var all = new Uint8Array(total), o = 0; for (var q = 0; q < n; q++) { all.set(new Uint8Array(parts[q]), o); o += parts[q].byteLength; }
      return all.buffer;
    }
    function file(url) {
      if (inflight[url]) return inflight[url];
      return (inflight[url] = (async function () {
        var k = await kept(url); if (k) return k;
        var srcs = [mirrorOf(url), url].filter(Boolean), last = null;
        for (var i = 0; i < srcs.length; i++) {
          try { var total = sizes[url] || (/^https:\/\/cdn\.jsdelivr\.net\//.test(srcs[i]) ? 1 : await sizeAt(srcs[i])); return await pull(srcs[i], url, total); }
          catch (e) { last = e; }
        }
        throw last || new Error("unreachable");
      })().finally(function () { delete inflight[url]; }));
    }
    // what loading still needs, so the progress is of the whole download
    async function plan(urls) {
      for (var i = 0; i < urls.length; i++) if (!(await has(urls[i]))) want += sizes[urls[i]] || 0;
      report();
    }
    async function has(url) {
      var n = await db().then(function (d) { return new Promise(function (res) { try { var c = d.transaction("files").objectStore("files").count(url); c.onsuccess = function () { res(c.result); }; c.onerror = function () { res(0); }; } catch (e) { res(0); } }); });
      if (n) return true;
      var meta = await get(url + "#meta"); return !!(meta && meta.done);
    }
    var routes = [];
    async function blobUrl(url, type) { return URL.createObjectURL(new Blob([await file(url)], { type: type || "application/octet-stream" })); }
    async function importCode(url, fallback) {
      try { return await import(await blobUrl(url, "text/javascript")); }
      catch (e) { if (fallback) return import(fallback); throw e; }
    }
    // a jsDelivr "+esm" module with the modules it imports ("/npm/…/+esm"), each kept, their imports pointed at the kept
    // copies (Voice Answers' transformers.js: it, onnxruntime-web and onnxruntime-common)
    var esm = {};
    function esmUrl(url) {
      return esm[url] || (esm[url] = (async function () {
        var text = new TextDecoder().decode(await file(url)), deps = {}, re = /(?:from|import)\s*\(?\s*"(\/npm\/[^"]+)"/g, m;
        while ((m = re.exec(text))) deps[m[1]] = 1;
        for (var d in deps) text = text.split('"' + d + '"').join('"' + await esmUrl("https://cdn.jsdelivr.net" + d) + '"');
        return URL.createObjectURL(new Blob([text], { type: "text/javascript" }));
      })());
    }
    async function importEsm(url) {
      try { return await import(await esmUrl(url)); }
      catch (e) { return import(url); }   // (online: as jsDelivr serves it)
    }
    // the libraries' own fetches (models, voices) come here; a browser cache they'd keep copies in is one that keeps nothing
    self.fetch = function (input, init) {
      var url = typeof input === "string" ? input : input && input.href ? input.href : input && input.url;
      for (var i = 0; url && i < routes.length; i++) { var made = routes[i](url); if (made) return made; }
      if (url && /^https:\/\/(huggingface\.co\/[^?#]+\/resolve\/|cdn\.jsdelivr\.net\/npm\/)/.test(url)) {
        return file(url).then(function (b) { return new Response(b, { status: 200, headers: { "content-length": String(b.byteLength) } }); });
      }
      return real(input, init);
    };
    var none = { match: async function () {}, put: async function () {}, delete: async function () { return false; }, keys: async function () { return []; } };
    try { Object.defineProperty(self, "caches", { configurable: true, value: { open: async function () { return none; }, has: async function () { return false; }, delete: async function () { return false; }, keys: async function () { return []; }, match: async function () {} } }); } catch (e) {}
    self.voiceFiles = { plan: plan, file: file, has: has, blobUrl: blobUrl, importCode: importCode, importEsm: importEsm, route: function (fn) { routes.push(fn); } };
  }

  // a record's text as practice reads it (notes and pronunciation guides per the player's settings)
  function readText(q) {
    try { if (ctx.host && ctx.host.questionText) { var t = ctx.host.questionText(q, "question"); if (t != null) return String(t).replace(/\(\*\)/g, "").replace(/\s{2,}/g, " ").trim(); } } catch (e) {}
    return String((q && q.question_sanitized) || "").replace(/\(\*\)/g, "").trim();
  }
  function powerAt(q) { return String((q && q.question_sanitized) || "").indexOf("(*)"); }
  // sentences, without breaking at "St." or an initial ("J. R. R. Tolkien")
  var ABBR = /(?:\b(?:St|Ste|Mt|Mts|Dr|Mr|Mrs|Ms|Mme|Prof|Sr|Jr|Rev|Fr|Gen|Col|Capt|Lt|Sgt|Maj|Adm|Hon|Pres|Gov|Sen|Rep|vs|etc|cf|ca|al|Inc|Co|Corp|Ltd|Bros|approx|No|Nos|Op|op|no|Vol|vol|Ch|ch|Fig|fig|Ft|Pt|pt|Ave|[A-Za-z])\.["”’']?)$/;
  function sentences(text) {
    var parts = String(text || "").split(/(?<=[.?!]["”’)]*)\s+(?=["“(]?[A-Z0-9])/), out = [], cur = "";
    for (var i = 0; i < parts.length; i++) {
      cur = cur ? cur + " " + parts[i] : parts[i];
      if (i < parts.length - 1 && ABBR.test(cur.trim())) continue;
      out.push(cur.trim()); cur = "";
    }
    if (cur.trim()) out.push(cur.trim());
    return out.filter(Boolean);
  }
  // where each sentence of a text ends (indexes into it)
  function sentenceEnds(text) {
    var at = 0, out = []; text = String(text || "");
    sentences(text).forEach(function (x) { var i = text.indexOf(x, at); if (i < 0) return; at = i + x.length; out.push(at); });
    return out;
  }
  // ── categories (15.63): the app's own picker, its picks kept under `key` ([] = every category) ──
  // mountCats(root, key, onChange) puts it in root's [data-cats] (made once, moved into each new render);
  // inCats(pk, e): a history entry or question in the picks; with no picks, all are
  var PICKERS = {};
  // opts.label: "" for just the picks, in a row that has its own label
  function catPicker(key, onChange, opts) {
    if (PICKERS[key]) return PICKERS[key];
    if (!ctx.host || !ctx.host.categoryPicker) return null;
    var o = { selected: ctx.storage.get(key) || [], onChange: function (ids) { ctx.storage.set(key, ids); if (onChange) onChange(ids); } };
    if (opts && opts.label != null) o.label = opts.label;
    var pk = ctx.host.categoryPicker(null, o);
    PICKERS[key] = pk;
    // the picks match nothing until the tree is in: draw again once it is
    if (pk.ready && (ctx.storage.get(key) || []).length) pk.ready.then(function () { if (onChange) onChange(pk.get()); });
    return pk;
  }
  function mountCats(root, key, onChange, opts) {
    var pk = catPicker(key, onChange, opts), host = root && root.querySelector("[data-cats]");
    if (pk && host) host.appendChild(pk.el);
    return pk;
  }
  function inCats(pk, e) {
    if (!pk || !pk.get().length) return true;
    return pk.matches(String((e && (e.category_path || e.path || e.category || e.root)) || ""));
  }
  // ── the app's reader on a page titled for the plugin (15.63: ctx.host.playPractice). Its Setup picks the categories ──
  function canRead() { return !!(ctx.host && ctx.host.playPractice); }
  function onReader() { return !!(ctx.host && ctx.host.onPracticePage && ctx.host.onPracticePage()); }
  // a plugin's start page: an icon, what it is, a Start button (data-pk="start"), a note under it
  function heroHtml(icon, title, text, start, note) {
    return '<div class="pk-hero"><span class="pk-hero-ico">' + ic(icon, 26) + "</span><h2>" + esc(title) + "</h2><p>" + esc(text) + "</p>" +
      '<div class="pk-actions pk-center"><button type="button" class="btn btn-primary" data-pk="start">' + ic("play", 14) + esc(start || "Start") + "</button></div>" +
      (note ? '<div class="pk-muted pk-small">' + note + "</div>" : "") + "</div>";
  }
  // the answer line, with its bold and underlining (nothing else of the HTML)
  function answerHtml(q) {
    var h = String((q && q.answer) || "");
    if (!/<\/?(b|u|strong|em|i)\b/i.test(h)) return esc((q && q.answer_sanitized) || h);
    return h.replace(/<(\/?)(b|u|strong|em|i)\b[^>]*>/gi, "\u0001$1$2\u0002").replace(/<[^>]*>/g, "").replace(/&(?!(?:amp|lt|gt|quot|#\d+);)/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/\u0001(\/?)(\w+)\u0002/g, "<$1$2>");
  }
  function primary(q) {
    var a = "";
    try { if (ctx.host && ctx.host.extractPrimaryAnswer) a = ctx.host.extractPrimaryAnswer((q && q.answer) || "", (q && q.answer_sanitized) || ""); } catch (e) {}
    return a || String((q && q.answer_sanitized) || "").replace(/\s*[\[(].*$/, "").trim();
  }
  // an answer as a person reads it in a list: the line up to its first bracket ("Mary, Queen of Scots"), where primary()
  // runs the bold parts together for matching ("Mary, Queen of Scots Mary Stuart")
  function answerName(q) { return String((q && q.answer_sanitized) || "").replace(/\s*[\[(].*$/, "").trim() || primary(q); }
  // judged right here, like practice (judge.js); { status: "accept" | "prompt" | "reject", prompt }. opts.asAnswer: as the
  // answer box would judge the question on screen now (the player's strictness, the buzz, a prompt's answer; 15.92)
  async function judge(q, answer, opts) {
    opts = opts || {};
    try {
      if (ctx.host && ctx.host.judgeTossup) return (await ctx.host.judgeTossup(q, answer, { strictness: opts.strictness != null ? opts.strictness : (cfg().strictness || 10), buzzPosition: opts.buzzPosition, previous: opts.previous || null, asAnswer: !!opts.asAnswer })) || { status: "reject" };
      return (await ctx.api.post("/api/evaluate-tossup", { questionId: q.id, answer: answer, strictness: cfg().strictness || 10, buzzPosition: opts.buzzPosition, previous: opts.previous || null })) || { status: "reject" };
    } catch (e) { return { status: "reject" }; }
  }
  async function judgePart(b, part, answer, opts) {
    opts = opts || {};
    try {
      if (ctx.host && ctx.host.judgeBonusPart) return (await ctx.host.judgeBonusPart(b, part, answer, { strictness: cfg().strictness || 10, previous: opts.previous || null, asAnswer: !!opts.asAnswer })) || { status: "reject" };
      return (await ctx.api.post("/api/evaluate-bonus-part", { questionId: b.id, part: part, answer: answer, strictness: cfg().strictness || 10 })) || { status: "reject" };
    } catch (e) { return { status: "reject" }; }
  }
  async function judgeLine(line, sani, answer, opts) {
    opts = opts || {};
    try {
      if (ctx.host && ctx.host.judgeAnswerLine) return (await ctx.host.judgeAnswerLine(line, sani, answer, { strictness: cfg().strictness || 10, previous: opts.previous || null })) || { status: "reject" };
      return (await ctx.api.post("/api/evaluate-answer", { answerline: line, answer: answer, strictness: cfg().strictness || 10 })) || { status: "reject" };
    } catch (e) { return { status: "reject" }; }
  }
  function bonusParts(b) { try { return JSON.parse((b && (b.parts_sanitized || b.parts)) || "[]"); } catch (e) { return []; } }
  function bonusAnswers(b) { try { return JSON.parse((b && b.answers) || "[]"); } catch (e) { return []; } }
  function bonusAnswersSani(b) { try { return JSON.parse((b && b.answers_sanitized) || "[]"); } catch (e) { return []; } }

  // the player's answers (Stats' history), only the fields asked for
  async function history(fields) {
    try { return ((await ctx.api.get("/api/sessions/all-entries?" + (/\banswer\b/.test(fields || "") ? "answers=1&" : "") + "fields=" + encodeURIComponent(fields || ""))).entries) || []; } catch (e) { return []; }
  }
  // record a tossup answered on a plugin's page into the player's stats (the path Coach Mode uses)
  function record(q, r) {
    try {
      ctx.api.post("/api/check-tossup", { questionId: q.id, answer: r.answer || "", buzzPosition: r.buzzPosition || 0, sessionId: r.session, overriding: true,
        correct: !!r.correct, isPower: !!r.power, points: r.points || 0, celerity: r.celerity != null ? r.celerity : 1 }).catch(function () {});
    } catch (e) {}
  }

  var ROOT_COLOR = { "Literature": "#bc8cff", "Science": "#58a6ff", "Math": "#a5e05b", "Pop Culture": "#ff7b72", "Sports": "#ff6f91", "Fine Arts": "#f778ba", "History": "#e3b341", "Geography": "#56d364", "Mythology": "#ffa657", "Social Science": "#3dd6a3", "Philosophy": "#39c5cf", "Theology": "#8e9bff", "Current Events": "#c9d16b", "Miscellaneous": "#8b949e" };
  // NAQT's high school distribution, per 24 tossups / bonuses (naqt.com/hs/distribution.jsp)
  var NAQT = [["Literature", 3.9, 3.8], ["Science", 4.5, 4.3], ["Math", 1.0, 1.0], ["Fine Arts", 2.0, 2.0], ["History", 4.6, 4.5], ["Geography", 1.9, 1.9], ["Mythology", 0.6, 0.7],
    ["Pop Culture", 1.0, 0.9], ["Sports", 0.7, 0.7], ["Social Science", 0.6, 0.6], ["Philosophy", 0.3, 0.3], ["Theology", 0.4, 0.4], ["Current Events", 1.5, 1.4], ["Miscellaneous", 1.0, 1.5]];
  function rootOf(e) { return String((e && (e.category_path || e.category)) || "").split(" > ")[0] || "Miscellaneous"; }
  function dot(root) { return '<span class="pk-dot" style="--c:' + (ROOT_COLOR[root] || "#8b949e") + '"></span>'; }
  var _roots = null;
  async function roots() {
    if (_roots) return _roots;
    try { var t = ctx.host && ctx.host.getCategoryTree ? await ctx.host.getCategoryTree("tossups") : (await ctx.api.get("/api/category-tree?type=tossups")).tree; _roots = (t || []).map(function (n) { return { id: n.id, name: n.name, count: n.count }; }); }
    catch (e) { _roots = []; }
    return _roots;
  }
  var DIFF_NAME = { 0: "Unrated", 1: "Middle school", 2: "Easy high school", 3: "Regular high school", 4: "Hard high school", 5: "National high school", 6: "Easy college", 7: "Medium college", 8: "Regionals college", 9: "Nationals college", 10: "Open" };

  function tile(value, label, cls) { return '<div class="pk-tile' + (cls ? " " + cls : "") + '"><b class="num">' + value + "</b><span>" + esc(label) + "</span></div>"; }
  function segHtml(name, items, on) {
    return '<div class="seg pk-seg" role="group">' + items.map(function (it) {
      return '<button type="button" data-' + name + '="' + esc(it[0]) + '" aria-pressed="' + (String(on) === String(it[0])) + '">' + esc(it[1]) + "</button>";
    }).join("") + "</div>";
  }
  function emptyHtml(text) { return '<div class="db-empty pk-empty">' + esc(text) + "</div>"; }
  // square toggles 0 to 10, Setup's difficulty look (the app's .diff-toggles), `on` the ones picked; diffsIn reads them
  function diffHtml(name, on) {
    var h = '<div class="diff-toggles pk-diffs" role="group" aria-label="Difficulty">';
    for (var d = 0; d <= 10; d++) h += '<label title="' + esc(DIFF_NAME[d]) + '"><input type="checkbox" data-' + name + '="' + d + '"' + ((on || []).indexOf(d) >= 0 ? " checked" : "") + "><span>" + d + "</span></label>";
    return h + "</div>";
  }
  function diffsIn(root, name) { return [].slice.call(root.querySelectorAll("[data-" + name + "]")).filter(function (i) { return i.checked; }).map(function (i) { return Number(i.getAttribute("data-" + name)); }); }
  // a list of difficulties in a few words: [2, 3, 4, 5] → "2 to 5"
  function diffWords(ds) {
    ds = (ds || []).slice().sort(function (a, b) { return a - b; });
    if (!ds.length) return "any difficulty";
    var run = ds.every(function (d, i) { return !i || d === ds[i - 1] + 1; });
    return ds.length === 1 ? "difficulty " + ds[0] : run ? "difficulty " + ds[0] + " to " + ds[ds.length - 1] : "difficulty " + ds.join(", ");
  }
  function playList(kind, ids, title) {
    if (!ids || !ids.length) return false;
    try { return !!(ctx.host && ctx.host.launchQuestions && ctx.host.launchQuestions(kind, ids, { title: title })); } catch (e) { return false; }
  }

  // a reader: shows `text` a character at a time at the practice reading speed. start(), pause(), go(), stop();
  // at() is how far it is; onEnd once it's all shown
  function Reader(el, text, opts) {
    opts = opts || {};
    var ms = opts.ms != null ? opts.ms : (Number(cfg().revealSpeed) || 25), idx = 0, raf = 0, last = 0, on = false;
    var paint = function () { el.innerHTML = '<span class="pk-read">' + esc(text.slice(0, idx)) + '</span><span class="pk-unread" aria-hidden="true">' + esc(text.slice(idx)) + "</span>"; };
    var step = function (t) {
      raf = 0; if (!on) return;
      if (!last) last = t;
      var n = ms > 0 ? Math.floor((t - last) / ms) : text.length;
      if (n > 0) { idx = Math.min(text.length, idx + n); last += n * ms; paint(); if (opts.onTick) opts.onTick(idx); }
      if (idx >= text.length) { on = false; if (opts.onEnd) opts.onEnd(); return; }
      raf = requestAnimationFrame(step);
    };
    paint();
    return {
      start: function () { if (on) return; on = true; last = 0; raf = requestAnimationFrame(step); },
      pause: function () { on = false; if (raf) cancelAnimationFrame(raf); raf = 0; },
      stop: function () { on = false; if (raf) cancelAnimationFrame(raf); raf = 0; },
      showAll: function () { this.stop(); idx = text.length; el.textContent = text; },
      at: function () { return idx; },
      running: function () { return on; },
    };
  }
  // a reader's position in the displayed text → the record's question_sanitized (what judging and stats count)
  function serverPos(q, display, pos) {
    try { if (ctx.host && ctx.host.mapDisplayPos) return ctx.host.mapDisplayPos(display, (q && q.question_sanitized) || "", pos); } catch (e) {}
    return pos;
  }

  // ── Voice Answers: say your answer after you buzz; what you say goes into the answer box and is sent ──
  // 2.0 (15.63): speech is turned into text on this computer by a small Whisper model (transformers.js, in a worker),
  // so it works in the desktop app and every browser, offline once the model is downloaded. The browser's own speech
  // recognition (1.x) didn't work in the app, and in Chrome it took seconds to start listening, so an answer said
  // right after the buzz was lost. Now the microphone stays open while a practice session runs: a buzz keeps the
  // last moment before it too, the answer ends when you stop talking, and it's written down and sent.
  // 3.0 (15.69): an answer is judged by how it sounds, as a moderator would: when what Whisper wrote isn't accepted, its
  // words are matched by sound to the answer line's ("Tony Morrison", "the crib cycle", "Chinua Chebe") and that spelling
  // goes in if it's accepted. Whisper's files and transformers.js come through voiceFilesWorker (kit.js): from our server
  // in ranges kept as they arrive, then from IndexedDB, offline too (2.x took transformers.js from jsDelivr at every
  // start). A clap or a shout buzzes while a tossup is read ("Say buzz" listened for the word, which was slow and
  // missed); talking doesn't. Moonshine was tried for speed (six times faster), but it heard spoken names far worse.
  // 4.0 (15.70): as quick as Dictation. In the Mac app what you say goes to Apple's own recognizer (the one Dictation
  // uses; the app's qb-speech helper, host.nativeSpeech): the words show in the box as you say them, on the Mac with
  // no internet, listening for the answer line's words. An answer that's already right goes the moment you stop (a
  // third of a second); anything else after the usual pause, so "Toni... Morrison" isn't cut at "Toni". Elsewhere
  // Whisper starts writing at the first pause, a quarter second sooner than 3.0. The voice reading the
  // question isn't taken for the answer any more ("Just shoot. Helios"): listening starts once it has been quiet a
  // moment, without the half second before the buzz while it was talking (host.voiceQuietFor).
  // 4.6 (15.92): what it hears is judged as the answer box would judge it (asAnswer: the player's strictness, the buzz,
  // a prompt's answer); a pause after an answer's first word is waited out ("Final", a breath, then "Fantasy VI" went
  // in as "Final"); Say final to send is a setting, and only "final answer" sends when the answer has the word; a
  // listen still on its way when the question changed no longer starts on the next one. Clap or shout to buzz learns
  // how loud you talk only from your talking (runs of 120 ms, never the read-aloud voice, a clap or a click), so a
  // clap can always reach its bar, and a clap is decided over 40 ms from a quiet start with weight to it (a split beep
  // and a key's click aren't). tests: scratchpad lc/vat.mjs, a microphone the test plays into.
  // 4.7 (15.93): multiplayer rooms too. A clap or a shout buzzes in the room in front (host.buzz / host.buzzOpen go to
  // the room), and an answer said after the room gives the buzz goes in its box (room:buzz, room:prompt, room:bonus).
  // The room judges it, so nothing is judged here and it's sent when you stop talking, or at "final".
  var TF ="https://cdn.jsdelivr.net/npm/@huggingface/transformers@3.8.1/+esm";
  var ORT = "https://cdn.jsdelivr.net/npm/@huggingface/transformers@3.8.1/dist/ort-wasm-simd-threaded.jsep.";
  var BASE = "https://huggingface.co/onnx-community/whisper-base.en/resolve/main/", TINY = "https://huggingface.co/onnx-community/whisper-tiny.en/resolve/main/";
  var SIZES = {};
  SIZES[BASE + "onnx/encoder_model.onnx"] = 82468078; SIZES[BASE + "onnx/decoder_model_merged_quantized.onnx"] = 53692803; SIZES[BASE + "tokenizer.json"] = 2405679;
  SIZES[TINY + "onnx/encoder_model_quantized.onnx"] = 10124993; SIZES[TINY + "onnx/decoder_model_merged_quantized.onnx"] = 30718858; SIZES[TINY + "tokenizer.json"] = 2405679;
  SIZES[ORT + "wasm"] = 21596019; SIZES[ORT + "mjs"] = 44484;
  var RATE = 16000, BLOCK = 320;                         // 20 ms blocks at 16 kHz
  var worker = null, wready = false, wloading = null, wfail = "", wq = {}, wid = 0, busy = 0, dlFns = [];
  var WHISPER_JSON = ["added_tokens.json", "config.json", "generation_config.json", "normalizer.json", "preprocessor_config.json", "special_tokens_map.json", "tokenizer.json", "tokenizer_config.json", "vocab.json"];
  var mic = null, micOpening = null;
  var cap = null;                                         // what's being listened for: { mode, target, … }
  var pill = null, pillT = 0, history = [], floor = 0.004;
  var zeros = 0, silentSaid = false, heardAny = false;    // pure digital silence from the start: a mic the system won't let us hear
  // the answer clock waits while the answer is still being heard or written down (the model may still be downloading)
  var held = false, holdT = 0;
  function hold(on) {
    if (!!on === held) return; held = !!on;
    clearTimeout(holdT); if (held) holdT = setTimeout(function () { hold(false); }, 45000);   // never longer than this (a stuck download)
    try { if (ctx.host && ctx.host.holdAnswerTime) ctx.host.holdAnswerTime(held); } catch (e) {}
  }

  function opt(k) { var v = ctx.getSetting(k); return v == null ? true : v; }
  // (4.7) a multiplayer room in front counts as playing (the base's host.roomFront; an older base has none)
  function roomFront() { try { return !!(ctx.host && ctx.host.roomFront && ctx.host.roomFront()); } catch (e) { return false; } }
  function practiceOn() { var s = ctx.getState(); return !!(s && s.sessionActive) || roomFront(); }
  // a room's answer box: the room judges it (its answer line isn't on this page), so nothing here is judged early
  function roomBox(t) { return !!(t && (t.id === "mp-ans-input" || (t.classList && t.classList.contains("mp-binput")))); }

  // ── the pill: what it's doing, with the microphone's level while it listens ──
  function showPill(text, cls, ms) {
    if (!pill) { pill = document.createElement("div"); pill.className = "va-pill"; pill.setAttribute("role", "status"); ctx.mount(pill); }
    clearTimeout(pillT);
    pill.className = "va-pill" + (cls ? " " + cls : "");
    pill.innerHTML = ic("mic", 14) + '<span class="va-lvl" aria-hidden="true"><i></i></span><span class="va-txt">' + esc(text) + "</span>";
    pill.hidden = false;
    if (ms) pillT = setTimeout(hidePill, ms);
  }
  function pillText(text) { var t = pill && pill.querySelector(".va-txt"); if (t) t.textContent = text; else showPill(text, "va-on"); }
  function hidePill() { clearTimeout(pillT); if (pill) pill.hidden = true; }
  function level(v) { var i = pill && !pill.hidden && pill.querySelector(".va-lvl i"); if (i) i.style.transform = "scaleX(" + Math.min(1, v * 18).toFixed(3) + ")"; }

  // ── the model, in a worker: Whisper base.en on the GPU's encoder when there is one (about 160 MB with its runtime, half
  // a second an answer), else tiny.en on the processor (about 65 MB) ──
  var WORKER = "(" + voiceFilesWorker.toString() + ")(" + JSON.stringify({ mirror: voiceMirror(), db: "qb-voice-models", sizes: SIZES }) + ");\n" + [
    "const V = self.voiceFiles, TF = " + JSON.stringify(TF) + ", ORT = " + JSON.stringify(ORT) + ", BASE = " + JSON.stringify(BASE) + ", TINY = " + JSON.stringify(TINY) + ";",
    "const JSONS = " + JSON.stringify(WHISPER_JSON) + ";",
    "let asr = null, gpu = false, fetching = null;",
    '  const files = (g) => g ? [BASE + "onnx/encoder_model.onnx", BASE + "onnx/decoder_model_merged_quantized.onnx"] : [TINY + "onnx/encoder_model_quantized.onnx", TINY + "onnx/decoder_model_merged_quantized.onnx"];',
    "// every file for this computer (base.en with a GPU, tiny.en without), downloaded and kept; a load waits on the same",
    "async function filesFor() {",
    "  try { gpu = !!(navigator.gpu && await navigator.gpu.requestAdapter()); } catch (e) {}",
    '  return [TF, ORT + "mjs", ORT + "wasm"].concat(files(gpu), JSONS.map((f) => (gpu ? BASE : TINY) + f));',
    "}",
    "function fetchAll() {",
    "  return fetching || (fetching = (async () => {",
    "    const all = await filesFor();",
    "    await V.plan(all);",
    "    await Promise.all(all.map((f) => V.file(f)));",
    "    await V.importEsm(TF);   // and the modules it imports",
    "  })().catch((e) => { fetching = null; throw e; }));",
    "}",
    "async function haveAll() { for (const f of await filesFor()) if (!(await V.has(f))) return false; return true; }",
    "async function load() {",
    "  await fetchAll();",
    "  const T = await V.importEsm(TF);",
    "  T.env.allowLocalModels = false; T.env.useBrowserCache = false; T.env.useCustomCache = false;",
    '  T.env.backends.onnx.wasm.wasmPaths = { mjs: await V.blobUrl(ORT + "mjs", "text/javascript"), wasm: await V.blobUrl(ORT + "wasm", "application/wasm") };',
    '  const make = (g) => T.pipeline("automatic-speech-recognition", g ? "onnx-community/whisper-base.en" : "onnx-community/whisper-tiny.en", g ? { device: { encoder_model: "webgpu", decoder_model_merged: "wasm" }, dtype: { encoder_model: "fp32", decoder_model_merged: "q8" } } : { device: "wasm", dtype: "q8" });',
    "  try { asr = await make(gpu); } catch (e) { if (!gpu) throw e; gpu = false; await V.plan(files(false)); asr = await make(false); }",
    "  await asr(new Float32Array(16000));   // the first run is slow; better now than on an answer",
    "}",
    "self.onmessage = async (e) => {",
    "  const m = e.data;",
    "  try {",
    '    if (m.t === "load") { await load(); postMessage({ t: "ready", id: m.id }); }',
    '    else if (m.t === "fetch") { await fetchAll(); postMessage({ t: "fetched", id: m.id }); }',
    '    else if (m.t === "have") postMessage({ t: "have", id: m.id, text: await haveAll() });',
    '    else if (m.t === "run") { const o = await asr(m.audio, { max_new_tokens: 32 }); postMessage({ t: "text", id: m.id, text: String((o && o.text) || "").trim() }); }',
    '  } catch (err) { postMessage({ t: "error", id: m.id, error: String((err && err.message) || err) }); }',
    "};",
  ].join("\n");
  // busy: answers being written down (Whisper's runs; a download or a load isn't one)
  function call(msg) {
    return new Promise(function (res, rej) { var id = ++wid; msg.id = id; wq[id] = { res: res, rej: rej, run: msg.t === "run" }; if (msg.t === "run") busy++; worker.postMessage(msg, msg.audio ? [msg.audio.buffer] : []); });
  }
  function ensureWorker() {
    if (worker) return;
    worker = new Worker(URL.createObjectURL(new Blob([WORKER], { type: "text/javascript" })), { type: "module" });
    worker.onmessage = function (e) {
      var m = e.data;
      if (m.t === "progress") {
        var f = m.total ? m.loaded / m.total : 0;
        dlFns.forEach(function (fn) { try { fn(f); } catch (x) {} });
        if (!cap && m.total && wloading && practiceOn()) showPill("Loading voice answers " + Math.round(100 * f) + "%", "va-off");
        return;
      }
      var w = wq[m.id]; if (!w) return; delete wq[m.id]; if (w.run) busy = Math.max(0, busy - 1);
      if (m.t === "error") w.rej(new Error(m.error)); else w.res(m.text);
    };
    worker.onerror = function () { wfail = "Voice answers couldn't start"; };
  }
  // (4.1) Getting it from the Store downloads the speech model there, the card showing how far (ctx.registerDownload);
  // otherwise it comes down with the first question, as before
  function download(onProgress) {
    try { ensureWorker(); } catch (e) { return Promise.reject(e); }
    if (onProgress) dlFns.push(onProgress);
    var off = function () { dlFns = dlFns.filter(function (fn) { return fn !== onProgress; }); };
    return call({ t: "fetch" }).then(off, function (e) { off(); throw e; });
  }
  if (ctx.registerDownload) ctx.registerDownload({ done: function () { if (wready) return true; try { ensureWorker(); } catch (e) { return true; } return call({ t: "have" }); }, start: download });
  function loadModel() {
    if (wready) return Promise.resolve();
    if (wloading) return wloading;
    wfail = "";
    try { ensureWorker(); }
    catch (e) { wfail = "This browser can't run voice answers"; return Promise.reject(e); }
    wloading = call({ t: "load" }).then(function () { wready = true; if (!cap && practiceOn()) showPill("Voice answers ready", "va-off", 2200); })
      .catch(function (e) { wloading = null; wfail = /fetch|network|Failed/i.test(String(e && e.message)) ? "Connect to the internet once to download voice answers" : "Voice answers couldn't start"; try { worker.terminate(); } catch (x) {} worker = null; throw e; });
    return wloading;
  }

  // ── the microphone, open while a session runs: 20 ms blocks at 16 kHz, the last second kept ──
  function openMic() {
    if (mic) return Promise.resolve(mic);
    if (micOpening) return micOpening;
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) return Promise.reject(new Error("nomic"));
    // (2.1) the raw sound, levelled: Whisper hears speech best as it is, and the browser's noise suppression smeared
    // words ("Wolf gangamidase" for Wolfgang Amadeus). The voice reading aloud has stopped by the time an answer is said
    // (3.0) and no automatic gain: it flattened a clap or a shout down to the level of talking. Answers are levelled here
    micOpening = navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: false, noiseSuppression: false, autoGainControl: false, channelCount: 1 } }).then(function (stream) {
      var AC = window.AudioContext || window.webkitAudioContext, ac = new AC();
      var src = ac.createMediaStreamSource(stream), proc = ac.createScriptProcessor(2048, 1, 1), mute = ac.createGain();
      mute.gain.value = 0;
      var step = ac.sampleRate / RATE, pos = 0, part = new Float32Array(BLOCK), n = 0, pk = 0;
      // down to 16 kHz (each output sample the mean of the input samples it covers), then into 20 ms blocks; each block's
      // peak is taken before that (averaging flattens a clap's spike)
      proc.onaudioprocess = function (e) {
        var x = e.inputBuffer.getChannelData(0);
        while (pos < x.length) {
          var a = Math.floor(pos), b = Math.min(x.length, Math.floor(pos + step)), s = 0;
          for (var i = a; i < Math.max(b, a + 1); i++) { s += x[i]; var m = x[i] < 0 ? -x[i] : x[i]; if (m > pk) pk = m; }
          part[n++] = s / Math.max(1, b - a);
          if (n === BLOCK) { onBlock(part, pk); part = new Float32Array(BLOCK); n = 0; pk = 0; }
          pos += step;
        }
        pos -= x.length;
      };
      src.connect(proc); proc.connect(mute); mute.connect(ac.destination);
      mic = { stream: stream, ac: ac, src: src, proc: proc };
      micOpening = null;
      return mic;
    }, function (e) { micOpening = null; throw e; });
    return micOpening;
  }
  function closeMic() {
    if (!mic) return;
    try { mic.proc.onaudioprocess = null; mic.src.disconnect(); mic.proc.disconnect(); } catch (e) {}
    try { mic.stream.getTracks().forEach(function (t) { t.stop(); }); } catch (e) {}
    try { mic.ac.close(); } catch (e) {}
    mic = null; history = []; zeros = 0; heardAny = false; silentSaid = false;
  }

  // ── listening: speech is louder than the room. It starts after 60 ms above the bar and ends after a quiet spell ──
  function rms(b) { var s = 0; for (var i = 0; i < b.length; i++) s += b[i] * b[i]; return Math.sqrt(s / b.length); }
  function peak(b) { var m = 0; for (var i = 0; i < b.length; i++) { var a = b[i] < 0 ? -b[i] : b[i]; if (a > m) m = a; } return m; }
  // A microphone the system blocks still opens, but every sample is exactly 0 (a real room never is). Three seconds of
  // that, with no sound at all since it opened, and we say so: on a Mac, the app needs the microphone allowed in System
  // Settings (and the app from 15.65's download, which asks for it; the copy before couldn't).
  function silentMic() {
    if (silentSaid) return;
    silentSaid = true;
    var app = !!window.qbreader, mac = /Mac/i.test(navigator.platform || navigator.userAgent || "");
    showPill(app && mac ? "Microphone is silent. Allow OfflineQuiz in System Settings, Privacy, Microphone"
      : "Microphone is silent. Check that it's allowed and unmuted", "va-off", 9000);
    if (cap && cap.mode === "answer") stopCap();
  }
  function onBlock(b, pk) {
    var v = rms(b);
    if (v === 0) { if (++zeros >= 150 && !heardAny) silentMic(); } else { zeros = 0; heardAny = true; }
    history.push(b); if (history.length > 50) history.shift();          // the last second
    if (!cap || !cap.speaking) floor = floor * 0.97 + Math.min(v, floor * 3 + 0.002) * 0.03;   // the room, while nobody talks
    var bar = Math.max(0.007, floor * 3);
    if (cap) level(v);
    if (!cap) { loudCheck(v, pk == null ? peak(b) : pk, b); return; }
    cap.blocks.push(b);
    if (cap.fast) fastAudio(cap, b);
    if (v > cap.peak) cap.peak = v;
    if (v > bar) { cap.loud++; cap.quiet = 0; cap.last = cap.blocks.length; if (cap.loud >= 3 && !cap.speaking) { cap.speaking = true; cap.from = Math.max(0, cap.blocks.length - 3 - 10); } }
    else { cap.loud = 0; if (cap.speaking) cap.quiet++; }
    var dur = cap.blocks.length * BLOCK / RATE, still = cap.quiet * 20;
    if (cap.speaking && still >= cap.endMs && !(still < 1500 && startsAnswer(cap))) return finish();
    if (cap.speaking && dur > cap.maxSec) return finish();
    if (cap.speaking) {
      // (4.0) right already: it goes after a moment's quiet (4.3: with Send when I stop talking off too, as Enter would).
      // Whisper starts writing at the first pause
      if (still >= 180) early(cap);
      if (still >= 150 && wready && !busy && (!cap.spec || cap.spec.last !== cap.last)) speculate(cap);
    }
    // seven seconds and no clear speech: something quiet was still said, maybe (a soft voice, a far mic), so it's
    // written down anyway; only a quiet room gives up
    if (!cap.speaking && dur > 7) {
      if (cap.peak > Math.max(0.004, floor * 1.8)) { cap.speaking = true; cap.from = 0; cap.last = cap.blocks.length; return finish(); }
      if (cap.quietStart) { stopCap(); return; }   // listening on for "final" after an answer: nothing more was said
      var t = cap.target; stopCap(); if (t && t.isConnected) showPill("Nothing heard. Type it or press V to retry", "va-off", 3500);
    }
  }
  // ── a clap or a shout buzzes (3.0): a sound well above how loud you talk here (and the room). Talking does nothing,
  // and neither does the read-aloud voice (it counts as talking). A clap is told by its peak: it hits the top, where
  // talking peaks at a third of that and the voice from the speakers under half; with some weight to it (a 20 ms block
  // of real sound). A shout is that, or two blocks in a row far louder than talking. Measured on a recording of talking,
  // the read-aloud voice, a clap and a shout (each level: the clap and the shout buzz, nothing else does) ──
  var talk = 0.03, talkPeak = 0.25, talkHist = [], peakHist = [], loudRun = 0, loudAt = 0, loudCool = 0, loudVoiced = false;
  var talkRun = [], inTalk = false;   // (4.6) talking is a run of loud blocks, 120 ms at least (a syllable)
  var loudPrev = null;                // (4.6) the loud block before this one, heard with it
  var clapPend = null;                // (4.6) a clap's first block, decided with the one after it
  var lastV = 0;                      // the block before this one, how loud
  // (4.6) the read-aloud voice from the speakers, measured apart from your talking: its level and its high peaks
  var ttsV = 0, ttsPeak = 0, ttsHist = [], ttsPkHist = [];
  // (4.4) a beep isn't a clap. The pop a Mac plays when the volume changes is one 20 ms block, as sharp as a clap, but
  // nearly all of it is one note (a 500 Hz tone: 0.92 to 0.98 of its energy in one narrow band, 0.68 through a thin
  // speaker), where a clap spreads over many (0.06 to 0.14). Talking lands anywhere (half its blocks above 0.62), so a
  // shout only needs one block in its run that isn't a pure note. The volume keys, where the browser is told of them,
  // hold buzzing off for a moment
  function noteShare(b) {
    var N = 512, re = new Float32Array(N), im = new Float32Array(N);
    for (var i = 0; i < b.length && i < N; i++) re[i] = b[i] * (0.5 - 0.5 * Math.cos(2 * Math.PI * i / (b.length - 1)));
    for (var i2 = 1, j = 0; i2 < N; i2++) { var bit = N >> 1; for (; j & bit; bit >>= 1) j ^= bit; j ^= bit; if (i2 < j) { var t = re[i2]; re[i2] = re[j]; re[j] = t; } }
    for (var len = 2; len <= N; len <<= 1) {
      var ang = -2 * Math.PI / len, wr = Math.cos(ang), wi = Math.sin(ang);
      for (var st = 0; st < N; st += len) {
        var cr = 1, ci = 0;
        for (var k = 0; k < len / 2; k++) {
          var a = st + k, c = a + len / 2, xr = re[c] * cr - im[c] * ci, xi = re[c] * ci + im[c] * cr;
          re[c] = re[a] - xr; im[c] = im[a] - xi; re[a] += xr; im[a] += xi;
          var nr = cr * wr - ci * wi; ci = cr * wi + ci * wr; cr = nr;
        }
      }
    }
    var P = new Float32Array(N / 2), tot = 0, top = 1;
    for (var f = 2; f < N / 2; f++) { P[f] = re[f] * re[f] + im[f] * im[f]; tot += P[f]; if (P[f] > P[top]) top = f; }
    var near = 0; for (var g = Math.max(2, top - 3); g <= Math.min(N / 2 - 1, top + 3); g++) near += P[g];
    return tot > 0 ? near / tot : 0;
  }
  window.addEventListener("keydown", function (e) {
    if (/^Audio(Volume(Up|Down|Mute))$/.test(e.key || "")) loudCool = Math.max(loudCool, performance.now() + 1200);
  }, true);
  var LOUD = { loud: [2.5, 1.6, 0.45], louder: [3.5, 2, 0.6], very: [5, 2.6, 0.75] };   // × how loud talking is, × its peaks, the least peak
  function loudArmed() {
    if (!ctx.getSetting("loudBuzz") || cap) return false;
    // (4.7) the base says when a buzz is open, in practice or in a room
    if (ctx.host && ctx.host.buzzOpen) { try { return !!ctx.host.buzzOpen(); } catch (e) { return false; } }
    var s = ctx.getState();
    return !!(s && s.sessionActive && s.mode === "tossups" && s.currentQuestion && !s.isBuzzed && !s.resultShown);
  }
  function loudK() { return LOUD[ctx.getSetting("loudLevel")] || LOUD.louder; }
  function loudBar() { return Math.max(0.08, floor * 25, talk * loudK()[0]); }
  function loudCheck(v, pk, b) {
    var cool = performance.now() < loudCool, vq = voiceQuiet(), voice = vq < 250;   // the read-aloud voice sounding (or its echo)
    var pv = lastV; lastV = v;
    // how loud talking is here: the blocks that sound like speech over the last 20 seconds, their middle level and their
    // high peaks. (4.6) Yours only: not the read-aloud voice's (it counted, and from loud speakers it put the clap's bar
    // past the loudest a microphone hears, so no clap buzzed), nor a clap or a shout that buzzed
    // (4.6) A clap, a tap or a click is over in a few blocks, and one that didn't buzz was learned as talking: its peak
    // went into how loud you talk and the next clap's bar went past what a microphone hears. Only a run of six loud
    // blocks or more counts
    var learn = function (x, y) {
      talkHist.push(x); peakHist.push(y); if (talkHist.length > 1000) { talkHist.shift(); peakHist.shift(); }
      if (talkHist.length % 25 === 0) {
        var a = talkHist.slice().sort(function (p, q) { return p - q; }), b2 = peakHist.slice().sort(function (p, q) { return p - q; });
        talk = Math.max(0.01, a[a.length >> 1]); talkPeak = Math.max(0.1, b2[Math.floor(b2.length * 0.9)]);
      }
    };
    if (v > floor * 3 && v > 0.004 && !cool && !voice) {
      if (inTalk) learn(v, pk || 0);
      else { talkRun.push([v, pk || 0]); if (talkRun.length >= 6) { inTalk = true; talkRun.forEach(function (x) { learn(x[0], x[1]); }); talkRun = []; } }
    } else { talkRun = []; inTalk = false; }
    if (v > floor * 3 && v > 0.004 && !cool && vq === 0) {
      ttsHist.push(v); ttsPkHist.push(pk || 0); if (ttsHist.length > 500) { ttsHist.shift(); ttsPkHist.shift(); }
      if (ttsHist.length % 25 === 0) {
        var c = ttsHist.slice().sort(function (x, y) { return x - y; }), d = ttsPkHist.slice().sort(function (x, y) { return x - y; });
        ttsV = c[Math.floor(c.length * 0.9)]; ttsPeak = d[Math.floor(d.length * 0.95)];
      }
    }
    if (!loudArmed() || cool) { loudRun = 0; loudVoiced = false; loudPrev = null; clapPend = null; return; }
    var k = loudK(), bar = loudBar();
    // a clap's peak: past how loud you talk, but never past what a microphone can hear (0.9); while the voice reads,
    // past its loudest too
    var clapBar = Math.min(0.9, Math.max(k[2], talkPeak * k[1]));
    // (until the voice has been heard a moment, as loud as a voice from speakers near the microphone gets)
    if (voice) { var tv = ttsHist.length >= 25 ? ttsV : Math.max(ttsV, 0.15), tp = ttsHist.length >= 25 ? ttsPeak : Math.max(ttsPeak, 0.6); clapBar = Math.max(clapBar, Math.min(0.97, tp * 1.35)); bar = Math.max(bar, tv * 1.8); }
    // (4.6) and it starts there: the block before was half as loud at most (the tail of a beep, after its loud part,
    // was sharp enough to pass)
    // and with weight to it: a clap's 20 ms (as heard here, at 16 kHz) are a tenth of its peak or more, a key's click
    // (a millisecond or two) 0.06
    var clap = (pk || 0) > clapBar && v > Math.max(0.05, talk * k[0] * 0.6) && pv < v * 0.5 && v > (pk || 0) * 0.08;
    // a beep (one note) isn't a clap, and a run of beeps isn't a shout
    var share = (clap || v > bar) && b ? noteShare(b) : 0;
    if (clap && share > 0.5) clap = false;
    // (4.6) a clap is decided over its first block and the next, 20 ms later: a beep that starts at the end of a block
    // leaves a sliver there, sharp and with no one note in it, and was taken for a clap
    var clapNow = false;
    if (clapPend) {
      var both = new Float32Array(clapPend.length + (b ? b.length : 0)); both.set(clapPend); if (b) both.set(b, clapPend.length);
      clapNow = noteShare(both) <= 0.5; clapPend = null;
    }
    if (clap) { if (!clapNow) clapPend = b; clap = clapNow; } else clap = clapNow;
    // (4.6) a shout's voice is heard over two blocks together: a beep that starts in the middle of one left a sliver
    // in it, which on its own sounded like a voice (0.57), and the Mac's volume pop buzzed one time in two
    if (v > bar && loudPrev && b) { var pair = new Float32Array(loudPrev.length + b.length); pair.set(loudPrev); pair.set(b, loudPrev.length); if (noteShare(pair) < 0.85) loudVoiced = true; }
    loudPrev = v > bar ? b : null;
    if (clap || (v > bar && ++loudRun >= 2 && (loudVoiced || loudRun >= 4))) {
      loudRun = 0; loudVoiced = false; loudCool = performance.now() + 1500;
      if (ctx.host && ctx.host.buzz && ctx.host.buzz()) loudAt = performance.now();
    } else if (v <= bar) { loudRun = 0; loudVoiced = false; }
  }
  // ── the quick recognizer (4.0), as Dictation is: the Mac app's (Apple's own, through the app's qb-speech helper,
  // host.nativeSpeech; biased to the answer line's words, on the Mac) or the browser's (Chrome, Edge, Safari:
  // SpeechRecognition, handed the microphone already open, so it starts listening at once where 1.x lost the first
  // word). Its words show in the box as they're said, and an answer it hears right goes at the first pause. Whisper
  // still writes each answer down, and when the quick one isn't right, Whisper's words are judged too: it hears names
  // better (80 of 90 spoken answers right, Chrome's 62), the quick one is half a second sooner ──
  var nat = { p: null, ok: false, off: null, sid: 0, on: {}, told: false };
  function natApi() { return ctx.host && ctx.host.nativeSpeech; }
  function native() {
    if (nat.p) return nat.p;
    var api = natApi();
    if (!api) return (nat.p = Promise.resolve(false));
    if (!nat.off) nat.off = api.on(onNat);
    return (nat.p = api.hello().then(function (h) {
      nat.ok = !!(h && h.auth === "authorized" && h.available);
      if (h && (h.auth === "denied" || h.auth === "restricted") && !nat.told) { nat.told = true; showPill("For faster voice answers, allow OfflineQuiz in System Settings, Privacy, Speech Recognition", "va-off", 7000); }
      return nat.ok;
    }, function () { return false; }));
  }
  function onNat(m) {
    if (!m) return;
    var f = nat.on[m.id]; if (f) f(m);
    // the helper stopped: Whisper alone from here (the sound so far is kept)
    if (m.t === "exit") { nat.ok = false; if (cap && cap.fast === "apple") { cap.fast = ""; loadModel().catch(function () {}); } if (cap && cap.onFinal) cap.onFinal(); }
  }
  // the browser's (not in the app: the app's Chromium has no recognizer). A network that fails sets it aside a minute
  var SRC = (!window.qbreader && (window.SpeechRecognition || window.webkitSpeechRecognition)) || null;
  var web = { downAt: 0 };
  function webOk() { return !!SRC && !!(mic && mic.stream) && Date.now() - web.downAt > 60000; }
  // the words the answer can be said with: the answer, what it accepts or prompts on, the hidden accepts
  function vocabFor(target) {
    if (roomBox(target)) return [];
    var s = ctx.getState(), q = s && s.currentQuestion; if (!q) return [];
    var pm = /^bonus-input-(\d+)$/.exec((target && target.id) || ""), part = pm ? +pm[1] : -1;
    var line = String((part >= 0 ? bonusAnswersSani(q)[part] : q.answer_sanitized) || ""), hid = q._hidden; if (Array.isArray(hid)) hid = hid[part] || null;
    var out = [], seen = {}, m, re = /(?:^|[\[(;])\s*(?:also\s+)?(?:accept|prompt on)\s+([^;\])]+)/gi;
    var add = function (x) { x = String(x || "").replace(/["“”]/g, "").replace(/\s+/g, " ").trim(); var k = x.toLowerCase(); if (x && x.length <= 60 && !seen[k]) { seen[k] = 1; out.push(x); } };
    add(line.replace(/[\[(].*$/, ""));
    while ((m = re.exec(line))) m[1].split(/\s+or\s+|,/).forEach(add);
    ((hid && hid.accept) || []).forEach(add);
    vocabOf(line, hid).forEach(add);
    return out.slice(0, 100);
  }
  // its words: c.live as they come; c.final once it's been told the answer's over
  function heard(c, text, final) {
    c.live = String(text || "").replace(/\s+/g, " ").trim();
    if (cap === c && sayFinal(c, c.live)) return;
    if (final && c.ended) { c.final = c.live; if (c.onFinal) c.onFinal(); }
    if (cap === c && c.live) liveText(c, c.live);
  }
  function fastStart(c) {
    if (nat.ok) {
      var api = natApi();
      c.sid = ++nat.sid; c.fast = "apple";
      nat.on[c.sid] = function (m) {
        if (m.t === "text") heard(c, m.text, m.final);
        else if (m.t === "error") { if (!c.ended && cap === c) c.fast = ""; if (c.onFinal) c.onFinal(); }   // Whisper alone then
      };
      api.start(c.sid, vocabFor(c.target), "search");
      c.blocks.forEach(function (b) { api.audio(c.sid, b); });
      return;
    }
    if (!webOk()) return;
    var rec; try { rec = new SRC(); } catch (e) { return; }
    rec.lang = "en-US"; rec.continuous = true; rec.interimResults = true; rec.maxAlternatives = 1;
    rec.onresult = function (e) { var t = ""; for (var i = 0; i < e.results.length; i++) t += e.results[i][0].transcript; heard(c, t, e.results[e.results.length - 1].isFinal); };
    rec.onerror = function (e) {
      if (e.error === "network" || e.error === "not-allowed" || e.error === "service-not-allowed" || e.error === "language-not-supported") { web.downAt = Date.now(); if (!c.ended && cap === c) c.fast = ""; }
      if (c.onFinal) c.onFinal();
    };
    rec.onend = function () { if (c.onFinal) c.onFinal(); };
    try { rec.start(mic.stream.getAudioTracks()[0]); } catch (e) { try { rec.start(); } catch (e2) { return; } }
    c.rec = rec; c.fast = "web";
  }
  function fastAudio(c, b) { if (c.fast === "apple" && c.sid) { var api = natApi(); if (api) api.audio(c.sid, b); } }
  function fastCancel(c) {
    if (!c) return;
    if (c.sid) { delete nat.on[c.sid]; var api = natApi(); if (api) api.cancel(); c.sid = 0; }
    if (c.rec) { try { c.rec.onresult = c.rec.onerror = c.rec.onend = null; c.rec.abort(); } catch (e) {} c.rec = null; }
  }
  // the quick one's last words: it's told the answer's over and its final words come a moment later (else its last)
  function fastEnd(c) {
    return new Promise(function (res) {
      var t = setTimeout(done, 450);
      function done() { clearTimeout(t); c.onFinal = null; var w = c.final != null ? c.final : c.live; fastCancel(c); res(w); }
      c.onFinal = done; c.ended = true;
      if (c.fast === "apple" && c.sid) { var api = natApi(); if (api) api.end(c.sid); else done(); }
      else if (c.fast === "web" && c.rec) { try { c.rec.stop(); } catch (e) { done(); } }
      else done();
    });
  }

  // a capture into an answer box. pre: blocks from before it started (the buzz key came down as you started to talk)
  function startCap(mode, target, pre) {
    var blocks = pre ? history.slice(-pre) : [];
    cap = { mode: mode, target: target, blocks: blocks, pre: blocks.length, last: 0, loud: 0, quiet: 0, speaking: false, from: 0, peak: 0,
      endMs: opt("autoSend") ? 650 : 1100, maxSec: 9, fast: "", sid: 0, rec: null, live: "", final: null, ended: false, tried: {},
      before: target && target.value ? String(target.value) : "" };
    cap.finalWord = finalInAnswer(target);
    fastStart(cap);
    if (mode === "answer" && !(pre === 0 && cap.before)) showPill(cap.fast || wready ? "Listening" : "Listening, still loading", "va-on");
  }
  // (4.6) listenTok: a listen still on its way (the microphone opening, the voice going quiet) when the question changed or
  // the session ended started on the next question's box, listening there for 7 s with no buzz and no clap heard
  var listenTok = 0;
  function stopCap() { listenTok++; if (cap) fastCancel(cap); cap = null; hold(false); }
  // the words so far, in the box as they're said (not sent)
  function liveText(c, t) {
    t = clean(t);
    if (!t || t === c.shown || !c.target || !c.target.isConnected || c.target.disabled) return;
    c.shown = t; put(c.target, t);
  }
  function audioOf(c) {
    var keep = c.blocks.slice(c.from), audio = new Float32Array(keep.length * BLOCK);
    keep.forEach(function (b, i) { audio.set(b, i * BLOCK); });
    return audio;
  }
  // (4.6) what's been said so far is how an answer starts and not all of it ("Final" of Final Fantasy VI, "Toni" of
  // Toni Morrison): the pause before the rest is waited out up to 1.5 s, where "Final", then a breath, went in alone
  function startsAnswer(c) {
    var t = norm(clean(c.live || (c.spec && c.spec.last === c.last ? c.spec.text : "") || "")).replace(/^the /, "");
    if (!t) return false;
    if (!c.phrases) c.phrases = vocabFor(c.target).map(function (p) { return norm(p).replace(/^the /, ""); }).filter(Boolean);
    return c.phrases.some(function (p) { return p.length > t.length && p.indexOf(t + " ") === 0; });
  }
  // (4.0) at the first short pause (0.18 s since 4.2) what's been heard is judged (the quick one's words, Whisper's): an
  // answer that's right goes then. Anything else waits for the usual pause, so "Toni... Morrison" isn't cut at "Toni"
  function early(c) {
    [c.live, c.spec && c.spec.last === c.last ? c.spec.text : ""].forEach(function (raw) {
      var t = clean(raw); if (!t || c.tried[t]) return;
      c.tried[t] = 1;
      var last = c.last;
      // (4.5) nothing said since: a breath or a click after it (80 ms of sound, then quiet again) doesn't hold it back
      judgeSaid(c.target, t).then(function (x) { if (x.ok && cap === c && (c.last === last || (c.last - last <= 4 && c.quiet * 20 >= 100))) finish(x.text, true); }, function () {});
    });
  }
  // (4.2) "final" said last sends what came before it at once, as a player says "final answer"; only as the last word, so
  // an answer with "final" in it ("Final Fantasy") still goes in whole. (4.3) It's Enter: it sends with Send when I stop
  // talking off too; "final" on its own sends what's in the box already (what was said before the pause); and the
  // recognizers' other spellings of it count ("finals", "finale", "final answer")
  // (4.6) Say final to send is a setting. When the answer has the word in it (Final Fantasy, the NBA Finals, a cup
  // final, "Finally"), only "final answer" sends: "final" said last, or before a pause, is the answer's own word
  var FINAL = /^(?:(.*\S)\s+)?(?:final(?:s|e|ly)?(?:\s+answer)?)\W*$/i, FINAL_ANSWER = /^(?:(.*\S)\s+)?final\s+answer\W*$/i;
  function finalInAnswer(target) { return /\bfinal(?:s|e|ly)?\b/i.test(vocabFor(target).join(" ")); }
  function sayFinal(c, t) {
    if (!opt("sayFinal") || c.finalSaid) return false;
    const m = (c.finalWord ? FINAL_ANSWER : FINAL).exec(String(t || "").trim());
    if (!m) return false;
    const before = clean(m[1] || "") || clean(c.before || "");
    if (!before) return false;
    c.finalSaid = true;
    judgeSaid(c.target, before).catch(function () { return { text: before }; }).then(function (x) { if (cap === c) finish(x.text || before, true); });
    return true;
  }
  // Whisper at the first pause, so the answer's written down when the pause turns out to be the end. (Its words as you
  // talk were tried: on part of a word it makes things up, "So" or "VO The", and each try held up the one that counts)
  function speculate(c) {
    var spec = { last: c.last, text: null };
    spec.p = transcribe(audioOf(c));
    c.spec = spec;
    spec.p.then(function (t) { spec.text = t; if (cap !== c || c.spec !== spec) return; if (sayFinal(c, t)) return; if (c.last === spec.last && c.quiet * 20 >= 180) early(c); }, function () {});
  }
  // judged: the words, when they're settled already (right, or "final"); send: sent as Enter would, whatever the setting
  function finish(judged, sendNow) {
    var c = cap; cap = null;
    // sound that stopped right as the buzz came (the read-aloud voice's last word, the key) isn't the answer: listen on
    if (judged == null && c.mode === "answer" && c.last < c.pre + 12) { fastCancel(c); startCap("answer", c.target, 0); return; }
    if (judged != null) { fastCancel(c); deliver(c, judged, sendNow); return; }
    pillText(c.fast || wready ? "…" : "Transcribing…");
    hold(true);
    said(c).then(function (x) {
      if (!c.target || !c.target.isConnected || c.target.disabled) { hold(false); hidePill(); return; }
      if (!x || !x.text) { hold(false); showPill("Didn't catch that. Press V to retry", "va-off", 3000); return; }
      deliver(c, x.text, x.ok);
    }, function () { hold(false); showPill(wfail || "Couldn't transcribe that", "va-off", 3500); });
  }
  // what goes in: the quick one's words if they're right, else Whisper's if they are, else whichever is prompted on,
  // else Whisper's (it hears names better), else the quick one's. Whisper is waited for only when it's there (a quick
  // one doesn't wait out its download). → { text, ok }: (4.5) a right one is sent at once, as at the first pause (it
  // waited for "final" with Send when I stop talking off, when Whisper's words came after the pause)
  function said(c) {
    var judgeOf = function (t) { t = clean(t); return t ? judgeSaid(c.target, t).catch(function () { return { text: t, ok: false }; }) : Promise.resolve(null); };
    var fastP = c.fast ? fastEnd(c).then(judgeOf) : Promise.resolve(null);
    return fastP.then(function (f) {
      if (f && f.ok) return f;
      if (c.fast && !wready) return f;
      return whisperOf(c).then(judgeOf, function (e) { if (f) return null; throw e; }).then(function (w) {
        return (w && w.ok && w) || (f && f.prompt && f) || (w && w.prompt && w) || w || f;
      });
    });
  }
  function whisperOf(c) { return c.spec && c.spec.last === c.last ? c.spec.p : transcribe(audioOf(c)); }
  function deliver(c, t, sendNow) {
    hold(false);
    if (!c.target || !c.target.isConnected || c.target.disabled) { hidePill(); return; }
    put(c.target, t);
    if (sendNow || opt("autoSend")) { showPill(t, "va-off", 1600); send(c.target); return; }
    // (4.3) not sent: it listens on, so "final" sends it (or another answer takes its place)
    showPill(t + " · " + (!opt("sayFinal") ? "Enter to send" : finalInAnswer(c.target) ? "Say final answer to send" : "Say final to send"), "va-off", 3000);
    var box = c.target;
    setTimeout(function () { if (!cap && box.isConnected && !box.disabled && opt("enabled")) { startCap("answer", box, 0); if (cap) { cap.before = t; cap.quietStart = true; } } }, 300);
  }
  // a quiet answer (a far or soft microphone) is brought up to a steady level first
  function level16(audio) {
    var pk = 0; for (var i = 0; i < audio.length; i++) { var a = Math.abs(audio[i]); if (a > pk) pk = a; }
    if (pk > 0 && pk < 0.5) { var g = Math.min(20, 0.7 / pk); for (var j = 0; j < audio.length; j++) audio[j] *= g; }
    return audio;
  }
  function transcribe(audio) {
    return loadModel().then(function () { return call({ t: "run", audio: level16(audio) }); });
  }
  // ── judged by how it sounds (3.0): a moderator hears an answer, so "Tony Morrison" or "the crib cycle" said for Toni
  // Morrison or the Krebs cycle is right. When what Whisper wrote isn't accepted, each word (and each two run together)
  // is matched by sound to the answer line's words, and that spelling goes in if it's accepted then ──
  // a word's sound: its consonants as said (a Metaphone of sorts), its first letter kept when it's a vowel
  function sound(w) {
    w = norm(w).replace(/ /g, ""); if (!w) return "";
    w = w.replace(/^(kn|gn|pn|wr|ps)/, function (m) { return m.slice(1); }).replace(/^x/, "s").replace(/^wh/, "w").replace(/^gh/, "g");
    w = w.replace(/ph/g, "f").replace(/gh/g, "").replace(/ck/g, "k").replace(/sch/g, "sk").replace(/t?ch|sh/g, "X").replace(/th/g, "0").replace(/dg(?=[eiy])/g, "j")
      .replace(/c(?=[eiy])/g, "s").replace(/[cq]/g, "k").replace(/x/g, "ks").replace(/z/g, "s").replace(/v/g, "f").replace(/g(?=[eiy])/g, "j").replace(/d/g, "t");
    var out = /^[aeiou]/.test(w) ? "A" : "";
    for (var i = 0; i < w.length; i++) {
      var c = w[i], n = w[i + 1] || "";
      if (/[aeiouh]/.test(c) || (/[wy]/.test(c) && !/[aeiou]/.test(n))) continue;
      if (out[out.length - 1] !== c) out += c;
    }
    return out;
  }
  function lev(a, b) {
    var d = []; for (var j = 0; j <= b.length; j++) d[j] = j;
    for (var i = 1; i <= a.length; i++) { var p = d[0]; d[0] = i; for (var k = 1; k <= b.length; k++) { var t = d[k]; d[k] = Math.min(d[k] + 1, d[k - 1] + 1, p + (a[i - 1] === b[k - 1] ? 0 : 1)); p = t; } }
    return d[b.length];
  }
  // the words an answer can be said with: the answer, what the line accepts (or prompts on), the hidden accepts
  function vocabOf(line, hid) {
    var t = String(line || ""), words = {}, m, re = /(?:^|[\[(;])\s*(?:also\s+)?(?:accept|prompt on)\s+([^;\])]+)/gi;
    var add = function (x) { norm(x).split(" ").forEach(function (w) { if (w.length >= 2) words[w] = 1; }); };
    add(t.replace(/[\[(].*$/, ""));
    while ((m = re.exec(t))) add(m[1].replace(/\b(either|or|equivalents?|word forms?|answers?|until|is|are|read|mentioned|before|after)\b/gi, " "));
    ((hid && hid.accept) || []).forEach(add);
    return Object.keys(words);
  }
  function snapWords(text, vocab) {
    var V = vocab.map(function (v) { return [v, sound(v)]; }).filter(function (x) { return x[1].length >= 2; });
    // one sound off counts in a longer word, or where the first sound is the same ("crib" isn't "Hammurabi"); a vowel
    // missed at the start ("Chebe" for Achebe) when the rest is the same
    function pick(w) {
      var c = sound(w), c0 = c.replace(/^A/, ""), b = null; if (c.length < 2) return null;
      V.forEach(function (x) {
        var d = lev(c, x[1]), m = Math.min(c.length, x[1].length);
        var ok = (d === 0 && m >= 2) || (d === 1 && m >= 3 && (c[0] === x[1][0] || m >= 4));
        if (!ok && c0.length >= 2 && c0 === x[1].replace(/^A/, "")) { ok = true; d = 1; }
        if (ok && (!b || d < b.d)) b = { v: x[0], d: d };
      });
      return b;
    }
    var ws = text.split(/[\s\u2010-\u2015-]+/).filter(Boolean), out = [], changed = false;
    for (var i = 0; i < ws.length; i++) {
      var one = pick(ws[i]), two = i + 1 < ws.length ? pick(ws[i] + ws[i + 1]) : null;
      if (two && (!one || two.d < one.d)) { out.push(two.v); i++; changed = true; continue; }
      if (one) { out.push(one.v); if (norm(one.v) !== norm(ws[i])) changed = true; } else out.push(ws[i]);
    }
    return changed ? out.join(" ") : null;
  }
  // → { text: what goes in (the sound-matched spelling when that's what's accepted), ok: accepted }
  async function judgeSaid(target, text) {
    if (roomBox(target)) return { text: text, ok: false };
    var s = ctx.getState(), q = s && s.currentQuestion; if (!q || !text) return { text: text, ok: false };
    var pm = /^bonus-input-(\d+)$/.exec((target && target.id) || ""), part = pm ? +pm[1] : -1;
    // (4.6) judged as the box would judge it when sent (the player's strictness, the buzz, a prompt's answer)
    var verdict = function (t) { return part >= 0 ? judgePart(q, part, t, { asAnswer: true }) : judge(q, t, { asAnswer: true }); };
    var r = await verdict(text);
    if (r && r.status === "accept") return { text: text, ok: true };
    if (r && r.status === "prompt") return { text: text, ok: false, prompt: true };
    if (!opt("bySound")) return { text: text, ok: false };
    var hid = q._hidden; if (Array.isArray(hid)) hid = hid[part] || null;
    var snapped = snapWords(text, vocabOf(part >= 0 ? bonusAnswersSani(q)[part] : q.answer_sanitized, hid));
    if (!snapped) return { text: text, ok: false };
    var r2 = await verdict(snapped);
    return r2 && r2.status === "accept" ? { text: snapped, ok: true } : { text: text, ok: false };
  }

  // what Whisper writes for a short answer: "Mozart." → "Mozart"; "(silence)", "[BLANK_AUDIO]" → nothing
  function clean(t) {
    t = String(t || "").replace(/\[[^\]]*\]|\([^)]*\)/g, " ").replace(/\s+/g, " ").trim().replace(/[.!?,;:]+$/, "");
    return /^(you|thank you|thanks for watching)$/i.test(t) ? "" : t;
  }
  function put(box, text) { box.value = text; box.dispatchEvent(new Event("input", { bubbles: true })); }
  function send(box) {
    if (!box || !box.isConnected || box.disabled) return;
    box.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", code: "Enter", bubbles: true, cancelable: true }));
  }

  // ── listen into an answer box (after a buzz, a bonus part, or V) ──
  // (4.0) ms since the voice reading the question last made a sound (Infinity on an older app)
  function voiceQuiet() { try { var q = ctx.host && ctx.host.voiceQuietFor ? ctx.host.voiceQuietFor() : Infinity; return q == null ? Infinity : q; } catch (e) { return Infinity; } }
  // its last sound still in the room (the speakers, the echo) for a moment after it stops
  function whenQuiet(fn, n) {
    var q = voiceQuiet();
    if (q >= 250 || (n || 0) > 600) return fn(q);
    setTimeout(function () { whenQuiet(fn, (n || 0) + 1); }, Math.max(30, 250 - q));
  }
  function listen(box, pre) {
    if (!box) return;
    var my = ++listenTok;
    native().then(function (apple) {
      if (my !== listenTok) return;
      if (!apple && !SRC && wfail && !wloading) { showPill(wfail, "va-off", 3500); return; }
      loadModel().catch(function () {});
      openMic().then(function () {
        if (mic && mic.ac.state === "suspended") mic.ac.resume();
        whenQuiet(function (q) {
          if (my !== listenTok || !box.isConnected || box.disabled || (cap && cap.target === box)) return;
          // the moment before (the buzz key came down as you started to talk), but none of the voice: only what came a
          // little after it stopped
          var n = pre || 0; if (q < 1000) n = Math.min(n, Math.max(0, Math.floor((q - 150) / 20)));
          startCap("answer", box, n);
          if (cap && !cap.fast && !wready) hold(true);   // Whisper alone and still downloading: the clock waits for it
        });
      }, function (e) {
        showPill(e && (e.name === "NotAllowedError" || e.name === "SecurityError") ? "Allow microphone access to answer by voice" : "No microphone found", "va-off", 4000);
      });
    });
  }
  function onBuzz(box) {
    if (!opt("enabled")) return;
    stopCap();
    if (mic && mic.ac.state === "suspended") mic.ac.resume();
    // the half second before the buzz key is kept (an answer started with the key isn't cut); a clap or a shout that
    // buzzed is let pass first, so it isn't taken for the answer
    // (in a room the box opens a round trip after the clap)
    var loud = performance.now() - loudAt < (box ? 1500 : 400);
    setTimeout(function () { var b = box || document.getElementById("buzz-input"); if (b && b.isConnected && !b.disabled) listen(b, loud ? 0 : 25); }, loud ? 450 : 30);
  }
  ctx.on("buzz", function () { onBuzz(null); });
  // (4.7) a room gave this player the buzz: its answer box (the room has it a round trip after the press)
  ctx.on("room:buzz", function (d) { if (d && d.input) onBuzz(d.input); });
  ctx.on("room:bonus", function (d) {
    if (!opt("enabled") || !ctx.getSetting("bonuses") || !d || !d.input) return;
    stopCap();
    setTimeout(function () { if (d.input.isConnected && !d.input.disabled && !(cap && cap.target === d.input)) listen(d.input, 0); }, 120);
  });
  // the microphone opens with a question (answers come quickly then), and with a clap or a shout to listen for.
  // (4.5) Clap or shout to buzz has it open from the start of a session and the moment it's turned on (it waited for
  // the first question, or a buzz), and works with Answer by voice off too (the answer typed)
  function wantMic() { return opt("enabled") || !!ctx.getSetting("loudBuzz"); }
  function micUp() {
    if (!wantMic() || !practiceOn()) return;
    openMic().then(function () { if (mic && mic.ac.state === "suspended") mic.ac.resume().catch(function () {}); }, function () {});
  }
  // a page that hadn't been clicked yet starts its sound held: the first click or key lets it hear
  function wake() { if (mic && mic.ac.state === "suspended") mic.ac.resume().catch(function () {}); }
  function onQuestion() {
    stopCap(); hidePill();
    if (!wantMic()) return;
    // Apple's recognizer where the app has it (the first time, macOS asks); Whisper's model always (the second opinion)
    if (opt("enabled")) { native(); loadModel().catch(function () {}); }
    micUp();
  }
  ctx.on("question:render", onQuestion);
  ctx.on("room:question", onQuestion);
  ctx.on("session:start", function () { if (ctx.getSetting("loudBuzz")) micUp(); });
  if (ctx.onSetting) ctx.onSetting(function (k) {
    if (k !== "enabled" && k !== "loudBuzz") return;
    if (wantMic()) micUp(); else { stopCap(); hidePill(); closeMic(); }
  });
  // (4.3) prompted ("more specific?"): it listens again for the answer, as after the buzz
  function onPrompt(d) {
    if (!opt("enabled")) return;
    var box = (d && d.input) || document.getElementById("buzz-input");
    if (!box || (d && d.type === "bonus" && !ctx.getSetting("bonuses"))) return;
    stopCap();
    setTimeout(function () { if (box.isConnected && !box.disabled && !(cap && cap.target === box)) listen(box, 0); }, 120);
  }
  ctx.on("answer:prompt", onPrompt);
  ctx.on("room:prompt", onPrompt);
  function done() { stopCap(); hidePill(); }
  ctx.on("answer:result", done);
  ctx.on("bonus:result", done);
  ctx.on("session:end", function () { done(); if (!roomFront()) closeMic(); });
  ctx.on("room:result", done);
  ctx.on("room:leave", function () { done(); closeMic(); });
  // (4.5) back on a practice page with its session still going: open again for a clap
  ctx.on("screen:change", function (d) { done(); closeMic(); if (ctx.getSetting("loudBuzz")) setTimeout(function () { if ((d && /^practice/.test(d.name || "")) || roomFront()) micUp(); }, 0); });
  // a bonus part asking for its answer
  function onFocus(e) {
    var t = e.target;
    if (!opt("enabled") || !ctx.getSetting("bonuses") || !t || !t.classList || !t.classList.contains("bonus-answer-input") || t.disabled) return;
    if (cap && cap.target === t) return;
    listen(t, 0);
  }
  // V: listen into the answer box in front of you; Esc stops
  function onKey(e) {
    wake();
    if ((e.key === "v" || e.key === "V") && !e.metaKey && !e.ctrlKey && !e.altKey && !inField(e)) {
      var box = [].slice.call(document.querySelectorAll("#buzz-input, .bonus-answer-input, #mp-ans-input, .mp-binput")).find(function (i) { return !i.disabled && i.offsetParent !== null; });
      if (box) { e.preventDefault(); box.focus(); listen(box, 0); }
    }
    if (e.key === "Escape" && cap && cap.mode === "answer") { stopCap(); hidePill(); }
  }
  document.addEventListener("focusin", onFocus);
  document.addEventListener("keydown", onKey, true);
  document.addEventListener("pointerdown", wake, true);
  // turned on in the middle of a session
  if (ctx.getSetting("loudBuzz")) micUp();
  ctx._cleanup = function () {
    document.removeEventListener("pointerdown", wake, true);
    done(); closeMic();
    if (nat.off) { try { nat.off(); } catch (e) {} nat.off = null; }
    if (worker) { try { worker.terminate(); } catch (e) {} worker = null; }
    document.removeEventListener("focusin", onFocus); document.removeEventListener("keydown", onKey, true);
  };

}
