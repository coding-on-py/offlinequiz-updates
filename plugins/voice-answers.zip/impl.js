function __qbMain(ctx) {
  // ── the kit the 15.62 plugins share (text, icons, questions, judging, history) ──
  function esc(s) { return (s == null ? "" : String(s)).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
  var IC = {
    play: '<path d="M7 4l13 8-13 8z"/>',
    pause: '<path d="M8 5v14M16 5v14"/>',
    left: '<path d="M15 6l-6 6 6 6"/>',
    right: '<path d="M9 6l6 6-6 6"/>',
    next: '<path d="M6 5l9 7-9 7zM18 5v14"/>',
    refresh: '<path d="M20 11a8 8 0 10-2.3 5.7M20 4v7h-7"/>',
    x: '<path d="M6 6l12 12M18 6L6 18"/>',
    check: '<path d="M5 12l5 5 9-10"/>',
    mic: '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
    volume: '<path d="M4 9v6h4l5 4V5L8 9z"/><path d="M16 9a4 4 0 0 1 0 6M19 6a8 8 0 0 1 0 12"/>',
    copy: '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h3"/>',
    edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="M13.5 6.5l4 4"/>',
    bolt: '<path d="M13 3L5 14h6l-1 7 8-11h-6z"/>',
    flag: '<path d="M5 21V4M5 4h11l-2 4 2 4H5"/>',
    users: '<circle cx="9" cy="8" r="3"/><path d="M3 20a6 6 0 0 1 12 0M16 4a3 3 0 0 1 0 6M21 20a6 6 0 0 0-4-5.6"/>',
    target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
    down: '<path d="M6 9l6 6 6-6"/>',
    up: '<path d="M6 15l6-6 6 6"/>',
    quote: '<path d="M7 7h4v4c0 3-1.5 5-4 6M15 7h4v4c0 3-1.5 5-4 6"/>',
    ear: '<path d="M7 9a5 5 0 0 1 10 0c0 3-3 4-3 7a3 3 0 0 1-6 0"/><path d="M10 9a2 2 0 0 1 4 0"/>',
  };
  function ic(name, size) {
    var s = size || 16;
    return '<svg width="' + s + '" height="' + s + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (IC[name] || "") + "</svg>";
  }
  function loading(label) { return '<div class="pk-loading">' + (ctx.loadingBarHtml ? ctx.loadingBarHtml(label) : esc(label)) + "</div>"; }
  function norm(s) { return String(s || "").toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[^a-z0-9]+/g, " ").trim(); }
  function pct(a, n) { return n ? Math.round(100 * a / n) : 0; }
  function fmt(n) { return Number(n || 0).toLocaleString(); }
  function plural(n, one, many) { return fmt(n) + " " + (n === 1 ? one : (many || one + "s")); }
  function shuffle(a) { for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)), t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
  function inField(e) { var t = e && e.target; return !!t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT" || t.isContentEditable); }
  function dayKey(t) { var d = new Date(t || Date.now()); return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0"); }
  var DAY = 86400000;

  // the practice setup (Setup panel): its filters and reading settings
  function cfg() { try { return (ctx.host && ctx.host.getPracticeConfig && ctx.host.getPracticeConfig()) || {}; } catch (e) { return {}; } }
  // filters → query parameters, the ones the app sends for a random question
  function filtersQuery(f, extra) {
    f = f || {}; var p = [];
    var add = function (k, v) { p.push(k + "=" + encodeURIComponent(v)); };
    if (f.categories && f.categories.length) add("categories", f.categories.join(","));
    if (f.categoryIds && f.categoryIds.length) add("categoryIds", f.categoryIds.join(","));
    if (f.difficulties && f.difficulties.length) add("difficulties", f.difficulties.join(","));
    if (f.setNames && f.setNames.length) add("setNames", f.setNames.join(","));
    if (f.packetNumbers && f.packetNumbers.length) add("packetNumbers", f.packetNumbers.join(","));
    if (f.yearMin != null) add("yearMin", f.yearMin);
    if (f.yearMax != null) add("yearMax", f.yearMax);
    if (f.powermarkOnly) add("powermarkOnly", "true");
    if (f.canon && f.canon.length) add("canon", f.canon.join(","));
    add("cleanOnly", "1");
    Object.keys(extra || {}).forEach(function (k) { if (extra[k] != null && extra[k] !== false) add(k, extra[k]); });
    return p.join("&");
  }
  // the practice filters without a set (a drill draws from everything the player picked)
  function practiceFilters() { var f = Object.assign({}, cfg().filters || {}); delete f.setNames; delete f.packetNumbers; delete f.setIds; return f; }
  async function getTossups(n, f, extra) {
    try { var d = await ctx.api.get("/api/tossups/query?" + filtersQuery(f || practiceFilters(), Object.assign({ random: 1, limit: n }, extra || {}))); return (d && d.rows) || []; } catch (e) { return []; }
  }
  async function getBonuses(n, f, extra) {
    try { var d = await ctx.api.get("/api/bonuses/query?" + filtersQuery(f || practiceFilters(), Object.assign({ random: 1, limit: n }, extra || {}))); return (d && d.rows) || []; } catch (e) { return []; }
  }
  async function getTossup(id) { try { return (await ctx.api.get("/api/tossups/" + encodeURIComponent(id))).tossup || null; } catch (e) { return null; } }
  async function getBonus(id) { try { return (await ctx.api.get("/api/bonuses/" + encodeURIComponent(id))).bonus || null; } catch (e) { return null; } }
  async function searchTossups(query, limit, f) {
    try { var d = await ctx.api.get("/api/tossups/search?query=" + encodeURIComponent(query) + "&limit=" + (limit || 20) + (f ? "&" + filtersQuery(f) : "")); return { rows: (d && d.rows) || [], total: (d && d.total) || 0 }; } catch (e) { return { rows: [], total: 0 }; }
  }
  // tossups whose answer line names an answer
  async function tossupsOn(answer, limit) { return (await searchTossups('answer_sanitized : ("' + String(answer).replace(/"/g, "") + '")', limit || 20)).rows; }

  // a record's text as practice reads it (notes and pronunciation guides per the player's settings)
  function readText(q) {
    try { if (ctx.host && ctx.host.questionText) { var t = ctx.host.questionText(q, "question"); if (t != null) return String(t).replace(/\(\*\)/g, "").replace(/\s{2,}/g, " ").trim(); } } catch (e) {}
    return String((q && q.question_sanitized) || "").replace(/\(\*\)/g, "").trim();
  }
  function powerAt(q) { return String((q && q.question_sanitized) || "").indexOf("(*)"); }
  // sentences, without breaking at "St." or an initial ("J. R. R. Tolkien")
  var ABBR = /(?:\b(?:St|Ste|Mt|Mts|Dr|Mr|Mrs|Ms|Mme|Prof|Sr|Jr|Rev|Fr|Gen|Col|Capt|Lt|Sgt|Maj|Adm|Hon|Pres|Gov|Sen|Rep|vs|etc|cf|ca|al|Inc|Co|Corp|Ltd|Bros|approx|No|Nos|Op|op|no|Vol|vol|Ch|ch|Fig|fig|Ft|Pt|pt|Ave|[A-Za-z])\.["”’']?)$/;
  function sentences(text) {
    var parts = String(text || "").split(/(?<=[.?!]["”’)]*)\s+(?=["“(]?[A-Z0-9])/), out = [], cur = "";
    for (var i = 0; i < parts.length; i++) {
      cur = cur ? cur + " " + parts[i] : parts[i];
      if (i < parts.length - 1 && ABBR.test(cur.trim())) continue;
      out.push(cur.trim()); cur = "";
    }
    if (cur.trim()) out.push(cur.trim());
    return out.filter(Boolean);
  }
  // where each sentence of a text ends (indexes into it)
  function sentenceEnds(text) {
    var at = 0, out = []; text = String(text || "");
    sentences(text).forEach(function (x) { var i = text.indexOf(x, at); if (i < 0) return; at = i + x.length; out.push(at); });
    return out;
  }
  // ── categories (15.63): the app's own picker, its picks kept under `key` ([] = every category) ──
  // mountCats(root, key, onChange) puts it in root's [data-cats] (made once, moved into each new render);
  // inCats(pk, e): a history entry or question in the picks; with no picks, all are
  var PICKERS = {};
  function catPicker(key, onChange) {
    if (PICKERS[key]) return PICKERS[key];
    if (!ctx.host || !ctx.host.categoryPicker) return null;
    var pk = ctx.host.categoryPicker(null, { selected: ctx.storage.get(key) || [], onChange: function (ids) { ctx.storage.set(key, ids); if (onChange) onChange(ids); } });
    PICKERS[key] = pk;
    // the picks match nothing until the tree is in: draw again once it is
    if (pk.ready && (ctx.storage.get(key) || []).length) pk.ready.then(function () { if (onChange) onChange(pk.get()); });
    return pk;
  }
  function mountCats(root, key, onChange) {
    var pk = catPicker(key, onChange), host = root && root.querySelector("[data-cats]");
    if (pk && host) host.appendChild(pk.el);
    return pk;
  }
  function inCats(pk, e) {
    if (!pk || !pk.get().length) return true;
    return pk.matches(String((e && (e.category_path || e.path || e.category || e.root)) || ""));
  }
  // ── the app's reader on a page titled for the plugin (15.63: ctx.host.playPractice). Its Setup picks the categories ──
  function canRead() { return !!(ctx.host && ctx.host.playPractice); }
  function onReader() { return !!(ctx.host && ctx.host.onPracticePage && ctx.host.onPracticePage()); }
  // a plugin's start page: an icon, what it is, a Start button (data-pk="start"), a note under it
  function heroHtml(icon, title, text, start, note) {
    return '<div class="pk-hero"><span class="pk-hero-ico">' + ic(icon, 26) + "</span><h2>" + esc(title) + "</h2><p>" + esc(text) + "</p>" +
      '<div class="pk-actions pk-center"><button type="button" class="btn btn-primary" data-pk="start">' + ic("play", 14) + esc(start || "Start") + "</button></div>" +
      (note ? '<div class="pk-muted pk-small">' + note + "</div>" : "") + "</div>";
  }
  // the answer line, with its bold and underlining (nothing else of the HTML)
  function answerHtml(q) {
    var h = String((q && q.answer) || "");
    if (!/<\/?(b|u|strong|em|i)\b/i.test(h)) return esc((q && q.answer_sanitized) || h);
    return h.replace(/<(\/?)(b|u|strong|em|i)\b[^>]*>/gi, "\u0001$1$2\u0002").replace(/<[^>]*>/g, "").replace(/&(?!(?:amp|lt|gt|quot|#\d+);)/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/\u0001(\/?)(\w+)\u0002/g, "<$1$2>");
  }
  function primary(q) {
    var a = "";
    try { if (ctx.host && ctx.host.extractPrimaryAnswer) a = ctx.host.extractPrimaryAnswer((q && q.answer) || "", (q && q.answer_sanitized) || ""); } catch (e) {}
    return a || String((q && q.answer_sanitized) || "").replace(/\s*[\[(].*$/, "").trim();
  }
  // judged right here, like practice (judge.js); { status: "accept" | "prompt" | "reject", prompt }
  async function judge(q, answer, opts) {
    opts = opts || {};
    try {
      if (ctx.host && ctx.host.judgeTossup) return (await ctx.host.judgeTossup(q, answer, { strictness: opts.strictness != null ? opts.strictness : (cfg().strictness || 10), buzzPosition: opts.buzzPosition, previous: opts.previous || null })) || { status: "reject" };
      return (await ctx.api.post("/api/evaluate-tossup", { questionId: q.id, answer: answer, strictness: cfg().strictness || 10, buzzPosition: opts.buzzPosition, previous: opts.previous || null })) || { status: "reject" };
    } catch (e) { return { status: "reject" }; }
  }
  async function judgePart(b, part, answer, opts) {
    opts = opts || {};
    try {
      if (ctx.host && ctx.host.judgeBonusPart) return (await ctx.host.judgeBonusPart(b, part, answer, { strictness: cfg().strictness || 10, previous: opts.previous || null })) || { status: "reject" };
      return (await ctx.api.post("/api/evaluate-bonus-part", { questionId: b.id, part: part, answer: answer, strictness: cfg().strictness || 10 })) || { status: "reject" };
    } catch (e) { return { status: "reject" }; }
  }
  async function judgeLine(line, sani, answer, opts) {
    opts = opts || {};
    try {
      if (ctx.host && ctx.host.judgeAnswerLine) return (await ctx.host.judgeAnswerLine(line, sani, answer, { strictness: cfg().strictness || 10, previous: opts.previous || null })) || { status: "reject" };
      return (await ctx.api.post("/api/evaluate-answer", { answerline: line, answer: answer, strictness: cfg().strictness || 10 })) || { status: "reject" };
    } catch (e) { return { status: "reject" }; }
  }
  function bonusParts(b) { try { return JSON.parse((b && (b.parts_sanitized || b.parts)) || "[]"); } catch (e) { return []; } }
  function bonusAnswers(b) { try { return JSON.parse((b && b.answers) || "[]"); } catch (e) { return []; } }
  function bonusAnswersSani(b) { try { return JSON.parse((b && b.answers_sanitized) || "[]"); } catch (e) { return []; } }

  // the player's answers (Stats' history), only the fields asked for
  async function history(fields) {
    try { return ((await ctx.api.get("/api/sessions/all-entries?" + (/\banswer\b/.test(fields || "") ? "answers=1&" : "") + "fields=" + encodeURIComponent(fields || ""))).entries) || []; } catch (e) { return []; }
  }
  // record a tossup answered on a plugin's page into the player's stats (the path Coach Mode uses)
  function record(q, r) {
    try {
      ctx.api.post("/api/check-tossup", { questionId: q.id, answer: r.answer || "", buzzPosition: r.buzzPosition || 0, sessionId: r.session, overriding: true,
        correct: !!r.correct, isPower: !!r.power, points: r.points || 0, celerity: r.celerity != null ? r.celerity : 1 }).catch(function () {});
    } catch (e) {}
  }

  var ROOT_COLOR = { "Literature": "#bc8cff", "Science": "#58a6ff", "Math": "#a5e05b", "Pop Culture": "#ff7b72", "Sports": "#ff6f91", "Fine Arts": "#f778ba", "History": "#e3b341", "Geography": "#56d364", "Mythology": "#ffa657", "Social Science": "#3dd6a3", "Philosophy": "#39c5cf", "Theology": "#8e9bff", "Current Events": "#c9d16b", "Miscellaneous": "#8b949e" };
  // NAQT's high school distribution, per 24 tossups / bonuses (naqt.com/hs/distribution.jsp)
  var NAQT = [["Literature", 3.9, 3.8], ["Science", 4.5, 4.3], ["Math", 1.0, 1.0], ["Fine Arts", 2.0, 2.0], ["History", 4.6, 4.5], ["Geography", 1.9, 1.9], ["Mythology", 0.6, 0.7],
    ["Pop Culture", 1.0, 0.9], ["Sports", 0.7, 0.7], ["Social Science", 0.6, 0.6], ["Philosophy", 0.3, 0.3], ["Theology", 0.4, 0.4], ["Current Events", 1.5, 1.4], ["Miscellaneous", 1.0, 1.5]];
  function rootOf(e) { return String((e && (e.category_path || e.category)) || "").split(" > ")[0] || "Miscellaneous"; }
  function dot(root) { return '<span class="pk-dot" style="--c:' + (ROOT_COLOR[root] || "#8b949e") + '"></span>'; }
  var _roots = null;
  async function roots() {
    if (_roots) return _roots;
    try { var t = ctx.host && ctx.host.getCategoryTree ? await ctx.host.getCategoryTree("tossups") : (await ctx.api.get("/api/category-tree?type=tossups")).tree; _roots = (t || []).map(function (n) { return { id: n.id, name: n.name, count: n.count }; }); }
    catch (e) { _roots = []; }
    return _roots;
  }
  var DIFF_NAME = { 0: "Unrated", 1: "Middle school", 2: "Easy high school", 3: "Regular high school", 4: "Hard high school", 5: "National high school", 6: "Easy college", 7: "Medium college", 8: "Regionals college", 9: "Nationals college", 10: "Open" };

  function tile(value, label, cls) { return '<div class="pk-tile' + (cls ? " " + cls : "") + '"><b class="num">' + value + "</b><span>" + esc(label) + "</span></div>"; }
  function segHtml(name, items, on) {
    return '<div class="seg pk-seg" role="group">' + items.map(function (it) {
      return '<button type="button" data-' + name + '="' + esc(it[0]) + '" aria-pressed="' + (String(on) === String(it[0])) + '">' + esc(it[1]) + "</button>";
    }).join("") + "</div>";
  }
  function emptyHtml(text) { return '<div class="db-empty pk-empty">' + esc(text) + "</div>"; }
  function playList(kind, ids, title) {
    if (!ids || !ids.length) return false;
    try { return !!(ctx.host && ctx.host.launchQuestions && ctx.host.launchQuestions(kind, ids, { title: title })); } catch (e) { return false; }
  }

  // a reader: shows `text` a character at a time at the practice reading speed. start(), pause(), go(), stop();
  // at() is how far it is; onEnd once it's all shown
  function Reader(el, text, opts) {
    opts = opts || {};
    var ms = opts.ms != null ? opts.ms : (Number(cfg().revealSpeed) || 25), idx = 0, raf = 0, last = 0, on = false;
    var paint = function () { el.innerHTML = '<span class="pk-read">' + esc(text.slice(0, idx)) + '</span><span class="pk-unread" aria-hidden="true">' + esc(text.slice(idx)) + "</span>"; };
    var step = function (t) {
      raf = 0; if (!on) return;
      if (!last) last = t;
      var n = ms > 0 ? Math.floor((t - last) / ms) : text.length;
      if (n > 0) { idx = Math.min(text.length, idx + n); last += n * ms; paint(); if (opts.onTick) opts.onTick(idx); }
      if (idx >= text.length) { on = false; if (opts.onEnd) opts.onEnd(); return; }
      raf = requestAnimationFrame(step);
    };
    paint();
    return {
      start: function () { if (on) return; on = true; last = 0; raf = requestAnimationFrame(step); },
      pause: function () { on = false; if (raf) cancelAnimationFrame(raf); raf = 0; },
      stop: function () { on = false; if (raf) cancelAnimationFrame(raf); raf = 0; },
      showAll: function () { this.stop(); idx = text.length; el.textContent = text; },
      at: function () { return idx; },
      running: function () { return on; },
    };
  }
  // a reader's position in the displayed text → the record's question_sanitized (what judging and stats count)
  function serverPos(q, display, pos) {
    try { if (ctx.host && ctx.host.mapDisplayPos) return ctx.host.mapDisplayPos(display, (q && q.question_sanitized) || "", pos); } catch (e) {}
    return pos;
  }

  // ── Voice Answers: say your answer after you buzz; what you say goes into the answer box and is sent ──
  // 2.0 (15.63): speech is turned into text on this computer by a small Whisper model (transformers.js, in a worker),
  // so it works in the desktop app and every browser, offline once the model is downloaded. The browser's own speech
  // recognition (1.x) didn't work in the app, and in Chrome it took seconds to start listening, so an answer said
  // right after the buzz was lost. Now the microphone stays open while a practice session runs: a buzz keeps the
  // last moment before it too, the answer ends when you stop talking, and it's written down and sent.
  // With "Say buzz" on, short things said while a tossup is read are checked for the word "buzz".
  var TF = "https://cdn.jsdelivr.net/npm/@huggingface/transformers@3.8.1/+esm";
  var RATE = 16000, BLOCK = 320;                         // 20 ms blocks at 16 kHz
  var worker = null, wready = false, wloading = null, wfail = "", wq = {}, wid = 0;
  var mic = null, micOpening = null;
  var cap = null;                                         // what's being listened for: { mode, target, … }
  var pill = null, pillT = 0, history = [], floor = 0.004;

  function opt(k) { var v = ctx.getSetting(k); return v == null ? true : v; }
  function practiceOn() { var s = ctx.getState(); return !!(s && s.sessionActive); }

  // ── the pill: what it's doing, with the microphone's level while it listens ──
  function showPill(text, cls, ms) {
    if (!pill) { pill = document.createElement("div"); pill.className = "va-pill"; pill.setAttribute("role", "status"); ctx.mount(pill); }
    clearTimeout(pillT);
    pill.className = "va-pill" + (cls ? " " + cls : "");
    pill.innerHTML = ic("mic", 14) + '<span class="va-lvl" aria-hidden="true"><i></i></span><span class="va-txt">' + esc(text) + "</span>";
    pill.hidden = false;
    if (ms) pillT = setTimeout(hidePill, ms);
  }
  function pillText(text) { var t = pill && pill.querySelector(".va-txt"); if (t) t.textContent = text; else showPill(text, "va-on"); }
  function hidePill() { clearTimeout(pillT); if (pill) pill.hidden = true; }
  function level(v) { var i = pill && !pill.hidden && pill.querySelector(".va-lvl i"); if (i) i.style.transform = "scaleX(" + Math.min(1, v * 18).toFixed(3) + ")"; }

  // ── the model, in a worker: Whisper base.en on the GPU's encoder when there is one (about 140 MB, half a second an
  // answer), else tiny.en on the processor (about 45 MB). Its files are kept in IndexedDB, which every origin has
  // (the desktop app's file:// page has no Cache API) ──
  var WORKER = [
    'import * as T from "' + TF + '";',
    "T.env.allowLocalModels = false; T.env.useBrowserCache = false; T.env.useCustomCache = true;",
    'const DB = new Promise((res, rej) => { const r = indexedDB.open("qb-voice-models", 1); r.onupgradeneeded = () => r.result.createObjectStore("files"); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });',
    "const key = (r) => (typeof r === \"string\" ? r : r && r.url) || String(r);",
    "T.env.customCache = {",
    '  async match(r) { const db = await DB; const v = await new Promise((res) => { const g = db.transaction("files").objectStore("files").get(key(r)); g.onsuccess = () => res(g.result); g.onerror = () => res(undefined); }); return v ? new Response(v) : undefined; },',
    '  async put(r, resp) { const buf = await resp.arrayBuffer(); const db = await DB; await new Promise((res) => { const tx = db.transaction("files", "readwrite"); tx.objectStore("files").put(buf, key(r)); tx.oncomplete = res; tx.onerror = res; }); },',
    "};",
    "let asr = null;",
    "async function load() {",
    "  let gpu = false; try { gpu = !!(navigator.gpu && await navigator.gpu.requestAdapter()); } catch (e) {}",
    "  const seen = {};",
    '  const progress = (p) => { if (p && p.file && p.total) { seen[p.file] = [p.loaded || 0, p.total]; let a = 0, b = 0; for (const k in seen) { a += seen[k][0]; b += seen[k][1]; } postMessage({ t: "progress", loaded: a, total: b }); } };',
    "  const make = (g) => T.pipeline(\"automatic-speech-recognition\", g ? \"onnx-community/whisper-base.en\" : \"onnx-community/whisper-tiny.en\",",
    '    g ? { device: { encoder_model: "webgpu", decoder_model_merged: "wasm" }, dtype: { encoder_model: "fp32", decoder_model_merged: "q8" }, progress_callback: progress } : { device: "wasm", dtype: "q8", progress_callback: progress });',
    "  try { asr = await make(gpu); } catch (e) { if (!gpu) throw e; asr = await make(false); }",
    "  await asr(new Float32Array(16000));   // the first run is slow; better now than on an answer",
    "}",
    "self.onmessage = async (e) => {",
    "  const m = e.data;",
    "  try {",
    '    if (m.t === "load") { await load(); postMessage({ t: "ready", id: m.id }); }',
    '    else if (m.t === "run") { const o = await asr(m.audio); postMessage({ t: "text", id: m.id, text: String((o && o.text) || "").trim() }); }',
    '  } catch (err) { postMessage({ t: "error", id: m.id, error: String((err && err.message) || err) }); }',
    "};",
  ].join("\n");
  function call(msg) {
    return new Promise(function (res, rej) { var id = ++wid; msg.id = id; wq[id] = { res: res, rej: rej }; worker.postMessage(msg, msg.audio ? [msg.audio.buffer] : []); });
  }
  function loadModel() {
    if (wready) return Promise.resolve();
    if (wloading) return wloading;
    wfail = "";
    try { worker = new Worker(URL.createObjectURL(new Blob([WORKER], { type: "text/javascript" })), { type: "module" }); }
    catch (e) { wfail = "This browser can't run voice answers"; return Promise.reject(e); }
    worker.onmessage = function (e) {
      var m = e.data;
      if (m.t === "progress") { if (!cap && m.total) showPill("Getting voice answers ready " + Math.round(100 * m.loaded / m.total) + "%", "va-off"); return; }
      var w = wq[m.id]; if (!w) return; delete wq[m.id];
      if (m.t === "error") w.rej(new Error(m.error)); else w.res(m.text);
    };
    worker.onerror = function () { wfail = "Voice answers couldn't start"; };
    wloading = call({ t: "load" }).then(function () { wready = true; if (!cap) showPill("Voice answers are ready", "va-off", 2200); })
      .catch(function (e) { wloading = null; wfail = /fetch|network|Failed/i.test(String(e && e.message)) ? "Voice answers need the internet once, to download" : "Voice answers couldn't start"; try { worker.terminate(); } catch (x) {} worker = null; throw e; });
    return wloading;
  }

  // ── the microphone, open while a session runs: 20 ms blocks at 16 kHz, the last second kept ──
  function openMic() {
    if (mic) return Promise.resolve(mic);
    if (micOpening) return micOpening;
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) return Promise.reject(new Error("nomic"));
    micOpening = navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true, channelCount: 1 } }).then(function (stream) {
      var AC = window.AudioContext || window.webkitAudioContext, ac = new AC();
      var src = ac.createMediaStreamSource(stream), proc = ac.createScriptProcessor(2048, 1, 1), mute = ac.createGain();
      mute.gain.value = 0;
      var step = ac.sampleRate / RATE, pos = 0, part = new Float32Array(BLOCK), n = 0;
      // down to 16 kHz (each output sample the mean of the input samples it covers), then into 20 ms blocks
      proc.onaudioprocess = function (e) {
        var x = e.inputBuffer.getChannelData(0);
        while (pos < x.length) {
          var a = Math.floor(pos), b = Math.min(x.length, Math.floor(pos + step)), s = 0;
          for (var i = a; i < Math.max(b, a + 1); i++) s += x[i];
          part[n++] = s / Math.max(1, b - a);
          if (n === BLOCK) { onBlock(part); part = new Float32Array(BLOCK); n = 0; }
          pos += step;
        }
        pos -= x.length;
      };
      src.connect(proc); proc.connect(mute); mute.connect(ac.destination);
      mic = { stream: stream, ac: ac, src: src, proc: proc };
      micOpening = null;
      return mic;
    }, function (e) { micOpening = null; throw e; });
    return micOpening;
  }
  function closeMic() {
    if (!mic) return;
    try { mic.proc.onaudioprocess = null; mic.src.disconnect(); mic.proc.disconnect(); } catch (e) {}
    try { mic.stream.getTracks().forEach(function (t) { t.stop(); }); } catch (e) {}
    try { mic.ac.close(); } catch (e) {}
    mic = null; history = [];
  }

  // ── listening: speech is louder than the room. It starts after 60 ms above the bar and ends after a quiet spell ──
  function rms(b) { var s = 0; for (var i = 0; i < b.length; i++) s += b[i] * b[i]; return Math.sqrt(s / b.length); }
  function onBlock(b) {
    var v = rms(b);
    history.push(b); if (history.length > 50) history.shift();          // the last second
    if (!cap || !cap.speaking) floor = floor * 0.97 + Math.min(v, floor * 3 + 0.002) * 0.03;   // the room, while nobody talks
    var bar = Math.max(0.012, floor * 3.2);
    if (cap) level(v);
    if (!cap) return;
    cap.blocks.push(b);
    if (v > bar) { cap.loud++; cap.quiet = 0; cap.last = cap.blocks.length; if (cap.loud >= 3 && !cap.speaking) { cap.speaking = true; cap.from = Math.max(0, cap.blocks.length - 3 - 10); } }
    else { cap.loud = 0; if (cap.speaking) cap.quiet++; }
    var dur = cap.blocks.length * BLOCK / RATE;
    if (cap.speaking && cap.quiet * 20 >= cap.endMs) return finish();
    if (cap.speaking && dur > cap.maxSec) { if (cap.mode === "buzz") { startCap("buzz", null, 0); return; } return finish(); }   // a long stretch isn't "buzz" (the read-aloud voice, say)
    if (!cap.speaking && cap.mode !== "buzz" && dur > 7) { var t = cap.target; stopCap(); if (t && t.isConnected) showPill("Didn't hear anything. Type it, or press V to try again", "va-off", 3500); }
  }
  // a capture: "answer" into a box, or "buzz" while a tossup reads. pre: blocks from before it started (the buzz key
  // came down as you started to talk)
  function startCap(mode, target, pre) {
    var blocks = pre ? history.slice(-pre) : [];
    cap = { mode: mode, target: target, blocks: blocks, pre: blocks.length, last: 0, loud: 0, quiet: 0, speaking: false, from: 0,
      endMs: mode === "buzz" ? 350 : opt("autoSend") ? 750 : 1100, maxSec: mode === "buzz" ? 2.6 : 9 };
    if (mode === "answer") showPill(wready ? "Listening" : "Listening (still getting ready)", "va-on");
  }
  function stopCap() { cap = null; }
  function finish() {
    var c = cap; cap = null;
    // sound that stopped right as the buzz came (the read-aloud voice's last word, the key) isn't the answer: listen on
    if (c.mode === "answer" && c.last < c.pre + 12) { startCap("answer", c.target, 0); return; }
    var keep = c.blocks.slice(c.from), audio = new Float32Array(keep.length * BLOCK);
    keep.forEach(function (b, i) { audio.set(b, i * BLOCK); });
    if (c.mode === "buzz") return heardWhileReading(audio);
    pillText("…");
    transcribe(audio).then(function (text) {
      if (!c.target || !c.target.isConnected || c.target.disabled) { hidePill(); return; }
      text = clean(text);
      if (!text) { showPill("Didn't catch that. Press V to try again", "va-off", 3000); return; }
      put(c.target, text);
      if (opt("autoSend")) { showPill(text, "va-off", 1600); send(c.target); } else showPill(text + " (Enter sends it)", "va-off", 3000);
    }, function () { showPill(wfail || "Couldn't write that down", "va-off", 3500); });
  }
  function transcribe(audio) {
    return loadModel().then(function () { return call({ t: "run", audio: audio }); });
  }
  // what Whisper writes for a short answer: "Mozart." → "Mozart"; "(silence)", "[BLANK_AUDIO]" → nothing
  function clean(t) {
    t = String(t || "").replace(/\[[^\]]*\]|\([^)]*\)/g, " ").replace(/\s+/g, " ").trim().replace(/[.!?,;:]+$/, "");
    return /^(you|thank you|thanks for watching)$/i.test(t) ? "" : t;
  }
  function put(box, text) { box.value = text; box.dispatchEvent(new Event("input", { bubbles: true })); }
  function send(box) {
    if (!box || !box.isConnected || box.disabled) return;
    box.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", code: "Enter", bubbles: true, cancelable: true }));
  }

  // ── listen into an answer box (after a buzz, a bonus part, or V) ──
  function listen(box, pre) {
    if (!box) return;
    if (wfail && !wloading) { showPill(wfail, "va-off", 3500); return; }
    loadModel().catch(function () {});
    openMic().then(function () {
      if (mic && mic.ac.state === "suspended") mic.ac.resume();
      if (!box.isConnected || box.disabled) return;
      startCap("answer", box, pre || 0);
    }, function (e) {
      showPill(e && (e.name === "NotAllowedError" || e.name === "SecurityError") ? "Allow the microphone to answer by voice" : "No microphone found", "va-off", 4000);
    });
  }
  // "Say buzz": a short thing said while it reads; "buzz" buzzes, and words after it start the answer
  function heardWhileReading(audio) {
    if (!wready) { listenForBuzz(); return; }
    call({ t: "run", audio: audio }).then(function (text) {
      var s = ctx.getState();
      var m = /\bbuzz(?:ed|er|z)?\b[\s,.!-]*(.*)$/i.exec(clean(text));
      if (!m || !s || !s.sessionActive || s.isBuzzed) { listenForBuzz(); return; }
      document.dispatchEvent(new KeyboardEvent("keydown", { key: " ", code: "Space", bubbles: true, cancelable: true }));
      var after = m[1].trim();
      setTimeout(function () {
        var box = document.getElementById("buzz-input"); if (!box || box.disabled) return;
        if (after) { put(box, after); if (opt("autoSend")) { showPill(after, "va-off", 1600); send(box); return; } }
        startCap("answer", box, 0);
      }, 80);
    }, function () { listenForBuzz(); });
  }
  function listenForBuzz() {
    var s = ctx.getState();
    if (!ctx.getSetting("sayBuzz") || !opt("enabled") || !s || !s.sessionActive || s.isBuzzed || cap) return;
    startCap("buzz", null, 0);
  }

  ctx.on("buzz", function () {
    if (!opt("enabled")) return;
    stopCap();
    if (mic && mic.ac.state === "suspended") mic.ac.resume();
    // the half second before the buzz is kept: an answer started with the key isn't cut
    setTimeout(function () { var box = document.getElementById("buzz-input"); if (box && !box.disabled) listen(box, 25); }, 30);
  });
  ctx.on("question:render", function (d) {
    stopCap(); hidePill();
    if (!opt("enabled")) return;
    loadModel().catch(function () {});
    openMic().then(function () { if (d && d.type === "tossup") setTimeout(listenForBuzz, 300); }, function () {});
  });
  function done() { stopCap(); hidePill(); }
  ctx.on("answer:result", function () { done(); setTimeout(listenForBuzz, 50); });
  ctx.on("bonus:result", done);
  ctx.on("session:end", function () { done(); closeMic(); });
  ctx.on("screen:change", function () { done(); closeMic(); });
  // a bonus part asking for its answer
  function onFocus(e) {
    var t = e.target;
    if (!opt("enabled") || !ctx.getSetting("bonuses") || !t || !t.classList || !t.classList.contains("bonus-answer-input") || t.disabled) return;
    if (cap && cap.target === t) return;
    listen(t, 0);
  }
  // V: listen into the answer box in front of you; Esc stops
  function onKey(e) {
    if ((e.key === "v" || e.key === "V") && !e.metaKey && !e.ctrlKey && !e.altKey && !inField(e)) {
      var box = [].slice.call(document.querySelectorAll("#buzz-input, .bonus-answer-input")).find(function (i) { return !i.disabled && i.offsetParent !== null; });
      if (box) { e.preventDefault(); box.focus(); listen(box, 0); }
    }
    if (e.key === "Escape" && cap && cap.mode === "answer") { stopCap(); hidePill(); }
  }
  document.addEventListener("focusin", onFocus);
  document.addEventListener("keydown", onKey, true);
  ctx._cleanup = function () {
    done(); closeMic();
    if (worker) { try { worker.terminate(); } catch (e) {} worker = null; }
    document.removeEventListener("focusin", onFocus); document.removeEventListener("keydown", onKey, true);
  };

}
