/**
 * OfflineQuiz plugin: Answer Notes
 *
 * Your notes, kept with the answer they're about. Under each practice result you can add or edit a
 * note on its answer, and it shows again whenever that answer comes up. The page lists them all and
 * quizzes you on them.
 */
QB.registerPlugin({
  id: "answer-notes",
  name: "Answer Notes",
  version: "1.0.1",
  author: "OfflineQuiz",
  description: "Write your own notes on an answer and see them every time it comes up in practice.",
  onEnable: __qbMain,
  onDisable: function (ctx) { if (ctx._cleanup) ctx._cleanup(); },
});
