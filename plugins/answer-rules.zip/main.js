/**
 * OfflineQuiz plugin: Answer Rules
 *
 * Edit how the answer checker treats YOUR answers. Add rules that force a
 * tossup answer to be ACCEPTED, PROMPTED, or REJECTED when what you type
 * matches a pattern — optionally only on questions whose answer line mentions
 * something. Rules run in order; the first match wins and overrides the
 * checker's verdict. A live tester shows exactly which rule fires.
 *
 * Scope: these rules apply to TOSSUP judging in solo practice (the path that
 * runs the plugin answer-rule hooks). Bonuses and multiplayer use the host's
 * unmodified checker.
 */
QB.registerPlugin({
  id: "answer-rules",
  name: "Answer Rules",
  version: "1.2.1",
  author: "OfflineQuiz",
  description: "Custom accept / prompt / reject rules for the answer checker: match what you type (and optionally the answer line) and override the verdict.",
  onEnable: __qbMain,
  onDisable: function () {},
});
