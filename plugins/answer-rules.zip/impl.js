function __qbMain(ctx) {
    var body = null, page = null;

    function esc(s) { return (s == null ? "" : String(s)).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
    function rules() { return ctx.storage.get("rules") || []; }
    function save(r) { ctx.storage.set("rules", r); syncRegistration(); }
    // Accept both "napoleon" and "/napoleon/i" forms; default case-insensitive.
    function buildRegex(pat) {
      var bodyRe = pat, flags = "i";
      var m = /^\/(.*)\/([a-z]*)$/i.exec(pat);
      if (m) { bodyRe = m[1]; flags = m[2] || "i"; }
      try { return new RegExp(bodyRe, flags); } catch (e) { return null; }
    }

    // Does a rule match this (already lowercased) answer + answer line?
    function matchRule(r, userAnswer, answerLine) {
      if (!r || !r.enabled) return false;
      var p = (r.pattern || "").trim();
      if (!p) return false;
      if (r.scope && r.scope.trim()) {
        if (answerLine.indexOf(r.scope.trim().toLowerCase()) < 0) return false;
      }
      if (r.mode === "equals") return userAnswer === p.toLowerCase();
      if (r.mode === "regex") { var re = buildRegex(p); return re ? re.test(userAnswer) : false; }
      return userAnswer.indexOf(p.toLowerCase()) >= 0; // "contains"
    }
    // First matching rule wins; returns its action ("accept"/"prompt"/"reject") or null.
    function firstMatch(userAnswer, answerLine) {
      var rs = rules();
      for (var i = 0; i < rs.length; i++) if (matchRule(rs[i], userAnswer, answerLine)) return { rule: rs[i], i: i };
      return null;
    }

    // ── the answer-checker hook, registered LAZILY so merely enabling the
    //    plugin (with no rules) does not reroute all tossup judging. ──
    function ruleFn(verdict, c) {
      var ua = String(c.userAnswer || "").toLowerCase().trim();
      if (!ua) return verdict;
      var ans = String((c.question && (c.question.answer_sanitized || c.question.answer)) || "").toLowerCase();
      var hit = firstMatch(ua, ans);
      return hit ? hit.rule.action : verdict;
    }
    var ruleRec = null;
    function hasActiveRules() {
      return rules().some(function (r) { return r && r.enabled && (r.pattern || "").trim(); });
    }
    function syncRegistration() {
      var want = hasActiveRules();
      if (want && !ruleRec) ruleRec = ctx.registerAnswerRule(ruleFn);
      else if (!want && ruleRec) { if (ruleRec.remove) ruleRec.remove(); ruleRec = null; }
    }
    syncRegistration();

    page = ctx.registerPage({
      id: "rules", navLabel: "Answer Rules", title: "ANSWER RULES",
      onShow: function (el) { body = el; if (!body.querySelector("#ar-pattern")) render(); },
    });

    var ACTION_LABEL = { accept: "ACCEPT", prompt: "PROMPT", reject: "REJECT" };
    var ACTION_CLASS = { accept: "ar-accept", prompt: "ar-prompt", reject: "ar-reject" };
    var MODE_LABEL = { contains: "contains", equals: "is exactly", regex: "matches regex" };

    function render() {
      if (!body) return;
      var rs = rules();
      body.innerHTML =
        '<div class="ar-wrap">' +
          '<div class="ar-card">' +
            // add form
            '<div class="ar-form">' +
              '<select id="ar-action" class="mode-input"><option value="accept">Accept</option><option value="prompt">Prompt</option><option value="reject">Reject</option></select>' +
              '<span class="ar-lbl">when I type</span>' +
              '<select id="ar-mode" class="mode-input"><option value="contains">contains</option><option value="equals">is exactly</option><option value="regex">matches regex</option></select>' +
              '<input type="text" id="ar-pattern" class="mode-input" placeholder="text or /regex/" autocomplete="off" spellcheck="false">' +
            "</div>" +
            '<div class="ar-form">' +
              '<span class="ar-lbl">if answer line has</span>' +
              '<input type="text" id="ar-scope" class="mode-input" placeholder="optional" autocomplete="off" spellcheck="false">' +
              '<button class="btn btn-primary" id="ar-add">Add rule</button>' +
            "</div>" +
          "</div>" +
          // rules list
          '<div class="ar-card">' +
            '<div class="filter-label">RULES (' + rs.length + ")" + '<span class="qb-info" data-tip="Rules override the answer checker for tossups in practice. They run top to bottom; the first match wins.">i</span>' + "</div>" +
            (rs.length
              ? '<table class="stats-table ar-table"><thead><tr><th></th><th>Then</th><th>When you type</th><th>Only if answer line has</th><th></th></tr></thead><tbody>' +
                rs.map(function (r, i) {
                  return "<tr>" +
                    '<td><input type="checkbox" class="ar-en" data-i="' + i + '"' + (r.enabled ? " checked" : "") + "></td>" +
                    '<td><span class="ar-badge ' + (ACTION_CLASS[r.action] || "") + '">' + (ACTION_LABEL[r.action] || esc(r.action)) + "</span></td>" +
                    "<td>" + esc(MODE_LABEL[r.mode] || r.mode) + " <strong>" + esc(r.pattern) + "</strong></td>" +
                    "<td>" + (r.scope ? esc(r.scope) : '<span class="text-muted">any</span>') + "</td>" +
                    '<td><button class="btn btn-sm btn-ghost ar-del" data-i="' + i + '" title="Delete">&times;</button></td>' +
                    "</tr>";
                }).join("") + "</tbody></table>"
              : '<div class="text-muted" style="font-size:12px">No rules yet.</div>') +
          "</div>" +
          // live tester
          '<div class="ar-card">' +
            '<div class="filter-label">TEST A RULE</div>' +
            '<div class="ar-form">' +
              '<span class="ar-lbl">if I typed</span>' +
              '<input type="text" id="ar-test-ans" class="mode-input" placeholder="your answer…" autocomplete="off" spellcheck="false">' +
              '<span class="ar-lbl">answer line</span>' +
              '<input type="text" id="ar-test-line" class="mode-input" placeholder="(optional answer line)" autocomplete="off" spellcheck="false">' +
            "</div>" +
            '<div id="ar-test-out" class="text-muted" style="font-size:12px"></div>' +
          "</div>" +
        "</div>";

      body.querySelector("#ar-add").onclick = function () {
        var pattern = body.querySelector("#ar-pattern").value.trim();
        if (!pattern) { ctx.toast("Enter what you type to match", "error"); return; }
        var r = rules();
        r.push({
          action: body.querySelector("#ar-action").value,
          mode: body.querySelector("#ar-mode").value,
          pattern: pattern,
          scope: body.querySelector("#ar-scope").value.trim(),
          enabled: true,
        });
        save(r);
        render();
        ctx.toast("Rule added");
      };
      body.querySelectorAll(".ar-en").forEach(function (cb) {
        cb.addEventListener("change", function () { var r = rules(); r[+cb.dataset.i].enabled = cb.checked; save(r); });
      });
      body.querySelectorAll(".ar-del").forEach(function (b) {
        b.addEventListener("click", function () { var r = rules(); r.splice(+b.dataset.i, 1); save(r); render(); });
      });

      var ta = body.querySelector("#ar-test-ans"), tl = body.querySelector("#ar-test-line"), out = body.querySelector("#ar-test-out");
      function runTest() {
        var ua = (ta.value || "").toLowerCase().trim();
        var line = (tl.value || "").toLowerCase();
        if (!ua) { out.className = "text-muted"; out.style.fontSize = "12px"; out.textContent = ""; return; }
        var badRe = rules().filter(function (r) { return r.enabled && r.mode === "regex" && (r.pattern || "").trim() && !buildRegex(r.pattern); });
        if (badRe.length) {
          out.className = "ar-test-hit ar-reject"; out.style.fontSize = "12px";
          out.textContent = "Warning: " + badRe.length + " regex rule(s) are invalid and never match.";
          return;
        }
        var hit = firstMatch(ua, line);
        if (hit) {
          out.style.fontSize = "13px";
          out.className = "ar-test-hit " + (ACTION_CLASS[hit.rule.action] || "");
          out.innerHTML = "Rule #" + (hit.i + 1) + " fires → <strong>" + (ACTION_LABEL[hit.rule.action] || esc(hit.rule.action)) + "</strong>";
        } else {
          out.className = "text-muted"; out.style.fontSize = "12px";
          out.textContent = "No rule matches";
        }
      }
      ta.addEventListener("input", runTest); tl.addEventListener("input", runTest);
    }

    ctx.toast("Answer Rules enabled");
  }
