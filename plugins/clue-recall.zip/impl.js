function __qbMain(ctx) {
  var body = null, page = null;
  function esc(s) { return (s == null ? "" : String(s)).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
  function ansHtml(raw, fallback) {
    var src = (raw && String(raw).trim()) ? String(raw) : String(fallback || "");
    var html = esc(src).replace(/&lt;(\/?)(b|u|i|em|strong)&gt;/gi, "<$1$2>");
    var d = document.createElement("div"); d.innerHTML = html; return d.innerHTML;
  }

  // Abbreviation-aware sentence split (same rules as Coach Mode) — a naive
  // period split would serve fragments like "The St." as clues.
  var SENT_ABBR = /(?:\b(?:St|Ste|Mt|Mts|Dr|Mr|Mrs|Ms|Messrs|Mme|Mlle|Prof|Sr|Jr|Rev|Fr|Gen|Col|Capt|Lt|Sgt|Maj|Adm|Hon|Pres|Gov|Sen|Rep|Supt|Msgr|vs|etc|cf|ca|al|Inc|Co|Corp|Ltd|Bros|approx|No|Nos|Op|op|no|Vol|vol|Ch|ch|Fig|fig|Ft|Pt|pt|Rte|Ave|Blvd|[A-Za-z])\.["”’']?)$/;
  function splitClues(text) {
    var parts = String(text || "").replace(/\(\*\)/g, "").split(/(?<=[.!?…]["”’']?)\s+(?=["“‘']?[A-Z0-9(])/);
    var out = [], cur = "";
    for (var i = 0; i < parts.length; i++) {
      cur = cur ? cur + " " + parts[i] : parts[i];
      if (i < parts.length - 1 && SENT_ABBR.test(cur.trim())) continue;
      out.push(cur.trim()); cur = "";
    }
    if (cur.trim()) out.push(cur.trim());
    return out.filter(Boolean);
  }

  // A tossup's clue text: the record's text as the practice screen reads it
  // (ctx.host.questionText), with moderator / reader notes ALWAYS cut, whatever
  // the Hide-notes setting — a note is one italic run in the HTML that starts
  // with its label; the plain copy keeps its text with no end marker.
  var NOTE_LABEL = /^\s*(?:note to (?:the )?(?:moderators?|readers?)\b|reader(?:'s)? note\b|moderator(?:'s)? note\b)/i;
  var ENT = { amp: "&", lt: "<", gt: ">", quot: '"', apos: "'", nbsp: "\u00a0" };
  function decodeEnt(s) {
    return String(s || "").replace(/&(#x[0-9a-f]+|#\d+|[a-z]+);/gi, function (m, e) {
      if (e[0] === "#") { var n = e[1] === "x" || e[1] === "X" ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10); try { return String.fromCodePoint(n); } catch (x) { return m; } }
      var v = ENT[e.toLowerCase()]; return v == null ? m : v;
    });
  }
  function foldPlain(s) {
    return String(s || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "")
      .replace(/[“”]/g, '"').replace(/[‘’]/g, "'").replace(/[–—]/g, "-").replace(/…/g, "...").replace(/\u00a0/g, " ");
  }
  function cutNotes(text, html) {
    var t = String(text || "");
    String(html || "").replace(/<(i|em)\b[^>]*>([\s\S]*?)<\/\1>/gi, function (m, tag, inner) {
      var note = decodeEnt(inner.replace(/<[^>]*>/g, "")).trim();
      if (!note || !NOTE_LABEL.test(note)) return m;
      [foldPlain(note), note].some(function (cand) {
        var i = t.indexOf(cand);
        if (i < 0) return false;
        t = t.slice(0, i).replace(/\s+$/, "") + (i > 0 ? " " : "") + t.slice(i + cand.length).replace(/^\s+/, "");
        return true;
      });
      return m;
    });
    // older records: a bracketed note in the plain text
    return t.replace(/\s*[\[(]\s*(?:notes?\s+to\s+(?:the\s+)?(?:moderators?|readers?)|moderator(?:'s)?\s+notes?|reader(?:'s)?\s+notes?)\b[^\])]*[\])]/gi, "").trim();
  }
  function clueText(t) {
    var s = null;
    try { if (ctx.host && ctx.host.questionText) s = ctx.host.questionText(t, "question"); } catch (e) { s = null; }
    if (s == null) s = t.question_sanitized || t.question || "";
    return cutNotes(s, t.question);
  }
  // Pill label: the deepest level of the question's category path.
  function catLabel(t) {
    var p = String((t && t.category_path) || "").split(" > ").filter(Boolean);
    return p.length ? p[p.length - 1] : ((t && t.category) || "");
  }

  // ── categories ──────────────────────────────────────────────────────────
  // The app's picker (ctx.host.categoryPicker) when the base has it: cfg.cats
  // holds the picked node ids (whole subtrees, [] = all), sent as categoryIds.
  // An older base keeps the cat → sub cascade below, on cfg.category.
  var PICKER = !!(ctx.host && typeof ctx.host.categoryPicker === "function");
  var picker = null;
  function getPicker() {
    if (picker || !PICKER) return picker;
    try {
      picker = ctx.host.categoryPicker(null, {
        selected: Array.isArray(cfg.cats) ? cfg.cats : [],
        type: "tossups",
        onChange: function (ids) { cfg.cats = ids; ctx.storage.set("cfg", cfg); clearNoMatch(); },
      });
    } catch (e) { picker = null; PICKER = false; }
    return picker;
  }
  // The old single pick (cfg.category: a node id, or a pre-tree root name that
  // resolveCfgCat maps) becomes a one-element list, once.
  async function ensureCats() {
    if (Array.isArray(cfg.cats)) return cfg.cats;
    if (cfg.category) { try { await loadTree(); } catch (e) {} }
    if (Array.isArray(cfg.cats)) return cfg.cats;
    if (cfg.category && !(TREE && TREE.roots.length)) return [String(cfg.category)];   // tree unavailable: try again later
    cfg.cats = cfg.category ? [String(cfg.category)] : [];
    ctx.storage.set("cfg", cfg);
    if (picker) picker.set(cfg.cats);
    return cfg.cats;
  }
  function clearNoMatch() { noMatch = false; var nm = body && body.querySelector(".cr-nomatch"); if (nm) nm.remove(); }
  function pickerOpen() {
    return [].some.call(document.querySelectorAll(".cat-ovl:not(.hidden)"), function (o) { return o.getClientRects().length > 0; });
  }

  // ── category tree: roots + their level-2 children (older bases) ──────────
  // cfg.category holds the DEEPEST pick's node id (root or level 2).
  var OLD_ROOT = { "Science": "Science and Math", "Religion": "Theology", "Pop Culture": "Pop Culture Sports", "Trash": "Pop Culture Sports", "Other Academic": "Miscellaneous" };
  var TREE = null, treeP = null;   // { roots, byId: { id: { node, root } } }
  function loadTree() {
    if (treeP) return treeP;
    treeP = (async function () {
      var roots = null;
      try {
        if (ctx.host && ctx.host.getCategoryTree) roots = await ctx.host.getCategoryTree("tossups");
        else roots = (await ctx.api.get("/api/category-tree?type=tossups")).tree;
      } catch (e) { roots = null; }
      if (!roots || !roots.length) {   // older base without the tree: level-1 names
        try {
          roots = ((await ctx.api.get("/api/categories?type=tossups")).categories || []).map(function (c) { return { id: c.category, name: c.category, children: [] }; });
        } catch (e) { roots = []; }
      }
      var byId = {};
      roots.forEach(function (r) {
        byId[r.id] = { node: r, root: r };
        (r.children || []).forEach(function (c) { byId[c.id] = { node: c, root: r }; });
      });
      TREE = { roots: roots, byId: byId };
      if (!roots.length) treeP = null;   // retry on the next paint
      resolveCfgCat();
      return TREE;
    })();
    return treeP;
  }
  // A saved cfg.category from before the tree held a root NAME: map it once,
  // or reset to "All categories" — a stale value must never break a draw.
  function resolveCfgCat() {
    if (!cfg.category || !TREE || !TREE.roots.length || TREE.byId[cfg.category]) return;
    var nm = OLD_ROOT[cfg.category] || cfg.category, hit = null;
    TREE.roots.forEach(function (r) { if (!hit && r.name === nm) hit = r; });
    cfg.category = hit ? hit.id : "";
    ctx.storage.set("cfg", cfg);
  }
  function addOpt(sel, value, label, on) {
    var o = document.createElement("option"); o.value = value; o.textContent = label;
    if (on) o.selected = true;
    sel.appendChild(o);
  }
  function fillSub(sub, rootId, subId) {
    if (!sub) return;
    sub.innerHTML = '<option value="">All subcategories</option>';
    var e = rootId && TREE && TREE.byId[rootId];
    var kids = e ? (e.node.children || []).filter(function (c) { return c.count == null || c.count > 0; }) : [];
    kids.forEach(function (c) { addOpt(sub, c.id, c.name, c.id === subId); });
    sub.disabled = !kids.length; sub.style.opacity = kids.length ? "1" : "0.5";
  }

  // ── settings ────────────────────────────────────────────────────────────
  var cfg = { category: "", difficulties: [2, 3, 4, 5], band: "any", secs: 15, autoReview: true };
  Object.assign(cfg, ctx.storage.get("cfg") || {});
  var best = ctx.storage.get("best") || { streak: 0, score: 0 };

  // ── round state ─────────────────────────────────────────────────────────
  var phase = "idle";     // idle | asking | result
  var q = null, clue = "", clueIdx = 0, clueCount = 1, deadline = 0, tick = null;
  var score = 0, streak = 0, asked = 0, right = 0, roundPts = 0;
  var noMatch = false;    // last draw found nothing; shown on the idle view
  var promptFrom = null, promptAsk = "";   // one prompt per answer: the prompted answer + its ask

  function strictness() {
    try { return (ctx.host.getPracticeConfig && ctx.host.getPracticeConfig().strictness) || 10; } catch (e) { return 10; }
  }
  function stopTick() { if (tick) { clearInterval(tick); tick = null; } }

  async function nextClue() {
    stopTick();
    phase = "asking"; q = null; clue = ""; promptFrom = null; promptAsk = "";
    paint();
    var qs = ["random=1", "limit=1"];
    if (PICKER) {
      var ids = await ensureCats();
      if (picker && Array.isArray(cfg.cats)) ids = picker.get();
      if (ids.length) qs.push("categoryIds=" + ids.map(encodeURIComponent).join(","));
    } else {
      await loadTree();
      if (cfg.category) qs.push("categories=" + encodeURIComponent(cfg.category));
    }
    if (cfg.difficulties.length) qs.push("difficulties=" + cfg.difficulties.join(","));
    for (var attempt = 0; attempt < 3 && !clue; attempt++) {
      try {
        var d = await ctx.api.get("/api/tossups/random?" + qs.join("&"));
        var t = d.tossup;
        if (!t) break;
        var clues = splitClues(clueText(t));
        clues = clues.filter(function (c) { return !NOTE_LABEL.test(c); });
        if (clues.length && /for (10|ten) points/i.test(clues[clues.length - 1])) clues.pop();
        clues = clues.filter(function (c) { return c.length > 40; });   // fragments make unfair clues
        if (!clues.length) continue;
        var idx;
        var third = Math.max(1, Math.ceil(clues.length / 3));
        if (cfg.band === "early") idx = Math.floor(Math.random() * third);
        else if (cfg.band === "late") idx = clues.length - 1 - Math.floor(Math.random() * third);
        else if (cfg.band === "middle") idx = Math.min(clues.length - 1, third + Math.floor(Math.random() * third));
        else idx = Math.floor(Math.random() * clues.length);
        idx = Math.max(0, Math.min(clues.length - 1, idx));
        q = t; clue = clues[idx]; clueIdx = idx; clueCount = clues.length;
      } catch (e) { break; }
    }
    if (!clue) { phase = "idle"; noMatch = true; paint(); ctx.toast("No questions match those filters", "error"); return; }
    noMatch = false;
    asked++;
    deadline = Date.now() + cfg.secs * 1000;
    paint();
    var inp = body && body.querySelector("#cr-input"); if (inp) inp.focus();
    startTick();
  }
  function startTick() {
    stopTick();
    tick = setInterval(function () {
      var left = deadline - Date.now();
      var bar = body && body.querySelector("#cr-timer-fill");
      if (bar) bar.style.width = Math.max(0, Math.min(100, (left / (cfg.secs * 1000)) * 100)) + "%";
      var lbl = body && body.querySelector("#cr-timer");
      if (lbl) lbl.textContent = Math.max(0, Math.ceil(left / 1000)) + "s";
      if (left <= 0) submit((body && body.querySelector("#cr-input") || {}).value || "", true);
    }, 100);
  }

  function ptsFor(idx, count) {
    var frac = count <= 1 ? 1 : idx / (count - 1);
    return frac < 0.34 ? 3 : frac < 0.67 ? 2 : 1;   // earlier clue = harder = more
  }

  // One prompt per answer: a first prompt reopens the input under a PROMPT
  // banner with the timer restarted, and the reply is judged with the prompted
  // answer (`previous`). A second prompt, or time running out on the prompt,
  // is a miss.
  async function submit(text, timedOut) {
    if (phase !== "asking" || !q) return;
    stopTick();
    phase = "result";
    var status = "reject", cur = q, r = null;
    var given = timedOut && promptFrom != null ? "" : String(text || "").trim();
    if (given) {
      try {
        r = await ctx.api.post("/api/evaluate-answer", { answerline: q.answer, sanitized: q.answer_sanitized, answer: given, strictness: strictness(), previous: promptFrom });
        status = (r && r.status) || "reject";
      } catch (e) {}
      if (q !== cur) return;   // [N] pressed while judging: that clue is gone
    }
    if (status === "prompt" && promptFrom == null) {
      promptFrom = given;
      promptAsk = (r.prompt && r.prompt.ask) || (r.antiprompt ? "less specific?" : "");
      phase = "asking";
      deadline = Date.now() + cfg.secs * 1000;
      paint();   // fresh, focused input under the banner
      startTick();
      return;
    }
    var prompted = promptFrom != null;
    promptFrom = null; promptAsk = "";
    var ok = status === "accept";
    if (ok) {
      right++;
      roundPts = ptsFor(clueIdx, clueCount);
      score += roundPts;
      streak++;
      if (streak > best.streak) best.streak = streak;
      if (score > best.score) best.score = score;
      ctx.storage.set("best", best);
      ctx.playSound("correct");
    } else {
      streak = 0; roundPts = 0;
      ctx.playSound("incorrect");
      if (cfg.autoReview && q.id) ctx.api.post("/api/review/manual", { questionId: q.id, add: true, type: "tossup" }).catch(function () {});
    }
    q._given = given;
    q._ok = ok; q._prompted = ok && prompted;
    paint();
  }

  function bandLabel(idx, count) {
    var frac = count <= 1 ? 1 : idx / (count - 1);
    return frac < 0.34 ? "EARLY CLUE · 3 pts" : frac < 0.67 ? "MIDDLE CLUE · 2 pts" : "LATE CLUE · 1 pt";
  }

  function paint() {
    if (!body) return;
    var head =
      '<div class="cr-head">' +
        '<span class="pill">Score ' + score + '</span><span class="pill' + (streak >= 3 ? " pill-green" : "") + '">Streak ' + streak + "</span>" +
        '<span class="pill">' + right + "/" + asked + '</span><span class="text-muted" style="font-size:11px">best streak ' + best.streak + " · best score " + best.score + "</span>" +
      "</div>";
    var controls =
      '<div class="cr-controls">' +
        (getPicker() ? '<span id="cr-catslot"></span>' :
          '<select id="cr-cat" class="mode-input" style="width:150px"><option value="">All categories</option></select>' +
          '<select id="cr-sub" class="mode-input" style="width:170px" disabled><option value="">All subcategories</option></select>') +
        '<select id="cr-band" class="mode-input" style="width:130px">' +
          [["any", "Any clue"], ["early", "Early clues"], ["middle", "Middle clues"], ["late", "Late clues"]].map(function (o) { return '<option value="' + o[0] + '"' + (cfg.band === o[0] ? " selected" : "") + ">" + o[1] + "</option>"; }).join("") +
        "</select>" +
        '<select id="cr-secs" class="mode-input" style="width:90px">' +
          [5, 10, 15, 20, 30].map(function (v) { return '<option value="' + v + '"' + (cfg.secs === v ? " selected" : "") + ">" + v + "s</option>"; }).join("") +
        "</select>" +
        '<label class="checkbox-row" title="Misses are added to your Review queue"><input type="checkbox" id="cr-rev"' + (cfg.autoReview ? " checked" : "") + "> Misses → Review</label>" +
      "</div>";
    var main;
    if (phase === "idle") {
      main = '<div class="cr-idle"><button class="btn btn-primary" id="cr-start">[S] Start</button><span class="qb-info" data-tip="One clue, one answer, ' + esc(cfg.secs) + ' seconds. Earlier clues score more; misses go to Review.">i</span>' +
        (noMatch ? '<span class="text-muted cr-nomatch" style="margin-left:10px;font-size:12px">No matches</span>' : "") + '</div>';
    } else if (phase === "asking" && !clue) {
      main = '<div class="text-muted" style="padding:24px">Drawing a clue…</div>';
    } else if (phase === "asking") {
      main =
        '<div class="cr-meta"><span class="pill" title="' + esc(q.category_path || q.category || "") + '">' + esc(catLabel(q)) + '</span><span class="pill">' + esc(bandLabel(clueIdx, clueCount)) + '</span><span id="cr-timer" class="pill"></span></div>' +
        '<div class="cr-clue">' + esc(clue) + "</div>" +
        '<div class="mp-timer-bar"><div id="cr-timer-fill"></div></div>' +
        (promptFrom != null ? '<div class="buzz-prompt-banner"><span class="prompt-tag">PROMPT</span>' + (promptAsk ? " " + esc(promptAsk) : "") + "</div>" : "") +
        '<div class="buzz-prompt"><span class="prompt-symbol">&gt;</span><input type="text" id="cr-input" placeholder="answer… (Enter)" autocomplete="off" autocorrect="off" spellcheck="false"></div>';
    } else {
      main =
        '<div class="cr-meta"><span class="pill" title="' + esc(q.category_path || q.category || "") + '">' + esc(catLabel(q)) + "</span></div>" +
        '<div class="cr-clue cr-dim">' + esc(clue) + "</div>" +
        '<div class="result-banner ' + (q._ok ? "correct" : "incorrect") + '">' + (q._ok ? "+" + roundPts + (q._prompted ? " (on a prompt)" : "") : (q._given ? "✗ “" + esc(q._given) + "”" : "✗ time")) + "</div>" +
        '<div class="result-answer">ANSWER: <span class="actual">' + ansHtml(q.answer, q.answer_sanitized) + "</span></div>" +
        '<div class="text-muted" style="font-size:12px;margin-top:8px">[N] next clue' + (!q._ok && cfg.autoReview ? " · added to Review" : "") + "</div>";
    }
    body.innerHTML = '<div class="cr-wrap">' + head + controls + '<div class="cr-main">' + main + "</div></div>";

    // wire
    var slot = body.querySelector("#cr-catslot");
    if (slot && picker) {
      slot.parentNode.replaceChild(picker.el, slot);   // one picker, re-seated on every paint
      if (!Array.isArray(cfg.cats)) ensureCats().catch(function () {});
    } else {
      var cat = body.querySelector("#cr-cat"), sub = body.querySelector("#cr-sub");
      sub.style.opacity = "0.5";
      loadTree().then(function (tr) {
        if (!cat || !cat.isConnected) return;
        var cur = tr.byId[cfg.category];
        var rootId = cur ? cur.root.id : "", subId = cur && cur.node !== cur.root ? cur.node.id : "";
        tr.roots.forEach(function (r) { addOpt(cat, r.id, r.name, r.id === rootId); });
        fillSub(sub, rootId, subId);
      }).catch(function () {});
      cat.onchange = function (e) { cfg.category = e.target.value; ctx.storage.set("cfg", cfg); fillSub(sub, cfg.category, ""); clearNoMatch(); };
      sub.onchange = function (e) { cfg.category = e.target.value || cat.value; ctx.storage.set("cfg", cfg); clearNoMatch(); };
    }
    body.querySelector("#cr-band").onchange = function (e) { cfg.band = e.target.value; ctx.storage.set("cfg", cfg); clearNoMatch(); };
    body.querySelector("#cr-secs").onchange = function (e) { cfg.secs = parseInt(e.target.value) || 15; ctx.storage.set("cfg", cfg); };
    body.querySelector("#cr-rev").onchange = function (e) { cfg.autoReview = e.target.checked; ctx.storage.set("cfg", cfg); };
    var start = body.querySelector("#cr-start"); if (start) start.onclick = nextClue;
    var inp = body.querySelector("#cr-input");
    if (inp) {
      inp.focus();
      inp.addEventListener("keydown", function (e) { if (e.key === "Enter") { e.stopPropagation(); submit(inp.value); } });
    }
  }

  function active() { return page && page.screenEl && page.screenEl.classList.contains("active") && !pickerOpen(); }
  ctx.onHotkey("start", function () { if (active() && phase === "idle") nextClue(); });
  ctx.onHotkey("next", function () { if (active() && (phase === "result" || phase === "idle")) nextClue(); });

  page = ctx.registerPage({
    id: "recall", navLabel: "Clue Recall", title: "CLUE RECALL",
    onShow: function (el) { body = el; paint(); },
    onHide: function () { stopTick(); },
  });
  ctx._cleanup = function () { stopTick(); };

  ctx.toast("Clue Recall enabled");
}
