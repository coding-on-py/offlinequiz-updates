function __qbMain(ctx) {
  var body = null, page = null;
  function esc(s) { return (s == null ? "" : String(s)).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
  function ansHtml(raw, fallback) {
    var src = (raw && String(raw).trim()) ? String(raw) : String(fallback || "");
    var html = esc(src).replace(/&lt;(\/?)(b|u|i|em|strong)&gt;/gi, "<$1$2>");
    var d = document.createElement("div"); d.innerHTML = html; return d.innerHTML;
  }

  // Abbreviation-aware sentence split (same rules as Coach Mode) — a naive
  // period split would serve fragments like "The St." as clues.
  var SENT_ABBR = /(?:\b(?:St|Ste|Mt|Mts|Dr|Mr|Mrs|Ms|Messrs|Mme|Mlle|Prof|Sr|Jr|Rev|Fr|Gen|Col|Capt|Lt|Sgt|Maj|Adm|Hon|Pres|Gov|Sen|Rep|Supt|Msgr|vs|etc|cf|ca|al|Inc|Co|Corp|Ltd|Bros|approx|No|Nos|Op|op|no|Vol|vol|Ch|ch|Fig|fig|Ft|Pt|pt|Rte|Ave|Blvd|[A-Za-z])\.["”’']?)$/;
  function splitClues(text) {
    var parts = String(text || "").replace(/\(\*\)/g, "").split(/(?<=[.!?…]["”’']?)\s+(?=["“‘']?[A-Z0-9(])/);
    var out = [], cur = "";
    for (var i = 0; i < parts.length; i++) {
      cur = cur ? cur + " " + parts[i] : parts[i];
      if (i < parts.length - 1 && SENT_ABBR.test(cur.trim())) continue;
      out.push(cur.trim()); cur = "";
    }
    if (cur.trim()) out.push(cur.trim());
    return out.filter(Boolean);
  }

  // ── settings ────────────────────────────────────────────────────────────
  var cfg = { category: "", difficulties: [2, 3, 4, 5], band: "any", secs: 15, autoReview: true };
  Object.assign(cfg, ctx.storage.get("cfg") || {});
  var best = ctx.storage.get("best") || { streak: 0, score: 0 };

  // ── round state ─────────────────────────────────────────────────────────
  var phase = "idle";     // idle | asking | result
  var q = null, clue = "", clueIdx = 0, clueCount = 1, deadline = 0, tick = null;
  var score = 0, streak = 0, asked = 0, right = 0, roundPts = 0;

  function strictness() {
    try { return (ctx.host.getPracticeConfig && ctx.host.getPracticeConfig().strictness) || 10; } catch (e) { return 10; }
  }
  function stopTick() { if (tick) { clearInterval(tick); tick = null; } }

  async function nextClue() {
    stopTick();
    phase = "asking"; q = null; clue = "";
    paint();
    var qs = ["random=1", "limit=1"];
    if (cfg.category) qs.push("categories=" + encodeURIComponent(cfg.category));
    if (cfg.difficulties.length) qs.push("difficulties=" + cfg.difficulties.join(","));
    for (var attempt = 0; attempt < 3 && !clue; attempt++) {
      try {
        var d = await ctx.api.get("/api/tossups/random?" + qs.join("&"));
        var t = d.tossup;
        if (!t) break;
        var clues = splitClues(t.question_sanitized || t.question || "");
        if (clues.length && /for (10|ten) points/i.test(clues[clues.length - 1])) clues.pop();
        clues = clues.filter(function (c) { return c.length > 40; });   // fragments make unfair clues
        if (!clues.length) continue;
        var idx;
        var third = Math.max(1, Math.ceil(clues.length / 3));
        if (cfg.band === "early") idx = Math.floor(Math.random() * third);
        else if (cfg.band === "late") idx = clues.length - 1 - Math.floor(Math.random() * third);
        else if (cfg.band === "middle") idx = Math.min(clues.length - 1, third + Math.floor(Math.random() * third));
        else idx = Math.floor(Math.random() * clues.length);
        idx = Math.max(0, Math.min(clues.length - 1, idx));
        q = t; clue = clues[idx]; clueIdx = idx; clueCount = clues.length;
      } catch (e) { break; }
    }
    if (!clue) { phase = "idle"; paint(); ctx.toast("No questions match those filters", "error"); return; }
    asked++;
    deadline = Date.now() + cfg.secs * 1000;
    paint();
    var inp = body && body.querySelector("#cr-input"); if (inp) inp.focus();
    tick = setInterval(function () {
      var left = deadline - Date.now();
      var bar = body && body.querySelector("#cr-timer-fill");
      if (bar) bar.style.width = Math.max(0, Math.min(100, (left / (cfg.secs * 1000)) * 100)) + "%";
      var lbl = body && body.querySelector("#cr-timer");
      if (lbl) lbl.textContent = Math.max(0, Math.ceil(left / 1000)) + "s";
      if (left <= 0) submit((body && body.querySelector("#cr-input") || {}).value || "");
    }, 100);
  }

  function ptsFor(idx, count) {
    var frac = count <= 1 ? 1 : idx / (count - 1);
    return frac < 0.34 ? 3 : frac < 0.67 ? 2 : 1;   // earlier clue = harder = more
  }

  async function submit(text) {
    if (phase !== "asking" || !q) return;
    stopTick();
    phase = "result";
    var status = "reject";
    if (String(text || "").trim()) {
      try {
        var r = await ctx.api.post("/api/evaluate-answer", { answerline: q.answer, sanitized: q.answer_sanitized, answer: String(text).trim(), strictness: strictness() });
        status = r.status || "reject";
      } catch (e) {}
    }
    var ok = status === "accept" || status === "prompt";
    if (ok) {
      right++;
      roundPts = ptsFor(clueIdx, clueCount);
      score += roundPts;
      streak++;
      if (streak > best.streak) best.streak = streak;
      if (score > best.score) best.score = score;
      ctx.storage.set("best", best);
      ctx.playSound("correct");
    } else {
      streak = 0; roundPts = 0;
      ctx.playSound("incorrect");
      if (cfg.autoReview && q.id) ctx.api.post("/api/review/manual", { questionId: q.id, add: true, type: "tossup" }).catch(function () {});
    }
    q._given = String(text || "").trim();
    q._ok = ok; q._prompted = status === "prompt";
    paint();
  }

  function bandLabel(idx, count) {
    var frac = count <= 1 ? 1 : idx / (count - 1);
    return frac < 0.34 ? "EARLY CLUE · 3 pts" : frac < 0.67 ? "MIDDLE CLUE · 2 pts" : "LATE CLUE · 1 pt";
  }

  function paint() {
    if (!body) return;
    var head =
      '<div class="cr-head">' +
        '<span class="pill">Score ' + score + '</span><span class="pill' + (streak >= 3 ? " pill-green" : "") + '">Streak ' + streak + "</span>" +
        '<span class="pill">' + right + "/" + asked + '</span><span class="text-muted" style="font-size:11px">best streak ' + best.streak + " · best score " + best.score + "</span>" +
      "</div>";
    var controls =
      '<div class="cr-controls">' +
        '<select id="cr-cat" class="mode-input" style="width:150px"><option value="">All categories</option></select>' +
        '<select id="cr-band" class="mode-input" style="width:130px">' +
          [["any", "Any clue"], ["early", "Early clues"], ["middle", "Middle clues"], ["late", "Late clues"]].map(function (o) { return '<option value="' + o[0] + '"' + (cfg.band === o[0] ? " selected" : "") + ">" + o[1] + "</option>"; }).join("") +
        "</select>" +
        '<select id="cr-secs" class="mode-input" style="width:90px">' +
          [5, 10, 15, 20, 30].map(function (v) { return '<option value="' + v + '"' + (cfg.secs === v ? " selected" : "") + ">" + v + "s</option>"; }).join("") +
        "</select>" +
        '<label class="checkbox-row" title="Misses are added to your Review queue"><input type="checkbox" id="cr-rev"' + (cfg.autoReview ? " checked" : "") + "> Misses → Review</label>" +
      "</div>";
    var main;
    if (phase === "idle") {
      main = '<div class="cr-idle"><button class="btn btn-primary" id="cr-start">[S] Start</button><span class="qb-info" data-tip="One clue, one answer, ' + esc(cfg.secs) + ' seconds. Earlier clues score more; misses go to Review.">i</span></div>';
    } else if (phase === "asking" && !clue) {
      main = '<div class="text-muted" style="padding:24px">Drawing a clue…</div>';
    } else if (phase === "asking") {
      main =
        '<div class="cr-meta"><span class="pill">' + esc(q.category || "") + '</span><span class="pill">' + esc(bandLabel(clueIdx, clueCount)) + '</span><span id="cr-timer" class="pill"></span></div>' +
        '<div class="cr-clue">' + esc(clue) + "</div>" +
        '<div class="mp-timer-bar"><div id="cr-timer-fill"></div></div>' +
        '<div class="buzz-prompt"><span class="prompt-symbol">&gt;</span><input type="text" id="cr-input" placeholder="answer… (Enter)" autocomplete="off" autocorrect="off" spellcheck="false"></div>';
    } else {
      main =
        '<div class="cr-meta"><span class="pill">' + esc(q.category || "") + "</span></div>" +
        '<div class="cr-clue cr-dim">' + esc(clue) + "</div>" +
        '<div class="result-banner ' + (q._ok ? "correct" : "incorrect") + '">' + (q._ok ? "+" + roundPts + (q._prompted ? " (on a prompt)" : "") : (q._given ? "✗ “" + esc(q._given) + "”" : "✗ time")) + "</div>" +
        '<div class="result-answer">ANSWER: <span class="actual">' + ansHtml(q.answer, q.answer_sanitized) + "</span></div>" +
        '<div class="text-muted" style="font-size:12px;margin-top:8px">[N] next clue' + (!q._ok && cfg.autoReview ? " · added to Review" : "") + "</div>";
    }
    body.innerHTML = '<div class="cr-wrap">' + head + controls + '<div class="cr-main">' + main + "</div></div>";

    // wire
    var cat = body.querySelector("#cr-cat");
    ctx.api.get("/api/categories?type=tossups").then(function (d) {
      if (!cat || !cat.isConnected) return;
      (d.categories || []).forEach(function (c) {
        var o = document.createElement("option"); o.value = c.category; o.textContent = c.category;
        if (cfg.category === c.category) o.selected = true;
        cat.appendChild(o);
      });
    }).catch(function () {});
    cat.onchange = function (e) { cfg.category = e.target.value; ctx.storage.set("cfg", cfg); };
    body.querySelector("#cr-band").onchange = function (e) { cfg.band = e.target.value; ctx.storage.set("cfg", cfg); };
    body.querySelector("#cr-secs").onchange = function (e) { cfg.secs = parseInt(e.target.value) || 15; ctx.storage.set("cfg", cfg); };
    body.querySelector("#cr-rev").onchange = function (e) { cfg.autoReview = e.target.checked; ctx.storage.set("cfg", cfg); };
    var start = body.querySelector("#cr-start"); if (start) start.onclick = nextClue;
    var inp = body.querySelector("#cr-input");
    if (inp) {
      inp.focus();
      inp.addEventListener("keydown", function (e) { if (e.key === "Enter") { e.stopPropagation(); submit(inp.value); } });
    }
  }

  function active() { return page && page.screenEl && page.screenEl.classList.contains("active"); }
  ctx.onHotkey("start", function () { if (active() && phase === "idle") nextClue(); });
  ctx.onHotkey("next", function () { if (active() && (phase === "result" || phase === "idle")) nextClue(); });

  page = ctx.registerPage({
    id: "recall", navLabel: "Clue Recall", title: "CLUE RECALL",
    onShow: function (el) { body = el; paint(); },
    onHide: function () { stopTick(); },
  });
  ctx._cleanup = function () { stopTick(); };

  ctx.toast("Clue Recall enabled");
}
