/**
 * OfflineQuiz plugin: Clue Recall
 *
 * The fastest way to grind clue→answer associations: one clue sentence from a
 * real tossup, a timer, and your answer — no waiting through a full read.
 * Earlier (harder) clues score more, streaks are tracked, and every miss goes
 * straight to your Review queue.
 */
QB.registerPlugin({
  id: "clue-recall",
  name: "Clue Recall",
  version: "1.1.0",
  author: "OfflineQuiz",
  description: "Rapid-fire clue→answer drills from real questions: one timed clue at a time, position-weighted scoring, streaks, and misses feeding Review.",
  hotkeys: [
    { id: "start", label: "Start", default: "s" },
    { id: "next", label: "Next clue", default: "n" },
  ],
  onEnable: __qbMain,
  onDisable: function (ctx) { if (ctx._cleanup) ctx._cleanup(); },
});
