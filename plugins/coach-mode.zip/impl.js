function __qbMain(ctx) {
    var body = null, page = null;
    var q = null, clues = [], shown = 0, phase = "idle"; // idle|reading|answering|result
    var log = []; // this session: {clue, totalClues, correct, ranOut, isPower, q}
    var qNum = 0; // questions started this session
    var pool = null, poolIdx = 0; // set when launched over a fixed list of question ids (Folders / Starred)
    var idleNote = ""; // one-shot status on the idle page: "done" (list finished) | "none" (no match) | "fail" (couldn't load) | ""
    var promptFrom = null, promptAsk = "", judging = false; // one prompt per answer: the prompted answer + its ask

    // ── lifetime stats (persisted in plugin storage) ──
    function lifeStats() {
      var st = ctx.storage.get("stats") || { attempts: 0, correct: 0, depthSum: 0, ranOut: 0, byClue: {} };
      if (!st.byDepth) st.byDepth = {};
      return st;
    }
    function depthKey(d) { return d <= 0.2 ? "0-20%" : d <= 0.4 ? "20-40%" : d <= 0.6 ? "40-60%" : d <= 0.8 ? "60-80%" : "80-100%"; }
    var DEPTH_KEYS = ["0-20%", "20-40%", "40-60%", "60-80%", "80-100%"];
    function recordLife(entry) {
      var st = lifeStats();
      st.attempts++;
      if (entry.correct) st.correct++;
      if (entry.ranOut) st.ranOut++;
      var depth = entry.clue / Math.max(1, entry.totalClues);
      st.depthSum += depth;
      var key = depthKey(depth);
      st.byDepth[key] = (st.byDepth[key] || 0) + 1;
      ctx.storage.set("stats", st);
    }

    function esc(s) { return (s == null ? "" : String(s)).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
    var SVG = function (inner, size) { return '<svg viewBox="0 0 24 24" width="' + (size || 16) + '" height="' + (size || 16) + '" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + inner + "</svg>"; };
    var IC = {
      sliders: '<path d="M4 6h10M18 6h2M4 12h4M12 12h8M4 18h12"/><circle cx="16" cy="6" r="2"/><circle cx="10" cy="12" r="2"/><circle cx="18" cy="18" r="2"/>',
      x: '<path d="M6 6l12 12M18 6L6 18"/>',
    };
    var ENT = { amp: "&", lt: "<", gt: ">", quot: '"', apos: "'", nbsp: " " };
    function decodeEnt(s) {
      return String(s || "").replace(/&(#x[0-9a-f]+|#\d+|[a-z]+);/gi, function (m, e) {
        try { if (e[0] === "#") return String.fromCodePoint(e[1] === "x" || e[1] === "X" ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10)); } catch (err) { return m; }
        var v = ENT[e.toLowerCase()]; return v != null ? v : m;
      });
    }
    // Allow-listed inline HTML, like the base's answer lines: <b> <u> <i> <em>
    // <strong> <sup> survive, any other "<…>" is text, entities decode once.
    function ansHtml(raw, fallback) {
      var src = (raw && String(raw).trim()) ? String(raw) : String(fallback || "");
      var html = src.split(/(<\/?(?:b|u|i|em|strong|sup)>)/i).map(function (p, i) { return i % 2 ? p.toLowerCase() : esc(decodeEnt(p)); }).join("");
      var d = document.createElement("div"); d.innerHTML = html; return d.innerHTML;
    }
    // The answer as printed: the answer line's HTML without its tags (keeps
    // accents and quotes; the plain copy can split words at underlines).
    function primaryAnswer(qq) {
      var cut = function (t) { return String(t || "").split(/[\[(]/)[0].trim().replace(/[;:,.]+$/, ""); };
      return cut(qq && qq.answer ? decodeEnt(String(qq.answer).replace(/<[^>]+>/g, "")) : "") || cut(qq && qq.answer_sanitized);
    }
    function cfg() { try { return ctx.host.getPracticeConfig() || {}; } catch (e) { return {}; } }
    // Defensive: works even if the running base predates ctx.keyLabel.
    var KEY_DEFAULTS = { buzz: "Space", next: "N", start: "S" };
    function keyLabel(id) {
      try { var v = ctx.keyLabel && ctx.keyLabel(id); if (v && v !== "?") return v; } catch (e) {}
      return KEY_DEFAULTS[id] || "?";
    }
    function kbd(id) { return "<kbd>" + esc(keyLabel(id)) + "</kbd>"; }

    // The practice filters as query parameters — the same ones the base sends
    // for a random question (categories are tree node ids; tags as JSON).
    function filtersToQuery(f) {
      f = f || {}; var p = ["random=1", "limit=1"];
      if (f.standard) p.push("standard=1");
      if (f.categories && f.categories.length) p.push("categories=" + encodeURIComponent(f.categories.join(",")));
      if (f.subcategories && f.subcategories.length) p.push("subcategories=" + encodeURIComponent(f.subcategories.join(",")));
      if (f.alternateSubcategories && f.alternateSubcategories.length) p.push("alternateSubcategories=" + encodeURIComponent(f.alternateSubcategories.join(",")));
      if (f.difficulties && f.difficulties.length) p.push("difficulties=" + f.difficulties.join(","));
      if (f.setIds && f.setIds.length) p.push("setIds=" + encodeURIComponent(f.setIds.join(",")));
      else if (f.setNames && f.setNames.length) p.push("setNames=" + encodeURIComponent(f.setNames.join(",")));
      if (f.packetNumbers && f.packetNumbers.length) p.push("packetNumbers=" + f.packetNumbers.join(","));
      if (f.yearMin != null) p.push("yearMin=" + f.yearMin);
      if (f.yearMax != null) p.push("yearMax=" + f.yearMax);
      if (f.powermarkOnly) p.push("powermarkOnly=true");
      if (f.cleanOnly) p.push("cleanOnly=1");
      if (f.tags && f.tags.length) p.push("tags=" + encodeURIComponent(JSON.stringify(f.tags.map(function (t) { var o = { f: t.f, v: t.v, x: t.x ? 1 : 0 }; if (t.id) o.id = t.id; return o; }))));
      return p.join("&");
    }

    function maybeStripPron(text) {
      try {
        var c = ctx.host.getPracticeConfig && ctx.host.getPracticeConfig();
        if (c && c.hidePron && ctx.host.stripPronunciations) return ctx.host.stripPronunciations(text);
      } catch (e) {}
      return text;
    }
    // Abbreviation-aware: a naive period split broke "the Michipicoten and
    // St. Ignace islands" (and "The St. Mary's river") into fragments. A chunk
    // ending in a known abbreviation or a single initial is glued to the next
    // one, as is any chunk the split left starting with a lowercase letter.
    var SENT_ABBR = /(?:\b(?:St|Ste|Mt|Mts|Dr|Mr|Mrs|Ms|Messrs|Mme|Mlle|Prof|Sr|Jr|Rev|Fr|Gen|Col|Capt|Lt|Sgt|Maj|Adm|Hon|Pres|Gov|Sen|Rep|Supt|Msgr|vs|etc|cf|ca|al|Inc|Co|Corp|Ltd|Bros|approx|No|Nos|Op|op|no|Vol|vol|Ch|ch|Fig|fig|Ft|Pt|pt|Rte|Ave|Blvd|[A-Za-z])\.["”’']?)$/;
    function mergeAbbrevChunks(parts) {
      var out = [], cur = "";
      for (var i = 0; i < parts.length; i++) {
        cur = cur ? cur + " " + parts[i] : parts[i];
        if (i < parts.length - 1 && SENT_ABBR.test(cur.trim())) continue;
        out.push(cur.trim());
        cur = "";
      }
      if (cur.trim()) out.push(cur.trim());
      return out;
    }
    // The question as the practice screen reads it (host helper: notes and
    // pronunciation guides per the user's settings). Older bases: the plain
    // copy with guides stripped when Hide pronunciations is on.
    function readText(qq) {
      try { if (ctx.host && ctx.host.questionText) { var t = ctx.host.questionText(qq, "question"); if (t != null) return String(t); } } catch (e) {}
      return maybeStripPron((qq && qq.question_sanitized) || "");
    }
    // A moderator note ("<i>Note to moderator: …</i>"; the plain copy has
    // nothing marking where it ends) is never a clue, even when notes are
    // shown: cut every such italic run of the HTML out of the plain text.
    var NOTE_RUN = /^\s*(?:note to (?:the )?(?:moderators?|readers?)\b|reader(?:'s)? note\b|moderator(?:'s)? note\b)/i;
    function foldSan(s) {
      return String(s || "").normalize("NFD").replace(/[̀-ͯ]/g, "")
        .replace(/[“”]/g, '"').replace(/[‘’]/g, "'").replace(/[–—]/g, "-").replace(/…/g, "...").replace(/ /g, " ");
    }
    function cutNoteRuns(text, html) {
      var t = String(text || ""), s = String(html || "");
      if (s.indexOf("<") < 0) return t;
      var runs = [], it = 0, last = 0, m, re = /<\/?([a-z]+)[^>]*>/gi;
      function push(x) { if (!x) return; var p = runs[runs.length - 1], ital = it > 0; if (p && p.italic === ital) p.text += x; else runs.push({ text: x, italic: ital }); }
      while ((m = re.exec(s))) {
        push(decodeEnt(s.slice(last, m.index)));
        var tag = m[1].toLowerCase();
        if (tag === "i" || tag === "em") it = Math.max(0, it + (m[0][1] === "/" ? -1 : 1));
        last = re.lastIndex;
      }
      push(decodeEnt(s.slice(last)));
      runs.forEach(function (r) {
        if (!r.italic || !NOTE_RUN.test(r.text)) return;
        var note = r.text.trim(), cands = [foldSan(note), note];
        try { if (ctx.host && ctx.host.stripPronunciations) cands.push(ctx.host.stripPronunciations(foldSan(note))); } catch (e) {}
        for (var k = 0; k < cands.length; k++) {
          var i = cands[k] ? t.indexOf(cands[k]) : -1;
          if (i >= 0) { t = t.slice(0, i).replace(/\s+$/, "") + (i > 0 ? " " : "") + t.slice(i + cands[k].length).replace(/^\s+/, ""); break; }
        }
      });
      return t;
    }
    function clueText(qq) { return cutNoteRuns(readText(qq), qq && qq.question); }
    function splitClues(text) {
      // Quote-aware: 'love." At' ends the sentence at the closing quote.
      var chunks = text.replace(/\(\*\)/g, "")
        .split(/(?<=[.!?…]["”’']?)\s+(?=["“‘']?[A-Z0-9(])/);
      return mergeAbbrevChunks(chunks)
        .map(function (c) { return c.trim(); })
        .filter(Boolean);
    }

    // ── category badge, like the app's (root colour + "Root › Leaf") ──
    var ROOT_COLOR = { "Literature": "#bc8cff", "Science and Math": "#58a6ff", "Fine Arts": "#f778ba", "History": "#e3b341", "Geography": "#56d364", "Mythology": "#ffa657", "Pop Culture Sports": "#ff7b72", "Social Science": "#3dd6a3", "Philosophy": "#39c5cf", "Theology": "#8e9bff", "Current Events": "#c9d16b", "Miscellaneous": "#8b949e" };
    // Sessions recorded before the category tree name old roots.
    var OLD_ROOT = { "Science": "Science and Math", "Religion": "Theology", "Pop Culture": "Pop Culture Sports", "Trash": "Pop Culture Sports", "Other Academic": "Miscellaneous" };
    var DIFF_FULL = ["Unrated", "Middle school", "Easy high school", "Regular high school", "Hard high school", "National high school", "Easy college", "Medium college", "Regionals college", "Nationals college", "Open"];
    function pathParts(qq) { return qq && qq.category_path ? String(qq.category_path).split(" > ") : [qq && qq.category, qq && qq.subcategory].filter(Boolean); }
    function rootColor(name) { return ROOT_COLOR[OLD_ROOT[name] || name] || "#8b949e"; }
    function metaBadges(qq) {
      var parts = pathParts(qq), h = "";
      if (parts.length) {
        var short = parts.length > 1 ? parts[0] + " › " + parts[parts.length - 1] : parts[0];
        h += '<span class="badge cat-badge" style="--c:' + rootColor(parts[0]) + '" title="' + esc(parts.join(" › ")) + '"><span class="dot"></span><span class="t">' + esc(short) + "</span></span>";
      }
      if (qq && qq.difficulty != null && qq.difficulty !== "") h += '<span class="badge diff-badge" title="' + esc(DIFF_FULL[parseInt(qq.difficulty, 10)] || "") + '">Diff ' + esc(String(qq.difficulty)) + "</span>";
      if (qq && qq.set_year) h += '<span class="badge year-badge">' + esc(String(qq.set_year)) + "</span>";
      return h;
    }

    var borrowedPanel = null, panelHome = null, panelObserver = null;
    page = ctx.registerPage({
      id: "coach", navLabel: "Coach Mode", title: "Coach Mode",
      onShow: function (el, info) {
        body = el;
        el.classList.add("cm-host");
        addSetupButton();
        // Back returns you to the session you left; only a fresh entry starts
        // a new recorded session (and, between questions, a fresh page).
        var fresh = !(info && info.back);
        if (fresh) sessId = null;
        try {
          var ho = JSON.parse(localStorage.getItem("qb-coach-handoff") || "null");
          if (ho && ho.ids && ho.ids.length) {
            localStorage.removeItem("qb-coach-handoff");
            pool = ho.ids.slice(0, 200); poolIdx = 0; log = []; qNum = 0;
            nextQuestion(); // auto-start over the handed-off set
            return;
          }
        } catch (e) {}
        if (fresh && (phase === "idle" || phase === "result")) { log = []; qNum = 0; phase = "idle"; idleNote = ""; q = null; render(); return; }
        // Coming back: the body still holds the screen the user left (same
        // question, same clue count, whatever was typed in the answer box).
        // Re-borrow the filter panel, but don't wipe it with a fresh render.
        if (body.querySelector(".cm-layout > .cm-grid")) { borrowPanel(); return; }
        render();
      },
      onHide: function () { returnPanel(); },
    });

    // ── saved sessions (view + delete from the Statistics section) ──
    // Each entry stores the buzz outcome AND enough to reproduce WHERE the
    // user buzzed: clue number, total clues, the read-position character
    // count (celerity), and the question text shown up to the buzz.
    var sessId = null;
    function sessionsAll() { return ctx.storage.get("sessions") || []; }
    function recordSession(entry) {
      var all = sessionsAll();
      var cur = null;
      if (sessId) for (var i = 0; i < all.length; i++) if (all[i].id === sessId) { cur = all[i]; break; }
      if (!cur) { sessId = Date.now(); cur = { id: sessId, entries: [] }; all.unshift(cur); if (all.length > 60) all.length = 60; }
      cur.entries.push(entry);
      ctx.storage.set("sessions", all);
    }
    function fmtWhen(ts) {
      try { return new Date(ts).toLocaleString(undefined, { month: "short", day: "numeric", year: new Date(ts).getFullYear() === new Date().getFullYear() ? undefined : "numeric", hour: "numeric", minute: "2-digit" }); }
      catch (e) { return new Date(ts).toLocaleString(); }
    }

    // ── per-session window (from the Statistics section) ──────────────────
    // celerity: how early in the question the buzz came, 100% = first word.
    function celerity(e) {
      if (e.totalChars && e.readChars != null) {
        return Math.max(0, Math.round((1 - e.readChars / Math.max(1, e.totalChars)) * 100));
      }
      // fallback for older sessions without char counts: use clue depth
      var depth = e.clue / Math.max(1, e.totalClues || 1);
      return Math.max(0, Math.round((1 - depth) * 100));
    }
    function depthPct(e) { return Math.round((e.clue / Math.max(1, e.totalClues || 1)) * 100); }
    function byCategory(entries) {
      var map = {}, order = [];
      (entries || []).forEach(function (e) {
        if (!e) return;
        var k = (e.category && String(e.category).trim()) || "Other";
        if (Object.prototype.hasOwnProperty.call(OLD_ROOT, k)) k = OLD_ROOT[k];
        if (!map[k]) { map[k] = { correct: 0, wrong: 0, total: 0 }; order.push(k); }
        var g = map[k]; g.total++;
        if (e.correct) g.correct++; else g.wrong++;
      });
      return order.map(function (k) { return { name: k, g: map[k] }; });
    }
    function closeOverlay(el) { if (!el) return; if (ctx.host && ctx.host.animateRemove) ctx.host.animateRemove(el); else el.remove(); }
    function modalShell(cls, title, sub, bodyHtml) {
      var el = document.createElement("div");
      el.className = "qb-overlay app-ovl cm-ovl " + cls;
      el.setAttribute("role", "dialog"); el.setAttribute("aria-modal", "true");
      el.innerHTML =
        '<div class="settings-modal cm-modal" tabindex="-1">' +
          '<div class="modal-head"><h2>' + esc(title) + "</h2>" + (sub ? '<span class="cm-modal-sub">' + esc(sub) + "</span>" : "") +
            '<span class="spacer"></span><button type="button" class="btn btn-ghost btn-icon cm-modal-x" aria-label="Close">' + SVG(IC.x, 18) + "</button></div>" +
          '<div class="cm-modal-body">' + bodyHtml + "</div>" +
        "</div>";
      el.addEventListener("click", function (ev) { if (ev.target === el || ev.target.closest(".cm-modal-x")) closeOverlay(el); });
      document.body.appendChild(el);
      return el;
    }
    function verdictHtml(e) {
      return e.correct ? '<span class="cm-res good">Correct</span>'
        : (e.ranOut ? '<span class="cm-res out">Out of clues</span>' : '<span class="cm-res bad">Incorrect</span>');
    }
    function openSessionModal(sess) {
      var entries = sess.entries || [];
      var total = entries.length;
      var correct = entries.filter(function (e) { return e.correct; }).length;
      var ranOut = entries.filter(function (e) { return e.ranOut; }).length;
      var accuracy = total ? Math.round((correct / total) * 100) : 0;
      var avgDepth = total ? Math.round(entries.reduce(function (s, e) { return s + depthPct(e); }, 0) / total) : 0;
      var avgCel = total ? Math.round(entries.reduce(function (s, e) { return s + celerity(e); }, 0) / total) : 0;
      var summary =
        '<div class="cm-sum">' +
          '<div class="stat-card"><div class="stat-card-value">' + total + '</div><div class="stat-card-label">Questions</div></div>' +
          '<div class="stat-card"><div class="stat-card-value cm-c-good">' + correct + '</div><div class="stat-card-label">Correct</div></div>' +
          '<div class="stat-card"><div class="stat-card-value">' + accuracy + '%</div><div class="stat-card-label">Accuracy</div></div>' +
          '<div class="stat-card"><div class="stat-card-value">' + avgDepth + '%</div><div class="stat-card-label">Buzz depth</div></div>' +
          '<div class="stat-card"><div class="stat-card-value">' + avgCel + '%</div><div class="stat-card-label">Celerity</div></div>' +
          '<div class="stat-card"><div class="stat-card-value">' + ranOut + '</div><div class="stat-card-label">Out of clues</div></div>' +
        "</div>";
      var buckets = {};
      DEPTH_KEYS.forEach(function (k) { buckets[k] = 0; });
      entries.forEach(function (e) { buckets[depthKey(depthPct(e) / 100)]++; });
      var bmax = Math.max.apply(null, DEPTH_KEYS.map(function (k) { return buckets[k]; }).concat([1]));
      var depthBlock = total ? '<section class="cm-msec"><div class="eyebrow">Where you buzzed</div>' + DEPTH_KEYS.map(function (k) {
        return '<div class="cm-catrow"><span class="cm-catname">' + k + '</span><span class="cm-bar"><b style="width:' + (buckets[k] ? Math.max(3, buckets[k] / bmax * 100) : 0) + '%"></b></span><span class="cm-catcount num">' + buckets[k] + "</span></div>";
      }).join("") + "</section>" : "";
      var cats = byCategory(entries);
      var catBlock = cats.length ? '<section class="cm-msec"><div class="eyebrow">By category</div>' + cats.map(function (c) {
        var g = c.g;
        return '<div class="cm-catrow"><span class="cm-catname" title="' + esc(c.name) + '"><i style="background:' + rootColor(c.name) + '"></i>' + esc(c.name) + "</span>" +
          '<span class="cm-stack"><b class="good" style="width:' + (g.correct / g.total * 100) + '%"></b><b class="bad" style="width:' + (g.wrong / g.total * 100) + '%"></b></span>' +
          '<span class="cm-catcount num">' + g.correct + "/" + g.total + "</span></div>";
      }).join("") + "</section>" : "";
      var list = entries.map(function (e, i) {
        var dep = depthPct(e);
        var said = e.given && e.given !== "(no answer)" && e.given !== "(out of clues)" ? e.given : "";
        return '<div class="cm-hrow">' +
          '<div class="cm-hrow-head"><span class="cm-hidx num">' + (i + 1) + "</span>" + verdictHtml(e) + '<span class="spacer"></span>' +
            (e.category ? '<span class="cm-hmeta">' + esc(e.category) + "</span>" : "") + "</div>" +
          '<div class="cm-hans"><b>' + esc(primaryAnswer({ answer_sanitized: e.answer }) || e.answer || "") + "</b>" + (said ? '<span class="cm-hsaid">you said <em>' + esc(said) + "</em></span>" : "") + "</div>" +
          '<div class="cm-hbuzz"><span class="cm-hbar"><b style="width:' + dep + '%"></b></span><span class="cm-hbl num">Clue ' + e.clue + " / " + (e.totalClues || "?") + " · celerity " + celerity(e) + "%</span></div>" +
          (e.questionText ? '<div class="cm-hread">' + esc(e.questionText) + "</div>" : "") +
        "</div>";
      }).join("");
      modalShell("cm-stm-overlay", "Coach session", fmtWhen(sess.id),
        summary + depthBlock + catBlock + '<section class="cm-msec"><div class="eyebrow">Questions</div><div class="cm-hist">' + (list || '<div class="cm-empty">No questions yet</div>') + "</div></section>");
    }

    function sessionsHtml() {
      var all = sessionsAll();
      if (!all.length) return "";
      var rows = all.map(function (sess, i) {
        var n = sess.entries.length, ok = sess.entries.filter(function (e) { return e.correct; }).length;
        var dep = n ? Math.round(sess.entries.reduce(function (s, e) { return s + depthPct(e); }, 0) / n) : 0;
        return '<tr class="session-row" data-view="' + i + '" style="cursor:pointer">' +
          "<td>" + esc(fmtWhen(sess.id)) + '</td><td class="num">' + n + '</td><td class="num">' + ok + '</td><td class="num">' + dep + "%</td>" +
          '<td style="text-align:right"><button type="button" class="btn btn-sm btn-ghost btn-icon session-delete" data-del="' + i + '" aria-label="Delete session">' + SVG(IC.x, 14) + "</button></td></tr>";
      }).join("");
      return '<div class="cm-stats-h eyebrow">Sessions</div>' +
        '<table class="stats-table cm-sess-table"><thead><tr><th>Session</th><th>Questions</th><th>Correct</th><th>Depth</th><th></th></tr></thead><tbody>' + rows + "</tbody></table>" +
        '<button type="button" class="btn btn-sm btn-ghost" id="cm-sess-clear">Delete all sessions</button>';
    }
    function wireSessions(el, rerender) {
      el.querySelectorAll("[data-view]").forEach(function (b) {
        b.onclick = function (ev) {
          if (ev.target.closest(".session-delete")) return;
          var sess = sessionsAll()[parseInt(b.dataset.view, 10)];
          if (sess) openSessionModal(sess);
        };
      });
      el.querySelectorAll("[data-del]").forEach(function (b) {
        b.onclick = function () {
          var doDel = function () { var all = sessionsAll(); all.splice(parseInt(b.dataset.del, 10), 1); ctx.storage.set("sessions", all); rerender(); };
          if (ctx.host && ctx.host.confirm) ctx.host.confirm("Delete this coach session?", doDel);
          else doDel();
        };
      });
      var ca = el.querySelector("#cm-sess-clear");
      if (ca) ca.onclick = function () {
        var doClear = function () { ctx.storage.set("sessions", []); rerender(); };
        if (ctx.host && ctx.host.confirm) ctx.host.confirm("Delete all coach sessions?", doClear);
        else doClear();
      };
    }
    function active() { return page && page.screenEl && page.screenEl.classList.contains("active"); }
    ctx.on("screen:change", function () { setTimeout(function () { if (!active()) returnPanel(); }, 0); });

    // ── the practice setup panel, borrowed as this page's Setup drawer ──
    // CRITICAL: the panel goes home (returnPanel) BEFORE anything wipes the
    // page with innerHTML, or the settings menu is detached for good.
    function borrowPanel() {
      var host = body && body.querySelector(".cm-layout");
      if (!host) return;
      try { if (ctx.host && ctx.host.ensureFiltersLoaded) ctx.host.ensureFiltersLoaded(); } catch (e) {}
      var panel = document.getElementById("filters-panel") || borrowedPanel;
      if (!panel || panel.parentNode === host) return;
      // No set/packet selection here — questions always come from the
      // category / difficulty filters (a running custom list is left alone).
      var ms = document.getElementById("mode-select");
      if (ms && ms.value === "set") { ms.value = "random"; ms.dispatchEvent(new Event("change", { bubbles: true })); }
      if (!panelHome) panelHome = { parent: panel.parentNode, next: panel.nextSibling };
      panel.classList.remove("open");
      panel.classList.add("cm-borrowed");
      host.insertBefore(panel, host.firstChild);
      borrowedPanel = panel;
      var ft = panel.querySelector(".fp-title"); if (ft) ft.textContent = "Setup";
      var fs = panel.querySelector("#btn-drawer-start"); if (fs) fs.textContent = "Done";
      var cnt = panel.querySelector("#fp-count"); if (cnt) cnt.textContent = "";
      try {
        panelObserver = new MutationObserver(syncSetupBtn);
        panelObserver.observe(panel, { attributes: true, attributeFilter: ["class"] });
      } catch (e) { panelObserver = null; }
      syncSetupBtn();
    }
    function returnPanel() {
      if (!borrowedPanel || !panelHome) return;
      if (panelObserver) { try { panelObserver.disconnect(); } catch (e) {} panelObserver = null; }
      borrowedPanel.classList.remove("cm-borrowed");
      borrowedPanel.classList.remove("open");
      var ft = borrowedPanel.querySelector(".fp-title"); if (ft) ft.textContent = "Practice setup";
      var fs = borrowedPanel.querySelector("#btn-drawer-start"); if (fs) fs.textContent = "Start";
      try { panelHome.parent.insertBefore(borrowedPanel, panelHome.next); } catch (e) {}
      borrowedPanel = null;
      syncSetupBtn();
    }
    function setupOpen() { return !!(borrowedPanel && borrowedPanel.classList.contains("open")); }
    function toggleSetup(on) {
      if (!borrowedPanel) borrowPanel();
      if (!borrowedPanel) return;
      var want = on == null ? !setupOpen() : !!on;
      borrowedPanel.classList.toggle("open", want);
      if (want) refreshCount();
      syncSetupBtn();
    }
    function setupBtn() { return page && page.screenEl && page.screenEl.querySelector(".cm-setup-btn"); }
    function syncSetupBtn() { var b = setupBtn(); if (b) b.setAttribute("aria-expanded", String(setupOpen())); }
    var _countTimer = null, _countSeq = 0;
    function refreshCount() {
      clearTimeout(_countTimer);
      _countTimer = setTimeout(function () {
        if (!setupOpen()) return;
        var el = borrowedPanel && borrowedPanel.querySelector("#fp-count"); if (!el) return;
        var seq = ++_countSeq;
        var qs = filtersToQuery(cfg().filters).replace(/(^|&)(random|limit)=[^&]*/g, "").replace(/^&/, "");
        ctx.api.get("/api/tossups/count?" + qs).then(function (d) {
          if (seq !== _countSeq || !setupOpen()) return;
          var n = d && typeof d.count === "number" ? d.count : null;
          el.textContent = n == null ? "" : n.toLocaleString() + (n === 1 ? " tossup" : " tossups");
        }).catch(function () { if (seq === _countSeq) el.textContent = ""; });
      }, 250);
    }
    // the page head gets a Setup button, like the practice page
    function addSetupButton() {
      var right = page && page.screenEl && page.screenEl.querySelector(".top-bar-right");
      if (!right || right.querySelector(".cm-setup-btn")) return;
      var b = document.createElement("button");
      b.type = "button"; b.className = "btn cm-setup-btn"; b.setAttribute("aria-expanded", "false");
      b.innerHTML = SVG(IC.sliders) + "Setup";
      b.addEventListener("click", function () { toggleSetup(); });
      right.insertBefore(b, right.firstChild);
    }
    addSetupButton();

    async function nextQuestion() {
      phase = "reading"; shown = 1; q = null; idleNote = ""; promptFrom = null; promptAsk = "";
      render();
      try {
        if (pool) {
          // An id that no longer resolves to a tossup (moved to bonuses by the
          // new database, or gone) is skipped, not the end of the run.
          while (!q && poolIdx < pool.length) {
            var dd = await ctx.api.get("/api/tossups/" + encodeURIComponent(pool[poolIdx++]));
            q = dd && dd.tossup;
          }
          if (!q) { phase = "idle"; pool = null; idleNote = "done"; render(); return; }
        } else {
          var c = cfg();
          var d = await ctx.api.get("/api/tossups/random?" + filtersToQuery(c.filters));
          q = d.tossup;
        }
      } catch (e) {}
      if (!q) { phase = "idle"; idleNote = pool ? "fail" : "none"; render(); return; }
      clues = splitClues(clueText(q));
      if (!clues.length) clues = [readText(q) || ""];
      shown = 1; qNum++;
      render();
    }

    function buzz() { if (phase !== "reading" || !q) return; ctx.playSound("buzz"); phase = "answering"; render(); }
    function nextClue() {
      if (phase !== "reading" || !q) return;
      if (shown >= clues.length) { resolve(false, "(out of clues)", true); return; }
      shown++; render({ newClue: true });
    }

    // Clues drop notes, guides and "(*)", so a read position in them is mapped
    // back to question_sanitized AS STORED (its "(*)" included) — the
    // coordinates the server, power scoring and recorded buzzes use. Older
    // bases without the helper get the clue position as-is.
    function serverPos(pos) {
      try {
        if (ctx.host && ctx.host.mapDisplayPos) return ctx.host.mapDisplayPos(clues.join(" "), (q && q.question_sanitized) || "", pos);
      } catch (e) {}
      return pos;
    }

    // One prompt per answer, as in practice: a first prompt reopens the input
    // under a PROMPT banner and the reply is judged together with the prompted
    // answer (`previous`). A second prompt is wrong — only "accept" is correct.
    async function submit(answer) {
      if (judging || phase !== "answering" || !q) return;
      judging = true;
      var cur = q, verdict = "reject", r = null;
      try {
        // read-position = the characters of the clues shown so far
        var readChars = clues.slice(0, shown).join(" ").length;
        r = await ctx.api.post("/api/evaluate-tossup", { questionId: q.id, answer: answer, strictness: cfg().strictness || 10, buzzPosition: serverPos(readChars), previous: promptFrom });
        verdict = (r && r.status) || "reject";
      } catch (e) {}
      judging = false;
      if (q !== cur || phase !== "answering") return;
      if (verdict === "prompt" && promptFrom == null && answer) {
        promptFrom = answer;
        promptAsk = (r.prompt && r.prompt.ask) || (r.antiprompt ? "less specific?" : "");
        render();   // fresh, focused input under the banner
        return;
      }
      promptFrom = null; promptAsk = "";
      resolve(verdict === "accept", answer || "(no answer)", false);
    }

    function resolve(correct, given, ranOut) {
      // capture WHERE the user buzzed: the read text + char position (celerity)
      var buzzText = clues.slice(0, shown).join(" ");
      var totalChars = clues.join(" ").length || (q && q.question_sanitized ? q.question_sanitized.length : 0);
      var sanitized = (q && q.question_sanitized) || "";
      var powerIdx = sanitized.indexOf("(*)");
      var buzzPos = serverPos(buzzText.length);   // question_sanitized coordinates, like powerIdx
      var isPower = !!correct && powerIdx >= 0 && buzzPos <= powerIdx;
      var points = correct ? (isPower ? 15 : 10) : (ranOut ? 0 : -5);
      var entry = { clue: shown, totalClues: clues.length, correct: correct, ranOut: ranOut,
        answer: (q && (q.answer_sanitized || q.answer)) || "", given: given || "", category: (q && q.category) || "",
        readChars: buzzText.length, totalChars: totalChars, questionText: buzzText };
      log.push(Object.assign({ isPower: isPower, points: points, q: q }, entry));
      recordLife(entry);
      recordSession(entry);
      // Record into the REAL session table too, through the same override
      // path multiplayer uses — so what's earned here counts toward stats and
      // the "power on …" achievements. Power = the read stayed before the (*)
      // mark (clues are sentences, so buzzing after a sentence that contains
      // the mark is not a power). Wrong = neg, out of clues = unanswered (0).
      try {
        var cel = totalChars ? Math.max(0, Math.min(1, buzzText.length / totalChars)) : 0;
        ctx.api.post("/api/check-tossup", {
          questionId: q.id, answer: given || "", buzzPosition: buzzPos,
          sessionId: "coach-" + (sessId || Date.now()), overriding: true, correct: !!correct,
          isPower: isPower, points: points, celerity: cel,
        }).catch(function () {});
      } catch (e) {}
      ctx.playSound(correct ? (isPower ? "power" : "correct") : "incorrect");
      phase = "result"; q._given = given; q._correct = correct; q._ranOut = ranOut; q._power = isPower; q._points = points;
      render();
    }

    // ── the page ──
    function sideHtml() {
      var n = log.length, ok = log.filter(function (l) { return l.correct; }).length;
      var pw = log.filter(function (l) { return l.isPower; }).length;
      var neg = log.filter(function (l) { return !l.correct && !l.ranOut; }).length;
      var dep = n ? Math.round(log.reduce(function (s, l) { return s + l.clue / Math.max(1, l.totalClues); }, 0) / n * 100) : null;
      var stat = function (cls, v, l) { return '<div class="stat-item ' + cls + '"><div class="stat-value">' + v + '</div><div class="stat-label">' + l + "</div></div>"; };
      var rows = log.slice().reverse().slice(0, 12).map(function (l) {
        var i = log.indexOf(l);
        var col = l.isPower ? "var(--yellow)" : l.correct ? "var(--green)" : l.ranOut ? "var(--muted)" : "var(--red)";
        var pp = pathParts(l.q);
        return '<button type="button" class="sm-row" data-log="' + i + '" title="' + esc(primaryAnswer(l.q)) + '"><span class="dot" style="background:' + rootColor(pp[0] || "") + '"></span>' +
          '<span class="a">' + esc(primaryAnswer(l.q) || "—") + '</span><b style="color:' + col + '">' + l.clue + "/" + l.totalClues + "</b></button>";
      }).join("");
      return '<div class="side-stats">' +
          stat("stat-heard", n, "HEARD") + stat("stat-score", n ? Math.round(ok / n * 100) + "%" : "—", "ACC") +
          stat("", n ? ok : "—", "CORRECT") + stat("", n ? '<span class="stat-pwr">' + pw + "</span>" : "—", "PWR") +
          stat("", n ? '<span class="stat-neg">' + neg + "</span>" : "—", "NEG") + stat("", dep == null ? "—" : dep + "%", "DEPTH") +
        "</div>" +
        '<div class="side-hist"><div class="eyebrow">This session</div><div class="session-mini cm-mini">' + rows + "</div></div>";
    }
    function trackHtml() {
      var segs = "";
      for (var i = 1; i <= clues.length; i++) {
        var cls = i <= shown ? (phase === "result" ? (q._correct ? "ok" : q._ranOut ? "out" : "bad") : "on") : "";
        segs += '<i class="' + cls + '"></i>';
      }
      return '<div class="cm-track"><span class="cm-track-bar">' + segs + '</span><span class="cm-track-l num">Clue ' + shown + " / " + clues.length + "</span></div>";
    }
    function questionHtml() {
      if (phase === "idle") {
        var note = idleNote === "done" ? '<div class="cm-note cm-note-done">Done</div>'
          : idleNote === "none" ? '<div class="cm-note">No questions match</div>'
          : idleNote === "fail" ? '<div class="cm-note">Couldn\'t load the question</div>' : "";
        return '<div class="question-placeholder cm-ph">' + note +
          (idleNote === "none" ? '<button type="button" class="btn" id="cm-open-setup">' + SVG(IC.sliders) + "Setup</button>" : "") + "</div>";
      }
      if (!q) return '<div class="question-placeholder cm-ph"><div class="cm-loading">' + (ctx.loadingBarHtml ? ctx.loadingBarHtml("Loading") : "Loading…") + "</div></div>";
      var reading = phase !== "result";
      var meta = '<div class="question-meta cm-meta' + (reading ? " qm-reading" : "") + '">' +
        '<span class="q-num">Question ' + qNum + "</span>" +
        '<span class="qm-info">' + metaBadges(q) + "</span>" +
        '<span class="spacer q-spacer"></span>' +
        '<span class="star-btn save-plus cm-save" role="button" title="Save to review / folders">+</span>' +
        '<span class="star-btn qb-star cm-star" role="button" data-qid="' + esc(q.id) + '" data-type="tossup" title="Star">☆</span>' +
      "</div>";
      // The clues heard so far; after the question the result comes right
      // under the clue you stopped on, and the rest of the tossup (faded)
      // below it.
      var clueLi = function (i, cls) { return '<li class="cm-clue' + (cls ? " " + cls : "") + '"><span class="cm-n num">' + (i + 1) + '</span><span class="cm-t">' + esc(clues[i]) + "</span></li>"; };
      var list = "";
      for (var i = 0; i < shown; i++) list += clueLi(i, reading && i === shown - 1 ? "cur" : "");
      var after = "", rest = "";
      if (phase === "answering") {
        after = '<div class="buzz-area cm-buzz">' +
          (promptFrom != null ? '<div class="buzz-prompt-banner"><span class="prompt-tag">PROMPT</span>' + (promptAsk ? " " + esc(promptAsk) : "") + "</div>" : "") +
          '<div class="buzz-prompt"><span class="prompt-symbol">&gt;</span>' +
          '<input type="text" id="cm-input" placeholder="type answer and press Enter..." autocomplete="off" autocorrect="off" spellcheck="false"></div></div>';
      } else if (phase === "result") {
        var b = q._correct ? "CORRECT +" + q._points + " pts" : (q._ranOut ? "OUT OF CLUES (0 pts)" : "INCORRECT " + q._points + " pts");
        var sub = (q._power ? "Power · " : "") + "clue " + shown + " / " + clues.length;
        after = '<div class="result-area cm-result"><div class="result-banner ' + (q._power ? "power" : q._correct ? "correct" : q._ranOut ? "dead" : "incorrect") + '">' + esc(b) + '<span class="cm-rb-sub">' + esc(sub) + "</span></div>" +
          '<div class="result-answer">' +
            (q._ranOut ? "" : '<div class="ra-row"><span class="ra-k">Your answer</span><strong class="ra-you ' + (q._correct ? "ok" : "bad") + '">' + esc(q._given) + "</strong></div>") +
            '<div class="ra-row"><span class="ra-k">Answer</span><span class="actual">' + ansHtml(q.answer, q.answer_sanitized || "") + "</span></div>" +
          "</div></div>";
        if (shown < clues.length) {
          var r = "";
          for (var j = shown; j < clues.length; j++) r += clueLi(j, "after");
          rest = '<div class="cm-rest"><div class="eyebrow">Rest of the question</div><ol class="cm-clues">' + r + "</ol></div>";
        }
      }
      return meta + trackHtml() + '<ol class="cm-clues">' + list + "</ol>" + after + rest;
    }
    function actionsHtml() {
      if (phase === "idle") return '<button type="button" class="btn btn-primary" id="cm-start">' + (idleNote === "done" ? "Random questions" : "Start") + kbd("start") + "</button>";
      if (phase === "reading" && q) {
        return '<button type="button" class="btn btn-go" id="cm-buzz">Buzz' + kbd("buzz") + "</button>" +
          '<button type="button" class="btn" id="cm-next-clue">' + (shown >= clues.length ? "Show answer" : "Next clue") + kbd("next") + "</button>";
      }
      if (phase === "result") return '<button type="button" class="btn btn-primary" id="cm-next">Next question' + kbd("next") + "</button>";
      return "";
    }
    function ensureShell() {
      if (body.querySelector(".cm-layout > .cm-grid")) { borrowPanel(); return; }
      // Give the borrowed panel back BEFORE innerHTML wipes the body, or the
      // settings menu is detached from the DOM and lost.
      returnPanel();
      body.innerHTML = '<div class="cm-layout cm-page"><div class="cm-grid">' +
        '<main class="cm-main"><div class="cm-q" id="cm-q"></div><div class="practice-actions cm-actions" id="cm-actions"></div></main>' +
        '<aside class="practice-side cm-side" id="cm-side" aria-label="This session"></aside>' +
      "</div></div>";
      borrowPanel();
    }
    function render(opts) {
      if (!body) return;
      ensureShell();
      var qa = body.querySelector("#cm-q"), act = body.querySelector("#cm-actions"), side = body.querySelector("#cm-side");
      qa.innerHTML = questionHtml();
      act.innerHTML = actionsHtml();
      side.innerHTML = sideHtml();
      if (opts && opts.newClue) { var cur = qa.querySelector(".cm-clue.cur"); if (cur) cur.classList.add("cm-new"); }
      // reflect the current star state
      var st = qa.querySelector(".cm-star");
      if (st && q) ctx.api.get("/api/starred/check?questionId=" + encodeURIComponent(q.id) + "&type=tossup").then(function (d) {
        if (d && d.starred && st.isConnected) { st.textContent = "★"; st.classList.add("on"); }
      }).catch(function () {});
      var sv = qa.querySelector(".cm-save");
      if (sv) sv.addEventListener("click", function (ev) { ev.stopPropagation(); if (q && ctx.host && ctx.host.openSaveMenu) ctx.host.openSaveMenu(q, "tossup", sv); });
      if (sv && !(ctx.host && ctx.host.openSaveMenu)) sv.remove();
      var on = function (sel, fn) { var b = body.querySelector(sel); if (b) b.onclick = fn; };
      on("#cm-start", function () { nextQuestion(); });
      on("#cm-buzz", buzz);
      on("#cm-next-clue", nextClue);
      on("#cm-next", function () { nextQuestion(); });
      on("#cm-open-setup", function () { toggleSetup(true); });
      side.querySelectorAll("[data-log]").forEach(function (b) {
        b.onclick = function () { var l = log[parseInt(b.dataset.log, 10)]; if (l && l.q) viewFullQuestion(l.q); };
      });
      qa.oncontextmenu = function (e) {
        if (!q) return;
        e.preventDefault();
        var qq = q;
        var items = [
          { label: "View full question", onClick: function () { viewFullQuestion(qq); } },
          { label: "Copy clues shown", onClick: function () { try { navigator.clipboard.writeText(clues.slice(0, phase === "result" ? clues.length : shown).join(" ")); } catch (err) {} } },
        ];
        if (phase === "result" && ctx.host && ctx.host.searchDatabase) {
          var pa = primaryAnswer(qq);
          if (pa) items.push({ label: "Find questions with this answer", onClick: function () { ctx.host.searchDatabase({ query: pa, field: "answer", exact: false }); } });
        }
        items.push({ sep: true });
        items.push({ label: "Star / unstar question", onClick: function () { var s = body.querySelector(".cm-star"); if (s) s.click(); } });
        ctx.contextMenu(e.clientX, e.clientY, items, { title: phase === "result" ? primaryAnswer(qq) : "Coach question" });
      };
      var inp = body.querySelector("#cm-input");
      if (inp) {
        inp.focus();
        inp.addEventListener("keydown", function (e) { if (e.key === "Enter") { e.preventDefault(); inp.disabled = true; submit(inp.value.trim()); } });
      }
      if (phase === "result") { var ra = qa.querySelector(".cm-result"); if (ra && ra.scrollIntoView) try { ra.scrollIntoView({ block: "nearest" }); } catch (err) {} }
      // the newest clue stays in view while the question grows
      if (opts && opts.newClue) { var c2 = qa.querySelector(".cm-clue.cur"); if (c2 && c2.scrollIntoView) try { c2.scrollIntoView({ block: "nearest" }); } catch (err) {} }
    }

    // Right-click "View full question" (and a click on a row of This session):
    // the whole tossup and its answer in a window. Peeking mid-read is the
    // player's own call.
    function viewFullQuestion(qq) {
      if (!qq) return;
      document.querySelectorAll(".cm-viewer").forEach(function (o) { o.remove(); });
      modalShell("cm-viewer", "Question", "",
        '<div class="cm-v-meta qmeta-row">' + metaBadges(qq) + (qq.set_name ? '<span class="cm-v-set">' + esc(qq.set_name) + "</span>" : "") + "</div>" +
        '<div class="cm-v-q">' + esc(readText(qq)).replace(/\(\*\)/g, '<span class="cm-pm">(*)</span>') + "</div>" +
        '<div class="cm-v-a"><span class="eyebrow">Answer</span><div>' + ansHtml(qq.answer, qq.answer_sanitized || "") + "</div></div>");
    }

    // Rebindable hotkeys (Settings > Keybinds). Handlers no-op off-page.
    function quiet() { return document.querySelector("#cat-ovl:not(.hidden), .cm-ovl"); }
    ctx.onHotkey("buzz", function () { if (active() && phase === "reading" && !quiet()) buzz(); });
    ctx.onHotkey("next", function () {
      if (!active() || quiet()) return;
      if (phase === "reading") nextClue();
      else if (phase === "result") nextQuestion();
    });
    ctx.onHotkey("start", function () { if (active() && phase === "idle" && !quiet()) nextQuestion(); });
    function onEsc(e) {
      if (e.key !== "Escape" || !active() || !setupOpen()) return;
      if (document.querySelector('#cat-ovl:not(.hidden), .qb-select[data-open="true"], .pop:not([hidden]), .qb-overlay:not(.hidden):not(.settings-ovl)')) return;
      e.preventDefault(); e.stopPropagation(); toggleSetup(false);
    }
    window.addEventListener("keydown", onEsc, true);
    // Widening the filters makes "No questions match" stale: drop it in place
    // (render() would hand the borrowed panel back mid-event); the drawer's
    // footer counts what matches.
    function onFilterEdit(e) {
      if (!active() || !(e.target && e.target.closest && e.target.closest("#filters-panel"))) return;
      refreshCount();
      if (phase !== "idle" || idleNote !== "none") return;
      idleNote = "";
      var n = body && body.querySelector(".cm-note"); if (n && n.parentNode) n.parentNode.removeChild(n);
      var sb = body && body.querySelector("#cm-open-setup"); if (sb) sb.remove();
    }
    document.addEventListener("change", onFilterEdit, true);
    document.addEventListener("input", onFilterEdit, true);
    ctx._cleanup = function () {
      returnPanel();
      window.removeEventListener("keydown", onEsc, true);
      document.removeEventListener("change", onFilterEdit, true);
      document.removeEventListener("input", onFilterEdit, true);
      document.querySelectorAll(".cm-ovl").forEach(function (o) { o.remove(); });
    };

    // Button on the base Starred screen: drill the starred TOSSUPS in Coach Mode.
    if (ctx.registerStarredAction) ctx.registerStarredAction({
      id: "run-coach", label: "Coach Mode",
      run: function (items) {
        var ids = (items || []).filter(function (it) { return it.type === "tossup" && it.question && it.question.id; }).map(function (it) { return it.question.id; });
        if (!ids.length) return;
        ctx.launchQuestions("coach", ids);
      },
    });

    // ── Statistics screen section ──
    ctx.registerStatsProvider({
      id: "coach-mode",
      title: "Coach Mode",
      render: function renderStats(el) {
        var st = lifeStats();
        if (!st.attempts) { el.innerHTML = '<div class="cm-empty">No coach sessions yet</div>'; return; }
        var acc = Math.round((st.correct / st.attempts) * 100);
        var depth = Math.round((st.depthSum / st.attempts) * 100);
        var html =
          '<div class="stats-grid cm-stats-grid">' +
            '<div class="stat-card"><div class="stat-card-value">' + st.attempts + '</div><div class="stat-card-label">Questions</div></div>' +
            '<div class="stat-card"><div class="stat-card-value">' + acc + '%</div><div class="stat-card-label">Correct</div></div>' +
            '<div class="stat-card"><div class="stat-card-value">' + depth + '%</div><div class="stat-card-label">Buzz depth</div></div>' +
            '<div class="stat-card"><div class="stat-card-value">' + st.ranOut + '</div><div class="stat-card-label">Out of clues</div></div>' +
          "</div>";
        // how deep into the question you buzz, as bars
        var keys = DEPTH_KEYS.filter(function (k) { return st.byDepth[k]; });
        if (keys.length) {
          var max = Math.max.apply(null, keys.map(function (k) { return st.byDepth[k]; }));
          html += '<div class="cm-stats-h eyebrow">Where you buzz</div><div class="cm-depthbars">' +
            DEPTH_KEYS.map(function (k) {
              var v = st.byDepth[k] || 0;
              return '<div class="cm-catrow"><span class="cm-catname">' + k + '</span><span class="cm-bar"><b style="width:' + (v ? Math.max(3, (v / max) * 100) : 0) + '%"></b></span><span class="cm-catcount num">' + v + "</span></div>";
            }).join("") + "</div>";
        }
        html += sessionsHtml();
        el.innerHTML = html;
        wireSessions(el, function () { renderStats(el); });
        // Session list pages with "Show more" (base helper; older bases skip).
        try { if (ctx.host && ctx.host.limitList) ctx.host.limitList(el.querySelector(".cm-sess-table"), "tbody > tr", "cm:sessions", 10, 25); } catch (e) {}
      },
    });
  }
