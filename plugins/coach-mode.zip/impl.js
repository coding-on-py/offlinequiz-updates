function __qbMain(ctx) {
    var body = null, page = null;
    var q = null, clues = [], shown = 0, phase = "idle"; // idle|reading|answering|result
    var log = []; // this session: {clue, totalClues, correct}
    var pool = null, poolIdx = 0; // set when launched over a fixed list of question ids (Folders / Starred)

    // ── lifetime stats (persisted in plugin storage) ──
    function lifeStats() {
      var st = ctx.storage.get("stats") || { attempts: 0, correct: 0, depthSum: 0, ranOut: 0, byClue: {} };
      if (!st.byDepth) st.byDepth = {};
      return st;
    }
    function recordLife(entry) {
      var st = lifeStats();
      st.attempts++;
      if (entry.correct) st.correct++;
      if (entry.ranOut) st.ranOut++;
      var depth = entry.clue / Math.max(1, entry.totalClues);
      st.depthSum += depth;
      var key = depth <= 0.2 ? "0-20%" : depth <= 0.4 ? "20-40%" : depth <= 0.6 ? "40-60%" : depth <= 0.8 ? "60-80%" : "80-100%";
      st.byDepth[key] = (st.byDepth[key] || 0) + 1;
      ctx.storage.set("stats", st);
    }

    function esc(s) { return (s == null ? "" : String(s)).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"); }
    function ansHtml(raw, fallback) {
      var src = (raw && String(raw).trim()) ? String(raw) : String(fallback || "");
      return esc(src).replace(/&lt;(\/?)(b|u|i|em|strong)&gt;/gi, "<$1$2>");
    }
    function cfg() { try { return ctx.host.getPracticeConfig() || {}; } catch (e) { return {}; } }
    // Defensive: works even if the running base predates ctx.keyLabel.
    var KEY_DEFAULTS = { buzz: "Space", next: "N", start: "S" };
    function keyLabel(id) {
      try { var v = ctx.keyLabel && ctx.keyLabel(id); if (v && v !== "?") return v; } catch (e) {}
      return KEY_DEFAULTS[id] || "?";
    }

    function filtersToQuery(f) {
      f = f || {}; var p = ["random=1", "limit=1"];
      if (f.standard) p.push("standard=1");
      if (f.categories && f.categories.length) p.push("categories=" + encodeURIComponent(f.categories.join(",")));
      if (f.subcategories && f.subcategories.length) p.push("subcategories=" + encodeURIComponent(f.subcategories.join(",")));
      if (f.alternateSubcategories && f.alternateSubcategories.length) p.push("alternateSubcategories=" + encodeURIComponent(f.alternateSubcategories.join(",")));
      if (f.difficulties && f.difficulties.length) p.push("difficulties=" + f.difficulties.join(","));
      if (f.setNames && f.setNames.length) p.push("setNames=" + encodeURIComponent(f.setNames.join(",")));
      if (f.yearMin != null) p.push("yearMin=" + f.yearMin);
      if (f.yearMax != null) p.push("yearMax=" + f.yearMax);
      return p.join("&");
    }

    function maybeStripPron(text) {
      try {
        var cfg = ctx.host.getPracticeConfig && ctx.host.getPracticeConfig();
        if (cfg && cfg.hidePron && ctx.host.stripPronunciations) return ctx.host.stripPronunciations(text);
      } catch (e) {}
      return text;
    }
    // Abbreviation-aware: a naive period split broke "the Michipicoten and
    // St. Ignace islands" (and "The St. Mary's river") into fragments. A chunk
    // ending in a known abbreviation or a single initial is glued to the next
    // one, as is any chunk the split left starting with a lowercase letter.
    var SENT_ABBR = /(?:\b(?:St|Ste|Mt|Mts|Dr|Mr|Mrs|Ms|Messrs|Mme|Mlle|Prof|Sr|Jr|Rev|Fr|Gen|Col|Capt|Lt|Sgt|Maj|Adm|Hon|Pres|Gov|Sen|Rep|Supt|Msgr|vs|etc|cf|ca|al|Inc|Co|Corp|Ltd|Bros|approx|No|Nos|Op|op|no|Vol|vol|Ch|ch|Fig|fig|Ft|Pt|pt|Rte|Ave|Blvd|[A-Za-z])\.["\u201d\u2019']?)$/;
    function mergeAbbrevChunks(parts) {
      var out = [], cur = "";
      for (var i = 0; i < parts.length; i++) {
        cur = cur ? cur + " " + parts[i] : parts[i];
        if (i < parts.length - 1 && SENT_ABBR.test(cur.trim())) continue;
        out.push(cur.trim());
        cur = "";
      }
      if (cur.trim()) out.push(cur.trim());
      return out;
    }
    function splitClues(text) {
      text = maybeStripPron(text);
      // Quote-aware: 'love." At' ends the sentence at the closing quote.
      var chunks = text.replace(/\(\*\)/g, "")
        .split(/(?<=[.!?…]["”’']?)\s+(?=["“‘']?[A-Z0-9(])/);
      return mergeAbbrevChunks(chunks)
        .map(function (c) { return c.trim(); })
        .filter(Boolean);
    }

    var borrowedPanel = null, panelHome = null;
    page = ctx.registerPage({
      id: "coach", navLabel: "Coach Mode", title: "COACH MODE",
      onShow: function (el, info) {
        body = el;
        // Back returns you to the session you left; only a fresh entry starts
        // a new recorded session.
        if (!(info && info.back)) sessId = null;
        try {
          var ho = JSON.parse(localStorage.getItem("qb-coach-handoff") || "null");
          if (ho && ho.ids && ho.ids.length) {
            localStorage.removeItem("qb-coach-handoff");
            pool = ho.ids.slice(0, 200); poolIdx = 0; log = [];
            nextQuestion(); // auto-start over the handed-off set
            return;
          }
        } catch (e) {}
        // Coming back: the body still holds the screen the user left (same
        // question, same clue count, whatever was typed in the answer box).
        // Re-borrow the filter panel, but don't wipe it with a fresh render.
        if (body.querySelector(".cm-layout")) { borrowPanel(); return; }
        render(); borrowPanel();
      },
      onHide: function () { returnPanel(); },
    });

    // ── saved sessions (view + delete from the Statistics section) ──
    // Each entry stores the buzz outcome AND enough to reproduce WHERE the
    // user buzzed: clue number, total clues, the read-position character
    // count (celerity), and the question text shown up to the buzz.
    var sessId = null;
    function sessionsAll() { return ctx.storage.get("sessions") || []; }
    function recordSession(entry) {
      var all = sessionsAll();
      var cur = null;
      if (sessId) for (var i = 0; i < all.length; i++) if (all[i].id === sessId) { cur = all[i]; break; }
      if (!cur) { sessId = Date.now(); cur = { id: sessId, entries: [] }; all.unshift(cur); if (all.length > 60) all.length = 60; }
      cur.entries.push(entry);
      ctx.storage.set("sessions", all);
    }

    // ── per-session STATS MENU (modal overlay) ──────────────────────────
    // celerity: how early in the question the buzz came, 100% = first word.
    function celerity(e) {
      if (e.totalChars && e.readChars != null) {
        return Math.max(0, Math.round((1 - e.readChars / Math.max(1, e.totalChars)) * 100));
      }
      // fallback for older sessions without char counts: use clue depth
      var depth = e.clue / Math.max(1, e.totalClues || 1);
      return Math.max(0, Math.round((1 - depth) * 100));
    }
    function depthPct(e) { return Math.round((e.clue / Math.max(1, e.totalClues || 1)) * 100); }
    function byCategory(entries) {
      var map = {}, order = [];
      entries.forEach(function (e) {
        var k = (e.category && String(e.category).trim()) || "(uncategorized)";
        if (!map[k]) { map[k] = { correct: 0, wrong: 0, total: 0, depthSum: 0 }; order.push(k); }
        var g = map[k]; g.total++; g.depthSum += depthPct(e);
        if (e.correct) g.correct++; else g.wrong++;
      });
      return order.map(function (k) { return { name: k, g: map[k] }; });
    }
    function openSessionModal(sess) {
      var entries = sess.entries || [];
      var total = entries.length;
      var correct = entries.filter(function (e) { return e.correct; }).length;
      var ranOut = entries.filter(function (e) { return e.ranOut; }).length;
      var accuracy = total ? Math.round((correct / total) * 100) : 0;
      var avgDepth = total ? Math.round(entries.reduce(function (s, e) { return s + depthPct(e); }, 0) / total) : 0;
      var avgCel = total ? Math.round(entries.reduce(function (s, e) { return s + celerity(e); }, 0) / total) : 0;

      // (1) summary grid — totals, correct, celerity
      var summary =
        '<div class="cm-stm-grid">' +
          '<div class="cm-stm-card"><div class="cm-stm-val">' + total + '</div><div class="cm-stm-lbl">Questions</div></div>' +
          '<div class="cm-stm-card"><div class="cm-stm-val" style="color:var(--green)">' + correct + '</div><div class="cm-stm-lbl">Correct</div></div>' +
          '<div class="cm-stm-card"><div class="cm-stm-val" style="color:var(--accent)">' + accuracy + '%</div><div class="cm-stm-lbl">Accuracy</div></div>' +
          '<div class="cm-stm-card"><div class="cm-stm-val">' + avgDepth + '%</div><div class="cm-stm-lbl">Avg Buzz Depth</div></div>' +
          '<div class="cm-stm-card"><div class="cm-stm-val">' + avgCel + '%</div><div class="cm-stm-lbl">Avg Celerity</div></div>' +
          '<div class="cm-stm-card"><div class="cm-stm-val">' + ranOut + '</div><div class="cm-stm-lbl">Out of Clues</div></div>' +
        '</div>';

      // (2a) buzz-depth distribution bar chart (where in the question)
      var buckets = { "0-20%": 0, "20-40%": 0, "40-60%": 0, "60-80%": 0, "80-100%": 0 };
      var bkeys = ["0-20%", "20-40%", "40-60%", "60-80%", "80-100%"];
      entries.forEach(function (e) {
        var d = depthPct(e) / 100;
        var k = d <= 0.2 ? "0-20%" : d <= 0.4 ? "20-40%" : d <= 0.6 ? "40-60%" : d <= 0.8 ? "60-80%" : "80-100%";
        buckets[k]++;
      });
      var bmax = Math.max.apply(null, bkeys.map(function (k) { return buckets[k]; }).concat([1]));
      var depthRows = bkeys.map(function (k) {
        var w = buckets[k] ? Math.max(4, (buckets[k] / bmax) * 100) : 0;
        return '<div class="cm-stm-catrow">' +
          '<div class="cm-stm-catname">' + k + '</div>' +
          '<div class="cm-stm-bar"><div class="cm-stm-bar-fill" style="width:' + w + '%"></div></div>' +
          '<div class="cm-stm-catcount">' + buckets[k] + '</div>' +
        '</div>';
      }).join("");
      var depthBlock = total
        ? '<div class="cm-stm-section"><div class="cm-stm-h">Buzz depth (where in the question)</div>' + depthRows + '</div>'
        : "";

      // (2b) per-category correct-vs-wrong breakdown
      var cats = byCategory(entries);
      var catRows = cats.map(function (c) {
        var g = c.g;
        var corrPct = g.total ? (g.correct / g.total) * 100 : 0;
        var wrongPct = g.total ? (g.wrong / g.total) * 100 : 0;
        return '<div class="cm-stm-catrow">' +
          '<div class="cm-stm-catname" title="' + esc(c.name) + '">' + esc(c.name) + '</div>' +
          '<div class="cm-stm-stack">' +
            '<div class="seg correct" style="width:' + corrPct + '%"></div>' +
            '<div class="seg wrong" style="width:' + wrongPct + '%"></div>' +
          '</div>' +
          '<div class="cm-stm-catcount">' + g.correct + '/' + g.total + '</div>' +
        '</div>';
      }).join("");
      var catBlock = cats.length
        ? '<div class="cm-stm-section"><div class="cm-stm-h">Per-category breakdown</div>' + catRows + '</div>'
        : "";

      // (3) full per-question history — each question + WHERE the user buzzed in
      var histRows = entries.map(function (e, i) {
        var cel = celerity(e), dep = depthPct(e);
        var verdict = e.correct
          ? '<span style="color:var(--green)">✓ Correct</span>'
          : (e.ranOut ? '<span class="text-muted">⏱ Out of clues</span>' : '<span style="color:var(--red)">✗ Incorrect</span>');
        var qtext = e.questionText || e.buzzText || "";
        var buzzInfo = 'clue ' + e.clue + '/' + (e.totalClues || "?") + ' · depth ' + dep + '% · celerity ' + cel + '%';
        return '<div class="cm-stm-item">' +
          '<div class="cm-stm-item-head">' +
            '<span class="cm-stm-idx">' + (i + 1) + '</span>' +
            verdict +
            (e.category ? '<span class="cm-stm-itemmeta">' + esc(e.category) + '</span>' : "") +
          '</div>' +
          '<div class="cm-stm-ans">Answer: <strong>' + esc(e.answer || "") + '</strong></div>' +
          (e.given && e.given !== "(no answer)" && e.given !== "(out of clues)"
            ? '<div class="cm-stm-given">You said: <em>' + esc(e.given) + '</em></div>' : "") +
          '<div class="cm-stm-buzz">' +
            '<div class="cm-stm-buzzbar"><div class="cm-stm-buzzfill" style="width:' + dep + '%"></div>' +
              '<div class="cm-stm-buzzmark" style="left:' + Math.min(99, dep) + '%"></div></div>' +
            '<div class="cm-stm-buzzlbl">' + buzzInfo + '</div>' +
          '</div>' +
          (qtext ? '<div class="cm-stm-qtext"><span class="cm-stm-qa-lbl">READ</span><span>' + esc(qtext) + '</span></div>' : "") +
        '</div>';
      }).join("");
      var histBlock =
        '<div class="cm-stm-section"><div class="cm-stm-h">Session history (' + total + ')</div>' +
          '<div class="cm-stm-hist">' + (histRows || '<div class="text-muted" style="padding:8px">No questions in this session.</div>') + '</div>' +
        '</div>';

      var overlay = document.createElement("div");
      overlay.className = "qb-overlay cm-stm-overlay";
      overlay.innerHTML =
        '<div class="cm-stm-box">' +
          '<div class="cm-stm-head">' +
            '<div><div class="cm-stm-title">Coach session</div>' +
              '<div class="cm-stm-sub">' + esc(new Date(sess.id).toLocaleString()) + '</div></div>' +
            '<button class="btn btn-sm btn-ghost cm-stm-close" title="Close">✕</button>' +
          '</div>' +
          '<div class="cm-stm-body">' + summary + depthBlock + catBlock + histBlock + '</div>' +
        '</div>';
      function close() { try { document.removeEventListener("keydown", onEsc); } catch (e) {} if (overlay.parentNode) overlay.parentNode.removeChild(overlay); }
      function onEsc(ev) { if (ev.key === "Escape") { ev.preventDefault(); close(); } }
      overlay.addEventListener("click", function (ev) { if (ev.target === overlay) close(); });
      overlay.querySelector(".cm-stm-close").onclick = close;
      document.addEventListener("keydown", onEsc);
      document.body.appendChild(overlay);
    }

    function sessionsHtml() {
      var all = sessionsAll();
      if (!all.length) return "";
      var rows = all.map(function (sess, i) {
        var n = sess.entries.length, ok = sess.entries.filter(function (e) { return e.correct; }).length;
        return '<tr class="session-row" data-view="' + i + '" title="Open session stats" style="cursor:pointer">' +
          "<td>" + new Date(sess.id).toLocaleString() + "</td><td>" + n + "</td><td>" + ok + " correct</td>" +
          '<td><button class="btn btn-sm btn-ghost session-delete" data-del="' + i + '" title="Delete session">&times;</button></td></tr>';
      }).join("");
      return '<div class="filter-label" style="margin:14px 0 6px">COACH SESSIONS</div>' +
        '<table class="stats-table"><thead><tr><th>Session</th><th>Questions</th><th>Result</th><th></th></tr></thead><tbody>' + rows + "</tbody></table>" +
        '<button class="btn btn-sm btn-ghost" id="cm-sess-clear" style="margin-top:8px">Delete all sessions</button>';
    }
    function wireSessions(el, rerender) {
      el.querySelectorAll("[data-view]").forEach(function (b) {
        b.onclick = function (ev) {
          if (ev.target.closest(".session-delete")) return;
          var all = sessionsAll();
          var sess = all[parseInt(b.dataset.view, 10)];
          if (sess) openSessionModal(sess);
        };
      });
      el.querySelectorAll("[data-del]").forEach(function (b) {
        b.onclick = function () {
          var doDel = function () { var all = sessionsAll(); all.splice(parseInt(b.dataset.del), 1); ctx.storage.set("sessions", all); rerender(); };
          if (ctx.host && ctx.host.confirm) ctx.host.confirm("Delete this coach session? Its stats are removed permanently.", doDel);
          else doDel();
        };
      });
      var ca = el.querySelector("#cm-sess-clear");
      if (ca) ca.onclick = function () {
        var doClear = function () { ctx.storage.set("sessions", []); rerender(); };
        if (ctx.host && ctx.host.confirm) ctx.host.confirm("Delete ALL coach sessions? This cannot be undone.", doClear);
        else doClear();
      };
    }
    function active() { return page && page.screenEl && page.screenEl.classList.contains("active"); }
    ctx.on("screen:change", function () { setTimeout(function () { if (!active()) returnPanel(); }, 0); });

    // Borrow the REAL practice filter panel (categories, sets, difficulties,
    // years, strictness…) so Coach Mode is filtered exactly like practice.
    function borrowPanel() {
      var layout = body && body.querySelector(".cm-layout");
      if (!layout) return;
      try { if (ctx.host && ctx.host.ensureFiltersLoaded) ctx.host.ensureFiltersLoaded(); } catch (e) {}
      var panel = document.getElementById("filters-panel") || borrowedPanel;
      if (!panel || panel.parentNode === layout) return;
      // No set/packet selection here — these pages always draw from the
      // category/difficulty filters, so force MODE back to random.
      var ms = document.getElementById("mode-select");
      if (ms && ms.value !== "random") { ms.value = "random"; ms.dispatchEvent(new Event("change", { bubbles: true })); }
      if (!panelHome) panelHome = { parent: panel.parentNode, next: panel.nextSibling };
      panel.classList.add("cm-borrowed");
      layout.insertBefore(panel, layout.firstChild);
      borrowedPanel = panel;
    }
    function returnPanel() {
      if (!borrowedPanel || !panelHome) return;
      borrowedPanel.classList.remove("cm-borrowed");
      try { panelHome.parent.insertBefore(borrowedPanel, panelHome.next); } catch (e) {}
      borrowedPanel = null;
    }

    async function nextQuestion() {
      phase = "reading"; shown = 1; q = null; render();
      try {
        if (pool) {
          if (poolIdx >= pool.length) { phase = "idle"; pool = null; render(); ctx.toast("Done — you went through every question.", "success"); return; }
          var dd = await ctx.api.get("/api/tossups/" + encodeURIComponent(pool[poolIdx++]));
          q = dd.tossup;
        } else {
          var c = cfg();
          var d = await ctx.api.get("/api/tossups/random?" + filtersToQuery(c.filters));
          q = d.tossup;
        }
      } catch (e) {}
      if (!q) { phase = "idle"; render(); ctx.toast("Couldn't load a question", "error"); return; }
      clues = splitClues(q.question_sanitized || "");
      shown = 1;
      render();
    }

    function buzz() { if (phase !== "reading") return; ctx.playSound("buzz"); phase = "answering"; render(); }
    function nextClue() {
      if (phase !== "reading") return;
      if (shown >= clues.length) { resolve(false, "(out of clues)", true); return; }
      shown++; render();
    }

    async function submit(answer) {
      var verdict = "reject";
      try {
        // read-position = the characters of the clues shown so far
        var readChars = clues.slice(0, shown).join(" ").length;
        var r = await ctx.api.post("/api/evaluate-tossup", { questionId: q.id, answer: answer, strictness: cfg().strictness || 10, buzzPosition: readChars });
        verdict = r.status;
      } catch (e) {}
      resolve(verdict === "accept" || verdict === "prompt", answer || "(no answer)", false);
    }

    function resolve(correct, given, ranOut) {
      // capture WHERE the user buzzed: the read text + char position (celerity)
      var buzzText = clues.slice(0, shown).join(" ");
      var totalChars = clues.join(" ").length || (q && q.question_sanitized ? q.question_sanitized.length : 0);
      var entry = { clue: shown, totalClues: clues.length, correct: correct, ranOut: ranOut,
        answer: (q && (q.answer_sanitized || q.answer)) || "", given: given || "", category: (q && q.category) || "",
        readChars: buzzText.length, totalChars: totalChars, questionText: buzzText };
      log.push(entry);
      recordLife(entry);
      recordSession(entry);
      // Record into the REAL session table too, through the same override
      // path multiplayer uses — until now coach powers lived only in this
      // plugin's storage, so nothing earned here counted toward stats or the
      // "power on …" achievements. Power = the read stayed before the (*) mark
      // (clues are sentences, so buzzing after a sentence that contains the
      // mark is not a power). Wrong = neg, out of clues = unanswered (0).
      try {
        var sanitized = (q && q.question_sanitized) || "";
        var powerIdx = sanitized.indexOf("(*)");
        var isPower = !!correct && powerIdx >= 0 && buzzText.length <= powerIdx;
        var points = correct ? (isPower ? 15 : 10) : (ranOut ? 0 : -5);
        var cel = totalChars ? Math.max(0, Math.min(1, buzzText.length / totalChars)) : 0;
        ctx.api.post("/api/check-tossup", {
          questionId: q.id, answer: given || "", buzzPosition: buzzText.length,
          sessionId: "coach-" + (sessId || Date.now()), overriding: true, correct: !!correct,
          isPower: isPower, points: points, celerity: cel,
        }).catch(function () {});
      } catch (e) {}
      ctx.playSound(correct ? "correct" : "incorrect");
      phase = "result"; q._given = given; q._correct = correct; q._ranOut = ranOut;
      render();
    }

    function summary() {
      var n = log.length; if (!n) return "";
      var corr = log.filter(function (l) { return l.correct; }).length;
      var avg = log.reduce(function (s, l) { return s + l.clue / Math.max(1, l.totalClues); }, 0) / n;
      return n + " questions · " + corr + " correct · avg buzz depth " + Math.round(avg * 100) + "%";
    }

    function render() {
      if (!body) return;
      // Give the borrowed panel back BEFORE innerHTML wipes the body, or the
      // settings menu is detached from the DOM and lost.
      returnPanel();
      var ls = lifeStats();
      var lifeLine = ls.attempts
        ? '<div class="cm-life text-muted">All-time: ' + ls.attempts + " questions · " +
          Math.round((ls.correct / ls.attempts) * 100) + "% correct · avg depth " +
          Math.round((ls.depthSum / ls.attempts) * 100) + "%</div>"
        : "";
      var head =
        '<div class="cm-top"><span class="pill">' + (log.length ? esc(summary()) : "Buzz Discipline Training") + "</span></div>" + lifeLine;
      function shell(inner) {
        return '<div class="practice-layout cm-layout"><main class="question-area"><div class="cm-wrap">' + head + inner + "</div></main></div>";
      }
      if (phase === "idle") {
        body.innerHTML = shell(
          '<div class="cm-card cm-start"><p><kbd>' + esc(keyLabel("buzz")) + '</kbd> buzz · <kbd>' + esc(keyLabel("next")) + '</kbd> next clue</p>' +
          '<button class="btn btn-primary" id="cm-start">[' + esc(keyLabel("start")) + '] Start</button></div>');
        var st = body.querySelector("#cm-start"); if (st) st.onclick = nextQuestion;
        borrowPanel();
        return;
      }
      if (!q) { body.innerHTML = shell('<div class="cm-card text-muted">Loading…</div>'); borrowPanel(); return; }
      var cluesHtml = clues.slice(0, phase === "result" ? clues.length : shown).map(function (c, i) {
        var cur = i === shown - 1 && phase !== "result";
        return '<div class="cm-clue' + (cur ? " cur" : "") + '"><span class="cm-cluenum">' + (i + 1) + "</span>" + esc(c) + "</div>";
      }).join("");
      var controls = "";
      if (phase === "reading") {
        controls = '<div class="cm-actions"><button class="btn btn-primary" id="cm-buzz">[' + esc(keyLabel("buzz")) + '] Buzz</button>' +
          '<button class="btn" id="cm-next-clue">[' + esc(keyLabel("next")) + '] Next clue (' + shown + "/" + clues.length + ")</button></div>";
      } else if (phase === "answering") {
        controls = '<div class="buzz-area"><div class="buzz-prompt"><span class="prompt-symbol">&gt;</span>' +
          '<input type="text" id="cm-input" placeholder="your answer… (Enter)" autocomplete="off" autocorrect="off" spellcheck="false"></div></div>';
      } else if (phase === "result") {
        controls = '<div class="result-area"><div class="result-banner ' + (q._correct ? "correct" : "incorrect") + '">' +
          (q._correct ? "CORRECT on clue " + shown + "/" + clues.length : (q._ranOut ? "OUT OF CLUES" : "INCORRECT on clue " + shown + "/" + clues.length)) + "</div>" +
          '<div class="result-answer">Your answer: <strong>' + esc(q._given) + "</strong><br>Answer: <span style=\"color:var(--green)\">" + ansHtml(q.answer, q.answer_sanitized || "") + "</span></div>" +
          '<div class="result-next"><button class="btn btn-primary" id="cm-next">[' + esc(keyLabel("next")) + '] Next question</button></div></div>';
      }
      body.innerHTML = shell(
        '<div class="cm-card"><div class="cm-meta">' + esc(q.category || "") + (q.subcategory ? " / " + esc(q.subcategory) : "") + " · diff " + esc(q.difficulty != null ? q.difficulty : "?") +
          ' <span class="qb-star" data-qid="' + esc(q.id) + '" data-type="tossup" title="Star this question" style="margin-left:8px">☆</span></div>' +
        cluesHtml + controls + "</div>");
      borrowPanel();
      // reflect current star state on the indicator
      (function () {
        var st = body.querySelector(".qb-star");
        if (!st) return;
        ctx.api.get("/api/starred/check?questionId=" + encodeURIComponent(q.id) + "&type=tossup").then(function (d) {
          if (d && d.starred) { st.textContent = "★"; st.classList.add("on"); }
        }).catch(function () {});
      })();
      var bz = body.querySelector("#cm-buzz"); if (bz) bz.onclick = buzz;
      var nc = body.querySelector("#cm-next-clue"); if (nc) nc.onclick = nextClue;
      var nx = body.querySelector("#cm-next"); if (nx) nx.onclick = nextQuestion;
      var cmCard = body.querySelector(".cm-card");
      if (cmCard) cmCard.oncontextmenu = function (e) {
        if (!window.QB || !QB.contextMenu) return;
        e.preventDefault();
        var qq = q;
        var items = [
          { label: "View full question", onClick: function () { viewFullQuestion(qq); } },
          { label: "Copy clues shown", onClick: function () { try { navigator.clipboard.writeText(clues.slice(0, phase === "result" ? clues.length : shown).join(" ")); QB.toast("Copied"); } catch (err) {} } },
        ];
        if (phase === "result" && ctx.host && ctx.host.searchDatabase) {
          var pa = (qq.answer_sanitized || "").split(/[\[(]/)[0].trim();
          if (pa) items.push({ label: "Find questions with this answer", onClick: function () { ctx.host.searchDatabase({ query: pa, field: "answer", exact: false }); } });
        }
        items.push({ sep: true });
        items.push({ label: "Star / unstar question", onClick: function () { var st = body.querySelector(".qb-star"); if (st) st.click(); } });
        QB.contextMenu(e.clientX, e.clientY, items, { title: phase === "result" ? (qq.answer_sanitized || "").split(/[\[(]/)[0].trim() : "Coach question" });
      };
      var inp = body.querySelector("#cm-input");
      if (inp) {
        inp.focus();
        inp.addEventListener("keydown", function (e) { if (e.key === "Enter") { e.preventDefault(); inp.disabled = true; submit(inp.value.trim()); } });
      }
    }

    // Right-click "View full question" — the whole tossup + answer in a
    // closeable overlay (Esc works via the app's .qb-overlay rule). Peeking
    // mid-read is the player's own call.
    function viewFullQuestion(qq) {
      if (!qq) return;
      var old = document.querySelector(".cm-viewer"); if (old) old.remove();
      var el = document.createElement("div");
      el.className = "qb-overlay cm-viewer";
      el.innerHTML =
        '<div class="cm-viewer-card">' +
          '<div class="cm-viewer-meta">' + esc(qq.category || "") + (qq.subcategory ? " / " + esc(qq.subcategory) : "") + (qq.set_name ? " · " + esc(qq.set_name) : "") + "</div>" +
          '<div class="cm-viewer-q">' + esc(qq.question_sanitized || "") + "</div>" +
          '<div class="cm-viewer-a">ANSWER: ' + ansHtml(qq.answer, qq.answer_sanitized || "") + "</div>" +
          '<div style="text-align:right"><button class="btn btn-sm cm-viewer-close">Close</button></div>' +
        "</div>";
      el.addEventListener("click", function (ev) { if (ev.target === el || ev.target.closest(".cm-viewer-close")) el.remove(); });
      document.body.appendChild(el);
    }

    // Rebindable hotkeys (Settings > Keybinds). Handlers no-op off-page.
    ctx.onHotkey("buzz", function () { if (active() && phase === "reading") buzz(); });
    ctx.onHotkey("next", function () {
      if (!active()) return;
      if (phase === "reading") nextClue();
      else if (phase === "result") nextQuestion();
    });
    ctx.onHotkey("start", function () { if (active() && phase === "idle") nextQuestion(); });
    ctx._cleanup = function () {
      var ov = document.querySelector(".cm-stm-overlay"); if (ov && ov.parentNode) ov.parentNode.removeChild(ov);
    };

    // Button on the base Starred screen: drill the starred TOSSUPS in Coach Mode.
    if (ctx.registerStarredAction) ctx.registerStarredAction({
      id: "run-coach", label: "▶ Coach",
      run: function (items) {
        var ids = (items || []).filter(function (it) { return it.type === "tossup" && it.question && it.question.id; }).map(function (it) { return it.question.id; });
        if (!ids.length) { ctx.toast("No starred tossups for Coach Mode", "error"); return; }
        ctx.launchQuestions("coach", ids);
      },
    });

    // ── STATISTICS screen section ──
    ctx.registerStatsProvider({
      id: "coach-mode",
      title: "Coach Mode",
      render: function renderStats(el) {
        var st = lifeStats();
        if (!st.attempts) { el.innerHTML = '<div class="text-muted" style="font-size:12px">No coach sessions yet — train buzz discipline from the title menu (Extra).</div>'; return; }
        var acc = Math.round((st.correct / st.attempts) * 100);
        var depth = Math.round((st.depthSum / st.attempts) * 100);
        var html =
          '<div class="stats-grid">' +
            '<div class="stat-card"><div class="stat-card-value">' + st.attempts + '</div><div class="stat-card-label">Questions</div></div>' +
            '<div class="stat-card"><div class="stat-card-value">' + acc + '%</div><div class="stat-card-label">Correct</div></div>' +
            '<div class="stat-card"><div class="stat-card-value">' + depth + '%</div><div class="stat-card-label">Avg Buzz Depth</div></div>' +
            '<div class="stat-card"><div class="stat-card-value">' + st.ranOut + '</div><div class="stat-card-label">Out of Clues</div></div>' +
          "</div>";
        // how deep into the question you buzz, as bars
        var keys = ["0-20%", "20-40%", "40-60%", "60-80%", "80-100%"].filter(function (k) { return st.byDepth[k]; });
        if (keys.length) {
          var max = Math.max.apply(null, keys.map(function (k) { return st.byDepth[k]; }));
          html += '<table class="stats-table" style="margin-top:10px"><thead><tr><th>Buzzed at depth</th><th>Count</th><th></th></tr></thead><tbody>' +
            keys.map(function (k) {
              return "<tr><td>" + k + "</td><td>" + st.byDepth[k] + '</td><td><div class="stats-bar"><div class="stats-bar-fill" style="width:' + Math.max(4, (st.byDepth[k] / max) * 100) + '%"></div></div></td></tr>';
            }).join("") + "</tbody></table>";
        }
        html += sessionsHtml();
        el.innerHTML = html;
        wireSessions(el, function () { renderStats(el); });
      },
    });

    ctx.toast("Coach Mode enabled");
  }
