/**
 * OfflineQuiz plugin: Coach Mode
 *
 * Trains buzz discipline: each tossup is revealed ONE CLUE (sentence) at a
 * time. At every clue you decide — buzz now, or ask for the next clue. The
 * page tracks which clue you buzzed on and whether you were right, so you can
 * see whether you buzz too early or sit on answers too long. Questions come
 * from the practice filters (the page's Setup drawer is the practice panel),
 * judged with your strictness, and every answer is recorded in your stats.
 */
QB.registerPlugin({
  id: "coach-mode",
  name: "Coach Mode",
  version: "1.30.0",
  author: "OfflineQuiz",
  description: "Clue-by-clue buzz training: reveal one sentence at a time and learn when to buzz.",
  hotkeys: [
    { id: "buzz", label: "Buzz", default: "Space" },
    { id: "next", label: "Next clue / next question", default: "n" },
    { id: "start", label: "Start", default: "s" },
  ],
  onEnable: __qbMain,
  onDisable: function (ctx) { if (ctx._cleanup) ctx._cleanup(); },
});
