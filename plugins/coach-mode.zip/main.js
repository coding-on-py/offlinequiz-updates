/**
 * OfflineQuiz plugin: Coach Mode
 *
 * Trains buzz discipline: each tossup is revealed ONE CLUE (sentence) at a
 * time. At every clue you decide — buzz now, or ask for the next clue. The
 * session tracks which clue number you buzzed on and your accuracy, so you
 * can see whether you're buzzing too early or sitting on answers too long.
 * Uses your Tossups practice filters and strictness.
 */
QB.registerPlugin({
  id: "coach-mode",
  name: "Coach Mode",
  version: "1.26.0",
  author: "OfflineQuiz",
  description: "Clue-by-clue buzz trainer: reveal one sentence at a time, buzz or pass, and track how deep into questions you buzz.",
  hotkeys: [
    { id: "buzz", label: "Buzz", default: "Space" },
    { id: "next", label: "Next clue / next question", default: "n" },
    { id: "start", label: "Start", default: "s" },
  ],
  onEnable: __qbMain,
  onDisable: function (ctx) { if (ctx._cleanup) ctx._cleanup(); },
});
