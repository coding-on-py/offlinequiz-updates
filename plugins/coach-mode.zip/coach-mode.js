/**
 * OfflineQuiz plugin: Coach Mode
 *
 * Trains buzz discipline: each tossup is revealed ONE CLUE (sentence) at a
 * time. At every clue you decide — buzz now, or ask for the next clue. The
 * session tracks which clue number you buzzed on and your accuracy, so you
 * can see whether you're buzzing too early or sitting on answers too long.
 * Uses your Tossups practice filters and strictness.
 */
QB.registerPlugin({
  id: "coach-mode",
  name: "Coach Mode",
  version: "1.16.0",
  author: "OfflineQuiz",
  description: "Clue-by-clue buzz trainer: reveal one sentence at a time, buzz or pass, and track how deep into questions you buzz.",
  hotkeys: [
    { id: "buzz", label: "Buzz", default: "Space" },
    { id: "next", label: "Next clue / next question", default: "n" },
    { id: "start", label: "Start", default: "s" },
  ],
  onEnable: function (ctx) {
    var body = null, page = null;
    var q = null, clues = [], shown = 0, phase = "idle"; // idle|reading|answering|result
    var log = []; // this session: {clue, totalClues, correct}
    var pool = null, poolIdx = 0; // set when launched over a fixed list of question ids (Folders / Starred)

    // ── lifetime stats (persisted in plugin storage) ──
    function lifeStats() {
      var st = ctx.storage.get("stats") || { attempts: 0, correct: 0, depthSum: 0, ranOut: 0, byClue: {} };
      if (!st.byDepth) st.byDepth = {};
      return st;
    }
    function recordLife(entry) {
      var st = lifeStats();
      st.attempts++;
      if (entry.correct) st.correct++;
      if (entry.ranOut) st.ranOut++;
      var depth = entry.clue / Math.max(1, entry.totalClues);
      st.depthSum += depth;
      var key = depth <= 0.2 ? "0-20%" : depth <= 0.4 ? "20-40%" : depth <= 0.6 ? "40-60%" : depth <= 0.8 ? "60-80%" : "80-100%";
      st.byDepth[key] = (st.byDepth[key] || 0) + 1;
      ctx.storage.set("stats", st);
    }

    function esc(s) { return (s == null ? "" : String(s)).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"); }
    function ansHtml(raw, fallback) {
      var src = (raw && String(raw).trim()) ? String(raw) : String(fallback || "");
      return esc(src).replace(/&lt;(\/?)(b|u|i|em|strong)&gt;/gi, "<$1$2>");
    }
    function cfg() { try { return ctx.host.getPracticeConfig() || {}; } catch (e) { return {}; } }
    // Defensive: works even if the running base predates ctx.keyLabel.
    var KEY_DEFAULTS = { buzz: "Space", next: "N", start: "S" };
    function keyLabel(id) {
      try { var v = ctx.keyLabel && ctx.keyLabel(id); if (v && v !== "?") return v; } catch (e) {}
      return KEY_DEFAULTS[id] || "?";
    }

    function filtersToQuery(f) {
      f = f || {}; var p = ["random=1", "limit=1"];
      if (f.standard) p.push("standard=1");
      if (f.categories && f.categories.length) p.push("categories=" + encodeURIComponent(f.categories.join(",")));
      if (f.subcategories && f.subcategories.length) p.push("subcategories=" + encodeURIComponent(f.subcategories.join(",")));
      if (f.alternateSubcategories && f.alternateSubcategories.length) p.push("alternateSubcategories=" + encodeURIComponent(f.alternateSubcategories.join(",")));
      if (f.difficulties && f.difficulties.length) p.push("difficulties=" + f.difficulties.join(","));
      if (f.setNames && f.setNames.length) p.push("setNames=" + encodeURIComponent(f.setNames.join(",")));
      if (f.yearMin != null) p.push("yearMin=" + f.yearMin);
      if (f.yearMax != null) p.push("yearMax=" + f.yearMax);
      return p.join("&");
    }

    function maybeStripPron(text) {
      try {
        var cfg = ctx.host.getPracticeConfig && ctx.host.getPracticeConfig();
        if (cfg && cfg.hidePron && ctx.host.stripPronunciations) return ctx.host.stripPronunciations(text);
      } catch (e) {}
      return text;
    }
    function splitClues(text) {
      text = maybeStripPron(text);
      // Quote-aware: 'love." At' ends the sentence at the closing quote.
      return text.replace(/\(\*\)/g, "")
        .split(/(?<=[.!?…]["”’']?)\s+(?=["“‘']?[A-Z0-9(])/)
        .map(function (c) { return c.trim(); })
        .filter(Boolean);
    }

    var borrowedPanel = null, panelHome = null;
    page = ctx.registerPage({
      id: "coach", navLabel: "Coach Mode", title: "COACH MODE",
      onShow: function (el) {
        body = el; sessId = null;
        try {
          var ho = JSON.parse(localStorage.getItem("qb-coach-handoff") || "null");
          if (ho && ho.ids && ho.ids.length) {
            localStorage.removeItem("qb-coach-handoff");
            pool = ho.ids.slice(0, 200); poolIdx = 0; log = [];
            nextQuestion(); // auto-start over the handed-off set
            return;
          }
        } catch (e) {}
        render(); borrowPanel();
      },
      onHide: function () { returnPanel(); },
    });

    // ── saved sessions (view + delete from the Statistics section) ──
    var sessId = null;
    function sessionsAll() { return ctx.storage.get("sessions") || []; }
    function recordSession(entry) {
      var all = sessionsAll();
      var cur = null;
      if (sessId) for (var i = 0; i < all.length; i++) if (all[i].id === sessId) { cur = all[i]; break; }
      if (!cur) { sessId = Date.now(); cur = { id: sessId, entries: [] }; all.unshift(cur); if (all.length > 60) all.length = 60; }
      cur.entries.push(entry);
      ctx.storage.set("sessions", all);
    }
    function sessionsHtml() {
      var all = sessionsAll();
      if (!all.length) return "";
      var rows = all.map(function (sess, i) {
        var n = sess.entries.length, ok = sess.entries.filter(function (e) { return e.correct; }).length;
        var body = sess.entries.map(function (e) {
          var pct = Math.round((e.clue / Math.max(1, e.totalClues)) * 100);
          return '<div style="font-size:12px">' +
            (e.correct ? '<span style="color:var(--green)">\u2713</span>' : '<span style="color:var(--red)">\u2717</span>') +
            " " + pct + "% \u2014 " + esc(e.answer || "") +
            (e.given ? ' <span class="text-muted">(you: ' + esc(e.given) + ")</span>" : (e.ranOut ? ' <span class="text-muted">(out of clues)</span>' : "")) +
            "</div>";
        }).join("");
        return '<tr class="session-row" data-view="' + i + '" title="View this session" style="cursor:pointer">' +
          "<td>" + new Date(sess.id).toLocaleString() + "</td><td>" + n + "</td><td>" + ok + " correct</td>" +
          '<td><button class="btn btn-sm btn-ghost session-delete" data-del="' + i + '" title="Delete session">&times;</button></td></tr>' +
          '<tr class="hidden" data-body="' + i + '"><td colspan="4">' + body + "</td></tr>";
      }).join("");
      return '<div class="filter-label" style="margin:14px 0 6px">COACH SESSIONS</div>' +
        '<table class="stats-table"><thead><tr><th>Session</th><th>Questions</th><th>Result</th><th></th></tr></thead><tbody>' + rows + "</tbody></table>" +
        '<button class="btn btn-sm btn-ghost" id="cm-sess-clear" style="margin-top:8px">Delete all sessions</button>';
    }
    function wireSessions(el, rerender) {
      el.querySelectorAll("[data-view]").forEach(function (b) {
        b.onclick = function (ev) {
          if (ev.target.closest(".session-delete")) return;
          var bd = el.querySelector('[data-body="' + b.dataset.view + '"]');
          if (bd) bd.classList.toggle("hidden");
        };
      });
      el.querySelectorAll("[data-del]").forEach(function (b) {
        b.onclick = function () { var all = sessionsAll(); all.splice(parseInt(b.dataset.del), 1); ctx.storage.set("sessions", all); rerender(); };
      });
      var ca = el.querySelector("#cm-sess-clear");
      if (ca) ca.onclick = function () { ctx.storage.set("sessions", []); rerender(); };
    }
    function active() { return page && page.screenEl && page.screenEl.classList.contains("active"); }
    ctx.on("screen:change", function () { setTimeout(function () { if (!active()) returnPanel(); }, 0); });

    // Borrow the REAL practice filter panel (categories, sets, difficulties,
    // years, strictness…) so Coach Mode is filtered exactly like practice.
    function borrowPanel() {
      var layout = body && body.querySelector(".cm-layout");
      if (!layout) return;
      try { if (ctx.host && ctx.host.ensureFiltersLoaded) ctx.host.ensureFiltersLoaded(); } catch (e) {}
      var panel = document.getElementById("filters-panel") || borrowedPanel;
      if (!panel || panel.parentNode === layout) return;
      // No set/packet selection here — these pages always draw from the
      // category/difficulty filters, so force MODE back to random.
      var ms = document.getElementById("mode-select");
      if (ms && ms.value !== "random") { ms.value = "random"; ms.dispatchEvent(new Event("change", { bubbles: true })); }
      if (!panelHome) panelHome = { parent: panel.parentNode, next: panel.nextSibling };
      panel.classList.add("cm-borrowed");
      // settings stay OPEN while training
      ["sec-mode", "sec-categories", "sec-difficulty"].forEach(function (id) {
        var el = document.getElementById(id); if (el) el.classList.remove("collapsed");
      });
      layout.insertBefore(panel, layout.firstChild);
      borrowedPanel = panel;
    }
    function returnPanel() {
      if (!borrowedPanel || !panelHome) return;
      borrowedPanel.classList.remove("cm-borrowed");
      try { panelHome.parent.insertBefore(borrowedPanel, panelHome.next); } catch (e) {}
      borrowedPanel = null;
    }

    async function nextQuestion() {
      phase = "reading"; shown = 1; q = null; render();
      try {
        if (pool) {
          if (poolIdx >= pool.length) { phase = "idle"; pool = null; render(); ctx.toast("Done — you went through every question.", "success"); return; }
          var dd = await ctx.api.get("/api/tossups/" + encodeURIComponent(pool[poolIdx++]));
          q = dd.tossup;
        } else {
          var c = cfg();
          var d = await ctx.api.get("/api/tossups/random?" + filtersToQuery(c.filters));
          q = d.tossup;
        }
      } catch (e) {}
      if (!q) { phase = "idle"; render(); ctx.toast("Couldn't load a question", "error"); return; }
      clues = splitClues(q.question_sanitized || "");
      shown = 1;
      render();
    }

    function buzz() { if (phase !== "reading") return; ctx.playSound("buzz"); phase = "answering"; render(); }
    function nextClue() {
      if (phase !== "reading") return;
      if (shown >= clues.length) { resolve(false, "(out of clues)", true); return; }
      shown++; render();
    }

    async function submit(answer) {
      var verdict = "reject";
      try {
        // read-position = the characters of the clues shown so far
        var readChars = clues.slice(0, shown).join(" ").length;
        var r = await ctx.api.post("/api/evaluate-tossup", { questionId: q.id, answer: answer, strictness: cfg().strictness || 10, buzzPosition: readChars });
        verdict = r.status;
      } catch (e) {}
      resolve(verdict === "accept" || verdict === "prompt", answer || "(no answer)", false);
    }

    function resolve(correct, given, ranOut) {
      var entry = { clue: shown, totalClues: clues.length, correct: correct, ranOut: ranOut,
        answer: (q && (q.answer_sanitized || q.answer)) || "", given: given || "", category: (q && q.category) || "" };
      log.push(entry);
      recordLife(entry);
      recordSession(entry);
      ctx.playSound(correct ? "correct" : "incorrect");
      phase = "result"; q._given = given; q._correct = correct; q._ranOut = ranOut;
      render();
    }

    function summary() {
      var n = log.length; if (!n) return "";
      var corr = log.filter(function (l) { return l.correct; }).length;
      var avg = log.reduce(function (s, l) { return s + l.clue / Math.max(1, l.totalClues); }, 0) / n;
      return n + " questions · " + corr + " correct · avg buzz depth " + Math.round(avg * 100) + "%";
    }

    function render() {
      if (!body) return;
      // Give the borrowed panel back BEFORE innerHTML wipes the body, or the
      // settings menu is detached from the DOM and lost.
      returnPanel();
      var ls = lifeStats();
      var lifeLine = ls.attempts
        ? '<div class="cm-life text-muted">All-time: ' + ls.attempts + " questions \u00b7 " +
          Math.round((ls.correct / ls.attempts) * 100) + "% correct \u00b7 avg depth " +
          Math.round((ls.depthSum / ls.attempts) * 100) + "%</div>"
        : "";
      var head =
        '<div class="cm-top"><span class="pill">' + (log.length ? esc(summary()) : "Buzz Discipline Training") + "</span></div>" + lifeLine;
      function shell(inner) {
        return '<div class="practice-layout cm-layout"><main class="question-area"><div class="cm-wrap">' + head + inner + "</div></main></div>";
      }
      if (phase === "idle") {
        body.innerHTML = shell(
          '<div class="cm-card cm-start"><p><kbd>' + esc(keyLabel("buzz")) + '</kbd> buzz \u00b7 <kbd>' + esc(keyLabel("next")) + '</kbd> next clue</p>' +
          '<button class="btn btn-primary" id="cm-start">[' + esc(keyLabel("start")) + '] Start</button></div>');
        var st = body.querySelector("#cm-start"); if (st) st.onclick = nextQuestion;
        borrowPanel();
        return;
      }
      if (!q) { body.innerHTML = shell('<div class="cm-card text-muted">Loading…</div>'); borrowPanel(); return; }
      var cluesHtml = clues.slice(0, phase === "result" ? clues.length : shown).map(function (c, i) {
        var cur = i === shown - 1 && phase !== "result";
        return '<div class="cm-clue' + (cur ? " cur" : "") + '"><span class="cm-cluenum">' + (i + 1) + "</span>" + esc(c) + "</div>";
      }).join("");
      var controls = "";
      if (phase === "reading") {
        controls = '<div class="cm-actions"><button class="btn btn-primary" id="cm-buzz">[' + esc(keyLabel("buzz")) + '] Buzz</button>' +
          '<button class="btn" id="cm-next-clue">[' + esc(keyLabel("next")) + '] Next clue (' + shown + "/" + clues.length + ")</button></div>";
      } else if (phase === "answering") {
        controls = '<div class="buzz-area"><div class="buzz-prompt"><span class="prompt-symbol">&gt;</span>' +
          '<input type="text" id="cm-input" placeholder="your answer… (Enter)" autocomplete="off" autocorrect="off" spellcheck="false"></div></div>';
      } else if (phase === "result") {
        controls = '<div class="result-area"><div class="result-banner ' + (q._correct ? "correct" : "incorrect") + '">' +
          (q._correct ? "CORRECT on clue " + shown + "/" + clues.length : (q._ranOut ? "OUT OF CLUES" : "INCORRECT on clue " + shown + "/" + clues.length)) + "</div>" +
          '<div class="result-answer">Your answer: <strong>' + esc(q._given) + "</strong><br>Answer: <span style=\"color:var(--green)\">" + ansHtml(q.answer, q.answer_sanitized || "") + "</span></div>" +
          '<div class="result-next"><button class="btn btn-primary" id="cm-next">[' + esc(keyLabel("next")) + '] Next question</button></div></div>';
      }
      body.innerHTML = shell(
        '<div class="cm-card"><div class="cm-meta">' + esc(q.category || "") + (q.subcategory ? " / " + esc(q.subcategory) : "") + " · diff " + esc(q.difficulty != null ? q.difficulty : "?") +
          ' <span class="qb-star" data-qid="' + esc(q.id) + '" data-type="tossup" title="Star this question" style="margin-left:8px">\u2606</span></div>' +
        cluesHtml + controls + "</div>");
      borrowPanel();
      // reflect current star state on the indicator
      (function () {
        var st = body.querySelector(".qb-star");
        if (!st) return;
        ctx.api.get("/api/starred/check?questionId=" + encodeURIComponent(q.id) + "&type=tossup").then(function (d) {
          if (d && d.starred) { st.textContent = "\u2605"; st.classList.add("on"); }
        }).catch(function () {});
      })();
      var bz = body.querySelector("#cm-buzz"); if (bz) bz.onclick = buzz;
      var nc = body.querySelector("#cm-next-clue"); if (nc) nc.onclick = nextClue;
      var nx = body.querySelector("#cm-next"); if (nx) nx.onclick = nextQuestion;
      var inp = body.querySelector("#cm-input");
      if (inp) {
        inp.focus();
        inp.addEventListener("keydown", function (e) { if (e.key === "Enter") { e.preventDefault(); inp.disabled = true; submit(inp.value.trim()); } });
      }
    }

    // Rebindable hotkeys (Settings > Keybinds). Handlers no-op off-page.
    ctx.onHotkey("buzz", function () { if (active() && phase === "reading") buzz(); });
    ctx.onHotkey("next", function () {
      if (!active()) return;
      if (phase === "reading") nextClue();
      else if (phase === "result") nextQuestion();
    });
    ctx.onHotkey("start", function () { if (active() && phase === "idle") nextQuestion(); });
    ctx._cleanup = function () {};

    // Button on the base Starred screen: drill the starred TOSSUPS in Coach Mode.
    if (ctx.registerStarredAction) ctx.registerStarredAction({
      id: "run-coach", label: "▶ Coach",
      run: function (items) {
        var ids = (items || []).filter(function (it) { return it.type === "tossup" && it.question && it.question.id; }).map(function (it) { return it.question.id; });
        if (!ids.length) { ctx.toast("No starred tossups for Coach Mode", "error"); return; }
        ctx.launchQuestions("coach", ids);
      },
    });

    ctx.addCSS(
      // Hide the practice-session controls inside the borrowed panel — Coach
      // Mode only uses the FILTERS (mode/categories/difficulty/year/strictness).
      ".cm-borrowed #sec-mode{display:none}" +

      ".cm-borrowed .filter-section:has(#btn-start-session){display:none}" +
      ".cm-borrowed .filter-section:has(#panel-buzz-timer){display:none}" +
      ".cm-borrowed .filter-section:has(#filter-starred){display:none}" +
      ".cm-borrowed .filter-section:has(#panel-speed-slider){display:none}" +
      ".cm-wrap{max-width:860px;width:100%;margin:0 auto;display:flex;flex-direction:column;gap:14px;padding:18px;align-items:center}" +
      ".cm-top{display:flex;justify-content:center}" +
      ".cm-life{text-align:center;font-size:11px;margin-top:-4px}" +
      // Same fixed size as a flashcard (460px), whatever the question: the
      // card NEVER grows or shrinks; clue overflow scrolls inside it.
      ".cm-card{background:var(--bg-secondary);border:1px solid var(--border);border-radius:var(--radius);padding:22px;display:flex;flex-direction:column;gap:10px;width:100%;box-sizing:border-box;height:460px!important;min-height:0!important;max-height:85vh!important;flex:0 0 auto!important;overflow-y:auto;overflow-x:hidden}" +
      // the start screen is the SAME fixed-size card, content centred in it
      ".cm-start{justify-content:center;align-items:center;text-align:center}" +
      ".cm-meta{font-size:11px;color:var(--text-muted)}" +
      ".cm-clue{display:flex;gap:10px;font-size:14px;line-height:1.7;color:var(--text-secondary)}" +
      ".cm-clue.cur{color:var(--text)}" +
      ".cm-cluenum{flex:0 0 22px;height:22px;display:inline-flex;align-items:center;justify-content:center;font-size:10px;border:1px solid var(--border);border-radius:50%;color:var(--text-muted);margin-top:3px}" +
      ".cm-clue.cur .cm-cluenum{border-color:var(--accent);color:var(--accent)}" +
      ".cm-actions{display:flex;gap:10px;margin-top:6px}" +
      ".cm-sess{border:1px solid var(--border);border-radius:var(--radius);padding:8px 10px;margin-top:6px}" +
      ".cm-sess-head{display:flex;align-items:center;justify-content:space-between;gap:8px;font-size:12px;flex-wrap:wrap}" +
      ".cm-sess-body{margin-top:6px;display:flex;flex-direction:column;gap:4px}"
    );
    // ── STATISTICS screen section ──
    ctx.registerStatsProvider({
      id: "coach-mode",
      title: "Coach Mode",
      render: function renderStats(el) {
        var st = lifeStats();
        if (!st.attempts) { el.innerHTML = '<div class="text-muted" style="font-size:12px">No coach sessions yet \u2014 train buzz discipline from the title menu (Extra).</div>'; return; }
        var acc = Math.round((st.correct / st.attempts) * 100);
        var depth = Math.round((st.depthSum / st.attempts) * 100);
        var html =
          '<div class="stats-grid">' +
            '<div class="stat-card"><div class="stat-card-value">' + st.attempts + '</div><div class="stat-card-label">Questions</div></div>' +
            '<div class="stat-card"><div class="stat-card-value">' + acc + '%</div><div class="stat-card-label">Correct</div></div>' +
            '<div class="stat-card"><div class="stat-card-value">' + depth + '%</div><div class="stat-card-label">Avg Buzz Depth</div></div>' +
            '<div class="stat-card"><div class="stat-card-value">' + st.ranOut + '</div><div class="stat-card-label">Out of Clues</div></div>' +
          "</div>";
        // how deep into the question you buzz, as bars
        var keys = ["0-20%", "20-40%", "40-60%", "60-80%", "80-100%"].filter(function (k) { return st.byDepth[k]; });
        if (keys.length) {
          var max = Math.max.apply(null, keys.map(function (k) { return st.byDepth[k]; }));
          html += '<table class="stats-table" style="margin-top:10px"><thead><tr><th>Buzzed at depth</th><th>Count</th><th></th></tr></thead><tbody>' +
            keys.map(function (k) {
              return "<tr><td>" + k + "</td><td>" + st.byDepth[k] + '</td><td><div class="stats-bar"><div class="stats-bar-fill" style="width:' + Math.max(4, (st.byDepth[k] / max) * 100) + '%"></div></div></td></tr>';
            }).join("") + "</tbody></table>";
        }
        html += sessionsHtml();
        el.innerHTML = html;
        wireSessions(el, function () { renderStats(el); });
      },
    });

    ctx.toast("Coach Mode enabled — open it from the title menu (Extra).");
  },
  onDisable: function (ctx) { if (ctx._cleanup) ctx._cleanup(); },
});
