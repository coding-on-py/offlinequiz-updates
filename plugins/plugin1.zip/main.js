QB.registerPlugin({
  id: "fact-sheet",
  name: "Fact Sheet",
  version: "1.9.0",
  author: "OfflineQuiz",
  description: "Compiles the most common hints, stories, and associations for any answer — the things you should know when it comes up.",
  onEnable: __qbMain,
});
