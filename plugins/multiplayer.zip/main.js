/**
 * OfflineQuiz plugin: Multiplayer (full page)
 *
 * A page laid out IDENTICALLY to Tossups practice (it reuses the base app's CSS),
 * wired for a synced lobby. TWO transports:
 *   - RELAY (recommended): paste your relay URL (deploy relay/worker.js to
 *     Cloudflare once — see relay/README.md). Every player makes an ordinary
 *     outbound WebSocket connection, so it works on school Wi-Fi, hotspots,
 *     and anywhere else direct peer-to-peer fails.
 *   - P2P (fallback, blank relay URL): WebRTC via the free PeerJS cloud.
 *     Only works on permissive networks.
 * Reading is clock-synced: the host sends "reading from index I at speed S"
 * once and every client animates locally — buzzes/pauses/results carry the
 * authoritative index, so there's no per-character network traffic.
 *
 * It mirrors practice features: the same reading-speed control (character-by-
 * character at the same ms/char), category + difficulty filters, answer
 * strictness, and a running session history of every question seen with a (#)
 * marker wherever a player buzzed.
 *
 * The first person in a lobby is the HOST: it drives the reading, arbitrates
 * buzzes, checks answers, and broadcasts state. NAQT-style rules: a buzz pauses
 * reading for everyone; a correct answer ends the question; with rebuzzes off a
 * wrong answer locks that player (and their team) out while others may buzz;
 * anyone can pause. Lobby settings are editable by anyone and sync to all.
 *
 * The host can also pick MODE > "Imported packet file" (a Packet Builder
 * export): tossups are read in file order, and with "TU + bonus" each correct
 * tossup earns its bonus — ONLY the player who got the tossup may answer the
 * three parts (everyone sees them; chat stays open for everyone).
 */
QB.registerPlugin({
  id: "multiplayer",
  name: "Multiplayer",
  version: "8.13.0",
  author: "OfflineQuiz",
  description: "Play together over a relay (works on any network) or P2P: full practice feature set, imported packets, and winner-only bonuses after every question.",
  hotkeys: [{ id: "chat", label: "Focus chat", default: "Enter" }],
  onEnable: __qbMain,
  onDisable(ctx) { if (ctx._cleanup) ctx._cleanup(); },
});
