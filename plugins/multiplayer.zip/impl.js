function __qbMain(ctx) {
    var PEERJS_URL = "https://unpkg.com/peerjs@1.5.4/dist/peerjs.min.js";
    var peer = null, isHost = false, conns = [], hostConn = null, myId = "";
    var ws = null, useRelay = false, _relayConns = {};
    // Baked-in relay — every game goes through it; users configure nothing.
    var DEFAULT_RELAY = "https://offlinequiz-mp-relay.warren2028045.workers.dev";
    function relayUrl() { return DEFAULT_RELAY; }
    var lobby = "", myName = "", body = null, page = null;
    var mySpec = false;  // joined as spectator (watch + chat, no buzzing)
    function myAv() { try { return ((ctx.host && ctx.host.getState && ctx.host.getState()) || {}).avatar || ""; } catch (e) { return ""; } }

    // Shared game state (host is the source of truth; clients mirror it).
    var players = {};            // id -> { id, name, team, score }
    var order = [];              // id order for stable display
    // MP-specific lobby settings (synced, anyone can edit). All the question
    // FILTERS (categories+weights, difficulties, year range, strictness, reading
    // speed, etc.) are reused from the host's Tossups Practice page via
    // ctx.host.getPracticeConfig() — multiplayer inherits every practice option.
    var settings = { answerSeconds: 10, buzzWindow: 10, rebuzz: false };
    var filterSummary = "";      // host's practice-filter summary, synced for display
    var curRevealSpeed = 25, curStrictness = 10;  // captured from practice per question
    var hostLocalSpeed = null;   // host's OWN slider value — client speed edits must not be reverted by it
    var current = null;          // { id, text } current question (char-based reveal)
    var hostQ = null;            // host-only full question object
    var mpSessId = "";           // this client's local stats session for the current game
    function mpSession() { if (!mpSessId) mpSessId = "mp-" + (lobby || "game") + "-" + Date.now(); return mpSessId; }
    // Bonus phase (imported TU+B packets): only the tossup winner answers.
    var bonusState = null;       // host-only { winner, k, got }
    var bonusParts = [], bonusAnswers = [], bonusRawAnswers = [];  // host-only
    var bonusView = null;        // everyone: { leadin, parts, winner, name, k, got, done, results[] }
    var bonusTimer = null;
    var bonusPending = false;    // a random bonus is being fetched after a correct TU
    var roomConfig = null;       // shared question filters (anyone can edit)
    var locked = false;          // host-only: when on, new players can't join
    var leftIntentionally = false;
    var curFilters = {};         // filters used for the current tossup (so the bonus matches)
    var curPowerEnd = 0, curStopPower = false, pausedAtPower = false;
    var revealIdx = 0, revealTimer = null;   // revealIdx = character index
    var ended = false, pendingBuzzer = null, answerTimer = null, answerDeadline = 0, tickTimer = null, pendingPrompted = false;
    var lockedTeams = {}, lockedIds = {};   // per-question lockouts
    var buzzHistory = [];        // per-question [{name, correct, points, given, index}]
    var buzzCharMarks = [];      // character indices where a buzz happened (for (#) marks)
    var sessionLog = [];         // all completed questions: {text, answer, category, difficulty, buzzes[], marks[]}
    var paused = false, qCount = 0;
    var borrowedPanel = null, panelHome = null;   // the borrowed practice filter panel

    // Build a /api/tossups/random query from a practice getActiveFilters() object.
    function filtersToQuery(f) {
      f = f || {};
      var p = ["random=1", "limit=1"];
      if (f.standard) p.push("standard=1");
      if (f.categories && f.categories.length) p.push("categories=" + encodeURIComponent(f.categories.join(",")));
      if (f.subcategories && f.subcategories.length) p.push("subcategories=" + encodeURIComponent(f.subcategories.join(",")));
      if (f.alternateSubcategories && f.alternateSubcategories.length) p.push("alternateSubcategories=" + encodeURIComponent(f.alternateSubcategories.join(",")));
      if (f.difficulties && f.difficulties.length) p.push("difficulties=" + f.difficulties.join(","));
      if (f.setNames && f.setNames.length) p.push("setNames=" + encodeURIComponent(f.setNames.join(",")));
      if (f.packetNumbers && f.packetNumbers.length) p.push("packetNumbers=" + f.packetNumbers.join(","));
      if (f.yearMin != null) p.push("yearMin=" + f.yearMin);
      if (f.yearMax != null) p.push("yearMax=" + f.yearMax);
      if (f.powermarkOnly) p.push("powermarkOnly=true");
      // (starred-only is intentionally NOT used in multiplayer)
      return p.join("&");
    }

    function esc(s) { return (s == null ? "" : String(s)).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"); }
    // Answer lines keep their real <b>/<u> formatting (everything else escaped).
    function ansHtml(raw, fallback) {
      var src = (raw && String(raw).trim()) ? String(raw) : String(fallback || "");
      var html = esc(src).replace(/&lt;(\/?)(b|u|i|em|strong)&gt;/gi, "<$1$2>");
      // auto-close unbalanced tags so a stray <u> can't underline the page
      var d = document.createElement("div");
      d.innerHTML = html;
      return d.innerHTML;
    }
    function lobbyId(n) { return "offlinequiz-mp-" + n.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, ""); }
    function loadPeer() {
      return new Promise(function (res, rej) {
        if (window.Peer) return res();
        var s = document.createElement("script"); s.src = PEERJS_URL;
        s.onload = function () { window.Peer ? res() : rej(new Error("PeerJS failed to load")); };
        s.onerror = function () { rej(new Error("Couldn't load PeerJS (need internet)")); };
        document.head.appendChild(s);
      });
    }

    // ── page (mirrors the practice screen) ──
    page = ctx.registerPage({
      id: "lobby", navLabel: "Multiplayer", title: "MULTIPLAYER",
      onShow: function (el) { body = el; el.classList.add("mp-flush"); render(); }, onHide: function () { returnPanel(); },
    });
    function active() { return page && page.screenEl && page.screenEl.classList.contains("active"); }
    // Safety net: whenever we navigate away from the MP page, give the borrowed
    // practice filter panel back so the Tossups screen is never left without it.
    ctx.on("screen:change", function () { setTimeout(function () { if (!active()) returnPanel(); }, 0); });

    ctx.onHotkey("chat", function () { if (!active()) return; var ci = body && body.querySelector("#mp-chat-input"); if (ci) ci.focus(); });

    // The borrowed practice panel hides its practice-only sections in MP.

    function onKey(e) {
      if (!active() || !lobby) return;
      var t = e.target.tagName; if (t === "INPUT" || t === "TEXTAREA") return;
      if (e.code === "Space") { e.preventDefault(); requestBuzz(); }
      else if (e.key === "p" || e.key === "P") { e.preventDefault(); requestPause(); }
      else if (e.key === "n" || e.key === "N" || e.key === "s" || e.key === "S") { e.preventDefault(); requestNext(); }
    }
    document.addEventListener("keydown", onKey);
    ctx._cleanup = function () { returnPanel(); document.removeEventListener("keydown", onKey); stopReveal(); stopAnswerTimer(); stopTick(); stopBuzzWindowTimer(); stopBonusTimer(); stopClientRead(); try { if (peer) peer.destroy(); } catch (e) {} try { if (ws) ws.close(); } catch (e) {} };

    // ── networking helpers (transport-agnostic) ──
    function sendRelay(o) { if (ws && ws.readyState === 1) { try { ws.send(JSON.stringify(o)); } catch (e) {} } }
    function broadcast(m) {
      if (useRelay) { sendRelay({ to: "all", d: m }); return; }
      conns.forEach(function (c) { try { c.send(m); } catch (e) {} });
    }
    function toHost(m) {
      if (useRelay) { sendRelay({ to: "host", d: m }); return; }
      if (hostConn) { try { hostConn.send(m); } catch (e) {} }
    }
    // A conn-shaped wrapper so the host code paths work identically on relay.
    function relayConn(id) {
      if (!_relayConns[id]) _relayConns[id] = { peer: id, send: function (d) { sendRelay({ to: id, d: d }); } };
      return _relayConns[id];
    }
    function stateMsg() { return { t: "state", players: order.map(function (id) { return players[id]; }), settings: settings, filterSummary: filterSummary, roomFilters: (roomConfig && roomConfig.filters) || null }; }
    function pushState() { broadcast(stateMsg()); renderScores(); renderSettings(); updateTopBar(); }

    function addPlayer(id, name, team, spec, avatar) {
      if (!players[id]) order.push(id);
      players[id] = { id: id, name: name || ("Player" + order.length), team: team || "", score: (players[id] && players[id].score) || 0, spec: !!spec, avatar: avatar || (players[id] && players[id].avatar) || "" };
    }
    function removePlayer(id) { delete players[id]; order = order.filter(function (x) { return x !== id; }); }

    // A visible banner when YOUR connection drops mid-game (lag-out).
    function showDisconnected() {
      var area = body && body.querySelector(".question-area");
      if (!area) { setStatus("Disconnected from the lobby."); return; }
      var existing = body.querySelector("#mp-disconnect"); if (existing) return;
      var el = document.createElement("div");
      el.id = "mp-disconnect"; el.className = "mp-disconnect";
      el.innerHTML = '<div class="mp-disc-box"><div class="mp-disc-title">\u26a0 Disconnected from the lobby</div>' +
        '<div class="text-muted" style="font-size:12px">You lost connection (lag or network drop).</div>' +
        '<div class="mp-disc-actions"><button class="btn btn-primary" id="mp-rejoin">Rejoin</button>' +
        '<button class="btn btn-ghost" id="mp-discleave">Leave</button></div></div>';
      area.appendChild(el);
      el.querySelector("#mp-rejoin").onclick = function () { el.remove(); isHost = false; join(); };
      el.querySelector("#mp-discleave").onclick = function () { el.remove(); leave(); };
    }

    // ── join ──
    var ROOM_DEFAULTS = { answerSeconds: 10, buzzWindow: 10, rebuzz: false, bonusEvery: false };
    async function join() {
      // Every room starts from the SAME defaults — nothing carries over from a
      // previous room, and a reopened room starts fresh too.
      settings = { answerSeconds: ROOM_DEFAULTS.answerSeconds, buzzWindow: ROOM_DEFAULTS.buzzWindow, rebuzz: ROOM_DEFAULTS.rebuzz, bonusEvery: ROOM_DEFAULTS.bonusEvery };
      // Packet/set reading never carries across lobbies — always start at q1.
      setSig = ""; setIndex = 0; setQueue = null; impSig = ""; impIndex = 0;
      roomConfig = null; locked = false; leftIntentionally = false;
      // Fresh log: on (re)join the host replays every entry, so keeping the old
      // list would duplicate the entire session history.
      sessionLog = []; logCollapsed = {};
      var relay = relayUrl();
      useRelay = !!relay && !ctx.getSetting("p2p"); // P2P opt-in skips the relay
      if (useRelay) { joinRelay(relay); return; }
      setStatus("Connecting…");
      try { await loadPeer(); } catch (e) { setStatus(e.message); return; }
      var id = lobbyId(lobby);
      peer = new window.Peer(id);
      peer.on("open", function (pid) {
        isHost = true; myId = pid;
        // New room ⇒ default question filters (mode random, no categories,
        // diff 2-5, speed 50ms, strictness 20, powermark on, 2010-2026 …).
        try { if (ctx.host && ctx.host.resetPracticeFilters) ctx.host.resetPracticeFilters(); } catch (e) {}
        addPlayer(myId, myName, "", mySpec, myAv());
        peer.on("connection", onHostConn);
        sysChat(myName + " created the lobby");
        render();
      });
      peer.on("error", function (err) { if (err && err.type === "unavailable-id") { peer.destroy(); becomeClient(id); } else setStatus("Error: " + (err && err.type || err)); });
    }
    // ── relay transport: one outbound WebSocket per player ──
    function joinRelay(relay) {
      setStatus("Connecting to relay…");
      var base = relay.replace(/\/+$/, "");
      if (/^https?:/i.test(base)) base = base.replace(/^http/i, "ws").replace(/^HTTPS/i, "wss");
      if (!/^wss?:/i.test(base)) base = "wss://" + base;
      var sock;
      try { sock = new WebSocket(base + "/lobby/" + encodeURIComponent(lobbyId(lobby))); }
      catch (e) { setStatus("Bad relay URL."); return; }
      ws = sock;
      var opened = false;
      sock.onmessage = function (ev) {
        var m; try { m = JSON.parse(ev.data); } catch (e) { return; }
        if (m.t === "welcome") {
          opened = true;
          myId = m.id; isHost = !!m.host;
          if (isHost) {
            try { if (ctx.host && ctx.host.resetPracticeFilters) ctx.host.resetPracticeFilters(); } catch (e) {}
            addPlayer(myId, myName, "", mySpec, myAv());
            sysChat(myName + " created the lobby");
          } else {
            toHost({ t: "hello", name: myName, spectate: mySpec, avatar: myAv() });
          }
          render();
          return;
        }
        if (m.t === "msg") {
          if (isHost) onHostData(relayConn(m.from), m.d);
          else if (m.host) onClientData(m.d);   // clients only trust the host
          return;
        }
        if (m.t === "peerleft") { if (isHost) hostPeerGone(m.id); return; }
        if (m.t === "hostleft") { setStatus("Host left \u2014 lobby closed."); }
      };
      sock.onclose = function () {
        if (!opened) setStatus("Couldn't reach the relay \u2014 check the URL (and that the worker is deployed).");
        else if (!leftIntentionally && lobby) showDisconnected();
        if (ws === sock) ws = null;
      };
      sock.onerror = function () { if (!opened) setStatus("Couldn't reach the relay \u2014 check the URL."); };
    }

    function becomeClient(hostId) {
      isHost = false; peer = new window.Peer();
      peer.on("open", function (pid) {
        myId = pid;
        hostConn = peer.connect(hostId, { reliable: true });
        hostConn.on("open", function () { hostConn.send({ t: "hello", name: myName, spectate: mySpec, avatar: myAv() }); render(); });
        hostConn.on("data", onClientData);
        hostConn.on("close", function () { setStatus("Host left — lobby closed."); });
      });
      peer.on("error", function (err) { setStatus("Error: " + (err && err.type || err)); });
    }
    function onHostConn(conn) {
      conn.on("open", function () { conns.push(conn); });
      conn.on("data", function (d) { onHostData(conn, d); });
      conn.on("close", function () {
        conns = conns.filter(function (c) { return c !== conn; });
        hostPeerGone(conn.peer);
      });
    }

    // A player left (either transport): keep their seat and score so a rejoin
    // under the same name continues where they left off; abandon their bonus.
    function hostPeerGone(id) {
      var p = players[id];
      if (p && !p.off) { p.off = true; sysChat(p.name + " disconnected \u2014 seat and score saved"); pushState(); }
      if (bonusState && id === bonusState.winner) {
        bonusState = null; stopBonusTimer();
        sysChat("Bonus abandoned \u2014 the answerer left.");
        broadcast({ t: "bcancel" }); applyBonusCancel();
      }
    }

    // ── host: handle messages from clients ──
    function onHostData(conn, d) {
      var id = conn.peer;
      if (d.t === "hello") {
        if (locked) { try { conn.send({ t: "locked" }); } catch (e) {} return; }
        // Same name = same person, but only an OFFLINE seat can be reclaimed:
        // never the host's own entry, never a connected player's (a live name
        // collision gets a numbered name instead of stealing the seat).
        var wantName = String(d.name || "").trim().toLowerCase();
        var sameName = function (x) { return x !== id && x !== myId && players[x] && String(players[x].name).trim().toLowerCase() === wantName; };
        var oldId = wantName ? order.find(function (x) { return sameName(x) && players[x].off; }) : null;
        if (oldId) {
          var seat = players[oldId];
          delete players[oldId];
          order[order.indexOf(oldId)] = id;
          seat.id = id;
          seat.off = false;
          seat.spec = !!d.spectate;
          if (d.avatar) seat.avatar = d.avatar;
          players[id] = seat;
          if (bonusState && bonusState.winner === oldId) bonusState.winner = id;
          if (pendingBuzzer === oldId) pendingBuzzer = id;
          if (lockedIds[oldId]) { lockedIds[id] = lockedIds[oldId]; delete lockedIds[oldId]; }
          sysChat(seat.name + " rejoined");
        } else {
          var joinName = String(d.name || "").trim();
          var hostClash = joinName && players[myId] && String(players[myId].name).trim().toLowerCase() === wantName;
          if (joinName && (hostClash || order.some(sameName))) {
            var base = joinName, n = 2;
            var taken = function (nm) {
              var low = nm.trim().toLowerCase();
              return order.some(function (x) { return x !== id && players[x] && String(players[x].name).trim().toLowerCase() === low; });
            };
            while (taken(base + " (" + n + ")")) n++;
            joinName = base + " (" + n + ")";
          }
          addPlayer(id, joinName || d.name, "", d.spectate, d.avatar);
          sysChat(players[id].name + " joined" + (d.spectate ? " (spectating)" : ""));
        }
        pushState();
        // bring the newcomer up to speed
        sessionLog.forEach(function (e) { conn.send({ t: "logentry", entry: e }); });
        if (current) {
          conn.send(questionMsg());
          var reading = !paused && !pendingBuzzer && !ended && revealIdx < current.text.length;
          conn.send({ t: "read", from: revealIdx, speed: reading ? Math.max(8, curRevealSpeed) : 0 });
          // A bonus is in progress — replay it (and its judged parts) so the
          // newcomer sees the bonus UI, not a frozen tossup.
          if (bonusState && bonusView) {
            conn.send({ t: "bonus", leadin: bonusView.leadin, parts: bonusView.parts, winner: bonusView.winner, name: bonusView.name, secs: settings.answerSeconds || 10 });
            (bonusView.results || []).forEach(function (rp) { if (rp) conn.send(rp); });
          }
        }
      }
      else if (d.t === "chat") { relayChat(players[id] ? players[id].name : "?", d.text); }
      else if (d.t === "setName") { if (players[id]) { var old = players[id].name; players[id].name = d.name || old; sysChat(old + " is now " + players[id].name); pushState(); } }
      else if (d.t === "setTeam") { if (players[id]) { players[id].team = d.team || ""; pushState(); } }
      else if (d.t === "setSetting") { settings[d.key] = d.val; sysChat((players[id] ? players[id].name : "?") + " " + describeSetting(d.key, d.val)); pushState(); }
      else if (d.t === "setConfig") { if (d.config) { roomConfig = roomConfig || {}; ["filters", "strictness", "revealSpeed", "hidePron", "filterSummary"].forEach(function (k) { if (d.config[k] !== undefined) roomConfig[k] = d.config[k]; }); if (d.config.filterSummary != null) filterSummary = d.config.filterSummary; } if (d.change) sysChat((players[id] ? players[id].name : "?") + " " + d.change); broadcast(stateMsg()); renderFilterSummary(); }
      else if (d.t === "buzz") { hostHandleBuzz(id); }
      else if (d.t === "answer") { if (id === pendingBuzzer) hostHandleAnswer(id, d.text); }
      else if (d.t === "reqNext") { if (!players[id] || players[id].spec) return; hostNext(players[id].name); }
      else if (d.t === "banswer") { if (bonusState && id === bonusState.winner) hostHandleBonusAnswer(id, d.text); }
      else if (d.t === "pause") { hostTogglePause(id); }
    }

    // ── host: game flow ──
    function questionMsg() { return { t: "question", q: { id: current.id, text: current.text }, count: qCount }; }

    // "Select set by name" mode → serve the packet's tossups in order (1, 2, …).
    var setQueue = null, setIndex = 0, setSig = "";
    async function nextSetQuestion(f) {
      var sig = (f.setNames || []).join("|") + "::" + (f.packetNumbers || []).join(",");
      if (sig !== setSig) {
        setSig = sig; setIndex = 0; setQueue = [];
        var setName = f.setNames[0];
        var packets = f.packetNumbers && f.packetNumbers.length ? f.packetNumbers : null;
        if (!packets) {
          try { packets = ((await ctx.api.get("/api/packets-for-set?setName=" + encodeURIComponent(setName))).packets || []).map(function (p) { return p.packet_number; }); } catch (e) { packets = []; }
        }
        for (var i = 0; i < packets.length; i++) {
          try { var pc = await ctx.api.get("/api/packet-content?setName=" + encodeURIComponent(setName) + "&packetNumber=" + packets[i]); setQueue = setQueue.concat(pc.tossups || []); } catch (e) {}
        }
      }
      if (!setQueue.length) { setStatus("No questions found in that set."); return null; }
      if (setIndex >= setQueue.length) { setStatus("Packet finished — no more questions."); sysChat("Packet finished — no more questions."); return null; }
      return setQueue[setIndex++];
    }

    // MODE > "Imported packet file" → serve the file's tossups in order; with
    // "TU + bonus" each tossup carries its same-index bonus.
    var impIndex = 0, impSig = "";
    function nextImportQuestion() {
      var pk = (ctx.host && ctx.host.getImportedPacket) ? ctx.host.getImportedPacket() : null;
      if (!pk) { setStatus("Choose a packet file in MODE first (export one from Packet Builder)."); return null; }
      if (!pk.tossups.length) { setStatus("That packet file has no tossups."); return null; }
      var sig = pk.name + "::" + pk.mode + "::" + pk.tossups.length + "/" + pk.bonuses.length;
      if (sig !== impSig) { impSig = sig; impIndex = 0; }
      if (impIndex >= pk.tossups.length) { setStatus("Imported packet finished \u2014 no more tossups."); sysChat("Imported packet finished."); return null; }
      var i = impIndex++;
      var q = Object.assign({}, pk.tossups[i]);
      if (pk.mode === "both" && pk.bonuses[i]) q._mpBonus = pk.bonuses[i];
      filterSummary = "Imported packet: " + pk.name + " (TU " + (i + 1) + "/" + pk.tossups.length + (pk.mode === "both" ? ", with bonuses" : "") + ")";
      return q;
    }

    // Any player may advance: after a question ends it's a plain "next"; mid-
    // question it's a SKIP and only allowed when skips are on (host included).
    function requestNext() {
      if (isHost) { hostNext(); return; }
      toHost({ t: "reqNext" });
    }
    function skipsAllowed() {
      var cfgSkip = (ctx.host && ctx.host.getPracticeConfig) ? ctx.host.getPracticeConfig() : {};
      return !(cfgSkip && cfgSkip.allowSkips === false);
    }
    async function hostNext(byName) {
      if (!isHost || bonusState || bonusPending) return;
      if (current && !ended) {
        if (!skipsAllowed()) { setStatus("Skips are off (OPTIONS) \u2014 finish this question first."); return; }
        if (byName) sysChat(byName + " skipped the question");
      }
      hostFinalize();
      // Reuse the host's Tossups Practice filters + strictness + reading speed.
      var cfg = roomConfig || ((ctx.host && ctx.host.getPracticeConfig) ? ctx.host.getPracticeConfig() : { filters: {}, strictness: 10, revealSpeed: 25, filterSummary: "" });
      curRevealSpeed = cfg.revealSpeed != null ? cfg.revealSpeed : 25;
      curStrictness = cfg.strictness != null ? cfg.strictness : 10;
      curStopPower = !!cfg.stopOnPower;
      filterSummary = cfg.filterSummary || "All categories";
      var f = cfg.filters || {};
      curFilters = f;
      try {
        var q;
        var modeSel = document.getElementById("mode-select");
        if (modeSel && modeSel.value === "import") {
          q = nextImportQuestion();                // imported packet file
          if (!q) return;                          // status already set
        } else if (f.setNames && f.setNames.length) {
          q = await nextSetQuestion(f);           // ordered set mode
          if (!q) return;                          // status already set
        } else {
          var data = await ctx.api.get("/api/tossups/random?" + filtersToQuery(f));
          q = data.tossup;
          if (!q) { setStatus("No question matches your Tossups filters."); return; }
        }
        hostQ = q;
        qCount++;
        var rawText = (q.question_sanitized || q.question || "").replace(/\s+/g, " ").trim();
        if (cfg.hidePron && ctx.host.stripPronunciations) rawText = ctx.host.stripPronunciations(rawText).replace(/\s+/g, " ").trim();
        var pIdx = rawText.indexOf("(*)");
        curPowerEnd = pIdx > 0 ? rawText.slice(0, pIdx).trim().length : 0;
        var text = rawText.split("(*)").join(" ").replace(/\s+/g, " ").trim();
        startQuestion({ id: q.id, text: text });
        broadcast(questionMsg());
        broadcast(stateMsg());            // sync the filter summary
        renderFilterSummary();
        beginReveal();
      } catch (e) { setStatus("Couldn't load question: " + (e.message || e)); }
    }
    function startQuestion(q) {
      current = q; ended = false; pendingBuzzer = null; revealIdx = 0;
      lockedTeams = {}; lockedIds = {}; buzzHistory = []; buzzCharMarks = []; paused = false;
      bonusState = null; bonusView = null; bonusPending = false; pausedAtPower = false;
      stopAnswerTimer(); stopTick(); stopBuzzWindowTimer(); stopReveal(); stopBonusTimer();
      renderQuestion(); renderBuzzes(); updateTopBar();
    }
    var bwTimer = null, bwDeadline = 0;
    function stopBuzzWindowTimer() { if (bwTimer) { clearTimeout(bwTimer); bwTimer = null; } }
    // Question finished reading → everyone gets a buzz window; if nobody
    // buzzes before it runs out, the question goes dead.
    function hostStartBuzzWindow() {
      if (!isHost || ended || pendingBuzzer) return;
      stopBuzzWindowTimer();
      var secs = settings.buzzWindow || 10;
      bwDeadline = Date.now() + secs * 1000;
      broadcast({ t: "buzzwin", secs: secs });
      applyBuzzWindow(bwDeadline);
      bwTimer = setTimeout(function () {
        if (ended || pendingBuzzer) return;
        ended = true;
        var payload = { t: "result", id: "", name: "", correct: false, points: 0, given: "", index: revealIdx, answer: hostQ ? (hostQ.answer_sanitized || "") : "", answerRaw: hostQ ? hostQ.answer : "", history: buzzHistory, ended: true, fullText: current ? current.text : "", noBuzz: true, category: hostQ ? (hostQ.category || "") : "" };
        broadcast(payload); applyResult(payload); pushState();
        stopReveal(); hostFinalize();
      }, secs * 1000);
    }
    function applyBuzzWindow(deadline) {
      var buzz = body && body.querySelector("#mp-buzz"); if (!buzz) return;
      buzz.className = "buzz-area";
      buzz.innerHTML = '<div class="buzz-hints">Question finished \u2014 buzz now! <span id="mp-timer"></span></div><div class="mp-timer-bar"><div id="mp-timer-fill"></div></div>';
      startTick(deadline, (settings.buzzWindow || 10) * 1000);
    }

    // Clock-synced reading: ONE "read" message (start index + speed) and every
    // client animates locally. Buzz/pause/result/buzzwin messages carry the
    // authoritative index, so clients re-sync at every event.
    function beginReveal() {
      stopReveal();
      if (curRevealSpeed === 0) { revealIdx = current.text.length; broadcast({ t: "read", from: revealIdx, speed: 0 }); applyReveal(revealIdx); hostStartBuzzWindow(); return; }
      broadcast({ t: "read", from: revealIdx, speed: Math.max(8, curRevealSpeed) });
      revealTimer = setInterval(function () {
        if (paused || pendingBuzzer || ended) return;
        // Live speed: if the host moves the practice reading-speed slider
        // mid-question, restart (and re-announce) at the new pace immediately.
        try {
          var cfg = ctx.host.getPracticeConfig && ctx.host.getPracticeConfig();
          if (cfg && typeof cfg.stopOnPower === "boolean") curStopPower = cfg.stopOnPower;
          // Restart only when the HOST moves their own slider — comparing
          // against curRevealSpeed would instantly revert a client's speed edit.
          if (cfg && typeof cfg.revealSpeed === "number") {
            if (hostLocalSpeed === null) hostLocalSpeed = cfg.revealSpeed;
            if (cfg.revealSpeed !== hostLocalSpeed) {
              hostLocalSpeed = cfg.revealSpeed;
              curRevealSpeed = cfg.revealSpeed;
              beginReveal();
              return;
            }
          }
        } catch (e) {}
        if (revealIdx >= current.text.length) { stopReveal(); hostStartBuzzWindow(); return; }
        revealIdx = Math.min(current.text.length, revealIdx + 1);
        applyReveal(revealIdx);
        // Stop on power: pause at the power mark (everyone), resume with P.
        if (curStopPower && curPowerEnd > 0 && revealIdx >= curPowerEnd && !pausedAtPower && revealIdx < current.text.length) {
          pausedAtPower = true;
          paused = true;
          sysChat("Stopped at power \u2014 press P to resume");
          broadcast({ t: "pause", paused: true, idx: revealIdx });
          applyPause(true);
        }
      }, Math.max(8, curRevealSpeed));
    }

    // ── client-side reading ticker (driven by the host's "read" message) ──
    var clientReadTimer = null;
    function stopClientRead() { if (clientReadTimer) { clearInterval(clientReadTimer); clientReadTimer = null; } }
    function clientStartRead(from, speed) {
      stopClientRead();
      if (typeof from === "number") revealIdx = from;
      applyReveal(revealIdx);
      if (!current || !speed) return;   // speed 0 ⇒ hold at "from" (instant reveal sends from = full length)
      clientReadTimer = setInterval(function () {
        if (paused || ended || !current) return;
        if (revealIdx >= current.text.length) { stopClientRead(); return; }
        revealIdx++;
        applyReveal(revealIdx);
      }, Math.max(8, speed));
    }
    function stopReveal() { if (revealTimer) { clearInterval(revealTimer); revealTimer = null; } }

    function hostHandleBuzz(id) {
      if (!current || ended || pendingBuzzer || paused) return;
      var p = players[id]; if (!p) return;
      if (p.spec) return; // spectators never buzz
      if (lockedIds[id]) return;
      if (p.team && lockedTeams[p.team]) return;
      pendingBuzzer = id;
      pendingPrompted = false;
      stopReveal();
      stopBuzzWindowTimer();
      var secs = settings.answerSeconds || 10;
      answerDeadline = Date.now() + secs * 1000;
      // Send REMAINING SECONDS (not an absolute timestamp) so clients compute
      // the deadline on their own clock — clock skew between machines would
      // otherwise make the countdown show 0 or a wrong number.
      broadcast({ t: "buzz", id: id, name: p.name, index: revealIdx, secs: secs });
      applyBuzz(id, p.name, revealIdx, answerDeadline);
      startAnswerTimer();
    }
    function startAnswerTimer() { if (answerTimer) clearTimeout(answerTimer); answerTimer = setTimeout(function () { if (pendingBuzzer) hostHandleAnswer(pendingBuzzer, ""); }, (settings.answerSeconds || 10) * 1000); }
    function stopAnswerTimer() { if (answerTimer) { clearTimeout(answerTimer); answerTimer = null; } }
    function stopTick() { if (tickTimer) { clearInterval(tickTimer); tickTimer = null; } }

    async function hostHandleAnswer(id, text) {
      if (id !== pendingBuzzer) return;
      stopAnswerTimer();
      var p = players[id]; if (!p) { pendingBuzzer = null; return; }
      var res;
      try {
        res = await ctx.api.post("/api/check-tossup", { questionId: hostQ.id, answer: text, buzzPosition: revealIdx, fullyRead: revealIdx >= current.text.length, strictness: curStrictness || 10, allowPrompt: !pendingPrompted, record: false });
      } catch (e) { res = { correct: false, points: 0, answer: hostQ.answer_sanitized }; }
      // Prompt: ask the same player to be more specific (one prompt per buzz).
      if (res && res.prompted && !pendingPrompted) {
        pendingPrompted = true;
        var ask = (res.prompt && res.prompt.ask) || "";
        var psecs = settings.answerSeconds || 10;
        answerDeadline = Date.now() + psecs * 1000; // fresh window for the prompt
        sysChat(p.name + " was prompted");
        broadcast({ t: "prompt", id: id, name: p.name, ask: ask, secs: psecs });
        applyPrompt(id, p.name, ask, answerDeadline);
        startAnswerTimer();
        return;
      }
      var correct = !!res.correct, points = res.points || 0;
      p.score = (p.score || 0) + points;
      buzzHistory.push({ name: p.name, correct: correct, points: points, given: text, index: revealIdx });
      pendingBuzzer = null;
      if (!correct && !settings.rebuzz) { if (p.team) lockedTeams[p.team] = true; else lockedIds[id] = true; }
      // With rebuzzes off, if everyone is now locked out, end the question.
      var deadEnd = !correct && !settings.rebuzz && allLockedOut();
      var payload = { t: "result", id: id, name: p.name, correct: correct, points: points, given: text, index: revealIdx, answer: res.answer || hostQ.answer_sanitized, answerRaw: hostQ.answer || "", history: buzzHistory };
      if (correct || deadEnd) { ended = true; payload.ended = true; payload.fullText = current.text; payload.category = hostQ ? (hostQ.category || "") : ""; }
      broadcast(payload); applyResult(payload); pushState();
      if (ended) {
        stopReveal(); hostFinalize();
        if (correct) maybeStartBonus(id);
      }
      else if (current && revealIdx >= current.text.length) { hostStartBuzzWindow(); }
      else { broadcast({ t: "reading" }); beginReveal(); }
    }

    // ── bonus phase (host): ONLY the tossup winner answers; all watch ──
    // Decide whether a bonus follows this (correct) tossup, and on what.
    function maybeStartBonus(winnerId) {
      // Imported "TU + bonus" packets already pair a bonus to the tossup.
      if (hostQ && hostQ._mpBonus) { hostStartBonus(winnerId); return; }
      if (!settings.bonusEvery) return;
      // Otherwise draw a random bonus matching the same filters as the tossup.
      bonusPending = true;
      ctx.api.get("/api/bonuses/random?" + bonusQueryForTossup()).then(function (data) {
        bonusPending = false;
        var b = data && data.bonus;
        // Still on the same (ended) question, and nobody advanced meanwhile?
        if (b && hostQ && ended && !bonusState) { hostQ._mpBonus = b; hostStartBonus(winnerId); }
        else if (!b) sysChat("No bonus matched the filters \u2014 skipping.");
      }).catch(function () { bonusPending = false; });
    }
    // A random bonus that genuinely matches the served tossup: same category
    // (and difficulty when known), regardless of how the tossup was picked.
    function bonusQueryForTossup() {
      var parts = ["random=1", "limit=1"];
      if (hostQ && hostQ.category) parts.push("categories=" + encodeURIComponent(hostQ.category));
      if (hostQ && hostQ.difficulty != null && hostQ.difficulty !== "") parts.push("difficulties=" + hostQ.difficulty);
      return parts.join("&");
    }
    function stopBonusTimer() { if (bonusTimer) { clearTimeout(bonusTimer); bonusTimer = null; } }
    function startBonusTimer() {
      stopBonusTimer();
      bonusTimer = setTimeout(function () { if (bonusState) hostHandleBonusAnswer(bonusState.winner, ""); }, (settings.answerSeconds || 10) * 1000);
    }
    function hostStartBonus(winnerId) {
      var b = hostQ._mpBonus, p = players[winnerId];
      if (!b || !p) return;
      bonusParts = []; bonusAnswers = []; bonusRawAnswers = [];
      try { bonusParts = JSON.parse(b.parts_sanitized || "[]"); } catch (e) {}
      try { bonusAnswers = JSON.parse(b.answers_sanitized || "[]"); } catch (e) {}
      try { bonusRawAnswers = JSON.parse(b.answers || "[]"); } catch (e) {}
      if (!bonusParts.length) return;
      bonusState = { winner: winnerId, k: 0, got: 0 };
      sysChat(p.name + " earned the bonus");
      var msg = { t: "bonus", leadin: b.leadin_sanitized || "", parts: bonusParts, winner: winnerId, name: p.name, secs: settings.answerSeconds || 10 };
      broadcast(msg); applyBonus(msg);
      startBonusTimer();
    }
    async function hostHandleBonusAnswer(id, text) {
      if (!bonusState || id !== bonusState.winner || bonusState.judging) return;
      stopBonusTimer();
      var k = bonusState.k;
      bonusState.judging = true;   // re-entrancy guard across the await
      var ok = false;
      try {
        var r = await ctx.api.post("/api/evaluate-answer", { answerline: bonusRawAnswers[k] || "", sanitized: bonusAnswers[k] || "", answer: text, strictness: curStrictness || 10 });
        ok = r.status === "accept" || r.status === "prompt";
      } catch (e) {}
      // The winner may have left, the bonus may have been cancelled, or a new
      // question may have started during the await — bail if state moved on.
      if (!bonusState || bonusState.winner !== id || bonusState.k !== k) return;
      bonusState.judging = false;
      var p = players[id];
      if (ok && p) { bonusState.got++; p.score = (p.score || 0) + 10; }
      var done = k + 1 >= bonusParts.length;
      bonusState.k++;
      var msg = { t: "bpart", k: k, ok: ok, given: text, answer: bonusAnswers[k] || "", answerRaw: bonusRawAnswers[k] || "", done: done, got: bonusState.got, secs: settings.answerSeconds || 10 };
      broadcast(msg); applyBonusPart(msg); pushState();
      if (done) { sysChat((p ? p.name : "?") + " bonus: " + (bonusState.got * 10) + "/" + (bonusParts.length * 10)); bonusState = null; }
      else startBonusTimer();
    }
    function allLockedOut() {
      var active = order.filter(function (id) { return players[id] && !players[id].spec && !players[id].off; });
      return active.length > 0 && active.every(function (id) {
        var p = players[id];
        return lockedIds[id] || (p && p.team && lockedTeams[p.team]);
      });
    }
    function hostTogglePause(who) {
      if (bonusState || bonusPending) { return; }   // no pausing during a bonus
      paused = !paused;
      var nm = (players[who] && players[who].name) || (who === myId ? myName : "Someone");
      sysChat(nm + (paused ? " paused the game" : " resumed the game"));
      broadcast({ t: "pause", paused: paused, idx: revealIdx }); applyPause(paused);
      if (!paused && !pendingBuzzer && !ended) beginReveal();
    }
    function describeSetting(key, val) {
      var label = key === "answerSeconds" ? "Answer Time" : key === "buzzWindow" ? "Buzz Window" : key === "rebuzz" ? "Rebuzzes" : key === "bonusEvery" ? "Bonus after every question" : key;
      return "changed " + label + " to " + val;
    }

    // Finalize the current question into the shared session log (host only).
    function hostFinalize() {
      if (!isHost || !current || current._logged) return;
      current._logged = true;
      var entry = {
        qid: (hostQ && hostQ.id) || (current && current.id) || "",
        text: current.text,
        answer: (hostQ && (hostQ.answer_sanitized || hostQ.answer)) || "",
        answerRaw: (hostQ && hostQ.answer) || "",
        category: (hostQ && hostQ.category) || "",
        difficulty: (hostQ && hostQ.difficulty) != null ? hostQ.difficulty : "",
        buzzes: buzzHistory.slice(),
        marks: buzzCharMarks.slice(),
      };
      sessionLog.push(entry); broadcast({ t: "logentry", entry: entry }); renderSessionLog();
    }

    // ── client: handle messages from host ──
    function onClientData(d) {
      if (d.t === "state") { players = {}; order = []; (d.players || []).forEach(function (p) { players[p.id] = p; order.push(p.id); }); settings = d.settings || settings; if (d.filterSummary != null) filterSummary = d.filterSummary; if (d.roomFilters) applyRoomFiltersToPanel(d.roomFilters); renderScores(); renderSettings(); renderFilterSummary(); updateTopBar(); }
      else if (d.t === "chat") { addChat(d.name, d.text, d.sys); }
      else if (d.t === "question") { stopClientRead(); current = d.q; if (typeof d.count === "number") qCount = d.count; ended = false; pendingBuzzer = null; revealIdx = 0; buzzHistory = []; buzzCharMarks = []; paused = false; bonusView = null; renderQuestion(); renderBuzzes(); updateTopBar(); }
      else if (d.t === "read") { clientStartRead(d.from, d.speed); }
      else if (d.t === "reveal") { revealIdx = d.index; applyReveal(d.index); }  // legacy hosts
      else if (d.t === "buzz") { stopClientRead(); if (typeof d.index === "number") { revealIdx = d.index; applyReveal(revealIdx); } answerDeadline = Date.now() + ((d.secs || settings.answerSeconds || 10) * 1000); applyBuzz(d.id, d.name, d.index, answerDeadline); }
      else if (d.t === "buzzwin") { stopClientRead(); if (current) { revealIdx = current.text.length; applyReveal(revealIdx); } applyBuzzWindow(Date.now() + ((d.secs || settings.buzzWindow || 10) * 1000)); }
      else if (d.t === "result") { stopClientRead(); if (typeof d.index === "number" && !d.ended) revealIdx = d.index; buzzHistory = d.history || buzzHistory; if (d.ended) ended = true; applyResult(d); renderBuzzes(); }
      else if (d.t === "reading") { /* the host's "read" message restarts the local ticker */ }
      else if (d.t === "pause") { paused = d.paused; if (typeof d.idx === "number") { revealIdx = d.idx; applyReveal(revealIdx); } applyPause(d.paused); }
      else if (d.t === "prompt") { answerDeadline = Date.now() + ((d.secs || settings.answerSeconds || 10) * 1000); applyPrompt(d.id, d.name, d.ask, answerDeadline); }
      else if (d.t === "logentry") { sessionLog.push(d.entry); renderSessionLog(); }
      else if (d.t === "locked") { leftIntentionally = true; setStatus("That lobby is locked \u2014 ask the host to unlock it."); ctx.toast("Lobby is locked", "error"); leave(); }
      else if (d.t === "config") { if (d.config) { filterSummary = d.config.filterSummary || filterSummary; } renderFilterSummary(); }
      else if (d.t === "bonus") { applyBonus(d); }
      else if (d.t === "bpart") { applyBonusPart(d); }
      else if (d.t === "bcancel") { applyBonusCancel(); }
    }

    // ── local actions (sent to host or handled if host) ──
    function requestBuzz() {
      if (!current || ended) return;
      if (players[myId] && players[myId].spec) { ctx.toast("You're spectating \u2014 no buzzing", "error"); return; }
      ctx.playSound("buzz");
      if (isHost) hostHandleBuzz(myId); else toHost({ t: "buzz" });
    }
    function requestPause() { if (isHost) hostTogglePause(myId); else toHost({ t: "pause" }); }
    function submitAnswer(text) { if (isHost) hostHandleAnswer(myId, text); else toHost({ t: "answer", text: text }); }
    function changeName(name) { myName = name; try { ctx.setSetting("name", name); } catch (e) {} if (isHost) { var old = players[myId].name; players[myId].name = name; sysChat(old + " is now " + name); pushState(); } else toHost({ t: "setName", name: name }); }
    function changeTeam(team) { if (isHost) { players[myId].team = team; pushState(); } else toHost({ t: "setTeam", team: team }); }
    function changeSetting(key, val) { settings[key] = val; if (isHost) { sysChat(myName + " " + describeSetting(key, val)); pushState(); } else toHost({ t: "setSetting", key: key, val: val }); renderSettings(); }
    function sendChat(text) { if (!text) return; if (isHost) relayChat(myName, text); else toHost({ t: "chat", text: text }); }

    // ── chat (host relays so every message appears exactly once) ──
    function relayChat(name, text) { var m = { t: "chat", name: name, text: text }; broadcast(m); addChat(name, text); }
    function sysChat(text) { if (!isHost) return; var m = { t: "chat", name: "", text: text, sys: true }; broadcast(m); addChat("", text, true); }
    function addChat(name, text, sys) {
      var el = body && body.querySelector("#mp-chat"); if (!el) return;
      var r = document.createElement("div");
      r.className = "mp-chat-msg" + (sys ? " mp-chat-sys" : "");
      r.innerHTML = sys ? esc(text) : "<strong>" + esc(name) + ":</strong> " + esc(text);
      el.appendChild(r); el.scrollTop = el.scrollHeight;
    }

    // ── top bar (mirrors practice: counter + score pills) ──
    function updateTopBar() {
      if (!page || !page.screenEl) return;
      var titleEl = page.screenEl.querySelector(".top-bar-title");
      if (titleEl) titleEl.textContent = lobby ? ("MULTIPLAYER: " + lobby.toUpperCase()) : "MULTIPLAYER";
      var right = page.screenEl.querySelector(".top-bar-right");
      if (!right) return;
      right.querySelectorAll(".mp-topbar").forEach(function (n) { n.remove(); });
      if (!lobby) return;
      var me = players[myId] || { score: 0 };
      var frag = document.createElement("span");
      frag.innerHTML =
        (isHost ? '<span class="pill mp-topbar">host</span>' : "") +
        '<span class="pill pill-green mp-topbar">Score: ' + (me.score || 0) + "</span>" +
        '<button class="btn btn-sm btn-ghost mp-topbar" id="mp-leave-top">Leave</button>';
      while (frag.firstChild) right.insertBefore(frag.firstChild, right.querySelector("button:last-child"));
      var lt = right.querySelector("#mp-leave-top"); if (lt) lt.onclick = leave;
    }

    // ── rendering ──
    function render() { if (!body) return; if (!lobby) renderForm(); else renderRoom(); updateTopBar(); }
    function setStatus(m) { var s = body && body.querySelector("#mp-status"); if (s) s.textContent = m; }

    function renderForm() {
      myName = ctx.getSetting("name") || ("Player" + Math.floor(Math.random() * 1000));
      body.innerHTML =
        '<div class="practice-layout">' +
          '<main class="question-area">' +
            '<div class="question-placeholder">' +
              '<div class="placeholder-icon"><svg viewBox="0 0 24 24" width="42" height="42" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M9.6 9.2a2.6 2.6 0 1 1 3.7 2.5c-.9.4-1.3 1-1.3 1.8v.3"/><circle cx="12" cy="17" r="0.9" fill="currentColor" stroke="none"/></svg></div>' +
              '<h2 style="margin:0 0 8px">Join a multiplayer lobby</h2>' +
              '<div class="mp-join-form">' +
                '<input id="mp-name" class="mode-input" placeholder="Your name" value="' + esc(myName) + '" autocomplete="off">' +
                '<input id="mp-lobby" class="mode-input" placeholder="Lobby name" autocomplete="off">' +
                '<label class="checkbox-row" style="justify-content:center"><input type="checkbox" id="mp-spectate"> Join as spectator</label>' +
                '<label class="checkbox-row" style="justify-content:center" title="Connects players directly instead of through the relay \u2014 lower latency, but strict school/work networks may block it"><input type="checkbox" id="mp-p2p"' + (ctx.getSetting("p2p") ? " checked" : "") + "> Direct P2P (lower latency)</label>" +
                '<button class="btn btn-primary btn-full" id="mp-join">Join Lobby</button>' +
                '<div class="text-muted" id="mp-status" style="font-size:12px;min-height:16px"></div>' +
              "</div>" +
            "</div>" +
          "</main>" +
        "</div>";
      var nameEl = body.querySelector("#mp-name");
      body.querySelector("#mp-join").onclick = function () {
        myName = (nameEl.value.trim()) || myName;
        ctx.setSetting("name", myName); // remember for next time
        lobby = body.querySelector("#mp-lobby").value.trim();
        mySpec = !!body.querySelector("#mp-spectate").checked;
        ctx.setSetting("p2p", !!body.querySelector("#mp-p2p").checked);
        if (!lobby) { setStatus("Enter a lobby name."); return; }
        join();
      };
    }

    // MP-specific controls injected into the (borrowed) filter panel — kept to
    // just TWO sections (Lobby + Game) to avoid heading clutter.
    function lobbySectionHtml() {
      // Lobby info + your name/team in one section.
      return '<div class="filter-section mp-injected">' +
        '<div class="filter-label">LOBBY: ' + esc(lobby) + (isHost ? ' <span class="pill">host</span>' : "") + "</div>" +
        '<label class="mode-field"><span>Your name</span><input id="mp-myname" class="mode-input" autocomplete="off"></label>' +
        (mySpec ? '<div class="text-muted" style="font-size:11px">Spectating \u2014 watching & chat only.</div>'
                : '<label class="mode-field"><span>Team</span><input id="mp-myteam" class="mode-input" placeholder="(none)" autocomplete="off"></label>') +
        '<div class="text-muted" id="mp-status" style="font-size:11px;min-height:14px;margin-top:4px"></div>' +
        '<div class="text-muted" id="mp-filter-summary" style="font-size:11px;margin-top:2px"></div>' +
        "</div>";
    }
    function controlsSectionsHtml() {
      // One "GAME" section. The answer timer + rebuzz toggle are editable by
      // EVERYONE and kept in sync (clients send setSetting to the host, the
      // host re-broadcasts state). Only "Next Question" is host-only.
      return '<div class="filter-section mp-injected"><div class="filter-label">GAME</div>' +
        '<div class="slider-group"><span style="font-size:11px;min-width:78px" title="Time to type an answer after buzzing">Answer time</span><input type="range" id="mp-ans" min="3" max="30" step="1" value="' + (settings.answerSeconds) + '"><span class="slider-value" id="mp-ans-val">' + (settings.answerSeconds) + "s</span></div>" +
        '<div class="slider-group" style="margin-top:6px"><span style="font-size:11px;min-width:78px" title="Time to buzz once the question finishes reading">Buzz window</span><input type="range" id="mp-bwin" min="3" max="30" step="1" value="' + (settings.buzzWindow || 10) + '"><span class="slider-value" id="mp-bwin-val">' + (settings.buzzWindow || 10) + "s</span></div>" +
        '<label class="checkbox-row"><input type="checkbox" id="mp-rebuzz" ' + (settings.rebuzz ? "checked" : "") + "> Allow rebuzzes</label>" +
        '<label class="checkbox-row" title="After every correct tossup, the winner answers a random bonus"><input type="checkbox" id="mp-bonusevery" ' + (settings.bonusEvery ? "checked" : "") + "> Bonus after every question</label>" +
        (isHost
          ? '<label class="checkbox-row"><input type="checkbox" id="mp-stoppow"' + (practiceChecked("opt-stop-on-power", false) ? " checked" : "") + "> Stop on power</label>" +
            '<label class="checkbox-row"><input type="checkbox" id="mp-skips"' + (practiceChecked("opt-allow-skips", true) ? " checked" : "") + "> Allow skips</label>" +
            '<label class="checkbox-row" title="When on, new players cannot join this lobby"><input type="checkbox" id="mp-lock"' + (locked ? " checked" : "") + "> Lock room</label>" +
            ''
          : "") +
        "</div>";
    }

    function renderRoom() {
      // Always return any borrowed panel before re-rendering (innerHTML wipes it).
      returnPanel();
      body.innerHTML =
        '<div class="practice-layout">' +
          // ── LEFT: the host borrows the REAL practice filter panel (inserted
          //    below); clients see a read-only summary. ──
          '<div class="resize-handle"></div>' +
          // ── CENTRE: question area (identical to practice) ──
          '<main class="question-area">' +
            '<div class="question-placeholder" id="mp-placeholder">' +
              '<div class="placeholder-icon"><svg viewBox="0 0 24 24" width="42" height="42" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M9.6 9.2a2.6 2.6 0 1 1 3.7 2.5c-.9.4-1.3 1-1.3 1.8v.3"/><circle cx="12" cy="17" r="0.9" fill="currentColor" stroke="none"/></svg></div>' +
              "<p>" + (isHost ? "Press [N] to read the first question." : "Waiting for the host to start…") + "</p>" +
            "</div>" +
            '<div class="question-content hidden" id="mp-content">' +
              '<div class="question-meta" id="mp-meta"></div>' +
              '<div class="question-text" id="mp-qtext"></div>' +
            "</div>" +
            '<div class="buzz-area hidden" id="mp-buzz"></div>' +
            '<div class="result-area hidden" id="mp-result"></div>' +
            '<div class="history-panel">' +
              '<div class="history-panel-header"><span class="history-panel-title">BUZZES THIS QUESTION</span></div>' +
              '<div class="history-list" id="mp-buzzes"></div>' +
            "</div>" +
            '<div class="history-panel">' +
              '<div class="history-panel-header"><span class="history-panel-title">SESSION HISTORY</span>' +
                '<span class="history-view-buttons"><button class="btn btn-sm btn-ghost" id="mp-log-collapse">Collapse all</button>' +
                '<button class="btn btn-sm btn-ghost" id="mp-log-expand">Expand all</button></span></div>' +
              '<div class="history-list" id="mp-log"></div>' +
            "</div>" +
          "</main>" +
          // ── RIGHT: stats-panel style scoreboard + chat (drag-resizable) ──
          '<div class="resize-handle" data-resize="next"></div>' +
          '<aside class="stats-panel mp-rightpanel">' +
            '<div class="mp-scores" id="mp-scores"></div>' +
            '<div class="mp-chatwrap">' +
              '<div class="filter-label">CHAT</div>' +
              '<div class="mp-chat" id="mp-chat"></div>' +
              '<input id="mp-chat-input" class="mode-input" placeholder="chat… (Enter)" autocomplete="off">' +
            "</div>" +
          "</aside>" +
        "</div>";

      // Chat is always present in the right panel — wire it once.
      var ci = body.querySelector("#mp-chat-input");
      if (ci) ci.addEventListener("keydown", function (e) { if (e.key === "Enter") { sendChat(ci.value.trim()); ci.value = ""; } });

      // Host: borrow the real practice filter panel as the left column and inject
      // the MP-specific sections (lobby/timer/you/next/hints) around its filters.
      borrowPanel(body.querySelector(".practice-layout"));

      renderScores(); renderSettings(); renderFilterSummary();
      if (current) { renderQuestion(); renderBuzzes(); }
      renderSessionLog();
    }

    // Wire the MP control sections (lobby/you/timer/next) wherever they live.
    // Mirror a GAME-section checkbox onto the real practice OPTIONS checkbox
    // (which lives in the host's DOM) so app settings + persistence stay true.
    function practiceChecked(id, dflt) {
      var el = document.getElementById(id);
      return el ? el.checked : dflt;
    }
    function bindMirror(mpId, realId) {
      var el = body.querySelector("#" + mpId);
      if (!el) return;
      el.addEventListener("change", function () {
        var real = document.getElementById(realId);
        if (real) { real.checked = el.checked; real.dispatchEvent(new Event("change")); }
      });
    }

    function wireControls() {
      bindMirror("mp-stoppow", "opt-stop-on-power");
      bindMirror("mp-skips", "opt-allow-skips");
      var nameInp = body.querySelector("#mp-myname");
      if (nameInp) { nameInp.value = (players[myId] || {}).name || myName; nameInp.addEventListener("change", function () { changeName(nameInp.value.trim() || myName); }); }
      var teamInp = body.querySelector("#mp-myteam");
      if (teamInp) { teamInp.value = (players[myId] || {}).team || ""; teamInp.addEventListener("change", function () { changeTeam(teamInp.value.trim()); }); }
      var an = body.querySelector("#mp-ans");
      if (an) { an.addEventListener("input", function (e) { body.querySelector("#mp-ans-val").textContent = e.target.value + "s"; }); an.addEventListener("change", function (e) { changeSetting("answerSeconds", parseInt(e.target.value) || 10); }); }
      var bw = body.querySelector("#mp-bwin");
      if (bw) { bw.addEventListener("input", function (e) { body.querySelector("#mp-bwin-val").textContent = e.target.value + "s"; }); bw.addEventListener("change", function (e) { changeSetting("buzzWindow", parseInt(e.target.value) || 10); }); }
      var rb = body.querySelector("#mp-rebuzz");
      if (rb) rb.addEventListener("change", function (e) { changeSetting("rebuzz", e.target.checked); });
      var be = body.querySelector("#mp-bonusevery");
      if (be) be.addEventListener("change", function (e) { changeSetting("bonusEvery", e.target.checked); });
      var lk = body.querySelector("#mp-lock");
      if (lk) lk.addEventListener("change", function (e) { locked = e.target.checked; sysChat(myName + (locked ? " locked the room" : " unlocked the room")); });
      var nx = body.querySelector("#mp-next"); if (nx) nx.onclick = function () { requestNext(); };
    }

    // Move the real practice filter panel into the multiplayer layout (host only).
    function borrowPanel(layout) {
      if (!layout) return;
      try { if (ctx.host && ctx.host.ensureFiltersLoaded) ctx.host.ensureFiltersLoaded(); } catch (e) {}
      var panel = document.getElementById("filters-panel");
      if (!panel) return;
      // Practice-only bits don't apply here: MP's GAME timers rule the room,
      // and packet-game is a solo mode.
      var gameOpt = document.querySelector('#mode-select option[value="game"]');
      if (gameOpt) { gameOpt.hidden = true; gameOpt.disabled = true; }
      if (!panelHome) panelHome = { parent: panel.parentNode, next: panel.nextSibling };
      panel.classList.add("mp-borrowed");
      layout.insertBefore(panel, layout.firstChild);
      borrowedPanel = panel;
      // inject MP sections: YOU + lobby at top, controls at bottom
      var top = document.createElement("div"); top.innerHTML = lobbySectionHtml();
      while (top.firstChild) panel.insertBefore(top.firstChild, panel.firstChild);
      var bottom = document.createElement("div"); bottom.innerHTML = controlsSectionsHtml();
      while (bottom.firstChild) panel.appendChild(bottom.firstChild);
      wireControls();
      // Log the host's filter changes (categories, difficulty, year, strictness…)
      // to chat and re-sync the summary to everyone.
      panel.addEventListener("change", onAnyFilterChange, true);
      panel.addEventListener("input", onAnyFilterChange, true);
    }
    var _filterTimer = null;
    // Describe a specific control change for the chat log, e.g.
    // "Warren changed Mythology to true" or "Warren changed difficulty to 2,3,4".
    function describeFilterChange(t) {
      if (!t) return "";
      var diffs = function () { return [].slice.call(document.querySelectorAll("#difficulty-filters .diff-checkbox:checked")).map(function (c) { return c.value; }).join(","); };
      if (t.classList && (t.classList.contains("diff-checkbox"))) return "changed difficulty to " + (diffs() || "none");
      if (t.classList && (t.classList.contains("cat-checkbox") || t.classList.contains("subcat-checkbox") || t.classList.contains("altsub-checkbox"))) return "changed " + (t.value || "category") + " to " + (t.checked ? "true" : "false");
      if (t.classList && (t.classList.contains("cat-weight") || t.classList.contains("subcat-weight") || t.classList.contains("altsub-weight"))) {
        var lbl = t.closest(".filter-item"); var nm = lbl ? (lbl.querySelector("span:not(.cat-expand):not(.text-muted):not(.altsub-expand)") || {}).textContent : "";
        return "changed " + (nm || "weight").trim() + " to " + t.value;
      }
      if (t.id === "year-min" || t.id === "year-max") { var lo = document.getElementById("year-min"), hi = document.getElementById("year-max"); var a = parseInt(lo.value), b = parseInt(hi.value); return "changed years to " + Math.min(a, b) + "-" + Math.max(a, b); }
      if (t.id === "strictness-slider") return "changed strictness to " + t.value;
      if (t.id === "panel-speed-slider") return "changed reading speed to " + t.value;
      if (t.id === "enable-cat-weights") return "changed weights to " + (t.checked ? "true" : "false");
      if (t.id === "filter-standard") return "changed standard-only to " + (t.checked ? "true" : "false");
      if (t.id === "filter-powermark") return "changed powermarked-only to " + (t.checked ? "true" : "false");
      if (t.id === "mode-select") return "changed mode to " + t.value;
      if (t.id === "mode-set-name") return "changed set to " + (t.value || "(none)");
      if (t.id === "mode-packet") return "changed packet to " + (t.value || "all");
      return "";
    }
    // Anyone can edit the filters. The host stores them as roomConfig and uses
    // them for the next question; a client sends its config to the host.
    // Mirror the room's toggle-style filters into this client's borrowed panel,
    // so a later local edit doesn't silently clobber them (the classic case:
    // the host's "Powermark only" being wiped by any client filter tweak).
    var _applyingRemote = false;
    function applyRoomFiltersToPanel(f) {
      if (isHost || !f) return;
      _applyingRemote = true;
      try {
        var pm = document.getElementById("filter-powermark"); if (pm) pm.checked = !!f.powermarkOnly;
        var st = document.getElementById("filter-standard"); if (st) st.checked = !!f.standard;
        var so = document.getElementById("filter-starred"); if (so) so.checked = !!f.starredOnly;
        if (f.yearMin != null) { var ym = document.getElementById("year-min"); if (ym) ym.value = f.yearMin; }
        if (f.yearMax != null) { var yx = document.getElementById("year-max"); if (yx) yx.value = f.yearMax; }
        if (Array.isArray(f.difficulties)) {
          var want = f.difficulties.map(String);
          document.querySelectorAll("#difficulty-filters .diff-checkbox").forEach(function (cb) { cb.checked = want.indexOf(String(cb.value)) >= 0; });
        }
      } catch (e) {}
      _applyingRemote = false;
    }
    function onAnyFilterChange(e) {
      if (_applyingRemote) return; // remote sync must not echo back as an edit
      if (e && e.target && e.target.closest && e.target.closest(".mp-injected")) return; // ignore MP's own controls
      var msg = describeFilterChange(e && e.target);
      clearTimeout(_filterTimer);
      _filterTimer = setTimeout(function () {
        if (!ctx.host || !ctx.host.getPracticeConfig) return;
        var cfg; try { cfg = ctx.host.getPracticeConfig(); } catch (e2) { return; }
        if (isHost) {
          roomConfig = cfg;
          filterSummary = cfg.filterSummary || "All categories";
          if (msg) sysChat(myName + " " + msg);
          broadcast(stateMsg()); renderFilterSummary();
        } else {
          toHost({ t: "setConfig", config: { filters: cfg.filters, strictness: cfg.strictness, revealSpeed: cfg.revealSpeed, hidePron: cfg.hidePron, filterSummary: cfg.filterSummary }, change: msg });
        }
      }, 400);
    }
    // Put the panel back where it belongs and strip the injected MP sections.
    function returnPanel() {
      var gameOpt = document.querySelector('#mode-select option[value="game"]');
      if (gameOpt) { gameOpt.hidden = false; gameOpt.disabled = false; }
      if (!borrowedPanel) return;
      borrowedPanel.removeEventListener("change", onAnyFilterChange, true);
      borrowedPanel.removeEventListener("input", onAnyFilterChange, true);
      borrowedPanel.querySelectorAll(".mp-injected").forEach(function (n) { n.remove(); });
      borrowedPanel.classList.remove("mp-borrowed");
      if (panelHome) { panelHome.parent.insertBefore(borrowedPanel, panelHome.next); }
      borrowedPanel = null;
    }

    function renderFilterSummary() {
      var el = body && body.querySelector("#mp-filter-summary"); if (!el) return;
      if (isHost && ctx.host && ctx.host.getPracticeConfig) { try { filterSummary = ctx.host.getPracticeConfig().filterSummary || "All categories"; } catch (e) {} }
      el.textContent = filterSummary || "All categories";
    }

    function renderScores() {
      var el = body && body.querySelector("#mp-scores"); if (!el) return;
      var teams = {}, specs = [];
      order.forEach(function (id) {
        var p = players[id];
        if (p.spec) { specs.push(p); return; }
        (teams[p.team || ""] = teams[p.team || ""] || []).push(p);
      });
      var html = '<div class="filter-label">SCOREBOARD</div>';
      Object.keys(teams).sort().forEach(function (tn) {
        var roster = teams[tn].sort(function (a, b) { return (b.score || 0) - (a.score || 0); });
        if (tn) { var tot = roster.reduce(function (s, p) { return s + (p.score || 0); }, 0); html += '<div class="mp-team-row"><span>' + esc(tn) + "</span><strong>" + tot + "</strong></div>"; }
        roster.forEach(function (p) {
          var you = p.id === myId;
          html += '<div class="mp-score-row' + (tn ? " mp-indent" : "") + (you ? " mp-you" : "") + (p.off ? " mp-off" : "") + '">' +
            '<span>' + (p.avatar ? '<span class="mp-avatar">' + esc(p.avatar) + '</span> ' : '') + esc(p.name) + (you ? " (you)" : "") + (p.off ? " · offline" : "") + "</span><strong>" + (p.score || 0) + "</strong></div>";
        });
      });
      if (specs.length) {
        html += '<div class="filter-label" style="margin-top:8px">SPECTATORS</div>';
        specs.forEach(function (p) {
          var you = p.id === myId;
          html += '<div class="mp-score-row' + (you ? " mp-you" : "") + '"><span>\ud83d\udc41 ' + (p.avatar ? '<span class="mp-avatar">' + esc(p.avatar) + '</span> ' : '') + esc(p.name) + (you ? " (you)" : "") + "</span></div>";
        });
      }
      el.innerHTML = html;
    }

    // keep the left-panel rule controls in sync with shared settings
    function renderSettings() {
      if (!body) return;
      var an = body.querySelector("#mp-ans"); if (an && document.activeElement !== an) { an.value = settings.answerSeconds; var av = body.querySelector("#mp-ans-val"); if (av) av.textContent = settings.answerSeconds + "s"; }
      var bw2 = body.querySelector("#mp-bwin"); if (bw2 && document.activeElement !== bw2) { bw2.value = settings.buzzWindow || 10; var bv = body.querySelector("#mp-bwin-val"); if (bv) bv.textContent = (settings.buzzWindow || 10) + "s"; }
      var rb = body.querySelector("#mp-rebuzz"); if (rb) rb.checked = !!settings.rebuzz;
      var be = body.querySelector("#mp-bonusevery"); if (be) be.checked = !!settings.bonusEvery;
    }

    function renderQuestion() {
      var ph = body && body.querySelector("#mp-placeholder"); if (ph) ph.classList.add("hidden");
      var content = body && body.querySelector("#mp-content"); if (content) content.classList.remove("hidden");
      var meta = body && body.querySelector("#mp-meta"); if (meta) meta.textContent = "";   // category stays hidden while reading
      applyReveal(revealIdx);
      var buzz = body && body.querySelector("#mp-buzz"); if (buzz) { buzz.className = "buzz-area hidden"; buzz.innerHTML = ""; }
      var res = body && body.querySelector("#mp-result"); if (res) { res.className = "result-area hidden"; res.innerHTML = ""; }
    }

    // Character-based reveal with (#) buzz marks — identical to practice.
    // Render the revealed text with (#) buzz marks. Your own buzzes use one
    // (themeable) color, everyone else's use another.
    function renderWithMarks(text, upTo, marks) {
      var list = (marks || []).filter(function (m) { return m.pos >= 0 && m.pos <= upTo; }).sort(function (a, b) { return a.pos - b.pos; });
      var out = "", last = 0;
      list.forEach(function (m) {
        out += esc(text.substring(last, m.pos)) + '<span class="buzz-mark ' + (m.by === myId ? "buzz-self" : "buzz-other") + '">(#)</span>';
        last = m.pos;
      });
      out += esc(text.substring(last, upTo));
      return out;
    }
    function applyReveal(idx) {
      var qt = body && body.querySelector("#mp-qtext"); if (!qt || !current) return;
      var text = current.text;
      var out = renderWithMarks(text, idx, buzzCharMarks);
      // Mask the unread text so it can't be read by highlighting (monospace font
      // + preserved whitespace keeps the wrapping identical).
      var rest = esc(text.substring(idx).replace(/\S/g, "·"));
      qt.innerHTML = '<span class="revealed">' + out + "</span>" + (rest ? '<span class="unrevealed" aria-hidden="true">' + rest + "</span>" : "");
    }

    function applyBuzz(id, name, idx, deadline) {
      var buzz = body && body.querySelector("#mp-buzz"); if (!buzz) return;
      if (id === myId) {
        buzz.className = "buzz-area";
        buzz.innerHTML =
          '<div class="buzz-prompt"><span class="prompt-symbol">&gt;</span>' +
          '<input type="text" id="mp-ans-input" placeholder="type answer and press Enter..." autocomplete="off" autocorrect="off" spellcheck="false"></div>' +
          '<div class="buzz-hints">You buzzed — <span id="mp-timer"></span></div>' +
          '<div class="mp-timer-bar"><div id="mp-timer-fill"></div></div>';
        var inp = buzz.querySelector("#mp-ans-input"); inp.focus();
        inp.addEventListener("keydown", function (e) { if (e.key === "Enter") { inp.disabled = true; submitAnswer(inp.value.trim()); } });
      } else {
        buzz.className = "buzz-area";
        buzz.innerHTML = '<div class="buzz-prompt"><span class="prompt-symbol">&gt;</span> <em>' + esc(name) + " is answering…</em></div>" +
          '<div class="buzz-hints"><span id="mp-timer"></span></div>' +
          '<div class="mp-timer-bar"><div id="mp-timer-fill"></div></div>';
      }
      startTick(deadline);
    }

    function applyPrompt(id, name, ask, deadline) {
      var buzz = body && body.querySelector("#mp-buzz"); if (!buzz) return;
      if (id === myId) {
        buzz.className = "buzz-area";
        buzz.innerHTML =
          '<div class="buzz-prompt"><span class="prompt-symbol">&gt;</span>' +
          '<input type="text" id="mp-ans-input" placeholder="answer again…" autocomplete="off" autocorrect="off" spellcheck="false"></div>' +
          '<div class="buzz-hints"><span style="color:var(--yellow);font-weight:700">PROMPT' + (ask ? ":</span> " + esc(ask) : "</span>") + ' — <span id="mp-timer"></span></div>' +
          '<div class="mp-timer-bar"><div id="mp-timer-fill"></div></div>';
        var inp = buzz.querySelector("#mp-ans-input"); inp.focus();
        inp.addEventListener("keydown", function (e) { if (e.key === "Enter") { inp.disabled = true; submitAnswer(inp.value.trim()); } });
      } else {
        buzz.className = "buzz-area";
        buzz.innerHTML = '<div class="buzz-prompt"><span class="prompt-symbol">&gt;</span> <em>' + esc(name) + " is being prompted…</em></div>" +
          '<div class="buzz-hints"><span style="color:var(--yellow);font-weight:700">PROMPT' + (ask ? ":</span> " + esc(ask) : "</span>") + ' <span id="mp-timer"></span></div>' +
          '<div class="mp-timer-bar"><div id="mp-timer-fill"></div></div>';
      }
      startTick(deadline || answerDeadline);
    }

    function startTick(deadline, totalMs) {
      if (tickTimer) clearInterval(tickTimer);
      var total = totalMs || (settings.answerSeconds || 10) * 1000;
      function paint() {
        var t = body && body.querySelector("#mp-timer");
        var left = Math.max(0, deadline - Date.now());
        if (t) t.textContent = Math.ceil(left / 1000) + "s";
        var bar = body && body.querySelector("#mp-timer-fill");
        if (bar) bar.style.width = Math.max(0, Math.min(100, (left / total) * 100)) + "%";
      }
      paint();
      tickTimer = setInterval(paint, 100);
    }

    var _endedCategory = "";
    function applyResult(d) {
      if (tickTimer) { clearInterval(tickTimer); tickTimer = null; }
      if (d.ended) {
        _endedCategory = d.category || "";
        var meta = body && body.querySelector("#mp-meta");
        if (meta && _endedCategory) meta.textContent = _endedCategory;
      }
      if (typeof d.index === "number" && !d.noBuzz && d.id && !buzzCharMarks.some(function (m) { return m.pos === d.index && m.by === d.id; })) buzzCharMarks.push({ pos: d.index, by: d.id });
      // Each client records ITS OWN buzz to local stats, so MP games show up in
      // Statistics with question history + buzz locations like solo play.
      if (d.id && d.id === myId && current && current.id && !d._recorded) {
        d._recorded = true;
        ctx.playSound(d.correct ? "correct" : "incorrect");
        var _cel = (current.text && current.text.length) ? Math.max(0, Math.min(1, (d.index || 0) / current.text.length)) : 0;
        try {
          ctx.api.post("/api/check-tossup", {
            questionId: current.id, answer: d.given || "", buzzPosition: d.index || 0,
            sessionId: mpSession(), overriding: true, correct: !!d.correct,
            isPower: (d.points || 0) >= 15, points: d.points || 0, celerity: _cel,
          });
        } catch (e) {}
      }
      var buzz = body && body.querySelector("#mp-buzz"); if (buzz) { buzz.className = "buzz-area hidden"; buzz.innerHTML = ""; }
      applyReveal(d.ended ? (current ? current.text.length : revealIdx) : revealIdx);
      var res = body && body.querySelector("#mp-result"); if (!res) { renderBuzzes(); return; }
      if (d.ended) {
        res.className = "result-area";
        var banner = d.correct
          ? '<div class="result-banner correct">' + esc(d.name) + " — +" + d.points + " pts</div>"
          : d.noBuzz
            ? '<div class="result-banner incorrect">Time! Nobody buzzed.</div>'
            : '<div class="result-banner incorrect">Nobody got it — everyone is locked out</div>';
        res.innerHTML =
          banner +
          '<div class="result-answer">ANSWER: <span class="actual">' + ansHtml(d.answerRaw, d.answer || "") + "</span></div>" +
          '<div class="result-next">' + (isHost ? '<span class="text-muted">Press [N] for the next question</span>' : '<span class="text-muted">Waiting for host…</span>') + "</div>";
        var n2 = res.querySelector("#mp-next2"); if (n2) n2.onclick = function () { requestNext(); };
      } else {
        res.className = "result-area hidden"; res.innerHTML = "";
      }
      renderBuzzes();
    }

    // ── bonus phase (everyone): rendered under the tossup result. Parts are
    // revealed one at a time; only the winner gets an input box. Chat is in a
    // separate panel and stays fully usable throughout. ──
    function submitBonusAnswer(text) { if (isHost) hostHandleBonusAnswer(myId, text); else toHost({ t: "banswer", text: text }); }
    function applyBonus(d) {
      bonusView = { leadin: d.leadin, parts: d.parts || [], winner: d.winner, name: d.name, k: 0, got: 0, done: false, results: [] };
      renderBonusArea(d.secs);
    }
    function applyBonusPart(d) {
      if (!bonusView) return;
      bonusView.results[d.k] = d;
      bonusView.k = d.k + 1;
      bonusView.got = d.got;
      bonusView.done = !!d.done;
      renderBonusArea(d.done ? 0 : d.secs);
    }
    function applyBonusCancel() {
      if (bonusView) { bonusView.done = true; renderBonusArea(0); }
    }
    function renderBonusArea(secs) {
      var res = body && body.querySelector("#mp-result"); if (!res || !bonusView) return;
      res.className = "result-area";
      var el = res.querySelector("#mp-bonus");
      if (!el) { el = document.createElement("div"); el.id = "mp-bonus"; el.className = "mp-bonus"; res.appendChild(el); }
      var mine = bonusView.winner === myId;
      var html = '<div class="filter-label">BONUS \u2014 ' + esc(bonusView.name) + (mine ? " (you)" : "") + " answers</div>" +
        (bonusView.leadin ? '<div class="question-text" style="font-size:13px;min-height:0">' + esc(bonusView.leadin) + "</div>" : "");
      for (var k = 0; k < bonusView.parts.length && k <= bonusView.k; k++) {
        html += '<div class="mp-bpart"><div class="bonus-part-text">[10] ' + esc(bonusView.parts[k]) + "</div>";
        var r = bonusView.results[k];
        if (r) {
          html += '<div style="font-size:12px">' + (r.ok ? '<span class="bonus-verdict correct">\u2713 </span>' : '<span class="bonus-verdict incorrect">\u2717 </span>') +
            (r.given ? "\u201c" + esc(r.given) + "\u201d \u2014 " : "") + 'ANSWER: <span class="ans">' + ansHtml(r.answerRaw, r.answer) + "</span></div>";
        } else if (k === bonusView.k && !bonusView.done) {
          html += mine
            ? '<div class="buzz-prompt"><span class="prompt-symbol">&gt;</span><input type="text" class="mp-binput" placeholder="your answer\u2026 (Enter)" autocomplete="off" autocorrect="off" spellcheck="false"></div>'
            : '<div class="text-muted" style="font-size:12px"><em>' + esc(bonusView.name) + " is answering\u2026</em></div>";
          html += '<div class="buzz-hints"><span id="mp-timer"></span></div><div class="mp-timer-bar"><div id="mp-timer-fill"></div></div>';
        }
        html += "</div>";
      }
      if (bonusView.done) html += '<div class="result-banner ' + (bonusView.got > 0 ? "correct" : "incorrect") + '" style="margin-top:2px">BONUS: ' + (bonusView.got * 10) + "/" + (bonusView.parts.length * 10) + "</div>";
      el.innerHTML = html;
      var inp = el.querySelector(".mp-binput");
      if (inp) { inp.focus(); inp.addEventListener("keydown", function (e) { if (e.key === "Enter") { inp.disabled = true; submitBonusAnswer(inp.value.trim()); } }); }
      if (bonusView.done) { if (tickTimer) { clearInterval(tickTimer); tickTimer = null; } }
      else if (secs) startTick(Date.now() + secs * 1000, secs * 1000);
    }

    function applyPause(p) {
      var qt = body && body.querySelector("#mp-qtext"); if (qt) qt.classList.toggle("paused-text", p);
      var meta = body && body.querySelector("#mp-meta"); if (meta && current) meta.textContent = p ? "PAUSED" : (ended && _endedCategory ? _endedCategory : "");
    }

    function buzzBadge(b) {
      return b.correct
        ? '<span class="pill pill-green">+' + b.points + "</span>"
        : (b.points < 0 ? '<span class="pill pill-red">' + b.points + "</span>" : '<span class="pill">' + b.points + "</span>");
    }

    function renderBuzzes() {
      var el = body && body.querySelector("#mp-buzzes"); if (!el) return;
      if (!buzzHistory.length) { el.innerHTML = '<div class="text-muted" style="padding:8px;font-size:12px">No buzzes yet this question.</div>'; return; }
      el.innerHTML = buzzHistory.map(function (b) {
        return '<div class="qcard" data-self-toggle><div class="qcard-head" style="cursor:default"><span class="qcard-meta"><span><strong>' + esc(b.name) + "</strong>: " + esc(b.given || "(no answer)") + "</span></span><span class=\"qcard-side\">" + buzzBadge(b) + "</span></div></div>";
      }).join("");
    }

    // Full session history: every question seen, with (#) at each buzz position.
    // Each entry is collapsible; the header click toggles it.
    var logCollapsed = {};   // index -> true when collapsed
    function renderSessionLog() {
      var el = body && body.querySelector("#mp-log"); if (!el) return;
      if (!sessionLog.length) { el.innerHTML = '<div class="text-muted" style="padding:8px;font-size:12px">No questions yet.</div>'; return; }
      el.innerHTML = sessionLog.map(function (e, i) {
        var num = i + 1;
        var collapsed = !!logCollapsed[i];
        var text = e.text || "";
        var out = renderWithMarks(text, text.length, e.marks);
        var buzzes = (e.buzzes || []).map(function (b) { return '<span style="color:' + (b.correct ? "var(--green)" : "var(--red)") + '">' + esc(b.name) + " " + (b.points >= 0 ? "+" + b.points : b.points) + "</span>"; }).join(" \u00b7 ");
        var dead = (e.buzzes || []).some(function (b) { return b.correct; }) ? "" : '<span class="pill pill-red">dead</span>';
        var star = e.qid ? '<span class="qb-star" data-qid="' + esc(e.qid) + '" data-type="tossup" title="Star">\u2606</span>' : "";
        var actions = e.qid ? ((ctx.host && ctx.host.openSaveMenu) ? '<span class="mp-save" data-qid="' + esc(e.qid) + '" title="Save to review / folders">+</span>' : "") : "";
        return '<div class="qcard ' + (collapsed ? "compact" : "expanded") + '" data-self-toggle data-i="' + i + '">' +
          '<div class="qcard-head"><span class="qcard-chev" aria-hidden="true"></span>' +
            '<span class="qcard-meta"><span>#' + num + "</span>" +
              (e.category ? "<span>" + esc(e.category) + "</span>" : "") +
              (e.difficulty !== "" && e.difficulty != null ? "<span>Diff " + esc(e.difficulty) + "</span>" : "") + "</span>" +
            '<span class="qcard-side">' + dead + actions + star + "</span></div>" +
          '<div class="qcard-answer">Answer: <span class="ans">' + ansHtml(e.answerRaw, e.answer || "") + "</span></div>" +
          '<div class="qcard-body"><div class="qcard-text">' + out + "</div>" +
            (buzzes ? '<div class="qcard-foot">' + buzzes + "</div>" : "") + "</div>" +
          "</div>";
      }).join("");
      // Clicking a compact card expands it; clicking an expanded card's head
      // collapses it (state kept per index so re-renders preserve it).
      el.querySelectorAll(".qcard[data-i]").forEach(function (card) {
        card.addEventListener("click", function (ev) {
          if (ev.target.closest(".qb-star") || ev.target.closest(".mp-save")) return;
          var i = +card.dataset.i;
          if (card.classList.contains("compact")) { logCollapsed[i] = false; renderSessionLog(); }
          else if (ev.target.closest(".qcard-head")) { logCollapsed[i] = true; renderSessionLog(); }
        });
      });
      el.querySelectorAll(".mp-save").forEach(function (b) {
        b.addEventListener("click", async function (ev) {
          ev.stopPropagation();
          var qid = b.dataset.qid; if (!qid) return;
          try { var d = await ctx.api.get("/api/tossups/" + encodeURIComponent(qid)); var q = d.tossup; if (q && ctx.host && ctx.host.openSaveMenu) ctx.host.openSaveMenu(q, "tossup", b); } catch (e2) {}
        });
      });
      var cAll = body.querySelector("#mp-log-collapse"), eAll = body.querySelector("#mp-log-expand");
      if (cAll) cAll.onclick = function () { sessionLog.forEach(function (_, i) { logCollapsed[i] = true; }); renderSessionLog(); };
      if (eAll) eAll.onclick = function () { logCollapsed = {}; renderSessionLog(); };
    }

    function leave() {
      leftIntentionally = true;
      mpSessId = ""; // next game records to a fresh local stats session
      var dc = body && body.querySelector("#mp-disconnect"); if (dc) dc.remove();
      returnPanel();
      stopReveal(); stopAnswerTimer(); stopBonusTimer(); stopClientRead();
      bonusState = null; bonusView = null; bonusPending = false;
      try { if (peer) peer.destroy(); } catch (e) {}
      try { if (ws) { ws.onclose = null; ws.onmessage = null; ws.close(); } } catch (e) {}
      ws = null; useRelay = false; _relayConns = {};
      peer = null; hostConn = null; conns = []; isHost = false; current = null;
      players = {}; order = []; lobby = ""; qCount = 0; sessionLog = [];
      render();
    }

    ctx.toast("Multiplayer enabled");
  }
