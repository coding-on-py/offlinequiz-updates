function __qbMain(ctx) {
    var PEERJS_URL = "https://unpkg.com/peerjs@1.5.4/dist/peerjs.min.js";
    var peer = null, isHost = false, conns = [], hostConn = null, myId = "";
    var ws = null, useRelay = false, _relayConns = {};
    // Baked-in relay — every game goes through it; users configure nothing.
    var DEFAULT_RELAY = "https://offlinequiz-mp-relay.warren2028045.workers.dev";
    function relayUrl() { return DEFAULT_RELAY; }
    var lobby = "", myName = "", body = null, page = null;
    var mySpec = false;  // joined as spectator (watch + chat, no buzzing)
    function myAv() { try { return ((ctx.host && ctx.host.getState && ctx.host.getState()) || {}).avatar || ""; } catch (e) { return ""; } }

    // Shared game state (host is the source of truth; clients mirror it).
    var players = {};            // id -> { id, name, team, score }
    var order = [];              // id order for stable display
    // MP-specific lobby settings (synced, anyone can edit). All the question
    // FILTERS (categories+weights, difficulties, year range, strictness, reading
    // speed, etc.) are reused from the host's Tossups Practice page via
    // ctx.host.getPracticeConfig() — multiplayer inherits every practice option.
    var settings = { answerSeconds: 10, buzzWindow: 10, rebuzz: false };
    var filterSummary = "";      // host's practice-filter summary, synced for display
    var curRevealSpeed = 25, curStrictness = 10;  // captured from practice per question
    var hostLocalSpeed = null;   // host's OWN slider value — client speed edits must not be reverted by it
    var current = null;          // { id, text } current question (char-based reveal)
    var hostQ = null;            // host-only full question object
    var mpSessId = "";           // this client's local stats session for the current game
    function mpSession() { if (!mpSessId) mpSessId = "mp-" + (lobby || "game") + "-" + Date.now(); return mpSessId; }
    // Bonus phase (imported TU+B packets): only the tossup winner answers.
    var bonusState = null;       // host-only { winner, k, got }
    var bonusParts = [], bonusAnswers = [], bonusRawAnswers = [];  // host-only
    var bonusView = null;        // everyone: { leadin, parts, winner, name, k, got, done, results[] }
    var bonusTimer = null;
    var bonusPending = false;    // a random bonus is being fetched after a correct TU
    var roomConfig = null;       // shared question filters (anyone can edit)
    var locked = false;          // host-only: when on, new players can't join
    var leftIntentionally = false;
    var curFilters = {};         // filters used for the current tossup (so the bonus matches)
    var curPowerEnd = 0, curStopPower = false, pausedAtPower = false;
    var revealIdx = 0, revealTimer = null;   // revealIdx = character index
    var ended = false, pendingBuzzer = null, answerTimer = null, answerDeadline = 0, tickTimer = null, pendingPrompted = false;
    var lockedTeams = {}, lockedIds = {};   // per-question lockouts
    var buzzHistory = [];        // per-question [{name, correct, points, given, index}]
    var buzzCharMarks = [];      // character indices where a buzz happened (for (#) marks)
    var sessionLog = [];         // all completed questions: {text, answer, category, difficulty, buzzes[], marks[]}
    var paused = false, qCount = 0;
    var borrowedPanel = null, panelHome = null;   // the borrowed practice filter panel
    var chatScope = "all";        // "all" | "team" — which channel the chat box sends to
    var autoSubTimer = null;      // client-side: submits whatever is typed when the timer runs out
    var mpPre = { key: "", q: null, busy: false };  // host-only: next tossup fetched ahead
    var _lastSelJson = "";        // last panel-selection snapshot applied/sent (dedupe)
    var _hostSelGen = 0;          // host-side: only the newest client-sel apply broadcasts

    // Build a /api/tossups/random query from a practice getActiveFilters() object.
    function filtersToQuery(f) {
      f = f || {};
      var p = ["random=1", "limit=1"];
      if (f.standard) p.push("standard=1");
      if (f.categories && f.categories.length) p.push("categories=" + encodeURIComponent(f.categories.join(",")));
      if (f.subcategories && f.subcategories.length) p.push("subcategories=" + encodeURIComponent(f.subcategories.join(",")));
      if (f.alternateSubcategories && f.alternateSubcategories.length) p.push("alternateSubcategories=" + encodeURIComponent(f.alternateSubcategories.join(",")));
      if (f.difficulties && f.difficulties.length) p.push("difficulties=" + f.difficulties.join(","));
      if (f.setNames && f.setNames.length) p.push("setNames=" + encodeURIComponent(f.setNames.join(",")));
      if (f.packetNumbers && f.packetNumbers.length) p.push("packetNumbers=" + f.packetNumbers.join(","));
      if (f.yearMin != null) p.push("yearMin=" + f.yearMin);
      if (f.yearMax != null) p.push("yearMax=" + f.yearMax);
      if (f.powermarkOnly) p.push("powermarkOnly=true");
      // (starred-only is intentionally NOT used in multiplayer)
      return p.join("&");
    }

    function esc(s) { return (s == null ? "" : String(s)).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"); }
    // Answer lines keep their real <b>/<u> formatting (everything else escaped).
    function ansHtml(raw, fallback) {
      var src = (raw && String(raw).trim()) ? String(raw) : String(fallback || "");
      var html = esc(src).replace(/&lt;(\/?)(b|u|i|em|strong)&gt;/gi, "<$1$2>");
      // auto-close unbalanced tags so a stray <u> can't underline the page
      var d = document.createElement("div");
      d.innerHTML = html;
      return d.innerHTML;
    }
    function lobbyId(n) { return "offlinequiz-mp-" + n.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, ""); }
    function loadPeer() {
      return new Promise(function (res, rej) {
        if (window.Peer) return res();
        var s = document.createElement("script"); s.src = PEERJS_URL;
        s.onload = function () { window.Peer ? res() : rej(new Error("PeerJS failed to load")); };
        s.onerror = function () { rej(new Error("Couldn't load PeerJS (need internet)")); };
        document.head.appendChild(s);
      });
    }

    // ── page (mirrors the practice screen) ──
    page = ctx.registerPage({
      id: "lobby", navLabel: "Multiplayer", title: "MULTIPLAYER",
      onShow: function (el) { body = el; el.classList.add("mp-flush"); render(); }, onHide: function () { returnPanel(); },
    });
    function active() { return page && page.screenEl && page.screenEl.classList.contains("active"); }
    // Safety net: whenever we navigate away from the MP page, give the borrowed
    // practice filter panel back so the Tossups screen is never left without it.
    ctx.on("screen:change", function () { setTimeout(function () { if (!active()) returnPanel(); }, 0); });

    ctx.onHotkey("chat", function () { if (!active()) return; var ci = body && body.querySelector("#mp-chat-input"); if (ci) ci.focus(); });

    // The borrowed practice panel hides its practice-only sections in MP.

    function onKey(e) {
      if (!active() || !lobby) return;
      var t = e.target.tagName; if (t === "INPUT" || t === "TEXTAREA") return;
      // I'm answering but the box lost focus: route printable keys INTO it
      // (focusing during keydown makes the character land there), exactly like
      // solo tossups.
      var myInp = body && (body.querySelector("#mp-ans-input") || body.querySelector(".mp-binput"));
      if (myInp && !myInp.disabled && e.key && e.key.length === 1 && !e.metaKey && !e.ctrlKey && !e.altKey) {
        myInp.focus();
        return;
      }
      if (e.code === "Space") { e.preventDefault(); requestBuzz(); }
      else if (e.key === "p" || e.key === "P") { e.preventDefault(); requestPause(); }
      else if (e.key === "n" || e.key === "N" || e.key === "s" || e.key === "S") { e.preventDefault(); requestNext(); }
      else if (e.key === "q" || e.key === "Q") { e.preventDefault(); confirmLeave(); }
    }
    function confirmLeave() {
      if (!lobby) return;
      if (ctx.host && ctx.host.confirm) ctx.host.confirm("Leave the lobby?", function () { leave(); }, { yes: "Leave" });
      else if (window.confirm("Leave the lobby?")) leave();
    }
    document.addEventListener("keydown", onKey);
    ctx._cleanup = function () { returnPanel(); restoreSoloPanel(); document.removeEventListener("keydown", onKey); stopReveal(); stopAnswerTimer(); stopTick(); stopBuzzWindowTimer(); stopBonusTimer(); stopClientRead(); stopAutoSub(); try { if (peer) peer.destroy(); } catch (e) {} try { if (ws) ws.close(); } catch (e) {} };

    // ── networking helpers (transport-agnostic) ──
    function sendRelay(o) { if (ws && ws.readyState === 1) { try { ws.send(JSON.stringify(o)); } catch (e) {} } }
    function broadcast(m) {
      if (useRelay) { sendRelay({ to: "all", d: m }); return; }
      conns.forEach(function (c) { try { c.send(m); } catch (e) {} });
    }
    function toHost(m) {
      if (useRelay) { sendRelay({ to: "host", d: m }); return; }
      if (hostConn) { try { hostConn.send(m); } catch (e) {} }
    }
    // A conn-shaped wrapper so the host code paths work identically on relay.
    function relayConn(id) {
      if (!_relayConns[id]) _relayConns[id] = { peer: id, send: function (d) { sendRelay({ to: id, d: d }); } };
      return _relayConns[id];
    }
    // roomSel is the host panel's lossless selection snapshot (app 14.2+) —
    // it's what lets every client mirror categories/subcats/alt-subcats, which
    // the derived roomFilters object cannot rebuild. roomFilters stays for
    // clients running an older base.
    function hostSel() { try { return (ctx.host && ctx.host.getFilterSelectionSnapshot) ? ctx.host.getFilterSelectionSnapshot() : null; } catch (e) { return null; } }
    function stateMsg() { return { t: "state", players: order.map(function (id) { return players[id]; }), settings: settings, filterSummary: filterSummary, roomFilters: (roomConfig && roomConfig.filters) || null, roomSel: isHost ? hostSel() : null }; }
    function pushState() { broadcast(stateMsg()); renderScores(); renderSettings(); updateTopBar(); }

    function addPlayer(id, name, team, spec, avatar) {
      if (!players[id]) order.push(id);
      players[id] = { id: id, name: name || ("Player" + order.length), team: team || "", score: (players[id] && players[id].score) || 0, spec: !!spec, avatar: avatar || (players[id] && players[id].avatar) || "" };
    }
    function removePlayer(id) { delete players[id]; order = order.filter(function (x) { return x !== id; }); }

    // A visible banner when YOUR connection drops mid-game (lag-out).
    function showDisconnected() {
      var area = body && body.querySelector(".question-area");
      if (!area) { setStatus("Disconnected from the lobby."); return; }
      var existing = body.querySelector("#mp-disconnect"); if (existing) return;
      var el = document.createElement("div");
      el.id = "mp-disconnect"; el.className = "mp-disconnect";
      el.innerHTML = '<div class="mp-disc-box"><div class="mp-disc-title">\u26a0 Disconnected from the lobby</div>' +
        '<div class="text-muted" style="font-size:12px">You lost connection (lag or network drop).</div>' +
        '<div class="mp-disc-actions"><button class="btn btn-primary" id="mp-rejoin">Rejoin</button>' +
        '<button class="btn btn-ghost" id="mp-discleave">Leave</button></div></div>';
      area.appendChild(el);
      el.querySelector("#mp-rejoin").onclick = function () { el.remove(); isHost = false; join(); };
      el.querySelector("#mp-discleave").onclick = function () { el.remove(); leave(); };
    }

    // ── solo-settings isolation ──
    // The lobby borrows and MUTATES the real practice panel (room creation
    // even resets it). Everything is snapshotted on join and restored on
    // leave THROUGH the real controls, so solo Tossups comes back exactly as
    // the player left it — multiplayer never bleeds into practice settings.
    var soloBackup = null;
    function backupSoloPanel() {
      try {
        if (!(ctx.host && ctx.host.getFilterSelectionSnapshot && ctx.host.getPracticeConfig)) return null;
        var ms = document.getElementById("mode-select");
        return {
          sel: ctx.host.getFilterSelectionSnapshot(),
          cfg: ctx.host.getPracticeConfig(),
          mode: ms ? ms.value : "random",
          setName: (document.getElementById("mode-set-name") || {}).value || "",
          packet: (document.getElementById("mode-packet") || {}).value || "",
        };
      } catch (e) { return null; }
    }
    function restoreSoloPanel() {
      var b = soloBackup;
      soloBackup = null;
      if (!b || !(ctx.host && ctx.host.applyFilterSelectionSnapshot)) return;
      var fire = function (el, evt) { try { el.dispatchEvent(new Event(evt, { bubbles: true })); } catch (e) {} };
      var setVal = function (id, v, evts) {
        var el = document.getElementById(id);
        if (!el || v === undefined || v === null) return;
        el.value = v;
        (evts || ["change"]).forEach(function (ev) { fire(el, ev); });
      };
      var setChk = function (id, want) {
        var el = document.getElementById(id);
        if (el && el.checked !== !!want) { el.checked = !!want; fire(el, "change"); }
      };
      try {
        setVal("mode-select", b.mode);
        if (b.mode === "set") { setVal("mode-set-name", b.setName); setVal("mode-packet", b.packet); }
        Promise.resolve(ctx.host.applyFilterSelectionSnapshot(b.sel)).catch(function () {}).then(function () {
          setVal("strictness-slider", b.cfg.strictness, ["input", "change"]);
          setVal("panel-speed-slider", b.cfg.revealSpeed, ["input", "change"]);
          setChk("opt-stop-on-power", b.cfg.stopOnPower);
          setChk("opt-allow-skips", b.cfg.allowSkips !== false);
          setChk("filter-hide-pron", b.cfg.hidePron);
          // persist the restored selection (the app saves on panel change)
          var panel = document.getElementById("filters-panel");
          if (panel) fire(panel, "change");
        });
      } catch (e) {}
    }

    // ── join ──
    var ROOM_DEFAULTS = { answerSeconds: 10, buzzWindow: 10, rebuzz: false, bonusEvery: false };
    async function join() {
      if (!soloBackup) soloBackup = backupSoloPanel();   // once per lobby stay (rejoins keep the original)
      // Every room starts from the SAME defaults — nothing carries over from a
      // previous room, and a reopened room starts fresh too.
      settings = { answerSeconds: ROOM_DEFAULTS.answerSeconds, buzzWindow: ROOM_DEFAULTS.buzzWindow, rebuzz: ROOM_DEFAULTS.rebuzz, bonusEvery: ROOM_DEFAULTS.bonusEvery };
      // Packet/set reading never carries across lobbies — always start at q1.
      setSig = ""; setIndex = 0; setQueue = null; impSig = ""; impIndex = 0;
      roomConfig = null; locked = false; leftIntentionally = false;
      // Fresh log: on (re)join the host replays every entry, so keeping the old
      // list would duplicate the entire session history.
      sessionLog = []; logCollapsed = {}; chatHist = [];
      var relay = relayUrl();
      useRelay = !!relay && !ctx.getSetting("p2p"); // P2P opt-in skips the relay
      if (useRelay) { joinRelay(relay); return; }
      setStatus("Connecting…");
      try { await loadPeer(); } catch (e) { setStatus(e.message); return; }
      var id = lobbyId(lobby);
      peer = new window.Peer(id);
      peer.on("open", function (pid) {
        isHost = true; myId = pid;
        // New room ⇒ default question filters (mode random, no categories,
        // diff 2-5, speed 50ms, strictness 20, powermark on, 2010-2026 …).
        try { if (ctx.host && ctx.host.resetPracticeFilters) ctx.host.resetPracticeFilters(); } catch (e) {}
        addPlayer(myId, myName, "", mySpec, myAv());
        peer.on("connection", onHostConn);
        sysChat(myName + " created the lobby");
        mpPrefetchNow();   // the FIRST question should serve instantly too
        render();
      });
      peer.on("error", function (err) {
        if (err && err.type === "unavailable-id") { peer.destroy(); becomeClient(id); return; }
        if (lobby && !leftIntentionally && err && (err.type === "network" || err.type === "disconnected" || err.type === "socket-error")) { showDisconnected(); return; }
        setStatus("Error: " + (err && err.type || err));
      });
    }
    // ── relay transport: one outbound WebSocket per player ──
    function joinRelay(relay) {
      setStatus("Connecting to relay…");
      var base = relay.replace(/\/+$/, "");
      if (/^https?:/i.test(base)) base = base.replace(/^http/i, "ws").replace(/^HTTPS/i, "wss");
      if (!/^wss?:/i.test(base)) base = "wss://" + base;
      var sock;
      try { sock = new WebSocket(base + "/lobby/" + encodeURIComponent(lobbyId(lobby))); }
      catch (e) { setStatus("Bad relay URL."); return; }
      ws = sock;
      var opened = false;
      sock.onmessage = function (ev) {
        var m; try { m = JSON.parse(ev.data); } catch (e) { return; }
        if (m.t === "welcome") {
          opened = true;
          myId = m.id; isHost = !!m.host;
          if (isHost) {
            try { if (ctx.host && ctx.host.resetPracticeFilters) ctx.host.resetPracticeFilters(); } catch (e) {}
            addPlayer(myId, myName, "", mySpec, myAv());
            sysChat(myName + " created the lobby");
            mpPrefetchNow();   // the FIRST question should serve instantly too
          } else {
            toHost({ t: "hello", name: myName, spectate: mySpec, avatar: myAv() });
          }
          render();
          return;
        }
        if (m.t === "msg") {
          if (isHost) onHostData(relayConn(m.from), m.d);
          else if (m.host) onClientData(m.d);   // clients only trust the host
          return;
        }
        if (m.t === "peerleft") { if (isHost) hostPeerGone(m.id); return; }
        // Relay 2.0: the host leaving promotes a survivor instead of closing
        // the lobby. "hostleft" only ever comes from an old relay build.
        if (m.t === "youhost") { becomePromotedHost(m.left); return; }
        if (m.t === "newhost") {
          if (m.left && players[m.left]) { players[m.left].off = true; renderScores(); }
          // If our hello was swallowed by the dying host (we joined during the
          // detection gap and never got seated), introduce ourselves again.
          if (!players[myId]) toHost({ t: "hello", name: myName, spectate: mySpec, avatar: myAv() });
          setStatus("Host left \u2014 " + (((players[m.id] || {}).name) || "another player") + " is now the host.");
          return;
        }
        if (m.t === "hostleft") { setStatus("Host left \u2014 lobby closed."); }
      };
      sock.onclose = function () {
        if (!opened) setStatus("Couldn't reach the relay \u2014 check the URL (and that the worker is deployed).");
        else if (!leftIntentionally && lobby) showDisconnected();
        if (ws === sock) ws = null;
      };
      sock.onerror = function () { if (!opened) setStatus("Couldn't reach the relay \u2014 check the URL."); };
    }

    // The relay promoted THIS client to host (the old host disconnected). The
    // players/scores/settings/log are already mirrored locally, and the filter
    // panel has been kept in sync via roomSel — so the host role can simply be
    // picked up. The one thing that can't continue is a question mid-read: its
    // answer key lived only on the old host, so it's cancelled cleanly.
    function becomePromotedHost(leftId) {
      if (isHost || !lobby) return;
      isHost = true;
      hostLocalSpeed = null;
      roomConfig = null;   // hostNext reads this (already-synced) panel instead
      mpPre = { key: "", q: null, busy: false };
      if (leftId && players[leftId]) players[leftId].off = true;
      var hadQ = !!current && !ended;
      stopClientRead(); stopAutoSub(); stopReveal(); stopAnswerTimer(); stopTick(); stopBuzzWindowTimer(); stopBonusTimer();
      current = null; hostQ = null; ended = false; pendingBuzzer = null; paused = false;
      bonusState = null; bonusView = null; bonusPending = false;
      // Only rebuild the page when it's actually on screen — renderRoom
      // borrows the REAL #filters-panel, and doing that from a background page
      // would yank the panel out from under the practice screen the player is
      // using. When they return, onShow renders with the host UI.
      if (active()) render();
      broadcast({ t: "qreset" });   // reset clients BEFORE the announcement lands
      sysChat("The host left — " + myName + " is the new host" + (hadQ ? " (that question was cancelled — press N)" : ""));
      pushState();
      mpPrefetchNow();   // this machine serves questions now — fetch ahead
    }

    function becomeClient(hostId) {
      isHost = false; peer = new window.Peer();
      peer.on("open", function (pid) {
        myId = pid;
        hostConn = peer.connect(hostId, { reliable: true });
        hostConn.on("open", function () { hostConn.send({ t: "hello", name: myName, spectate: mySpec, avatar: myAv() }); render(); });
        hostConn.on("data", onClientData);
        hostConn.on("close", function () { setStatus("Host left — lobby closed."); });
      });
      peer.on("error", function (err) {
        if (lobby && !leftIntentionally && err && (err.type === "network" || err.type === "disconnected" || err.type === "socket-error")) { showDisconnected(); return; }
        setStatus("Error: " + (err && err.type || err));
      });
    }
    function onHostConn(conn) {
      conn.on("open", function () { conns.push(conn); });
      conn.on("data", function (d) { onHostData(conn, d); });
      conn.on("close", function () {
        conns = conns.filter(function (c) { return c !== conn; });
        hostPeerGone(conn.peer);
      });
    }

    // A player left (either transport): keep their seat and score so a rejoin
    // under the same name continues where they left off; abandon their bonus.
    function hostPeerGone(id) {
      var p = players[id];
      if (p && !p.off) { p.off = true; sysChat(p.name + " disconnected \u2014 seat and score saved"); pushState(); }
      if (bonusState && id === bonusState.winner) {
        bonusState = null; stopBonusTimer();
        sysChat("Bonus abandoned \u2014 the answerer left.");
        broadcast({ t: "bcancel" }); applyBonusCancel();
      }
    }

    // ── host: handle messages from clients ──
    function onHostData(conn, d) {
      var id = conn.peer;
      if (d.t === "hello") {
        if (locked) { try { conn.send({ t: "locked" }); } catch (e) {} return; }
        // Same name = same person, but only an OFFLINE seat can be reclaimed:
        // never the host's own entry, never a connected player's (a live name
        // collision gets a numbered name instead of stealing the seat).
        var wantName = String(d.name || "").trim().toLowerCase();
        var sameName = function (x) { return x !== id && x !== myId && players[x] && String(players[x].name).trim().toLowerCase() === wantName; };
        var oldId = wantName ? order.find(function (x) { return sameName(x) && players[x].off; }) : null;
        if (oldId) {
          var seat = players[oldId];
          delete players[oldId];
          order[order.indexOf(oldId)] = id;
          seat.id = id;
          seat.off = false;
          seat.spec = !!d.spectate;
          if (d.avatar) seat.avatar = d.avatar;
          players[id] = seat;
          if (bonusState && bonusState.winner === oldId) bonusState.winner = id;
          if (pendingBuzzer === oldId) pendingBuzzer = id;
          if (lockedIds[oldId]) { lockedIds[id] = lockedIds[oldId]; delete lockedIds[oldId]; }
          sysChat(seat.name + " rejoined");
        } else {
          var joinName = String(d.name || "").trim();
          var hostClash = joinName && players[myId] && String(players[myId].name).trim().toLowerCase() === wantName;
          if (joinName && (hostClash || order.some(sameName))) {
            var base = joinName, n = 2;
            var taken = function (nm) {
              var low = nm.trim().toLowerCase();
              return order.some(function (x) { return x !== id && players[x] && String(players[x].name).trim().toLowerCase() === low; });
            };
            while (taken(base + " (" + n + ")")) n++;
            joinName = base + " (" + n + ")";
          }
          addPlayer(id, joinName || d.name, "", d.spectate, d.avatar);
          sysChat(players[id].name + " joined" + (d.spectate ? " (spectating)" : ""));
        }
        pushState();
        // bring the newcomer up to speed
        sessionLog.forEach(function (e) { conn.send({ t: "logentry", entry: e }); });
        if (current) {
          conn.send(questionMsg());
          var reading = !paused && !pendingBuzzer && !ended && revealIdx < current.text.length;
          conn.send({ t: "read", from: revealIdx, speed: reading ? Math.max(8, curRevealSpeed) : 0 });
          // A bonus is in progress — replay it (and its judged parts) so the
          // newcomer sees the bonus UI, not a frozen tossup.
          if (bonusState && bonusView) {
            conn.send({ t: "bonus", leadin: bonusView.leadin, parts: bonusView.parts, winner: bonusView.winner, name: bonusView.name, secs: settings.answerSeconds || 10 });
            (bonusView.results || []).forEach(function (rp) { if (rp) conn.send(rp); });
          }
        }
      }
      else if (d.t === "chat") {
        if (d.chan === "team") relayTeamChat(id, players[id] ? players[id].name : "?", d.text);
        else relayChat(players[id] ? players[id].name : "?", d.text);
      }
      else if (d.t === "setName") { if (players[id]) { var old = players[id].name; players[id].name = d.name || old; sysChat(old + " is now " + players[id].name); pushState(); } }
      else if (d.t === "setTeam") { if (players[id]) { players[id].team = d.team || ""; pushState(); } }
      else if (d.t === "setSetting") { settings[d.key] = d.val; sysChat((players[id] ? players[id].name : "?") + " " + describeSetting(d.key, d.val)); pushState(); }
      else if (d.t === "setConfig") {
        if (d.config) { roomConfig = roomConfig || {}; ["filters", "strictness", "revealSpeed", "hidePron", "filterSummary"].forEach(function (k) { if (d.config[k] !== undefined) roomConfig[k] = d.config[k]; }); if (d.config.filterSummary != null) filterSummary = d.config.filterSummary; }
        if (d.change) sysChat((players[id] ? players[id].name : "?") + " " + d.change);
        mpPre.q = null;   // the prefetched tossup no longer matches the filters
        mpPrefetchNow();  // queue one for the NEW filters right away
        // Mirror the sender's panel selection into the HOST panel — hostNext
        // reads this panel, and without the mirror the host's next local edit
        // would silently clobber the client's change.
        // roomConfig keeps the SENDER's values (merged above) — recomputing it
        // from the host panel here would discard the client's strictness /
        // reading-speed / set-mode edits, which the sel snapshot doesn't carry.
        if (d.config && d.config.sel && ctx.host && ctx.host.applyFilterSelectionSnapshot) {
          _lastSelJson = JSON.stringify(d.config.sel);
          var selGen = ++_hostSelGen;
          Promise.resolve(ctx.host.applyFilterSelectionSnapshot(d.config.sel)).catch(function () {}).then(function () {
            if (selGen !== _hostSelGen) return;   // a newer edit superseded this apply — it will broadcast
            broadcast(stateMsg()); renderFilterSummary();
          });
          return;
        }
        broadcast(stateMsg()); renderFilterSummary();
      }
      else if (d.t === "typing") {
        if (id === pendingBuzzer || (bonusState && id === bonusState.winner)) {
          var _tx = String(d.text || "").slice(0, 120);
          liveTyped = _tx;   // the timeout fallback submits this, not ""
          broadcast({ t: "typing", id: id, text: _tx });   // the typer ignores its own echo
          applyTyping(id, _tx);
        }
      }
      else if (d.t === "buzz") { hostHandleBuzz(id); }
      else if (d.t === "answer") { if (id === pendingBuzzer) hostHandleAnswer(id, d.text); }
      else if (d.t === "reqNext") { if (!players[id] || players[id].spec) return; hostNext(players[id].name); }
      else if (d.t === "banswer") { if (bonusState && id === bonusState.winner) hostHandleBonusAnswer(id, d.text, d.k); }
      else if (d.t === "pause") { hostTogglePause(id); }
    }

    // ── host: game flow ──
    function questionMsg() { return { t: "question", q: { id: current.id, text: current.text }, count: qCount }; }

    // "Select set by name" mode → serve the packet's tossups in order (1, 2, …).
    var setQueue = null, setIndex = 0, setSig = "";
    async function nextSetQuestion(f) {
      var sig = (f.setNames || []).join("|") + "::" + (f.packetNumbers || []).join(",");
      if (sig !== setSig) {
        setSig = sig; setIndex = 0; setQueue = [];
        var setName = f.setNames[0];
        var packets = f.packetNumbers && f.packetNumbers.length ? f.packetNumbers : null;
        if (!packets) {
          try { packets = ((await ctx.api.get("/api/packets-for-set?setName=" + encodeURIComponent(setName))).packets || []).map(function (p) { return p.packet_number; }); } catch (e) { packets = []; }
        }
        for (var i = 0; i < packets.length; i++) {
          try { var pc = await ctx.api.get("/api/packet-content?setName=" + encodeURIComponent(setName) + "&packetNumber=" + packets[i]); setQueue = setQueue.concat(pc.tossups || []); } catch (e) {}
        }
      }
      if (!setQueue.length) { setStatus("No questions found in that set."); return null; }
      if (setIndex >= setQueue.length) { setStatus("Packet finished — no more questions."); sysChat("Packet finished — no more questions."); return null; }
      return setQueue[setIndex++];
    }

    // MODE > "Imported packet file" → serve the file's tossups in order; with
    // "TU + bonus" each tossup carries its same-index bonus.
    var impIndex = 0, impSig = "";
    function nextImportQuestion() {
      var pk = (ctx.host && ctx.host.getImportedPacket) ? ctx.host.getImportedPacket() : null;
      if (!pk) { setStatus("Choose a packet file in MODE first (export one from Packet Builder)."); return null; }
      if (!pk.tossups.length) { setStatus("That packet file has no tossups."); return null; }
      var sig = pk.name + "::" + pk.mode + "::" + pk.tossups.length + "/" + pk.bonuses.length;
      if (sig !== impSig) { impSig = sig; impIndex = 0; }
      if (impIndex >= pk.tossups.length) { setStatus("Imported packet finished \u2014 no more tossups."); sysChat("Imported packet finished."); return null; }
      var i = impIndex++;
      var q = Object.assign({}, pk.tossups[i]);
      if (pk.mode === "both" && pk.bonuses[i]) q._mpBonus = pk.bonuses[i];
      filterSummary = "Imported packet: " + pk.name + " (TU " + (i + 1) + "/" + pk.tossups.length + (pk.mode === "both" ? ", with bonuses" : "") + ")";
      return q;
    }

    // Any player may advance: after a question ends it's a plain "next"; mid-
    // question it's a SKIP and only allowed when skips are on (host included).
    function requestNext() {
      if (isHost) { hostNext(); return; }
      toHost({ t: "reqNext" });
    }
    function skipsAllowed() {
      var cfgSkip = (ctx.host && ctx.host.getPracticeConfig) ? ctx.host.getPracticeConfig() : {};
      return !(cfgSkip && cfgSkip.allowSkips === false);
    }
    async function hostNext(byName) {
      if (!isHost || bonusState || bonusPending) return;
      // Never advance while a buzz is live or being judged — the in-flight
      // verdict would otherwise land on (and instantly end) the NEXT question.
      if (pendingBuzzer || answerJudging) { setStatus("Someone is answering — wait for the verdict."); return; }
      if (current && !ended) {
        if (!skipsAllowed()) { setStatus("Skips are off (OPTIONS) \u2014 finish this question first."); return; }
        if (byName) sysChat(byName + " skipped the question");
      }
      hostFinalize();
      // Reuse the host's Tossups Practice filters + strictness + reading speed.
      var cfg = roomConfig || ((ctx.host && ctx.host.getPracticeConfig) ? ctx.host.getPracticeConfig() : { filters: {}, strictness: 10, revealSpeed: 25, filterSummary: "" });
      curRevealSpeed = cfg.revealSpeed != null ? cfg.revealSpeed : 25;
      curStrictness = cfg.strictness != null ? cfg.strictness : 10;
      curStopPower = !!cfg.stopOnPower;
      filterSummary = cfg.filterSummary || "All categories";
      var f = cfg.filters || {};
      curFilters = f;
      try {
        var q;
        var modeSel = document.getElementById("mode-select");
        // Weighted mode re-rolls per question: a stored roomConfig froze the
        // ONE category rolled at edit time, which would serve every question
        // from a single category. The host panel mirrors every edit (sel
        // sync), so it is safe to re-derive the roll live.
        var wEl = document.getElementById("enable-cat-weights");
        if (roomConfig && wEl && wEl.checked && (!modeSel || modeSel.value === "random") && !(f.setNames && f.setNames.length) && ctx.host && ctx.host.getPracticeConfig) {
          try { f = ctx.host.getPracticeConfig().filters || f; curFilters = f; } catch (e2) {}
        }
        if (modeSel && modeSel.value === "import") {
          q = nextImportQuestion();                // imported packet file
          if (!q) return;                          // status already set
        } else if (f.setNames && f.setNames.length) {
          q = await nextSetQuestion(f);           // ordered set mode
          if (!q) return;                          // status already set
        } else {
          // Serve the prefetched tossup when it matches the current filters —
          // pressing N renders instantly; the next one loads in the background.
          // (Weighted mode matches on "W": the queued question carries its own
          // fresh roll, drawn from the same distribution.)
          var qkey = weightedOn() ? "W" : filtersToQuery(f);
          if (mpPre.q && mpPre.key === qkey) { q = mpPre.q; mpPre.q = null; }
          else {
            var data = await ctx.api.get("/api/tossups/random?" + filtersToQuery(f));
            q = data.tossup;
            if (!q) { setStatus("No question matches your Tossups filters."); return; }
          }
        }
        hostQ = q;
        qCount++;
        var rawText = (q.question_sanitized || q.question || "").replace(/\s+/g, " ").trim();
        if (cfg.hidePron && ctx.host.stripPronunciations) rawText = ctx.host.stripPronunciations(rawText).replace(/\s+/g, " ").trim();
        var pIdx = rawText.indexOf("(*)");
        curPowerEnd = pIdx > 0 ? rawText.slice(0, pIdx).trim().length : 0;
        var text = rawText.split("(*)").join(" ").replace(/\s+/g, " ").trim();
        startQuestion({ id: q.id, text: text });
        broadcast(questionMsg());
        broadcast(stateMsg());            // sync the filter summary
        renderFilterSummary();
        beginReveal();
        // Preload the NEXT question while this one reads (mpPrefetchNext
        // no-ops in set/import modes — those are in-memory queues already).
        mpPrefetchNext(f);
        if (settings.bonusEvery && !q._mpBonus) prefetchBonusFor(q);
      } catch (e) { setStatus("Couldn't load question: " + (e.message || e)); }
    }
    // ── host-side preloading ──
    // Weighted mode note: each question is its own category roll, so an exact
    // filter-key match would NEVER hit. Instead the prefetch itself draws a
    // fresh roll and stores under the "W" key — the queued question follows
    // the same weighted distribution as an on-demand one, so serving it is
    // statistically identical. Any panel edit clears mpPre either way.
    function weightedOn() {
      var w = document.getElementById("enable-cat-weights");
      var ms = document.getElementById("mode-select");
      return !!(w && w.checked && (!ms || ms.value === "random"));
    }
    function mpPrefetchNext(f) {
      if (!isHost) return;
      var ms = document.getElementById("mode-select");
      if (ms && ms.value === "import") return;               // ordered local queue
      if (f && f.setNames && f.setNames.length) return;      // ordered local queue
      var wt = weightedOn();
      if (wt && ctx.host && ctx.host.getPracticeConfig) {
        try { f = ctx.host.getPracticeConfig().filters || f; } catch (e) {}
      }
      var key = wt ? "W" : filtersToQuery(f);
      if (mpPre.busy || (mpPre.q && mpPre.key === key)) return;
      mpPre.busy = true;
      ctx.api.get("/api/tossups/random?" + filtersToQuery(f)).then(function (data) {
        mpPre.busy = false;
        var q = data && data.tossup;
        if (q && (!hostQ || q.id !== hostQ.id)) { mpPre.key = key; mpPre.q = q; }
      }).catch(function () { mpPre.busy = false; });
    }
    // Fetch ahead as soon as this machine is hosting (room created, promoted,
    // or filters settled) — the FIRST press of N should be instant too.
    function mpPrefetchNow() {
      try { if (isHost && ctx.host && ctx.host.getPracticeConfig) mpPrefetchNext(((roomConfig || ctx.host.getPracticeConfig()) || {}).filters || {}); } catch (e) {}
    }
    // With "bonus after every question" on, fetch the matching bonus while the
    // tossup is still being read, so a correct buzz starts the bonus instantly.
    function prefetchBonusFor(q) {
      ctx.api.get("/api/bonuses/random?" + bonusQueryForTossup()).then(function (data) {
        var b = data && data.bonus;
        if (b && hostQ === q && !q._mpBonus && !bonusState) q._mpBonusPre = b;
      }).catch(function () {});
    }

    function startQuestion(q) {
      qGen++; answerJudging = false;   // void any in-flight verdict from the previous question
      resetTyping();
      current = q; ended = false; pendingBuzzer = null; revealIdx = 0;
      lockedTeams = {}; lockedIds = {}; buzzHistory = []; buzzCharMarks = []; paused = false;
      bonusState = null; bonusView = null; bonusPending = false; pausedAtPower = false;
      stopAnswerTimer(); stopTick(); stopBuzzWindowTimer(); stopReveal(); stopBonusTimer(); stopAutoSub();
      renderQuestion(); renderBuzzes(); updateTopBar();
    }
    var bwTimer = null, bwDeadline = 0;
    function stopBuzzWindowTimer() { if (bwTimer) { clearTimeout(bwTimer); bwTimer = null; } }
    // Question finished reading → everyone gets a buzz window; if nobody
    // buzzes before it runs out, the question goes dead.
    function hostStartBuzzWindow() {
      if (!isHost || ended || pendingBuzzer) return;
      stopBuzzWindowTimer();
      var secs = settings.buzzWindow || 10;
      bwDeadline = Date.now() + secs * 1000;
      broadcast({ t: "buzzwin", secs: secs });
      applyBuzzWindow(bwDeadline);
      bwTimer = setTimeout(function () {
        if (ended || pendingBuzzer) return;
        ended = true;
        var payload = { t: "result", id: "", name: "", correct: false, points: 0, given: "", index: revealIdx, answer: hostQ ? (hostQ.answer_sanitized || "") : "", answerRaw: hostQ ? hostQ.answer : "", history: buzzHistory, ended: true, fullText: current ? current.text : "", noBuzz: true, category: hostQ ? (hostQ.category || "") : "" };
        broadcast(payload); applyResult(payload); pushState();
        stopReveal(); hostFinalize();
      }, secs * 1000);
    }
    function applyBuzzWindow(deadline) {
      var buzz = body && body.querySelector("#mp-buzz"); if (!buzz) return;
      buzz.className = "buzz-area";
      buzz.innerHTML = '<div class="buzz-hints">Question finished \u2014 buzz now! <span id="mp-timer"></span></div><div class="mp-timer-bar"><div id="mp-timer-fill"></div></div>';
      startTick(deadline, (settings.buzzWindow || 10) * 1000);
    }

    // Clock-synced reading: ONE "read" message (start index + speed) and every
    // client animates locally. Buzz/pause/result/buzzwin messages carry the
    // authoritative index, so clients re-sync at every event.
    function beginReveal() {
      stopReveal();
      if (curRevealSpeed === 0) {
        // Instant reading still honours "Stop on power": hold at the mark;
        // resuming (P) reveals the rest instantly.
        if (curStopPower && curPowerEnd > 0 && !pausedAtPower && revealIdx < curPowerEnd) {
          revealIdx = curPowerEnd;
          broadcast({ t: "read", from: revealIdx, speed: 0 });
          applyReveal(revealIdx);
          pausedAtPower = true;
          paused = true;
          sysChat("Stopped at power \u2014 press P to resume");
          broadcast({ t: "pause", paused: true, idx: revealIdx });
          applyPause(true);
          return;
        }
        revealIdx = current.text.length; broadcast({ t: "read", from: revealIdx, speed: 0 }); applyReveal(revealIdx); hostStartBuzzWindow(); return;
      }
      broadcast({ t: "read", from: revealIdx, speed: Math.max(8, curRevealSpeed) });
      // TIME-BASED reveal: the index follows the wall clock, not the number of
      // interval fires — a busy host machine can no longer fall behind its own
      // clients' text. (The old ticker also ran getPracticeConfig — two full
      // panel scans — per CHARACTER on the host and nothing on clients, which
      // is exactly why nonhosts used to see the question sooner.)
      var tickMs = Math.max(8, curRevealSpeed);
      var t0 = Date.now(), base = revealIdx, lastCfg = 0;
      revealTimer = setInterval(function () {
        // While held, keep sliding the baseline so resuming never jumps ahead.
        if (paused || pendingBuzzer || ended) { t0 = Date.now(); base = revealIdx; return; }
        var nowT = Date.now();
        // Live speed / stop-on-power: sample at most twice a second — far too
        // expensive to run per character.
        if (nowT - lastCfg > 500) {
          lastCfg = nowT;
          try {
            var cfg = ctx.host.getPracticeConfig && ctx.host.getPracticeConfig();
            if (cfg && typeof cfg.stopOnPower === "boolean") curStopPower = cfg.stopOnPower;
            // Restart only when the HOST moves their own slider — comparing
            // against curRevealSpeed would instantly revert a client's speed edit.
            if (cfg && typeof cfg.revealSpeed === "number") {
            if (hostLocalSpeed === null) hostLocalSpeed = cfg.revealSpeed;
            if (cfg.revealSpeed !== hostLocalSpeed) {
              hostLocalSpeed = cfg.revealSpeed;
              curRevealSpeed = cfg.revealSpeed;
              beginReveal();
              return;
            }
            }
          } catch (e) {}
        }
        if (revealIdx >= current.text.length) { stopReveal(); hostStartBuzzWindow(); return; }
        var want = Math.min(current.text.length, base + Math.floor((nowT - t0) / tickMs));
        // Catching up must not blow past the power mark — stop exactly on it.
        if (curStopPower && curPowerEnd > 0 && !pausedAtPower && revealIdx < curPowerEnd && want > curPowerEnd) want = curPowerEnd;
        if (want <= revealIdx) return;
        revealIdx = want;
        applyReveal(revealIdx);
        // Stop on power: pause at the power mark (everyone), resume with P.
        if (curStopPower && curPowerEnd > 0 && revealIdx >= curPowerEnd && !pausedAtPower && revealIdx < current.text.length) {
          pausedAtPower = true;
          paused = true;
          sysChat("Stopped at power \u2014 press P to resume");
          broadcast({ t: "pause", paused: true, idx: revealIdx });
          applyPause(true);
        }
      }, tickMs);
    }

    // ── client-side reading ticker (driven by the host's "read" message) ──
    var clientReadTimer = null;
    function stopClientRead() { if (clientReadTimer) { clearInterval(clientReadTimer); clientReadTimer = null; } }
    function clientStartRead(from, speed) {
      stopClientRead();
      if (typeof from === "number") revealIdx = from;
      applyReveal(revealIdx);
      if (!current || !speed) return;   // speed 0 ⇒ hold at "from" (instant reveal sends from = full length)
      // Same wall-clock pacing as the host's reveal, so both texts track the
      // same clock regardless of tick jitter on either machine.
      var tickMs = Math.max(8, speed);
      var t0 = Date.now(), base = revealIdx;
      clientReadTimer = setInterval(function () {
        // While held, slide the baseline so a resume never leaks unread text.
        if (paused || ended || !current) { t0 = Date.now(); base = revealIdx; return; }
        if (revealIdx >= current.text.length) { stopClientRead(); return; }
        var want = Math.min(current.text.length, base + Math.floor((Date.now() - t0) / tickMs));
        if (want <= revealIdx) return;
        revealIdx = want;
        applyReveal(revealIdx);
      }, tickMs);
    }
    function stopReveal() { if (revealTimer) { clearInterval(revealTimer); revealTimer = null; } }

    function hostHandleBuzz(id) {
      if (!current || ended || pendingBuzzer || paused) return;
      var p = players[id]; if (!p) return;
      if (p.spec) return; // spectators never buzz
      if (lockedIds[id]) return;
      if (p.team && lockedTeams[p.team]) return;
      pendingBuzzer = id;
      pendingPrompted = false;
      liveTyped = "";
      stopReveal();
      stopBuzzWindowTimer();
      var secs = settings.answerSeconds || 10;
      answerDeadline = Date.now() + secs * 1000;
      // Send REMAINING SECONDS (not an absolute timestamp) so clients compute
      // the deadline on their own clock — clock skew between machines would
      // otherwise make the countdown show 0 or a wrong number.
      broadcast({ t: "buzz", id: id, name: p.name, index: revealIdx, secs: secs });
      applyBuzz(id, p.name, revealIdx, answerDeadline);
      startAnswerTimer();
    }
    // The host timer is a FALLBACK: the answering client submits whatever it
    // has typed at the deadline (armAutoSub), so the extra 1.5s here is grace
    // for that message to arrive before the host closes the buzz with "".
    function startAnswerTimer() { if (answerTimer) clearTimeout(answerTimer); answerTimer = setTimeout(function () { if (pendingBuzzer) hostHandleAnswer(pendingBuzzer, liveTyped); }, (settings.answerSeconds || 10) * 1000 + 1500); }
    function stopAnswerTimer() { if (answerTimer) { clearTimeout(answerTimer); answerTimer = null; } }
    function stopTick() { if (tickTimer) { clearInterval(tickTimer); tickTimer = null; } }

    // answerJudging + qGen mirror the bonus path's judging guard: the client's
    // auto-submitted answer and the host's fallback "" can otherwise BOTH be in
    // flight for the same buzz (double-judged score, double lockout), and a
    // question change during the await must void the verdict entirely.
    var answerJudging = false, qGen = 0;
    var liveTyped = "";   // host: the answerer's last live-typed text (fallback submission)
    async function hostHandleAnswer(id, text) {
      if (id !== pendingBuzzer || answerJudging) return;
      answerJudging = true;
      var myGen = qGen;
      stopAnswerTimer();
      var p = players[id]; if (!p) { pendingBuzzer = null; answerJudging = false; return; }
      var res;
      try {
        res = await ctx.api.post("/api/check-tossup", { questionId: hostQ.id, answer: text, buzzPosition: revealIdx, fullyRead: revealIdx >= current.text.length, strictness: curStrictness || 10, allowPrompt: !pendingPrompted, record: false });
      } catch (e) { res = { correct: false, points: 0, answer: hostQ.answer_sanitized }; }
      // The question advanced or the buzz was resolved elsewhere while we
      // were judging — this verdict belongs to a dead world; drop it.
      if (myGen !== qGen || id !== pendingBuzzer) { answerJudging = false; return; }
      answerJudging = false;
      // Prompt: ask the same player to be more specific (one prompt per buzz).
      if (res && res.prompted && !pendingPrompted) {
        pendingPrompted = true;
        var ask = (res.prompt && res.prompt.ask) || "";
        var psecs = settings.answerSeconds || 10;
        answerDeadline = Date.now() + psecs * 1000; // fresh window for the prompt
        liveTyped = "";   // fresh window, fresh live text
        sysChat(p.name + " was prompted");
        broadcast({ t: "prompt", id: id, name: p.name, ask: ask, secs: psecs });
        applyPrompt(id, p.name, ask, answerDeadline);
        startAnswerTimer();
        return;
      }
      var correct = !!res.correct, points = res.points || 0;
      p.score = (p.score || 0) + points;
      buzzHistory.push({ name: p.name, correct: correct, points: points, given: text, index: revealIdx });
      pendingBuzzer = null;
      if (!correct && !settings.rebuzz) { if (p.team) lockedTeams[p.team] = true; else lockedIds[id] = true; }
      // With rebuzzes off, if everyone is now locked out, end the question.
      var deadEnd = !correct && !settings.rebuzz && allLockedOut();
      var payload = { t: "result", id: id, name: p.name, correct: correct, points: points, given: text, index: revealIdx, answer: res.answer || hostQ.answer_sanitized, answerRaw: hostQ.answer || "", history: buzzHistory };
      if (correct || deadEnd) { ended = true; payload.ended = true; payload.fullText = current.text; payload.category = hostQ ? (hostQ.category || "") : ""; }
      broadcast(payload); applyResult(payload); pushState();
      if (ended) {
        stopReveal(); hostFinalize();
        if (correct) maybeStartBonus(id);
      }
      else if (current && revealIdx >= current.text.length) { hostStartBuzzWindow(); }
      else { broadcast({ t: "reading" }); beginReveal(); }
    }

    // ── bonus phase (host): ONLY the tossup winner answers; all watch ──
    // Decide whether a bonus follows this (correct) tossup, and on what.
    function maybeStartBonus(winnerId) {
      // Imported "TU + bonus" packets already pair a bonus to the tossup.
      if (hostQ && hostQ._mpBonus) { hostStartBonus(winnerId); return; }
      if (!settings.bonusEvery) return;
      // Prefetched while the tossup was reading — kept SEPARATE from _mpBonus
      // so toggling "bonus after every question" off mid-question still wins.
      if (hostQ && hostQ._mpBonusPre) { hostQ._mpBonus = hostQ._mpBonusPre; hostStartBonus(winnerId); return; }
      // Otherwise draw a random bonus matching the same filters as the tossup.
      bonusPending = true;
      ctx.api.get("/api/bonuses/random?" + bonusQueryForTossup()).then(function (data) {
        bonusPending = false;
        var b = data && data.bonus;
        // Still on the same (ended) question, and nobody advanced meanwhile?
        if (b && hostQ && ended && !bonusState) { hostQ._mpBonus = b; hostStartBonus(winnerId); }
        else if (!b) sysChat("No bonus matched the filters \u2014 skipping.");
      }).catch(function () { bonusPending = false; });
    }
    // A random bonus that genuinely matches the served tossup: same category
    // (and difficulty when known), regardless of how the tossup was picked.
    function bonusQueryForTossup() {
      var parts = ["random=1", "limit=1"];
      if (hostQ && hostQ.category) parts.push("categories=" + encodeURIComponent(hostQ.category));
      if (hostQ && hostQ.difficulty != null && hostQ.difficulty !== "") parts.push("difficulties=" + hostQ.difficulty);
      return parts.join("&");
    }
    function stopBonusTimer() { if (bonusTimer) { clearTimeout(bonusTimer); bonusTimer = null; } }
    function startBonusTimer() {
      stopBonusTimer();
      // +1.5s grace: the winner's client auto-submits their typed text at the
      // deadline; this fallback only fires if that message never arrives.
      bonusTimer = setTimeout(function () { if (bonusState) hostHandleBonusAnswer(bonusState.winner, liveTyped, bonusState.k); }, (settings.answerSeconds || 10) * 1000 + 1500);
    }
    function hostStartBonus(winnerId) {
      var b = hostQ._mpBonus, p = players[winnerId];
      if (!b || !p) return;
      bonusParts = []; bonusAnswers = []; bonusRawAnswers = [];
      try { bonusParts = JSON.parse(b.parts_sanitized || "[]"); } catch (e) {}
      try { bonusAnswers = JSON.parse(b.answers_sanitized || "[]"); } catch (e) {}
      try { bonusRawAnswers = JSON.parse(b.answers || "[]"); } catch (e) {}
      if (!bonusParts.length) return;
      bonusState = { winner: winnerId, k: 0, got: 0 };
      liveTyped = "";
      sysChat(p.name + " earned the bonus");
      var msg = { t: "bonus", leadin: b.leadin_sanitized || "", parts: bonusParts, winner: winnerId, name: p.name, secs: settings.answerSeconds || 10 };
      broadcast(msg); applyBonus(msg);
      startBonusTimer();
    }
    async function hostHandleBonusAnswer(id, text, k) {
      if (!bonusState || id !== bonusState.winner || bonusState.judging) return;
      // A late answer for an already-scored part (the +1.5s fallback advanced
      // it) must not be judged against the NEXT part's answerline.
      if (k != null && bonusState.k !== k) return;
      stopBonusTimer();
      var k = bonusState.k;
      bonusState.judging = true;   // re-entrancy guard across the await
      var ok = false;
      try {
        var r = await ctx.api.post("/api/evaluate-answer", { answerline: bonusRawAnswers[k] || "", sanitized: bonusAnswers[k] || "", answer: text, strictness: curStrictness || 10 });
        ok = r.status === "accept" || r.status === "prompt";
      } catch (e) {}
      // The winner may have left, the bonus may have been cancelled, or a new
      // question may have started during the await — bail if state moved on.
      if (!bonusState || bonusState.winner !== id || bonusState.k !== k) return;
      bonusState.judging = false;
      var p = players[id];
      if (ok && p) { bonusState.got++; p.score = (p.score || 0) + 10; }
      var done = k + 1 >= bonusParts.length;
      bonusState.k++;
      liveTyped = "";   // next part starts with a clean slate
      var msg = { t: "bpart", k: k, ok: ok, given: text, answer: bonusAnswers[k] || "", answerRaw: bonusRawAnswers[k] || "", done: done, got: bonusState.got, secs: settings.answerSeconds || 10 };
      broadcast(msg); applyBonusPart(msg); pushState();
      if (done) { sysChat((p ? p.name : "?") + " bonus: " + (bonusState.got * 10) + "/" + (bonusParts.length * 10)); bonusState = null; }
      else startBonusTimer();
    }
    function allLockedOut() {
      var active = order.filter(function (id) { return players[id] && !players[id].spec && !players[id].off; });
      return active.length > 0 && active.every(function (id) {
        var p = players[id];
        return lockedIds[id] || (p && p.team && lockedTeams[p.team]);
      });
    }
    function hostTogglePause(who) {
      if (bonusState || bonusPending) { return; }   // no pausing during a bonus
      paused = !paused;
      var nm = (players[who] && players[who].name) || (who === myId ? myName : "Someone");
      sysChat(nm + (paused ? " paused the game" : " resumed the game"));
      broadcast({ t: "pause", paused: paused, idx: revealIdx }); applyPause(paused);
      if (!paused && !pendingBuzzer && !ended) beginReveal();
    }
    function describeSetting(key, val) {
      var label = key === "answerSeconds" ? "Answer Time" : key === "buzzWindow" ? "Buzz Window" : key === "rebuzz" ? "Rebuzzes" : key === "bonusEvery" ? "Bonus after every question" : key;
      return "changed " + label + " to " + val;
    }

    // Finalize the current question into the shared session log (host only).
    function hostFinalize() {
      if (!isHost || !current || current._logged) return;
      current._logged = true;
      var entry = {
        qid: (hostQ && hostQ.id) || (current && current.id) || "",
        text: current.text,
        answer: (hostQ && (hostQ.answer_sanitized || hostQ.answer)) || "",
        answerRaw: (hostQ && hostQ.answer) || "",
        category: (hostQ && hostQ.category) || "",
        difficulty: (hostQ && hostQ.difficulty) != null ? hostQ.difficulty : "",
        buzzes: buzzHistory.slice(),
        marks: buzzCharMarks.slice(),
      };
      sessionLog.push(entry); broadcast({ t: "logentry", entry: entry }); renderSessionLog();
    }

    // ── client: handle messages from host ──
    function onClientData(d) {
      if (d.t === "state") {
        players = {}; order = []; (d.players || []).forEach(function (p) { players[p.id] = p; order.push(p.id); });
        settings = d.settings || settings;
        if (d.filterSummary != null) filterSummary = d.filterSummary;
        // Full panel mirror when the host sends one (app 14.2+); the lossy
        // toggle-only sync is the fallback for older hosts. Deduped: state is
        // re-broadcast on every score change, and re-applying an unchanged
        // selection would thrash the panel while this player is mid-edit.
        if (d.roomSel) {
          var sj = JSON.stringify(d.roomSel);
          if (sj !== _lastSelJson) { _lastSelJson = sj; applyRemoteSel(d.roomSel); }
        } else if (d.roomFilters) applyRoomFiltersToPanel(d.roomFilters);
        renderScores(); renderSettings(); renderFilterSummary(); updateTopBar();
      }
      else if (d.t === "chat") { addChat(d.name, d.text, d.sys, d.chan === "team"); }
      else if (d.t === "question") { stopClientRead(); stopAutoSub(); current = d.q; if (typeof d.count === "number") qCount = d.count; ended = false; pendingBuzzer = null; revealIdx = 0; buzzHistory = []; buzzCharMarks = []; paused = false; bonusView = null; renderQuestion(); renderBuzzes(); updateTopBar(); }
      else if (d.t === "read") { clientStartRead(d.from, d.speed); }
      else if (d.t === "reveal") { revealIdx = d.index; applyReveal(d.index); }  // legacy hosts
      else if (d.t === "buzz") { stopClientRead(); if (typeof d.index === "number") { revealIdx = d.index; applyReveal(revealIdx); } answerDeadline = Date.now() + ((d.secs || settings.answerSeconds || 10) * 1000); applyBuzz(d.id, d.name, d.index, answerDeadline); }
      else if (d.t === "buzzwin") { stopClientRead(); if (current) { revealIdx = current.text.length; applyReveal(revealIdx); } applyBuzzWindow(Date.now() + ((d.secs || settings.buzzWindow || 10) * 1000)); }
      else if (d.t === "result") { stopClientRead(); if (typeof d.index === "number" && !d.ended) revealIdx = d.index; buzzHistory = d.history || buzzHistory; if (d.ended) ended = true; applyResult(d); renderBuzzes(); }
      else if (d.t === "reading") { /* the host's "read" message restarts the local ticker */ }
      else if (d.t === "pause") { paused = d.paused; if (typeof d.idx === "number") { revealIdx = d.idx; applyReveal(revealIdx); } applyPause(d.paused); }
      else if (d.t === "prompt") { answerDeadline = Date.now() + ((d.secs || settings.answerSeconds || 10) * 1000); applyPrompt(d.id, d.name, d.ask, answerDeadline); }
      else if (d.t === "typing") { if (d.id !== myId) applyTyping(d.id, d.text); }
      else if (d.t === "logentry") { sessionLog.push(d.entry); renderSessionLog(); }
      else if (d.t === "locked") { leftIntentionally = true; setStatus("That lobby is locked \u2014 ask the host to unlock it."); ctx.toast("Lobby is locked", "error"); leave(); }
      else if (d.t === "config") { if (d.config) { filterSummary = d.config.filterSummary || filterSummary; } renderFilterSummary(); }
      else if (d.t === "bonus") { applyBonus(d); }
      else if (d.t === "bpart") { applyBonusPart(d); }
      else if (d.t === "bcancel") { applyBonusCancel(); }
      // A promoted host cancelled the question that was mid-read when the old
      // host vanished — reset the question area (scores and log are kept).
      // render only when visible — renderRoom borrows the filters panel and
      // must never steal it from a practice screen in the foreground.
      else if (d.t === "qreset") { stopClientRead(); stopAutoSub(); current = null; ended = false; pendingBuzzer = null; bonusView = null; paused = false; if (active()) render(); }
    }

    // ── local actions (sent to host or handled if host) ──
    function requestBuzz() {
      if (!current || ended) return;
      if (players[myId] && players[myId].spec) { ctx.toast("You're spectating \u2014 no buzzing", "error"); return; }
      ctx.playSound("buzz");
      if (isHost) hostHandleBuzz(myId); else toHost({ t: "buzz" });
    }
    function requestPause() { if (isHost) hostTogglePause(myId); else toHost({ t: "pause" }); }
    function submitAnswer(text) { if (isHost) hostHandleAnswer(myId, text); else toHost({ t: "answer", text: text }); }
    function changeName(name) { myName = name; try { ctx.setSetting("name", name); } catch (e) {} if (isHost) { var old = players[myId].name; players[myId].name = name; sysChat(old + " is now " + name); pushState(); } else toHost({ t: "setName", name: name }); }
    function changeTeam(team) { if (isHost) { players[myId].team = team; pushState(); } else toHost({ t: "setTeam", team: team }); }
    function changeSetting(key, val) { settings[key] = val; if (isHost) { sysChat(myName + " " + describeSetting(key, val)); pushState(); } else toHost({ t: "setSetting", key: key, val: val }); renderSettings(); }
    function teamOf(id) { var p = players[id]; return (p && p.team) || ""; }
    function sendChat(text) {
      if (!text) return;
      if (chatScope === "team") {
        var tm = teamOf(myId);
        if (!tm) { chatScope = "all"; syncChatScope(); ctx.toast("Set a team first to use team chat", "error"); return; }
        if (isHost) relayTeamChat(myId, myName, text);
        else toHost({ t: "chat", text: text, chan: "team" });
      } else {
        if (isHost) relayChat(myName, text);
        else toHost({ t: "chat", text: text });
      }
    }
    function syncChatScope() {
      if (chatScope === "team" && !teamOf(myId)) chatScope = "all";   // team was cleared
      var cs = body && body.querySelector("#mp-chat-scope");
      var ci = body && body.querySelector("#mp-chat-input");
      if (cs) { cs.textContent = chatScope === "team" ? "Team" : "All"; cs.classList.toggle("mp-scope-team", chatScope === "team"); }
      if (ci) ci.placeholder = chatScope === "team" ? "Message your team…" : "Message everyone…";
    }

    // ── chat (host relays so every message appears exactly once) ──
    function relayChat(name, text) { var m = { t: "chat", name: name, text: text }; broadcast(m); addChat(name, text); }
    // Team chat: the host sends the message ONLY to that team's members (and
    // shows it itself when it's on the team) — nobody else ever receives it.
    function sendToTeam(team, m) {
      order.forEach(function (x) {
        if (x === myId || !players[x] || players[x].off) return;
        if ((players[x].team || "") !== team) return;
        if (useRelay) relayConn(x).send(m);
        else { for (var i = 0; i < conns.length; i++) { if (conns[i].peer === x) { try { conns[i].send(m); } catch (e) {} break; } } }
      });
    }
    function relayTeamChat(fromId, name, text) {
      var team = teamOf(fromId);
      if (!team) { relayChat(name, text); return; }   // no team ⇒ everyone
      var m = { t: "chat", name: name, text: text, chan: "team", team: team };
      sendToTeam(team, m);
      if (teamOf(myId) === team) addChat(name, text, false, true);
    }
    function sysChat(text) { if (!isHost) return; var m = { t: "chat", name: "", text: text, sys: true }; broadcast(m); addChat("", text, true); }
    // Chat history lives in this array, not just the DOM — renderRoom rebuilds
    // the page (host promotion, rejoin, resize) and replays it, so messages
    // survive every re-render.
    var chatHist = [];
    function paintChatMsg(el, c) {
      var r = document.createElement("div");
      r.className = "mp-chat-msg" + (c.s ? " mp-chat-sys" : "") + (c.m ? " mp-chat-team" : "");
      r.innerHTML = c.s ? esc(c.x) : (c.m ? '<span class="mp-chat-teamtag">TEAM</span> ' : "") + "<strong>" + esc(c.n) + ":</strong> " + esc(c.x);
      el.appendChild(r);
    }
    function addChat(name, text, sys, team) {
      chatHist.push({ n: name, x: text, s: !!sys, m: !!team });
      if (chatHist.length > 200) chatHist.shift();
      var el = body && body.querySelector("#mp-chat"); if (!el) return;
      paintChatMsg(el, chatHist[chatHist.length - 1]);
      el.scrollTop = el.scrollHeight;
    }
    function replayChat() {
      var el = body && body.querySelector("#mp-chat"); if (!el) return;
      el.innerHTML = "";
      chatHist.forEach(function (c) { paintChatMsg(el, c); });
      el.scrollTop = el.scrollHeight;
    }

    // ── top bar (mirrors practice: counter + score pills) ──
    function updateTopBar() {
      if (!page || !page.screenEl) return;
      var titleEl = page.screenEl.querySelector(".top-bar-title");
      if (titleEl) titleEl.textContent = lobby ? ("MULTIPLAYER: " + lobby.toUpperCase()) : "MULTIPLAYER";
      var right = page.screenEl.querySelector(".top-bar-right");
      if (!right) return;
      right.querySelectorAll(".mp-topbar").forEach(function (n) { n.remove(); });
      if (!lobby) return;
      var me = players[myId] || { score: 0 };
      var frag = document.createElement("span");
      frag.innerHTML =
        (isHost ? '<span class="pill mp-topbar">host</span>' : "") +
        '<span class="pill pill-green mp-topbar">Score: ' + (me.score || 0) + "</span>" +
        '<button class="btn btn-sm btn-ghost mp-topbar" id="mp-leave-top">Leave</button>';
      while (frag.firstChild) right.insertBefore(frag.firstChild, right.querySelector("button:last-child"));
      var lt = right.querySelector("#mp-leave-top"); if (lt) lt.onclick = leave;
    }

    // ── rendering ──
    function render() { if (!body) return; if (!lobby) renderForm(); else renderRoom(); updateTopBar(); }
    function setStatus(m) { var s = body && body.querySelector("#mp-status"); if (s) s.textContent = m; }

    function renderForm() {
      myName = ctx.getSetting("name") || ("Player" + Math.floor(Math.random() * 1000));
      body.innerHTML =
        '<div class="practice-layout">' +
          '<main class="question-area">' +
            '<div class="question-placeholder">' +
              '<div class="placeholder-icon"><svg viewBox="0 0 24 24" width="42" height="42" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M9.6 9.2a2.6 2.6 0 1 1 3.7 2.5c-.9.4-1.3 1-1.3 1.8v.3"/><circle cx="12" cy="17" r="0.9" fill="currentColor" stroke="none"/></svg></div>' +
              '<h2 style="margin:0 0 8px">Join a multiplayer lobby</h2>' +
              '<div class="mp-join-form">' +
                '<input id="mp-name" class="mode-input" placeholder="Your name" value="' + esc(myName) + '" autocomplete="off">' +
                '<input id="mp-lobby" class="mode-input" placeholder="Lobby name" autocomplete="off">' +
                // One shrink-wrapped column so both boxes share a left edge.
                // Centring each row independently put them at different x
                // positions, because the two labels are different lengths.
                '<div class="mp-optcol">' +
                  '<label class="checkbox-row"><input type="checkbox" id="mp-spectate"> Join as spectator</label>' +
                  '<label class="checkbox-row" title="Connects players directly instead of through the relay \u2014 lower latency, but strict school/work networks may block it"><input type="checkbox" id="mp-p2p"' + (ctx.getSetting("p2p") ? " checked" : "") + "> Direct P2P (lower latency)</label>" +
                "</div>" +
                '<button class="btn btn-primary btn-full" id="mp-join">Join Lobby</button>' +
                '<div class="text-muted" id="mp-status" style="font-size:12px;min-height:16px"></div>' +
              "</div>" +
            "</div>" +
          "</main>" +
        "</div>";
      var nameEl = body.querySelector("#mp-name");
      body.querySelector("#mp-join").onclick = function () {
        myName = (nameEl.value.trim()) || myName;
        ctx.setSetting("name", myName); // remember for next time
        lobby = body.querySelector("#mp-lobby").value.trim();
        mySpec = !!body.querySelector("#mp-spectate").checked;
        ctx.setSetting("p2p", !!body.querySelector("#mp-p2p").checked);
        if (!lobby) { setStatus("Enter a lobby name."); return; }
        join();
      };
    }

    // MP-specific controls injected into the (borrowed) filter panel — kept to
    // just TWO sections (Lobby + Game) to avoid heading clutter.
    function lobbySectionHtml() {
      // Lobby info + your name/team in one section.
      return '<div class="filter-section mp-injected">' +
        '<div class="filter-label">LOBBY: ' + esc(lobby) + (isHost ? ' <span class="pill">host</span>' : "") + "</div>" +
        '<label class="mode-field"><span>Your name</span><input id="mp-myname" class="mode-input" autocomplete="off"></label>' +
        (mySpec ? '<div class="text-muted" style="font-size:11px">Spectating \u2014 watching & chat only.</div>'
                : '<label class="mode-field"><span>Team</span><input id="mp-myteam" class="mode-input" placeholder="(none)" autocomplete="off"></label>') +
        '<div class="text-muted" id="mp-status" style="font-size:11px;min-height:14px;margin-top:4px"></div>' +
        '<div class="text-muted" id="mp-filter-summary" style="font-size:11px;margin-top:2px"></div>' +
        "</div>";
    }
    function controlsSectionsHtml() {
      // One "GAME" section. The answer timer + rebuzz toggle are editable by
      // EVERYONE and kept in sync (clients send setSetting to the host, the
      // host re-broadcasts state). Only "Next Question" is host-only.
      return '<div class="filter-section mp-injected"><div class="filter-label">GAME</div>' +
        '<div class="slider-group"><span style="font-size:11px;min-width:78px" title="Time to type an answer after buzzing">Answer time</span><input type="range" id="mp-ans" min="3" max="30" step="1" value="' + (settings.answerSeconds) + '"><span class="slider-value" id="mp-ans-val">' + (settings.answerSeconds) + "s</span></div>" +
        '<div class="slider-group" style="margin-top:6px"><span style="font-size:11px;min-width:78px" title="Time to buzz once the question finishes reading">Buzz window</span><input type="range" id="mp-bwin" min="3" max="30" step="1" value="' + (settings.buzzWindow || 10) + '"><span class="slider-value" id="mp-bwin-val">' + (settings.buzzWindow || 10) + "s</span></div>" +
        '<label class="checkbox-row"><input type="checkbox" id="mp-rebuzz" ' + (settings.rebuzz ? "checked" : "") + "> Allow rebuzzes</label>" +
        '<label class="checkbox-row" title="After every correct tossup, the winner answers a random bonus"><input type="checkbox" id="mp-bonusevery" ' + (settings.bonusEvery ? "checked" : "") + "> Bonus after every question</label>" +
        (isHost
          ? '<label class="checkbox-row"><input type="checkbox" id="mp-stoppow"' + (practiceChecked("opt-stop-on-power", false) ? " checked" : "") + "> Stop on power</label>" +
            '<label class="checkbox-row"><input type="checkbox" id="mp-skips"' + (practiceChecked("opt-allow-skips", true) ? " checked" : "") + "> Allow skips</label>" +
            '<label class="checkbox-row" title="When on, new players cannot join this lobby"><input type="checkbox" id="mp-lock"' + (locked ? " checked" : "") + "> Lock room</label>" +
            ''
          : "") +
        "</div>";
    }

    function renderRoom() {
      // Always return any borrowed panel before re-rendering (innerHTML wipes it).
      returnPanel();
      body.innerHTML =
        '<div class="practice-layout">' +
          // ── LEFT: the host borrows the REAL practice filter panel (inserted
          //    below); clients see a read-only summary. ──
          '<div class="resize-handle"></div>' +
          // ── CENTRE: question area (identical to practice) ──
          '<main class="question-area">' +
            '<div class="question-placeholder" id="mp-placeholder">' +
              '<div class="placeholder-icon"><svg viewBox="0 0 24 24" width="42" height="42" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M9.6 9.2a2.6 2.6 0 1 1 3.7 2.5c-.9.4-1.3 1-1.3 1.8v.3"/><circle cx="12" cy="17" r="0.9" fill="currentColor" stroke="none"/></svg></div>' +
              "<p>" + (isHost ? "Press [N] to read the first question." : "Waiting for the host to start…") + "</p>" +
            "</div>" +
            '<div class="question-content hidden" id="mp-content">' +
              '<div class="question-meta" id="mp-meta"></div>' +
              '<div class="question-text" id="mp-qtext"></div>' +
            "</div>" +
            '<div class="buzz-area hidden" id="mp-buzz"></div>' +
            '<div class="result-area hidden" id="mp-result"></div>' +
            '<div class="history-panel">' +
              '<div class="history-panel-header"><span class="history-panel-title">BUZZES THIS QUESTION</span></div>' +
              '<div class="history-list" id="mp-buzzes"></div>' +
            "</div>" +
            // Same control the practice screen uses: it opens the app's OWN
            // session-history overlay (filters, compact/expand, buzz track,
            // star + save) instead of a multiplayer-only imitation.
            '<div class="history-panel" id="mp-history-panel" style="display:none">' +
              '<button class="btn btn-full" id="mp-history-open">Session history (<span id="mp-history-count">0</span>)</button>' +
            "</div>" +
          "</main>" +
          // ── RIGHT: stats-panel style scoreboard + chat (drag-resizable) ──
          '<div class="resize-handle" data-resize="next"></div>' +
          '<aside class="stats-panel mp-rightpanel">' +
            '<div class="mp-scores" id="mp-scores"></div>' +
            '<div class="mp-chatwrap">' +
              '<div class="filter-label">CHAT</div>' +
              '<div class="mp-chat" id="mp-chat"></div>' +
              '<div class="mp-chatrow">' +
                '<button class="btn btn-sm btn-ghost mp-chat-scope" id="mp-chat-scope" title="Switch between chatting with everyone and only your team">All</button>' +
                '<input id="mp-chat-input" class="mode-input" placeholder="Message everyone…" autocomplete="off">' +
              "</div>" +
            "</div>" +
          "</aside>" +
        "</div>";

      // Chat is always present in the right panel — wire it once.
      var ci = body.querySelector("#mp-chat-input");
      if (ci) ci.addEventListener("keydown", function (e) { if (e.key === "Enter") { sendChat(ci.value.trim()); ci.value = ""; } });
      var cscope = body.querySelector("#mp-chat-scope");
      if (cscope) cscope.onclick = function () {
        if (chatScope === "all") {
          if (!teamOf(myId)) { ctx.toast("Set a team first to use team chat", "error"); return; }
          chatScope = "team";
        } else chatScope = "all";
        syncChatScope();
        if (ci) ci.focus();
      };
      syncChatScope();
      replayChat();

      var histBtn = body.querySelector("#mp-history-open");
      if (histBtn) histBtn.onclick = openMpHistory;

      // Host: borrow the real practice filter panel as the left column and inject
      // the MP-specific sections (lobby/timer/you/next/hints) around its filters.
      borrowPanel(body.querySelector(".practice-layout"));

      renderScores(); renderSettings(); renderFilterSummary();
      if (current) { renderQuestion(); renderBuzzes(); }
      renderSessionLog();
    }

    // Wire the MP control sections (lobby/you/timer/next) wherever they live.
    // Mirror a GAME-section checkbox onto the real practice OPTIONS checkbox
    // (which lives in the host's DOM) so app settings + persistence stay true.
    function practiceChecked(id, dflt) {
      var el = document.getElementById(id);
      return el ? el.checked : dflt;
    }
    function bindMirror(mpId, realId) {
      var el = body.querySelector("#" + mpId);
      if (!el) return;
      el.addEventListener("change", function () {
        var real = document.getElementById(realId);
        if (real) { real.checked = el.checked; real.dispatchEvent(new Event("change")); }
      });
    }

    function wireControls() {
      bindMirror("mp-stoppow", "opt-stop-on-power");
      bindMirror("mp-skips", "opt-allow-skips");
      var nameInp = body.querySelector("#mp-myname");
      if (nameInp) { nameInp.value = (players[myId] || {}).name || myName; nameInp.addEventListener("change", function () { changeName(nameInp.value.trim() || myName); }); }
      var teamInp = body.querySelector("#mp-myteam");
      if (teamInp) { teamInp.value = (players[myId] || {}).team || ""; teamInp.addEventListener("change", function () { changeTeam(teamInp.value.trim()); }); }
      var an = body.querySelector("#mp-ans");
      if (an) { an.addEventListener("input", function (e) { body.querySelector("#mp-ans-val").textContent = e.target.value + "s"; }); an.addEventListener("change", function (e) { changeSetting("answerSeconds", parseInt(e.target.value) || 10); }); }
      var bw = body.querySelector("#mp-bwin");
      if (bw) { bw.addEventListener("input", function (e) { body.querySelector("#mp-bwin-val").textContent = e.target.value + "s"; }); bw.addEventListener("change", function (e) { changeSetting("buzzWindow", parseInt(e.target.value) || 10); }); }
      var rb = body.querySelector("#mp-rebuzz");
      if (rb) rb.addEventListener("change", function (e) { changeSetting("rebuzz", e.target.checked); });
      var be = body.querySelector("#mp-bonusevery");
      if (be) be.addEventListener("change", function (e) { changeSetting("bonusEvery", e.target.checked); });
      var lk = body.querySelector("#mp-lock");
      if (lk) lk.addEventListener("change", function (e) { locked = e.target.checked; sysChat(myName + (locked ? " locked the room" : " unlocked the room")); });
      var nx = body.querySelector("#mp-next"); if (nx) nx.onclick = function () { requestNext(); };
    }

    // Move the real practice filter panel into the multiplayer layout (host only).
    function borrowPanel(layout) {
      if (!layout) return;
      try { if (ctx.host && ctx.host.ensureFiltersLoaded) ctx.host.ensureFiltersLoaded(); } catch (e) {}
      var panel = document.getElementById("filters-panel");
      if (!panel) return;
      // Practice-only bits don't apply here: MP's GAME timers rule the room,
      // and packet-game is a solo mode.
      var gameOpt = document.querySelector('#mode-select option[value="game"]');
      if (gameOpt) { gameOpt.hidden = true; gameOpt.disabled = true; }
      if (!panelHome) panelHome = { parent: panel.parentNode, next: panel.nextSibling };
      panel.classList.add("mp-borrowed");
      layout.insertBefore(panel, layout.firstChild);
      borrowedPanel = panel;
      // inject MP sections: YOU + lobby at top, controls at bottom
      var top = document.createElement("div"); top.innerHTML = lobbySectionHtml();
      while (top.firstChild) panel.insertBefore(top.firstChild, panel.firstChild);
      var bottom = document.createElement("div"); bottom.innerHTML = controlsSectionsHtml();
      while (bottom.firstChild) panel.appendChild(bottom.firstChild);
      wireControls();
      // Log the host's filter changes (categories, difficulty, year, strictness…)
      // to chat and re-sync the summary to everyone.
      panel.addEventListener("change", onAnyFilterChange, true);
      panel.addEventListener("input", onAnyFilterChange, true);
    }
    var _filterTimer = null;
    // Describe a specific control change for the chat log, e.g.
    // "Warren changed Mythology to true" or "Warren changed difficulty to 2,3,4".
    function describeFilterChange(t) {
      if (!t) return "";
      var diffs = function () { return [].slice.call(document.querySelectorAll("#difficulty-filters .diff-checkbox:checked")).map(function (c) { return c.value; }).join(","); };
      if (t.classList && (t.classList.contains("diff-checkbox"))) return "changed difficulty to " + (diffs() || "none");
      if (t.classList && (t.classList.contains("cat-checkbox") || t.classList.contains("subcat-checkbox") || t.classList.contains("altsub-checkbox"))) return "changed " + (t.value || "category") + " to " + (t.checked ? "true" : "false");
      if (t.classList && (t.classList.contains("cat-weight") || t.classList.contains("subcat-weight") || t.classList.contains("altsub-weight"))) {
        var lbl = t.closest(".filter-item"); var nm = lbl ? (lbl.querySelector("span:not(.cat-expand):not(.text-muted):not(.altsub-expand)") || {}).textContent : "";
        return "changed " + (nm || "weight").trim() + " to " + t.value;
      }
      if (t.id === "year-min" || t.id === "year-max") { var lo = document.getElementById("year-min"), hi = document.getElementById("year-max"); var a = parseInt(lo.value), b = parseInt(hi.value); return "changed years to " + Math.min(a, b) + "-" + Math.max(a, b); }
      if (t.id === "strictness-slider") return "changed strictness to " + t.value;
      if (t.id === "panel-speed-slider") return "changed reading speed to " + t.value;
      if (t.id === "enable-cat-weights") return "changed weights to " + (t.checked ? "true" : "false");
      if (t.id === "filter-standard") return "changed standard-only to " + (t.checked ? "true" : "false");
      if (t.id === "filter-powermark") return "changed powermarked-only to " + (t.checked ? "true" : "false");
      if (t.id === "mode-select") return "changed mode to " + t.value;
      if (t.id === "mode-set-name") return "changed set to " + (t.value || "(none)");
      if (t.id === "mode-packet") return "changed packet to " + (t.value || "all");
      return "";
    }
    // Anyone can edit the filters. The host stores them as roomConfig and uses
    // them for the next question; a client sends its config to the host.
    // Mirror the room's toggle-style filters into this client's borrowed panel,
    // so a later local edit doesn't silently clobber them (the classic case:
    // the host's "Powermark only" being wiped by any client filter tweak).
    var _applyingRemote = false;
    // Mirror the room's FULL panel selection (categories, subcategories,
    // alternate subcategories, difficulties, years, toggles) into this
    // player's panel via the base's lossless snapshot API. Newer snapshot
    // arriving mid-apply wins (the base serializes on its own generation).
    function applyRemoteSel(sel) {
      if (isHost || !sel) return;
      if (!(ctx.host && ctx.host.applyFilterSelectionSnapshot)) return;   // older base: roomFilters fallback already ran
      // The base serializes overlapping applies itself (newest wins), and the
      // apply fires no events — nothing to guard here.
      Promise.resolve(ctx.host.applyFilterSelectionSnapshot(sel)).catch(function () {});
    }
    function applyRoomFiltersToPanel(f) {
      if (isHost || !f) return;
      _applyingRemote = true;
      try {
        var pm = document.getElementById("filter-powermark"); if (pm) pm.checked = !!f.powermarkOnly;
        var st = document.getElementById("filter-standard"); if (st) st.checked = !!f.standard;
        var so = document.getElementById("filter-starred"); if (so) so.checked = !!f.starredOnly;
        if (f.yearMin != null) { var ym = document.getElementById("year-min"); if (ym) ym.value = f.yearMin; }
        if (f.yearMax != null) { var yx = document.getElementById("year-max"); if (yx) yx.value = f.yearMax; }
        if (Array.isArray(f.difficulties)) {
          var want = f.difficulties.map(String);
          document.querySelectorAll("#difficulty-filters .diff-checkbox").forEach(function (cb) { cb.checked = want.indexOf(String(cb.value)) >= 0; });
        }
      } catch (e) {}
      _applyingRemote = false;
    }
    function onAnyFilterChange(e) {
      // No remote-apply suppression here: applyFilterSelectionSnapshot fires
      // NO events, so any change/input landing during a remote apply is a REAL
      // user edit — swallowing it would desync that player's panel for good.
      if (e && e.target && e.target.closest && e.target.closest(".mp-injected")) return; // ignore MP's own controls
      var msg = describeFilterChange(e && e.target);
      clearTimeout(_filterTimer);
      _filterTimer = setTimeout(function () {
        if (!ctx.host || !ctx.host.getPracticeConfig) return;
        var cfg; try { cfg = ctx.host.getPracticeConfig(); } catch (e2) { return; }
        var sel = null;
        try { sel = ctx.host.getFilterSelectionSnapshot ? ctx.host.getFilterSelectionSnapshot() : null; } catch (e2) {}
        if (sel) _lastSelJson = JSON.stringify(sel);   // our own edit — don't re-apply it when it echoes back
        if (isHost) {
          roomConfig = cfg;
          filterSummary = cfg.filterSummary || "All categories";
          mpPre.q = null;               // the prefetched tossup no longer matches…
          mpPrefetchNext(cfg.filters || {});   // …so queue one for the NEW filters now
          if (msg) sysChat(myName + " " + msg);
          broadcast(stateMsg()); renderFilterSummary();
        } else {
          toHost({ t: "setConfig", config: { filters: cfg.filters, strictness: cfg.strictness, revealSpeed: cfg.revealSpeed, hidePron: cfg.hidePron, filterSummary: cfg.filterSummary, sel: sel }, change: msg });
        }
      }, 400);
    }
    // Put the panel back where it belongs and strip the injected MP sections.
    function returnPanel() {
      var gameOpt = document.querySelector('#mode-select option[value="game"]');
      if (gameOpt) { gameOpt.hidden = false; gameOpt.disabled = false; }
      if (!borrowedPanel) return;
      borrowedPanel.removeEventListener("change", onAnyFilterChange, true);
      borrowedPanel.removeEventListener("input", onAnyFilterChange, true);
      borrowedPanel.querySelectorAll(".mp-injected").forEach(function (n) { n.remove(); });
      borrowedPanel.classList.remove("mp-borrowed");
      if (panelHome) { panelHome.parent.insertBefore(borrowedPanel, panelHome.next); }
      borrowedPanel = null;
    }

    function renderFilterSummary() {
      var el = body && body.querySelector("#mp-filter-summary"); if (!el) return;
      if (isHost && ctx.host && ctx.host.getPracticeConfig) { try { filterSummary = ctx.host.getPracticeConfig().filterSummary || "All categories"; } catch (e) {} }
      el.textContent = filterSummary || "All categories";
    }

    function renderScores() {
      var el = body && body.querySelector("#mp-scores"); if (!el) return;
      var teams = {}, specs = [];
      order.forEach(function (id) {
        var p = players[id];
        if (p.spec) { specs.push(p); return; }
        (teams[p.team || ""] = teams[p.team || ""] || []).push(p);
      });
      var html = '<div class="filter-label">SCOREBOARD</div>';
      Object.keys(teams).sort().forEach(function (tn) {
        var roster = teams[tn].sort(function (a, b) { return (b.score || 0) - (a.score || 0); });
        if (tn) { var tot = roster.reduce(function (s, p) { return s + (p.score || 0); }, 0); html += '<div class="mp-team-row"><span>' + esc(tn) + "</span><strong>" + tot + "</strong></div>"; }
        roster.forEach(function (p) {
          var you = p.id === myId;
          html += '<div class="mp-score-row' + (tn ? " mp-indent" : "") + (you ? " mp-you" : "") + (p.off ? " mp-off" : "") + '">' +
            '<span>' + (p.avatar ? '<span class="mp-avatar">' + esc(p.avatar) + '</span> ' : '') + esc(p.name) + (you ? " (you)" : "") + (p.off ? " · offline" : "") + "</span><strong>" + (p.score || 0) + "</strong></div>";
        });
      });
      if (specs.length) {
        html += '<div class="filter-label" style="margin-top:8px">SPECTATORS</div>';
        specs.forEach(function (p) {
          var you = p.id === myId;
          html += '<div class="mp-score-row' + (you ? " mp-you" : "") + '"><span>\ud83d\udc41 ' + (p.avatar ? '<span class="mp-avatar">' + esc(p.avatar) + '</span> ' : '') + esc(p.name) + (you ? " (you)" : "") + "</span></div>";
        });
      }
      el.innerHTML = html;
      syncChatScope();   // team changes can invalidate the "Team" chat scope
    }

    // keep the left-panel rule controls in sync with shared settings
    function renderSettings() {
      if (!body) return;
      var an = body.querySelector("#mp-ans"); if (an && document.activeElement !== an) { an.value = settings.answerSeconds; var av = body.querySelector("#mp-ans-val"); if (av) av.textContent = settings.answerSeconds + "s"; }
      var bw2 = body.querySelector("#mp-bwin"); if (bw2 && document.activeElement !== bw2) { bw2.value = settings.buzzWindow || 10; var bv = body.querySelector("#mp-bwin-val"); if (bv) bv.textContent = (settings.buzzWindow || 10) + "s"; }
      var rb = body.querySelector("#mp-rebuzz"); if (rb) rb.checked = !!settings.rebuzz;
      var be = body.querySelector("#mp-bonusevery"); if (be) be.checked = !!settings.bonusEvery;
    }

    function renderQuestion() {
      clearPauseUi();   // a new question must never inherit the paused grey
      var ph = body && body.querySelector("#mp-placeholder"); if (ph) ph.classList.add("hidden");
      var content = body && body.querySelector("#mp-content"); if (content) content.classList.remove("hidden");
      var meta = body && body.querySelector("#mp-meta"); if (meta) meta.textContent = "";   // category stays hidden while reading
      applyReveal(revealIdx);
      var buzz = body && body.querySelector("#mp-buzz"); if (buzz) { buzz.className = "buzz-area hidden"; buzz.innerHTML = ""; }
      var res = body && body.querySelector("#mp-result"); if (res) { res.className = "result-area hidden"; res.innerHTML = ""; }
    }

    // Character-based reveal with (#) buzz marks — identical to practice.
    // Render the revealed text with (#) buzz marks. Your own buzzes use one
    // (themeable) color, everyone else's use another.
    function renderWithMarks(text, upTo, marks) {
      var list = (marks || []).filter(function (m) { return m.pos >= 0 && m.pos <= upTo; }).sort(function (a, b) { return a.pos - b.pos; });
      var out = "", last = 0;
      list.forEach(function (m) {
        out += esc(text.substring(last, m.pos)) + '<span class="buzz-mark ' + (m.by === myId ? "buzz-self" : "buzz-other") + '">(#)</span>';
        last = m.pos;
      });
      out += esc(text.substring(last, upTo));
      return out;
    }
    function applyReveal(idx) {
      var qt = body && body.querySelector("#mp-qtext"); if (!qt || !current) return;
      var text = current.text;
      var out = renderWithMarks(text, idx, buzzCharMarks);
      // Mask the unread text so it can't be read by highlighting (monospace font
      // + preserved whitespace keeps the wrapping identical).
      var rest = esc(text.substring(idx).replace(/\S/g, "·"));
      qt.innerHTML = '<span class="revealed">' + out + "</span>" + (rest ? '<span class="unrevealed" aria-hidden="true">' + rest + "</span>" : "");
    }

    function applyBuzz(id, name, idx, deadline) {
      var buzz = body && body.querySelector("#mp-buzz"); if (!buzz) return;
      if (id === myId) {
        buzz.className = "buzz-area";
        buzz.innerHTML =
          '<div class="buzz-prompt"><span class="prompt-symbol">&gt;</span>' +
          '<input type="text" id="mp-ans-input" placeholder="type answer and press Enter..." autocomplete="off" autocorrect="off" spellcheck="false"></div>' +
          '<div class="buzz-hints">You buzzed — <span id="mp-timer"></span></div>' +
          '<div class="mp-timer-bar"><div id="mp-timer-fill"></div></div>';
        var inp = buzz.querySelector("#mp-ans-input");
        var grab = function () { try { inp.focus({ preventScroll: true }); } catch (e2) { inp.focus(); } };
        grab(); requestAnimationFrame(grab); setTimeout(grab, 120);
        resetTyping();
        inp.addEventListener("input", function () { sendTyping(inp.value); });
        inp.addEventListener("keydown", function (e) { if (e.key === "Enter") { stopAutoSub(); inp.disabled = true; submitAnswer(inp.value.trim()); } });
        armAutoSub(inp, deadline, submitAnswer);
      } else {
        buzz.className = "buzz-area";
        buzz.innerHTML = '<div class="buzz-prompt"><span class="prompt-symbol">&gt;</span> <em id="mp-live-ph">' + esc(name) + " is answering…</em><span id=\"mp-live\" class=\"mp-live\"></span></div>" +
          '<div class="buzz-hints"><span id="mp-timer"></span></div>' +
          '<div class="mp-timer-bar"><div id="mp-timer-fill"></div></div>';
      }
      startTick(deadline);
    }

    function applyPrompt(id, name, ask, deadline) {
      var buzz = body && body.querySelector("#mp-buzz"); if (!buzz) return;
      if (id === myId) {
        buzz.className = "buzz-area";
        buzz.innerHTML =
          '<div class="buzz-prompt"><span class="prompt-symbol">&gt;</span>' +
          '<input type="text" id="mp-ans-input" placeholder="answer again…" autocomplete="off" autocorrect="off" spellcheck="false"></div>' +
          '<div class="buzz-hints"><span style="color:var(--yellow);font-weight:700">PROMPT' + (ask ? ":</span> " + esc(ask) : "</span>") + ' — <span id="mp-timer"></span></div>' +
          '<div class="mp-timer-bar"><div id="mp-timer-fill"></div></div>';
        var inp = buzz.querySelector("#mp-ans-input"); inp.focus();
        resetTyping();
        inp.addEventListener("input", function () { sendTyping(inp.value); });
        inp.addEventListener("keydown", function (e) { if (e.key === "Enter") { stopAutoSub(); inp.disabled = true; submitAnswer(inp.value.trim()); } });
        armAutoSub(inp, deadline || answerDeadline, submitAnswer);
      } else {
        buzz.className = "buzz-area";
        buzz.innerHTML = '<div class="buzz-prompt"><span class="prompt-symbol">&gt;</span> <em id="mp-live-ph">' + esc(name) + " is being prompted…</em><span id=\"mp-live\" class=\"mp-live\"></span></div>" +
          '<div class="buzz-hints"><span style="color:var(--yellow);font-weight:700">PROMPT' + (ask ? ":</span> " + esc(ask) : "</span>") + ' <span id="mp-timer"></span></div>' +
          '<div class="mp-timer-bar"><div id="mp-timer-fill"></div></div>';
      }
      startTick(deadline || answerDeadline);
    }

    // ── live typing: everyone watches the answerer type ──
    // The typer's input is COALESCED (one send per 150ms, whole value, capped
    // at 120 chars) and only flows while an answer window is open: the host
    // rebroadcasts it only from the current buzzer / bonus winner, so stale or
    // spoofed typing dies at the host.
    var _typeTimer = null, _typeLast = "", _typeSentAt = 0;
    function resetTyping() { if (_typeTimer) { clearTimeout(_typeTimer); _typeTimer = null; } _typeLast = ""; _typeSentAt = 0; }
    function _typeSend() {
      _typeSentAt = Date.now();
      if (isHost) broadcast({ t: "typing", id: myId, text: _typeLast });
      else toHost({ t: "typing", text: _typeLast });
    }
    function sendTyping(text) {
      text = String(text || "").slice(0, 120);
      if (text === _typeLast) return;
      _typeLast = text;
      var now = Date.now();
      // LEADING edge: the first keystroke (and any keystroke 150ms after the
      // last send) goes out synchronously — no timer, so background-tab timer
      // throttling can't delay it. Rapid typing coalesces via the trailer.
      if (now - _typeSentAt >= 150) { _typeSend(); return; }
      if (_typeTimer) return;
      _typeTimer = setTimeout(function () { _typeTimer = null; _typeSend(); }, Math.max(20, 150 - (now - _typeSentAt)));
    }
    function applyTyping(id, text) {
      var live = body && body.querySelector("#mp-live");
      var ph = body && body.querySelector("#mp-live-ph");
      if (!live) return;
      text = String(text || "").slice(0, 120);
      live.textContent = text;
      if (ph) ph.style.display = text ? "none" : "";
    }

    // ── timeout auto-submit (the answering machine owns the typed text) ──
    function stopAutoSub() { if (autoSubTimer) { clearTimeout(autoSubTimer); autoSubTimer = null; } }
    function armAutoSub(inp, deadline, submit) {
      stopAutoSub();
      var ms = Math.max(0, deadline - Date.now() - 150);   // beat the host's fallback
      autoSubTimer = setTimeout(function () {
        if (inp && !inp.disabled && document.contains(inp)) { inp.disabled = true; submit(inp.value.trim()); }
      }, ms);
    }

    function startTick(deadline, totalMs) {
      if (tickTimer) clearInterval(tickTimer);
      var total = totalMs || (settings.answerSeconds || 10) * 1000;
      function paint() {
        var t = body && body.querySelector("#mp-timer");
        var left = Math.max(0, deadline - Date.now());
        if (t) t.textContent = Math.ceil(left / 1000) + "s";
        var bar = body && body.querySelector("#mp-timer-fill");
        if (bar) bar.style.width = Math.max(0, Math.min(100, (left / total) * 100)) + "%";
      }
      paint();
      tickTimer = setInterval(paint, 100);
    }

    var _endedCategory = "";
    function applyResult(d) {
      stopAutoSub(); resetTyping();
      if (d.ended) clearPauseUi();
      if (tickTimer) { clearInterval(tickTimer); tickTimer = null; }
      if (d.ended) {
        _endedCategory = d.category || "";
        var meta = body && body.querySelector("#mp-meta");
        if (meta && _endedCategory) meta.textContent = _endedCategory;
      }
      if (typeof d.index === "number" && !d.noBuzz && d.id && !buzzCharMarks.some(function (m) { return m.pos === d.index && m.by === d.id; })) buzzCharMarks.push({ pos: d.index, by: d.id });
      // Each client records ITS OWN buzz to local stats — every ATTEMPT counts
      // (powers, tens, AND negs), exactly like solo play. Questions this
      // player never buzzed on are not recorded (there is no attempt to log).
      if (d.id && d.id === myId && current && current.id && !d._recorded) {
        d._recorded = true;
        ctx.playSound(d.correct ? "correct" : "incorrect");
        var _cel = (current.text && current.text.length) ? Math.max(0, Math.min(1, (d.index || 0) / current.text.length)) : 0;
        try {
          ctx.api.post("/api/check-tossup", {
            questionId: current.id, answer: d.given || "", buzzPosition: d.index || 0,
            sessionId: mpSession(), overriding: true, correct: !!d.correct,
            isPower: (d.points || 0) >= 15, points: d.points || 0, celerity: _cel,
          });
        } catch (e) {}
      }
      var buzz = body && body.querySelector("#mp-buzz"); if (buzz) { buzz.className = "buzz-area hidden"; buzz.innerHTML = ""; }
      applyReveal(d.ended ? (current ? current.text.length : revealIdx) : revealIdx);
      var res = body && body.querySelector("#mp-result"); if (!res) { renderBuzzes(); return; }
      if (d.ended) {
        res.className = "result-area";
        var banner = d.correct
          ? '<div class="result-banner correct">' + esc(d.name) + " — +" + d.points + " pts</div>"
          : d.noBuzz
            ? '<div class="result-banner incorrect">Time! Nobody buzzed.</div>'
            : '<div class="result-banner incorrect">Nobody got it — everyone is locked out</div>';
        res.innerHTML =
          banner +
          '<div class="result-answer">ANSWER: <span class="actual">' + ansHtml(d.answerRaw, d.answer || "") + "</span></div>" +
          '<div class="result-next">' + (isHost ? '<span class="text-muted">Press [N] for the next question</span>' : '<span class="text-muted">Waiting for host…</span>') + "</div>";
        var n2 = res.querySelector("#mp-next2"); if (n2) n2.onclick = function () { requestNext(); };
      } else {
        res.className = "result-area hidden"; res.innerHTML = "";
      }
      renderBuzzes();
    }

    // ── bonus phase (everyone): rendered under the tossup result. Parts are
    // revealed one at a time; only the winner gets an input box. Chat is in a
    // separate panel and stays fully usable throughout. ──
    function submitBonusAnswer(text, k) { if (isHost) hostHandleBonusAnswer(myId, text, k); else toHost({ t: "banswer", text: text, k: k }); }
    function applyBonus(d) {
      bonusView = { leadin: d.leadin, parts: d.parts || [], winner: d.winner, name: d.name, k: 0, got: 0, done: false, results: [] };
      renderBonusArea(d.secs);
    }
    function applyBonusPart(d) {
      if (!bonusView) return;
      bonusView.results[d.k] = d;
      bonusView.k = d.k + 1;
      bonusView.got = d.got;
      bonusView.done = !!d.done;
      renderBonusArea(d.done ? 0 : d.secs);
    }
    function applyBonusCancel() {
      if (bonusView) { bonusView.done = true; renderBonusArea(0); }
    }
    function renderBonusArea(secs) {
      var res = body && body.querySelector("#mp-result"); if (!res || !bonusView) return;
      res.className = "result-area";
      var el = res.querySelector("#mp-bonus");
      if (!el) { el = document.createElement("div"); el.id = "mp-bonus"; el.className = "mp-bonus"; res.appendChild(el); }
      var mine = bonusView.winner === myId;
      var html = '<div class="filter-label">BONUS \u2014 ' + esc(bonusView.name) + (mine ? " (you)" : "") + " answers</div>" +
        (bonusView.leadin ? '<div class="question-text" style="font-size:13px;min-height:0">' + esc(bonusView.leadin) + "</div>" : "");
      for (var k = 0; k < bonusView.parts.length && k <= bonusView.k; k++) {
        html += '<div class="mp-bpart"><div class="bonus-part-text">[10] ' + esc(bonusView.parts[k]) + "</div>";
        var r = bonusView.results[k];
        if (r) {
          html += '<div style="font-size:12px">' + (r.ok ? '<span class="bonus-verdict correct">\u2713 </span>' : '<span class="bonus-verdict incorrect">\u2717 </span>') +
            (r.given ? "\u201c" + esc(r.given) + "\u201d \u2014 " : "") + 'ANSWER: <span class="ans">' + ansHtml(r.answerRaw, r.answer) + "</span></div>";
        } else if (k === bonusView.k && !bonusView.done) {
          html += mine
            ? '<div class="buzz-prompt"><span class="prompt-symbol">&gt;</span><input type="text" class="mp-binput" placeholder="your answer\u2026 (Enter)" autocomplete="off" autocorrect="off" spellcheck="false"></div>'
            : '<div class="text-muted" style="font-size:12px"><em id="mp-live-ph">' + esc(bonusView.name) + " is answering\u2026</em><span id=\"mp-live\" class=\"mp-live\"></span></div>";
          html += '<div class="buzz-hints"><span id="mp-timer"></span></div><div class="mp-timer-bar"><div id="mp-timer-fill"></div></div>';
        }
        html += "</div>";
      }
      if (bonusView.done) html += '<div class="result-banner ' + (bonusView.got > 0 ? "correct" : "incorrect") + '" style="margin-top:2px">BONUS: ' + (bonusView.got * 10) + "/" + (bonusView.parts.length * 10) + "</div>";
      el.innerHTML = html;
      var inp = el.querySelector(".mp-binput");
      var myK = bonusView.k;   // pinned: a late submit must carry the part it answered
      if (inp) {
        inp.focus();
        resetTyping();
        inp.addEventListener("input", function () { sendTyping(inp.value); });
        inp.addEventListener("keydown", function (e) { if (e.key === "Enter") { stopAutoSub(); inp.disabled = true; submitBonusAnswer(inp.value.trim(), myK); } });
      }
      if (bonusView.done) { stopAutoSub(); if (tickTimer) { clearInterval(tickTimer); tickTimer = null; } }
      else if (secs) {
        var bd = Date.now() + secs * 1000;
        startTick(bd, secs * 1000);
        if (inp) armAutoSub(inp, bd, function (tx) { submitBonusAnswer(tx, myK); });
      }
    }

    function clearPauseUi() {
      var qt = body && body.querySelector("#mp-qtext"); if (qt) qt.classList.remove("paused-text");
      var ov = body && body.querySelector("#mp-pause-overlay"); if (ov) ov.remove();
    }
    function applyPause(p) {
      var qt = body && body.querySelector("#mp-qtext"); if (qt) qt.classList.toggle("paused-text", p);
      var area = body && body.querySelector(".question-area");
      var ov = body && body.querySelector("#mp-pause-overlay");
      if (p && area && !ov) {
        ov = document.createElement("div");
        ov.className = "pause-overlay"; ov.id = "mp-pause-overlay";
        ov.textContent = "PAUSED";
        area.appendChild(ov);
      } else if (!p && ov) ov.remove();
      var meta = body && body.querySelector("#mp-meta"); if (meta && current) meta.textContent = !p && ended && _endedCategory ? _endedCategory : "";
    }

    function buzzBadge(b) {
      return b.correct
        ? '<span class="pill pill-green">+' + b.points + "</span>"
        : (b.points < 0 ? '<span class="pill pill-red">' + b.points + "</span>" : '<span class="pill">' + b.points + "</span>");
    }

    function renderBuzzes() {
      var el = body && body.querySelector("#mp-buzzes"); if (!el) return;
      if (!buzzHistory.length) { el.innerHTML = '<div class="text-muted" style="padding:8px;font-size:12px">No buzzes yet this question.</div>'; return; }
      el.innerHTML = buzzHistory.map(function (b) {
        return '<div class="qcard" data-self-toggle><div class="qcard-head" style="cursor:default"><span class="qcard-meta"><span><strong>' + esc(b.name) + "</strong>: " + esc(b.given || "(no answer)") + "</span></span><span class=\"qcard-side\">" + buzzBadge(b) + "</span></div></div>";
      }).join("");
    }

    // Session history now uses the app's OWN overlay, so it looks and behaves
    // exactly like tossups/bonuses. This function only keeps the button's count
    // in sync; the list itself is built on demand by openMpHistory().
    var logCollapsed = {};   // kept for older call sites; the overlay owns view mode now
    var _qRowCache = {};     // question id -> full DB row (for real metadata + power mark)

    function renderSessionLog() {
      if (!body) return;
      var panel = body.querySelector("#mp-history-panel");
      var count = body.querySelector("#mp-history-count");
      if (count) count.textContent = String(sessionLog.length);
      if (panel) panel.style.display = sessionLog.length ? "" : "none";
    }

    // Turn one shared log entry into the shape the app's history overlay wants.
    // `me` is this client's own buzz on that question, if any \u2014 the card shows
    // YOUR result, matching how solo history reads.
    function mpEntryToHistory(e, q) {
      var buzzes = e.buzzes || [];
      var me = null;
      for (var i = 0; i < buzzes.length; i++) if (buzzes[i].name === myName) { me = buzzes[i]; break; }
      var shownLen = (e.text || "").length || 1;
      // MP reads a transformed string ((*) removed, whitespace collapsed), so a
      // raw index would not line up with the original. Carry the FRACTION over
      // instead and re-project onto the real question text.
      var frac = me && typeof me.index === "number" ? Math.max(0, Math.min(1, me.index / shownLen)) : 0;
      var realText = (q && q.question_sanitized) || "";
      var realLen = realText.replace(/\(\*\)/g, "").length || 0;
      var pts = me ? (me.points || 0) : 0;
      return {
        id: e.qid || "",
        type: "tossup",
        points: pts,
        correct: !!(me && me.correct),
        isPower: pts >= 15,
        celerity: frac,
        buzzPosition: me && realLen ? Math.round(frac * realLen) : 0,
        userAnswer: me ? (me.given || "") : "(no buzz)",
        answer: (q && q.answer_sanitized) || e.answer || "",
        question: q || {
          // No DB row (imported packet, or the fetch failed): fall back to what
          // the wire gave us so the card still renders.
          question_sanitized: e.text || "",
          answer: e.answerRaw || "",
          answer_sanitized: e.answer || "",
          category: e.category || "",
          difficulty: e.difficulty,
        },
      };
    }

    async function openMpHistory() {
      if (!(ctx.host && ctx.host.openSessionHistory)) {
        ctx.toast("Session history needs a newer app version", "error");
        return;
      }
      // Pull the real question rows once each \u2014 that is what gives the cards
      // their power mark, subcategory, set name and year, exactly like solo.
      var need = [];
      sessionLog.forEach(function (e) {
        if (e.qid && !(e.qid in _qRowCache) && need.indexOf(e.qid) < 0) need.push(e.qid);
      });
      if (need.length) {
        await Promise.all(need.map(function (id) {
          return ctx.api.get("/api/tossups/" + encodeURIComponent(id))
            .then(function (d) { _qRowCache[id] = (d && d.tossup) || null; })
            .catch(function () { _qRowCache[id] = null; });
        }));
      }
      var entries = sessionLog.map(function (e) { return mpEntryToHistory(e, e.qid ? _qRowCache[e.qid] : null); });
      ctx.host.openSessionHistory(entries, { title: "MULTIPLAYER HISTORY" });
    }

    function leave() {
      leftIntentionally = true;
      mpSessId = ""; // next game records to a fresh local stats session
      var dc = body && body.querySelector("#mp-disconnect"); if (dc) dc.remove();
      returnPanel();
      restoreSoloPanel();
      stopReveal(); stopAnswerTimer(); stopBonusTimer(); stopClientRead(); stopAutoSub();
      chatScope = "all"; mpPre = { key: "", q: null, busy: false }; _lastSelJson = ""; chatHist = [];
      bonusState = null; bonusView = null; bonusPending = false;
      try { if (peer) peer.destroy(); } catch (e) {}
      try { if (ws) { ws.onclose = null; ws.onmessage = null; ws.close(); } } catch (e) {}
      ws = null; useRelay = false; _relayConns = {};
      peer = null; hostConn = null; conns = []; isHost = false; current = null;
      players = {}; order = []; lobby = ""; qCount = 0; sessionLog = [];
      render();
    }

    ctx.toast("Multiplayer enabled");
  }
