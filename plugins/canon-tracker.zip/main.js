/**
 * OfflineQuiz plugin: Canon Tracker
 *
 * Quizbowl has a canon — answers that come up again and again. This plugin
 * measures YOUR coverage of it: for every category it pulls the most-asked
 * answers in the database and lines them up against your practice history,
 * showing what you've converted, what you've heard but missed, and what
 * you've never faced at all — then drills any answer with real questions.
 */
QB.registerPlugin({
  id: "canon-tracker",
  name: "Canon Tracker",
  version: "1.8.0",
  author: "OfflineQuiz",
  description: "See which common answers you've converted in each category, and drill the rest.",
  onEnable: __qbMain,
  onDisable: function (ctx) { if (ctx._cleanup) ctx._cleanup(); },
});
