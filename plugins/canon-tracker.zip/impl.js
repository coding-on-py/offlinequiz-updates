function __qbMain(ctx) {
  var body = null, page = null;
  function esc(s) { return (s == null ? "" : String(s)).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
  function norm(s) { return String(s || "").toLowerCase().replace(/[^a-z0-9]+/g, " ").trim(); }
  function loading(label) { return '<div class="ct-loading">' + (ctx.loadingBarHtml ? ctx.loadingBarHtml(label) : esc(label)) + "</div>"; }

  var IC = {
    play: '<path d="M7 4l13 8-13 8z"/>',
    left: '<path d="M15 6l-6 6 6 6"/>',
    right: '<path d="M9 6l6 6-6 6"/>',
    refresh: '<path d="M20 11a8 8 0 10-2.3 5.7M20 4v7h-7"/>',
  };
  function ic(name, size) {
    var s = size || 16;
    return '<svg width="' + s + '" height="' + s + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (IC[name] || "") + "</svg>";
  }
  var ROOT_COLOR = { "Literature": "#bc8cff", "Science and Math": "#58a6ff", "Fine Arts": "#f778ba", "History": "#e3b341", "Geography": "#56d364", "Mythology": "#ffa657", "Pop Culture Sports": "#ff7b72", "Social Science": "#3dd6a3", "Philosophy": "#39c5cf", "Theology": "#8e9bff", "Current Events": "#c9d16b", "Miscellaneous": "#8b949e" };

  // ── data ────────────────────────────────────────────────────────────────
  var CATS = [];                 // [{key, id, name}] — the category tree's roots
  var ALL_IDS = null;            // id -> 1 for every node of the tree (picker path)
  // QBReader-era root names a saved view may still hold → the new roots.
  var OLD_ROOT = { "Science": "Science and Math", "Religion": "Theology", "Pop Culture": "Pop Culture Sports", "Trash": "Pop Culture Sports", "Other Academic": "Miscellaneous" };
  var history = null;            // norm(answer) -> { heard, correct, negs, last }
  var OVERVIEW_N = 50;
  var FILTERS = [["all", "All"], ["missed", "Missed"], ["new", "Never heard"], ["got", "Converted"]];
  var view = { cat: "", topN: 100, filter: "all" };
  Object.assign(view, ctx.storage.get("view") || {});
  if (!FILTERS.some(function (f) { return f[0] === view.filter; })) view.filter = "all";
  delete view.hideDone;
  // A newer app chooses categories through its own picker: any mix of
  // subtrees, kept as node ids in view.cats. An older app (no picker API)
  // keeps the single root in view.cat and the clickable overview rows.
  var HAS_PICKER = !!(ctx.host && typeof ctx.host.categoryPicker === "function");
  var PICK = false;              // decided in boot(), once the tree has loaded
  var picker = null;             // the ctx.host.categoryPicker handle
  function saveView() { ctx.storage.set("view", view); }

  // Every answer the player has ever faced, keyed by the SAME normalization
  // the server uses for answer_norms — so canon rows match session history
  // as a set-membership test, not fuzzy matching.
  async function loadHistory() {
    var map = {};
    try {
      var d = await ctx.api.get("/api/sessions/all-entries?answers=1");
      (d.entries || []).forEach(function (e) {
        if (e.type !== "tossup" || !e.answer) return;
        (e.answer_norms || [norm(e.answer)]).forEach(function (k) {
          if (!k) return;
          var rec = map[k] = map[k] || { heard: 0, correct: 0, negs: 0, last: 0 };
          rec.heard++;
          if (e.correct) rec.correct++;
          if ((e.points || 0) < 0) rec.negs++;
          var t = new Date(e.timestamp).getTime() || 0;
          if (t > rec.last) rec.last = t;
        });
      });
    } catch (e) {}
    return map;
  }

  function catByKey(k) {
    for (var i = 0; i < CATS.length; i++) if (String(CATS[i].key) === String(k)) return CATS[i];
    return null;
  }
  function freqUrl(c, limit) {
    return "/api/frequent-answers?limit=" + limit + (c.id ? "&nodeId=" + encodeURIComponent(c.id) : "&category=" + encodeURIComponent(c.name));
  }
  // The union of the picked subtrees (none = the whole database).
  function freqUrlIds(ids, limit) {
    return "/api/frequent-answers?limit=" + limit + (ids.length ? "&nodeIds=" + ids.map(encodeURIComponent).join(",") : "");
  }
  async function loadCats() {
    var roots = null;
    try {
      if (ctx.host && ctx.host.getCategoryTree) roots = await ctx.host.getCategoryTree("tossups");
      else roots = (await ctx.api.get("/api/category-tree?type=tossups")).tree;
    } catch (e) { roots = null; }
    if (roots && roots.length) {
      ALL_IDS = {};
      (function walk(ns) { (ns || []).forEach(function (n) { if (n && n.id != null) { ALL_IDS[String(n.id)] = 1; walk(n.children); } }); })(roots);
      return roots.map(function (r) { return { key: r.id, id: r.id, name: r.name }; });
    }
    try {   // older base without the tree: level-1 names
      return ((await ctx.api.get("/api/categories?type=tossups")).categories || []).map(function (c) { return { key: c.category, id: null, name: c.category }; });
    } catch (e) { return []; }
  }
  // A saved view.cat from before the tree held a root NAME: map it once to
  // the new root's key, or fall back to the overview.
  function resolveViewCat() {
    if (!view.cat || !CATS.length || catByKey(view.cat)) return;
    var nm = OLD_ROOT[view.cat] || view.cat, hit = null;
    CATS.forEach(function (c) { if (!hit && c.name === nm) hit = c; });
    view.cat = hit ? hit.key : "";
    saveView();
  }
  // Picker path: view.cats is the list of picked node ids. A view saved
  // before the picker held ONE root (view.cat) — it becomes a one-element
  // list; ids the current tree no longer has are dropped.
  function resolveViewCats() {
    var had = JSON.stringify(view.cats);
    if (!Array.isArray(view.cats)) { view.cats = view.cat ? [String(view.cat)] : []; view.cat = ""; }
    view.cats = view.cats.filter(function (id, i, a) { return id != null && id !== "" && a.indexOf(id) === i; }).map(String);
    if (ALL_IDS) view.cats = view.cats.filter(function (id) { return ALL_IDS[id]; });
    if (JSON.stringify(view.cats) !== had) saveView();
  }
  function catsSig() { return (view.cats || []).join(","); }
  function picked() { return PICK && view.cats && view.cats.length > 0; }
  function setCats(ids) {
    view.cats = (ids || []).map(String);
    if (picker && JSON.stringify(picker.get()) !== JSON.stringify(view.cats)) picker.set(view.cats);
    saveView();
    render();
  }
  function ensurePicker() {
    if (picker) {
      if (JSON.stringify(picker.get()) !== JSON.stringify(view.cats || [])) picker.set(view.cats || []);
      return picker;
    }
    if (!PICK) return null;
    try {
      picker = ctx.host.categoryPicker(null, {
        selected: view.cats || [],
        type: "tossups",
        label: "Categories",
        onChange: function (ids) { setCats(ids); },
      });
      picker.el.id = "ct-cats";
    } catch (e) { picker = null; }
    return picker;
  }

  function recFor(answer) {
    var k = norm(answer);
    return (history && history[k]) || null;
  }
  function statusOf(r) { return !r ? "new" : r.correct > 0 ? "got" : "missed"; }
  function pct(a, n) { return n ? Math.round(100 * a / n) : 0; }
  function tilesHtml(n, got, heard) {
    return '<div class="ct-tiles">' +
      '<div class="ct-tile ct-t-got"><b class="num">' + got + '<small>/' + n + "</small></b><span>Converted</span></div>" +
      '<div class="ct-tile ct-t-missed"><b class="num">' + (heard - got) + "</b><span>Missed</span></div>" +
      '<div class="ct-tile ct-t-new"><b class="num">' + (n - heard) + "</b><span>Never heard</span></div>" +
      '<div class="ct-tile"><b class="num">' + pct(got, n) + '<small>%</small></b><span>Coverage</span></div>' +
    "</div>";
  }

  // ── overview: coverage bar per category ─────────────────────────────────
  async function renderOverview(host) {
    host.innerHTML = loading("Measuring your canon coverage…");
    var per = await Promise.all(CATS.map(function (c) {
      return ctx.api.get(PICK ? freqUrlIds([c.id], OVERVIEW_N) : freqUrl(c, OVERVIEW_N))
        .then(function (d) { return { cat: c.key, name: c.name, answers: d.answers || [] }; })
        .catch(function () { return { cat: c.key, name: c.name, answers: [] }; });
    }));
    if (!body || !host.isConnected || (PICK ? picked() : view.cat)) return;   // navigated meanwhile
    var tN = 0, tGot = 0, tHeard = 0;
    var rows = per.map(function (p) {
      var heard = 0, converted = 0;
      p.answers.forEach(function (a) {
        var r = recFor(a.answer);
        if (r) { heard++; if (r.correct > 0) converted++; }
      });
      tN += p.answers.length; tGot += converted; tHeard += heard;
      return { cat: p.cat, name: p.name, n: p.answers.length, heard: heard, converted: converted };
    }).filter(function (r) { return r.n > 0; });
    if (!rows.length) { host.innerHTML = '<div class="db-empty">Nothing here yet</div>'; return; }
    rows.sort(function (a, b) { return (a.converted / a.n) - (b.converted / b.n) || (a.heard / a.n) - (b.heard / b.n); });
    host.innerHTML =
      tilesHtml(tN, tGot, tHeard) +
      '<div class="ct-sechead"><span class="eyebrow">Top ' + OVERVIEW_N + ' per category</span><span class="ct-legend"><span class="ct-key ct-k-got"></span>Converted<span class="ct-key ct-k-heard"></span>Heard</span></div>' +
      '<div class="list ct-list">' +
      rows.map(function (r) {
        var hp = pct(r.heard, r.n), cp = pct(r.converted, r.n);
        return '<div class="list-row clickable ct-cat" role="button" tabindex="0" data-cat="' + esc(r.cat) + '">' +
          '<span class="ct-dot" style="--c:' + (ROOT_COLOR[r.name] || ROOT_COLOR[OLD_ROOT[r.name]] || "#8b949e") + '"></span>' +
          '<span class="ct-name">' + esc(r.name) + "</span>" +
          '<span class="ct-bar" aria-hidden="true"><span class="ct-bar-heard" style="width:' + hp + '%"></span><span class="ct-bar-conv" style="width:' + cp + '%"></span></span>' +
          '<span class="ct-nums num"><b>' + r.converted + '</b><span class="ct-of">/' + r.n + '</span><small>' + r.heard + " heard</small></span>" +
          '<span class="ct-chev">' + ic("right", 16) + "</span></div>";
      }).join("") + "</div>";
    host.querySelectorAll(".ct-cat").forEach(function (el) {
      // Picker path: a row is a shortcut for picking that root in the picker.
      var go = PICK
        ? function () { setCats([el.dataset.cat]); }
        : function () { view.cat = el.dataset.cat; saveView(); render(); };
      el.addEventListener("click", go);
      el.addEventListener("keydown", function (e) { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); go(); } });
    });
  }

  // ── category drill-down: the canon list vs your record ──────────────────
  async function renderCategory(host) {
    var c = null, sig = "", url, label;
    if (PICK) {
      sig = catsSig();
      if (picker && picker.ready) { try { await picker.ready; } catch (e) {} }
      if (!body || catsSig() !== sig) return;
      label = picker ? picker.summary() : "";
      url = freqUrlIds(view.cats, view.topN);
    } else {
      c = catByKey(view.cat);
      if (!c) {
        if (!CATS.length) { host.innerHTML = '<div class="db-empty">Couldn’t load categories</div>'; return; }
        view.cat = ""; saveView(); render(); return;
      }
      label = c.name;
      url = freqUrl(c, view.topN);
    }
    host.innerHTML = loading("Loading the " + label + " canon…");
    var answers = [];
    try {
      answers = (await ctx.api.get(url)).answers || [];
    } catch (e) {}
    if (!body || !host.isConnected || (PICK ? catsSig() !== sig : view.cat !== c.key)) return;   // navigated away meanwhile
    if (!answers.length) { host.innerHTML = '<div class="db-empty">Nothing here yet</div>'; return; }
    var counts = { all: answers.length, got: 0, missed: 0, "new": 0 };
    var rowsData = answers.map(function (a, i) {
      var r = recFor(a.answer), st = statusOf(r);
      counts[st]++;
      return { a: a, r: r, st: st, rank: i + 1 };
    });
    var maxCount = answers.reduce(function (m, a) { return Math.max(m, a.count || 0); }, 1);
    var shown = rowsData.filter(function (x) { return view.filter === "all" || x.st === view.filter; });
    var seg = '<div class="seg ct-seg" role="group" aria-label="Show">' + FILTERS.map(function (f) {
      return '<button type="button" data-filter="' + f[0] + '" aria-pressed="' + (view.filter === f[0]) + '">' + esc(f[1]) + ' <span class="ct-segn num">' + counts[f[0]] + "</span></button>";
    }).join("") + "</div>";
    var rowsHtml = shown.map(function (x) {
      var r = x.r;
      var badge = x.st === "new" ? '<span class="ct-st ct-st-new">Never heard</span>'
        : '<span class="ct-st ct-st-' + x.st + '" title="' + r.correct + " right of " + r.heard + " heard" + (r.negs ? ", " + r.negs + " neg" + (r.negs === 1 ? "" : "s") : "") + '"><b class="num">' + r.correct + "/" + r.heard + "</b>" + (x.st === "got" ? "right" : "missed") + "</span>";
      return '<div class="list-row ct-row ct-row-' + x.st + '">' +
        '<span class="ct-rank num">' + x.rank + "</span>" +
        '<span class="ct-ans"><b>' + esc(x.a.answer) + '</b><small class="num">' + (x.a.count || 0) + "× asked</small></span>" +
        '<span class="ct-freq" aria-hidden="true"><span style="width:' + Math.max(4, Math.round(100 * (x.a.count || 0) / maxCount)) + '%"></span></span>' +
        badge +
        '<button type="button" class="btn btn-sm ct-play" data-ans="' + esc(x.a.answer) + '" title="Play questions on ' + esc(x.a.answer) + '">' + ic("play", 13) + '<span class="ct-play-l">Play</span></button>' +
        "</div>";
    }).join("");
    host.innerHTML =
      tilesHtml(answers.length, counts.got, counts.got + counts.missed) +
      '<div class="ct-sechead">' + seg + "</div>" +
      (shown.length ? '<div class="list ct-list ct-canon">' + rowsHtml + "</div>" : '<div class="db-empty">None here</div>');
    host.querySelectorAll("[data-filter]").forEach(function (b) {
      b.onclick = function () { view.filter = b.dataset.filter; saveView(); renderCategory(host); };
    });
    host.querySelectorAll(".ct-play").forEach(function (b) {
      b.onclick = function () { playAnswer(b.dataset.ans, b); };
    });
  }

  // Drill an answer: every tossup whose answerline names it, served in order
  // through the app's real practice screen (records stats like any session).
  async function playAnswer(answer, btn) {
    var lbl = btn && btn.querySelector(".ct-play-l");
    if (btn) { btn.disabled = true; if (lbl) lbl.textContent = "…"; }
    var ids = [];
    try {
      var quoted = '"' + String(answer).replace(/"/g, "") + '"';
      var d = await ctx.api.get("/api/tossups/search?query=" + encodeURIComponent("answer_sanitized : (" + quoted + ")") + "&limit=20");
      ids = (d.rows || []).map(function (r) { return r.id; });
    } catch (e) {}
    if (!ids.length) { if (btn) { btn.disabled = true; if (lbl) lbl.textContent = "None"; } return; }
    if (btn) { btn.disabled = false; if (lbl) lbl.textContent = "Play"; }
    if (!(ctx.host && ctx.host.launchQuestions && ctx.host.launchQuestions("tossups", ids)) && btn) { btn.disabled = true; if (lbl) lbl.textContent = "None"; }
  }

  function render() {
    if (!body) return;
    var inCat = PICK ? picked() : !!view.cat;
    var vc = !PICK && view.cat ? catByKey(view.cat) : null;
    body.innerHTML =
      '<div class="ct-wrap">' +
        '<div class="ct-bar-top">' +
          (PICK ? '<span id="ct-pick-slot"></span>' : (vc ? '<span class="ct-title">' + esc(vc.name) + "</span>" : "")) +
          (inCat ? '<select id="ct-topn" aria-label="How many answers">' +
            [50, 100, 200, 500].map(function (v) { return '<option value="' + v + '"' + (v === view.topN ? " selected" : "") + ">Top " + v + "</option>"; }).join("") + "</select>" : "") +
          '<span class="spacer"></span>' +
          '<button type="button" class="btn btn-ghost btn-icon" id="ct-refresh" title="Refresh" aria-label="Refresh">' + ic("refresh", 16) + "</button>" +
        "</div>" +
        (inCat ? '<div class="ct-crumbs"><button type="button" class="btn btn-ghost btn-sm" id="ct-back">' + ic("left", 15) + "All categories</button></div>" : "") +
        '<div id="ct-body"></div>' +
      "</div>";
    var slot = body.querySelector("#ct-pick-slot");
    if (slot && picker) slot.parentNode.replaceChild(picker.el, slot);
    var back = body.querySelector("#ct-back");
    if (back) back.onclick = PICK
      ? function () { setCats([]); }
      : function () { view.cat = ""; saveView(); render(); };
    var topn = body.querySelector("#ct-topn");
    if (topn) topn.onchange = function (e) { view.topN = parseInt(e.target.value) || 100; saveView(); render(); };
    body.querySelector("#ct-refresh").onclick = function () { history = null; boot(); };
    var host = body.querySelector("#ct-body");
    if (inCat) renderCategory(host); else renderOverview(host);
  }

  async function boot() {
    if (!body) return;
    body.innerHTML = '<div class="ct-wrap">' + loading("Reading your practice history…") + "</div>";
    if (!CATS.length) CATS = await loadCats();
    resolveViewCat();
    // The picker needs the node-id tree; without it the old chooser stays.
    PICK = HAS_PICKER && !!ALL_IDS;
    if (PICK) { resolveViewCats(); if (!ensurePicker()) PICK = false; }
    if (!history) history = await loadHistory();
    render();
  }

  page = ctx.registerPage({
    id: "canon", navLabel: "Canon Tracker", title: "Canon Tracker",
    onShow: function (el, info) {
      body = el;
      // Back keeps the page as-is; a fresh visit re-reads history (it changes
      // every session).
      if (info && info.back && body.querySelector(".ct-wrap")) return;
      history = null;
      boot();
    },
  });

  function active() { return page && page.screenEl && page.screenEl.classList.contains("active"); }
  if (ctx.onBack) ctx.onBack(function () {
    if (!active()) return false;
    if (PICK) { if (!picked()) return false; setCats([]); return true; }
    if (!view.cat) return false;
    view.cat = ""; saveView(); render();
    return true;
  });
}
