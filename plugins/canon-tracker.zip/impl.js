function __qbMain(ctx) {
  var body = null, page = null;
  function esc(s) { return (s == null ? "" : String(s)).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
  function norm(s) { return String(s || "").toLowerCase().replace(/[^a-z0-9]+/g, " ").trim(); }

  // ── data ────────────────────────────────────────────────────────────────
  var CATS = [];                 // [{category, count}]
  var history = null;            // norm(answer) -> { heard, correct, negs, last }
  var view = { cat: "", topN: 100, hideDone: false };
  Object.assign(view, ctx.storage.get("view") || {});

  // Every answer the player has ever faced, keyed by the SAME normalization
  // the server uses for answer_norms — so canon rows match session history
  // as a set-membership test, not fuzzy matching.
  async function loadHistory() {
    var map = {};
    try {
      var d = await ctx.api.get("/api/sessions/all-entries?answers=1");
      (d.entries || []).forEach(function (e) {
        if (e.type !== "tossup" || !e.answer) return;
        (e.answer_norms || [norm(e.answer)]).forEach(function (k) {
          if (!k) return;
          var rec = map[k] = map[k] || { heard: 0, correct: 0, negs: 0, last: 0 };
          rec.heard++;
          if (e.correct) rec.correct++;
          if ((e.points || 0) < 0) rec.negs++;
          var t = new Date(e.timestamp).getTime() || 0;
          if (t > rec.last) rec.last = t;
        });
      });
    } catch (e) {}
    return map;
  }

  function recFor(answer) {
    var k = norm(answer);
    return (history && history[k]) || null;
  }

  // ── overview: coverage bar per category ─────────────────────────────────
  async function renderOverview(host) {
    host.innerHTML = '<div class="text-muted" style="padding:12px">Measuring your canon coverage…</div>';
    var per = await Promise.all(CATS.map(function (c) {
      return ctx.api.get("/api/frequent-answers?limit=50&category=" + encodeURIComponent(c.category))
        .then(function (d) { return { cat: c.category, answers: d.answers || [] }; })
        .catch(function () { return { cat: c.category, answers: [] }; });
    }));
    if (!body || view.cat) return;   // navigated meanwhile
    var rows = per.map(function (p) {
      var heard = 0, converted = 0;
      p.answers.forEach(function (a) {
        var r = recFor(a.answer);
        if (r) { heard++; if (r.correct > 0) converted++; }
      });
      return { cat: p.cat, n: p.answers.length, heard: heard, converted: converted };
    }).filter(function (r) { return r.n > 0; });
    rows.sort(function (a, b) { return (a.converted / a.n) - (b.converted / b.n); });
    host.innerHTML =
      rows.map(function (r) {
        var hp = Math.round(100 * r.heard / r.n), cp = Math.round(100 * r.converted / r.n);
        return '<div class="ct-cat" data-cat="' + esc(r.cat) + '">' +
          '<div class="ct-cat-head"><span>' + esc(r.cat) + '</span><span class="text-muted">' + r.converted + "/" + r.n + " converted · " + r.heard + "/" + r.n + " heard</span></div>" +
          '<div class="ct-bar"><div class="ct-bar-heard" style="width:' + hp + '%"></div><div class="ct-bar-conv" style="width:' + cp + '%"></div></div>' +
          "</div>";
      }).join("");
    host.querySelectorAll(".ct-cat").forEach(function (el) {
      el.onclick = function () { view.cat = el.dataset.cat; ctx.storage.set("view", view); render(); };
    });
  }

  // ── category drill-down: the canon list vs your record ──────────────────
  async function renderCategory(host) {
    host.innerHTML = '<div class="text-muted" style="padding:12px">Loading the ' + esc(view.cat) + " canon…</div>";
    var answers = [];
    try {
      answers = (await ctx.api.get("/api/frequent-answers?limit=" + view.topN + "&category=" + encodeURIComponent(view.cat))).answers || [];
    } catch (e) {}
    if (!body || !view.cat) return;   // navigated away meanwhile
    var heard = 0, converted = 0;
    var rowsHtml = answers.map(function (a, i) {
      var r = recFor(a.answer);
      if (r) { heard++; if (r.correct > 0) converted++; }
      if (view.hideDone && r && r.correct > 0) return "";
      var status = !r
        ? '<span class="pill ct-never">never heard</span>'
        : r.correct > 0
          ? '<span class="pill pill-green">✓ ' + r.correct + "</span>" + (r.negs ? ' <span class="pill pill-red">✗ ' + r.negs + "</span>" : "")
          : '<span class="pill pill-red">heard, 0 right</span>';
      return '<tr><td class="text-muted">' + (i + 1) + "</td><td><strong>" + esc(a.answer) + "</strong></td>" +
        '<td class="text-muted">' + a.count + "× in DB</td><td>" + status + "</td>" +
        '<td><button class="btn btn-sm ct-play" data-ans="' + esc(a.answer) + '">Play</button></td></tr>';
    }).join("");
    host.innerHTML =
      '<div class="ct-sum">' +
        '<div class="ct-card"><div class="ct-cv">' + converted + "/" + answers.length + '</div><div class="ct-cl">converted</div></div>' +
        '<div class="ct-card"><div class="ct-cv">' + heard + "/" + answers.length + '</div><div class="ct-cl">heard</div></div>' +
        '<div class="ct-card"><div class="ct-cv">' + (answers.length - heard) + '</div><div class="ct-cl">never heard</div></div>' +
        '<label class="checkbox-row" style="margin-left:auto"><input type="checkbox" id="ct-hide"' + (view.hideDone ? " checked" : "") + "> Hide converted</label>" +
      "</div>" +
      '<table class="stats-table ct-table"><thead><tr><th>#</th><th>Answer</th><th>Asked</th><th>Your record</th><th></th></tr></thead><tbody>' + rowsHtml + "</tbody></table>";
    var hide = host.querySelector("#ct-hide");
    if (hide) hide.onchange = function (e) { view.hideDone = e.target.checked; ctx.storage.set("view", view); render(); };
    host.querySelectorAll(".ct-play").forEach(function (b) {
      b.onclick = function () { playAnswer(b.dataset.ans, b); };
    });
  }

  // Drill an answer: every tossup whose answerline names it, served in order
  // through the app's real practice screen (records stats like any session).
  async function playAnswer(answer, btn) {
    if (btn) { btn.disabled = true; btn.textContent = "…"; }
    var ids = [];
    try {
      var quoted = '"' + String(answer).replace(/"/g, "") + '"';
      var d = await ctx.api.get("/api/tossups/search?query=" + encodeURIComponent("answer_sanitized : (" + quoted + ")") + "&limit=20");
      ids = (d.rows || []).map(function (r) { return r.id; });
    } catch (e) {}
    if (btn) { btn.disabled = false; btn.textContent = "Play"; }
    if (!ids.length) { ctx.toast("No questions found for that answer", "error"); return; }
    if (!(ctx.host && ctx.host.launchQuestions && ctx.host.launchQuestions("tossups", ids))) ctx.toast("Needs a newer app version", "error");
  }

  function render() {
    if (!body) return;
    body.innerHTML =
      '<div class="ct-wrap">' +
        '<div class="ct-bar-top">' +
          (view.cat ? '<button class="btn btn-sm btn-ghost" id="ct-back">‹ All categories</button><span class="ct-title">' + esc(view.cat) + "</span>" : '<span class="ct-title">CANON COVERAGE</span><span class="qb-info" data-tip="Of each category’s 50 most-asked answers: how many you’ve heard in practice, and how many you’ve converted at least once. Weakest first — click one to study it.">i</span>') +
          (view.cat ? '<select id="ct-topn" class="mode-input" style="width:110px">' +
            [50, 100, 200, 500].map(function (v) { return '<option value="' + v + '"' + (v === view.topN ? " selected" : "") + ">Top " + v + "</option>"; }).join("") + "</select>" : "") +
          '<button class="btn btn-sm btn-ghost" id="ct-refresh" title="Re-reads your practice history">Refresh</button>' +
        "</div>" +
        '<div id="ct-body"></div>' +
      "</div>";
    var back = body.querySelector("#ct-back");
    if (back) back.onclick = function () { view.cat = ""; ctx.storage.set("view", view); render(); };
    var topn = body.querySelector("#ct-topn");
    if (topn) topn.onchange = function (e) { view.topN = parseInt(e.target.value) || 100; ctx.storage.set("view", view); render(); };
    body.querySelector("#ct-refresh").onclick = function () { history = null; boot(); };
    var host = body.querySelector("#ct-body");
    if (view.cat) renderCategory(host); else renderOverview(host);
  }

  async function boot() {
    if (!body) return;
    body.innerHTML = '<div class="text-muted" style="padding:16px">Reading your practice history…</div>';
    if (!CATS.length) {
      try { CATS = (await ctx.api.get("/api/categories?type=tossups")).categories || []; } catch (e) { CATS = []; }
    }
    if (!history) history = await loadHistory();
    render();
  }

  page = ctx.registerPage({
    id: "canon", navLabel: "Canon Tracker", title: "CANON TRACKER",
    onShow: function (el, info) {
      body = el;
      // Back keeps the page as-is; a fresh visit re-reads history (it changes
      // every session).
      if (info && info.back && body.querySelector(".ct-wrap")) return;
      history = null;
      boot();
    },
  });

  function active() { return page && page.screenEl && page.screenEl.classList.contains("active"); }
  if (ctx.onBack) ctx.onBack(function () {
    if (!active() || !view.cat) return false;
    view.cat = ""; ctx.storage.set("view", view); render();
    return true;
  });

  ctx.toast("Canon Tracker enabled");
}
