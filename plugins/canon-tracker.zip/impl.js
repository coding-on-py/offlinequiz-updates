function __qbMain(ctx) {
  var body = null, page = null;
  function esc(s) { return (s == null ? "" : String(s)).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
  function norm(s) { return String(s || "").toLowerCase().replace(/[^a-z0-9]+/g, " ").trim(); }

  // ── data ────────────────────────────────────────────────────────────────
  var CATS = [];                 // [{key, id, name}] — the category tree's roots
  var ALL_IDS = null;            // id -> 1 for every node of the tree (picker path)
  // QBReader-era root names a saved view may still hold → the new roots.
  var OLD_ROOT = { "Science": "Science and Math", "Religion": "Theology", "Pop Culture": "Pop Culture Sports", "Trash": "Pop Culture Sports", "Other Academic": "Miscellaneous" };
  var history = null;            // norm(answer) -> { heard, correct, negs, last }
  var view = { cat: "", topN: 100, hideDone: false };
  Object.assign(view, ctx.storage.get("view") || {});
  // A newer app chooses categories through its own picker: any mix of
  // subtrees, kept as node ids in view.cats. An older app (no picker API)
  // keeps the single root in view.cat and the clickable overview rows.
  var HAS_PICKER = !!(ctx.host && typeof ctx.host.categoryPicker === "function");
  var PICK = false;              // decided in boot(), once the tree has loaded
  var picker = null;             // the ctx.host.categoryPicker handle

  // Every answer the player has ever faced, keyed by the SAME normalization
  // the server uses for answer_norms — so canon rows match session history
  // as a set-membership test, not fuzzy matching.
  async function loadHistory() {
    var map = {};
    try {
      var d = await ctx.api.get("/api/sessions/all-entries?answers=1");
      (d.entries || []).forEach(function (e) {
        if (e.type !== "tossup" || !e.answer) return;
        (e.answer_norms || [norm(e.answer)]).forEach(function (k) {
          if (!k) return;
          var rec = map[k] = map[k] || { heard: 0, correct: 0, negs: 0, last: 0 };
          rec.heard++;
          if (e.correct) rec.correct++;
          if ((e.points || 0) < 0) rec.negs++;
          var t = new Date(e.timestamp).getTime() || 0;
          if (t > rec.last) rec.last = t;
        });
      });
    } catch (e) {}
    return map;
  }

  function catByKey(k) {
    for (var i = 0; i < CATS.length; i++) if (CATS[i].key === k) return CATS[i];
    return null;
  }
  function freqUrl(c, limit) {
    return "/api/frequent-answers?limit=" + limit + (c.id ? "&nodeId=" + encodeURIComponent(c.id) : "&category=" + encodeURIComponent(c.name));
  }
  // The union of the picked subtrees (none = the whole database).
  function freqUrlIds(ids, limit) {
    return "/api/frequent-answers?limit=" + limit + (ids.length ? "&nodeIds=" + ids.map(encodeURIComponent).join(",") : "");
  }
  async function loadCats() {
    var roots = null;
    try {
      if (ctx.host && ctx.host.getCategoryTree) roots = await ctx.host.getCategoryTree("tossups");
      else roots = (await ctx.api.get("/api/category-tree?type=tossups")).tree;
    } catch (e) { roots = null; }
    if (roots && roots.length) {
      ALL_IDS = {};
      (function walk(ns) { (ns || []).forEach(function (n) { if (n && n.id != null) { ALL_IDS[String(n.id)] = 1; walk(n.children); } }); })(roots);
      return roots.map(function (r) { return { key: r.id, id: r.id, name: r.name }; });
    }
    try {   // older base without the tree: level-1 names
      return ((await ctx.api.get("/api/categories?type=tossups")).categories || []).map(function (c) { return { key: c.category, id: null, name: c.category }; });
    } catch (e) { return []; }
  }
  // A saved view.cat from before the tree held a root NAME: map it once to
  // the new root's key, or fall back to the overview.
  function resolveViewCat() {
    if (!view.cat || !CATS.length || catByKey(view.cat)) return;
    var nm = OLD_ROOT[view.cat] || view.cat, hit = null;
    CATS.forEach(function (c) { if (!hit && c.name === nm) hit = c; });
    view.cat = hit ? hit.key : "";
    ctx.storage.set("view", view);
  }
  // Picker path: view.cats is the list of picked node ids. A view saved
  // before the picker held ONE root (view.cat) — it becomes a one-element
  // list; ids the current tree no longer has are dropped.
  function resolveViewCats() {
    var had = JSON.stringify(view.cats);
    if (!Array.isArray(view.cats)) { view.cats = view.cat ? [String(view.cat)] : []; view.cat = ""; }
    view.cats = view.cats.filter(function (id, i, a) { return id != null && id !== "" && a.indexOf(id) === i; }).map(String);
    if (ALL_IDS) view.cats = view.cats.filter(function (id) { return ALL_IDS[id]; });
    if (JSON.stringify(view.cats) !== had) ctx.storage.set("view", view);
  }
  function catsSig() { return (view.cats || []).join(","); }
  function picked() { return PICK && view.cats && view.cats.length > 0; }
  function setCats(ids) {
    view.cats = (ids || []).map(String);
    if (picker && JSON.stringify(picker.get()) !== JSON.stringify(view.cats)) picker.set(view.cats);
    ctx.storage.set("view", view);
    render();
  }
  function ensurePicker() {
    if (picker) {
      if (JSON.stringify(picker.get()) !== JSON.stringify(view.cats || [])) picker.set(view.cats || []);
      return picker;
    }
    if (!PICK) return null;
    try {
      picker = ctx.host.categoryPicker(null, {
        selected: view.cats || [],
        type: "tossups",
        label: "Categories",
        onChange: function (ids) { setCats(ids); },
      });
      picker.el.id = "ct-cats";
      picker.el.classList.add("btn-sm");
    } catch (e) { picker = null; }
    return picker;
  }

  function recFor(answer) {
    var k = norm(answer);
    return (history && history[k]) || null;
  }

  // ── overview: coverage bar per category ─────────────────────────────────
  async function renderOverview(host) {
    host.innerHTML = '<div class="text-muted" style="padding:12px">Measuring your canon coverage…</div>';
    var per = await Promise.all(CATS.map(function (c) {
      return ctx.api.get(PICK ? freqUrlIds([c.id], 50) : freqUrl(c, 50))
        .then(function (d) { return { cat: c.key, name: c.name, answers: d.answers || [] }; })
        .catch(function () { return { cat: c.key, name: c.name, answers: [] }; });
    }));
    if (!body || (PICK ? picked() : view.cat)) return;   // navigated meanwhile
    var rows = per.map(function (p) {
      var heard = 0, converted = 0;
      p.answers.forEach(function (a) {
        var r = recFor(a.answer);
        if (r) { heard++; if (r.correct > 0) converted++; }
      });
      return { cat: p.cat, name: p.name, n: p.answers.length, heard: heard, converted: converted };
    }).filter(function (r) { return r.n > 0; });
    rows.sort(function (a, b) { return (a.converted / a.n) - (b.converted / b.n); });
    host.innerHTML =
      rows.map(function (r) {
        var hp = Math.round(100 * r.heard / r.n), cp = Math.round(100 * r.converted / r.n);
        return '<div class="ct-cat" data-cat="' + esc(r.cat) + '">' +
          '<div class="ct-cat-head"><span>' + esc(r.name) + '</span><span class="text-muted">' + r.converted + "/" + r.n + " converted · " + r.heard + "/" + r.n + " heard</span></div>" +
          '<div class="ct-bar"><div class="ct-bar-heard" style="width:' + hp + '%"></div><div class="ct-bar-conv" style="width:' + cp + '%"></div></div>' +
          "</div>";
      }).join("");
    host.querySelectorAll(".ct-cat").forEach(function (el) {
      // Picker path: a row is a shortcut for picking that root in the picker.
      el.onclick = PICK
        ? function () { setCats([el.dataset.cat]); }
        : function () { view.cat = el.dataset.cat; ctx.storage.set("view", view); render(); };
    });
  }

  // ── category drill-down: the canon list vs your record ──────────────────
  async function renderCategory(host) {
    var c = null, sig = "", url, label;
    if (PICK) {
      sig = catsSig();
      if (picker && picker.ready) { try { await picker.ready; } catch (e) {} }
      if (!body || catsSig() !== sig) return;
      label = picker ? picker.summary() : "";
      url = freqUrlIds(view.cats, view.topN);
    } else {
      c = catByKey(view.cat);
      if (!c) {
        if (!CATS.length) { host.innerHTML = '<div class="text-muted" style="padding:12px">Couldn’t load categories.</div>'; return; }
        view.cat = ""; ctx.storage.set("view", view); render(); return;
      }
      label = c.name;
      url = freqUrl(c, view.topN);
    }
    host.innerHTML = '<div class="text-muted" style="padding:12px">Loading the ' + esc(label) + " canon…</div>";
    var answers = [];
    try {
      answers = (await ctx.api.get(url)).answers || [];
    } catch (e) {}
    if (!body || (PICK ? catsSig() !== sig : view.cat !== c.key)) return;   // navigated away meanwhile
    var heard = 0, converted = 0;
    var rowsHtml = answers.map(function (a, i) {
      var r = recFor(a.answer);
      if (r) { heard++; if (r.correct > 0) converted++; }
      if (view.hideDone && r && r.correct > 0) return "";
      var status = !r
        ? '<span class="pill ct-never">never heard</span>'
        : r.correct > 0
          ? '<span class="pill pill-green">✓ ' + r.correct + "</span>" + (r.negs ? ' <span class="pill pill-red">✗ ' + r.negs + "</span>" : "")
          : '<span class="pill pill-red">heard, 0 right</span>';
      return '<tr><td class="text-muted">' + (i + 1) + "</td><td><strong>" + esc(a.answer) + "</strong></td>" +
        '<td class="text-muted">' + a.count + "× in DB</td><td>" + status + "</td>" +
        '<td><button class="btn btn-sm ct-play" data-ans="' + esc(a.answer) + '">Play</button></td></tr>';
    }).join("");
    host.innerHTML =
      '<div class="ct-sum">' +
        '<div class="ct-card"><div class="ct-cv">' + converted + "/" + answers.length + '</div><div class="ct-cl">converted</div></div>' +
        '<div class="ct-card"><div class="ct-cv">' + heard + "/" + answers.length + '</div><div class="ct-cl">heard</div></div>' +
        '<div class="ct-card"><div class="ct-cv">' + (answers.length - heard) + '</div><div class="ct-cl">never heard</div></div>' +
        '<label class="checkbox-row" style="margin-left:auto"><input type="checkbox" id="ct-hide"' + (view.hideDone ? " checked" : "") + "> Hide converted</label>" +
      "</div>" +
      '<table class="stats-table ct-table"><thead><tr><th>#</th><th>Answer</th><th>Asked</th><th>Your record</th><th></th></tr></thead><tbody>' + rowsHtml + "</tbody></table>";
    var hide = host.querySelector("#ct-hide");
    if (hide) hide.onchange = function (e) { view.hideDone = e.target.checked; ctx.storage.set("view", view); render(); };
    host.querySelectorAll(".ct-play").forEach(function (b) {
      b.onclick = function () { playAnswer(b.dataset.ans, b); };
    });
  }

  // Drill an answer: every tossup whose answerline names it, served in order
  // through the app's real practice screen (records stats like any session).
  async function playAnswer(answer, btn) {
    if (btn) { btn.disabled = true; btn.textContent = "…"; }
    var ids = [];
    try {
      var quoted = '"' + String(answer).replace(/"/g, "") + '"';
      var d = await ctx.api.get("/api/tossups/search?query=" + encodeURIComponent("answer_sanitized : (" + quoted + ")") + "&limit=20");
      ids = (d.rows || []).map(function (r) { return r.id; });
    } catch (e) {}
    if (btn) { btn.disabled = false; btn.textContent = "Play"; }
    if (!ids.length) { if (btn) { btn.disabled = true; btn.textContent = "None"; } ctx.toast("No questions found for that answer", "error"); return; }
    if (!(ctx.host && ctx.host.launchQuestions && ctx.host.launchQuestions("tossups", ids))) ctx.toast("Needs a newer app version", "error");
  }

  function render() {
    if (!body) return;
    var inCat = PICK ? picked() : !!view.cat;
    var vc = !PICK && view.cat ? catByKey(view.cat) : null;
    body.innerHTML =
      '<div class="ct-wrap">' +
        '<div class="ct-bar-top">' +
          (inCat
            ? '<button class="btn btn-sm btn-ghost" id="ct-back">‹ All categories</button>' + (PICK ? "" : '<span class="ct-title">' + esc(vc ? vc.name : "") + "</span>")
            : '<span class="ct-title">CANON COVERAGE</span><span class="qb-info" data-tip="Of each category’s 50 most-asked answers: how many you’ve heard in practice, and how many you’ve converted at least once. Weakest first — click one, or pick any mix of categories, to study it.">i</span>') +
          (PICK ? '<span id="ct-pick-slot"></span>' : "") +
          (inCat ? '<select id="ct-topn" class="mode-input" style="width:110px">' +
            [50, 100, 200, 500].map(function (v) { return '<option value="' + v + '"' + (v === view.topN ? " selected" : "") + ">Top " + v + "</option>"; }).join("") + "</select>" : "") +
          '<button class="btn btn-sm btn-ghost" id="ct-refresh" title="Re-reads your practice history">Refresh</button>' +
        "</div>" +
        '<div id="ct-body"></div>' +
      "</div>";
    var slot = body.querySelector("#ct-pick-slot");
    if (slot && picker) slot.parentNode.replaceChild(picker.el, slot);
    var back = body.querySelector("#ct-back");
    if (back) back.onclick = PICK
      ? function () { setCats([]); }
      : function () { view.cat = ""; ctx.storage.set("view", view); render(); };
    var topn = body.querySelector("#ct-topn");
    if (topn) topn.onchange = function (e) { view.topN = parseInt(e.target.value) || 100; ctx.storage.set("view", view); render(); };
    body.querySelector("#ct-refresh").onclick = function () { history = null; boot(); };
    var host = body.querySelector("#ct-body");
    if (inCat) renderCategory(host); else renderOverview(host);
  }

  async function boot() {
    if (!body) return;
    body.innerHTML = '<div class="text-muted" style="padding:16px">Reading your practice history…</div>';
    if (!CATS.length) CATS = await loadCats();
    resolveViewCat();
    // The picker needs the node-id tree; without it the old chooser stays.
    PICK = HAS_PICKER && !!ALL_IDS;
    if (PICK) { resolveViewCats(); if (!ensurePicker()) PICK = false; }
    if (!history) history = await loadHistory();
    render();
  }

  page = ctx.registerPage({
    id: "canon", navLabel: "Canon Tracker", title: "CANON TRACKER",
    onShow: function (el, info) {
      body = el;
      // Back keeps the page as-is; a fresh visit re-reads history (it changes
      // every session).
      if (info && info.back && body.querySelector(".ct-wrap")) return;
      history = null;
      boot();
    },
  });

  function active() { return page && page.screenEl && page.screenEl.classList.contains("active"); }
  if (ctx.onBack) ctx.onBack(function () {
    if (!active()) return false;
    if (PICK) { if (!picked()) return false; setCats([]); return true; }
    if (!view.cat) return false;
    view.cat = ""; ctx.storage.set("view", view); render();
    return true;
  });

  ctx.toast("Canon Tracker enabled");
}
