/**
 * OfflineQuiz plugin: Backdrops
 *
 * A quiet scene behind the app, in your theme's colors: drifting stars, an aurora, soft bokeh, a grid
 * running to the horizon or slow waves. It only changes how things look.
 */
QB.registerPlugin({
  id: "backdrops",
  name: "Backdrops",
  version: "1.1.0",
  author: "OfflineQuiz",
  description: "A quiet moving scene behind the app: stars, aurora, bokeh, a grid or waves.",
  settings: [
    {
      "key": "scene",
      "label": "Scene",
      "type": "select",
      "default": "starfield",
      "location": "appearance",
      "options": [
        {
          "value": "starfield",
          "label": "Starfield"
        },
        {
          "value": "aurora",
          "label": "Aurora"
        },
        {
          "value": "bokeh",
          "label": "Bokeh"
        },
        {
          "value": "grid",
          "label": "Grid"
        },
        {
          "value": "waves",
          "label": "Waves"
        }
      ]
    },
    {
      "key": "strength",
      "label": "Strength",
      "type": "select",
      "default": "soft",
      "location": "appearance",
      "options": [
        {
          "value": "faint",
          "label": "Faint"
        },
        {
          "value": "soft",
          "label": "Soft"
        },
        {
          "value": "bold",
          "label": "Bold"
        }
      ]
    },
    {
      "key": "motion",
      "label": "Moving",
      "type": "toggle",
      "default": true,
      "location": "appearance"
    },
    {
      "key": "calm",
      "label": "Calm while you practice",
      "type": "toggle",
      "default": true,
      "location": "appearance"
    },
    {
      "key": "homeText",
      "label": "Questions on the home screen",
      "type": "toggle",
      "default": false,
      "location": "appearance"
    }
  ],
  onEnable: __qbMain,
  onDisable: function (ctx) { if (ctx._cleanup) ctx._cleanup(); },
});
