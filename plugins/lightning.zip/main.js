/**
 * OfflineQuiz plugin: Lightning
 *
 * Timed rounds of quick recall. Each item is a tossup's last clue; type the answer and the next
 * one comes at once. It keeps your best score for each round length and your best streak.
 */
QB.registerPlugin({
  id: "lightning",
  name: "Lightning",
  version: "1.0.0",
  author: "OfflineQuiz",
  description: "Name as many late clues as you can in 60 seconds, and beat your best.",
  onEnable: __qbMain,
  onDisable: function (ctx) { if (ctx._cleanup) ctx._cleanup(); },
});
