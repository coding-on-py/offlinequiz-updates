/**
 * OfflineQuiz plugin: System Voice TTS  (zero setup)
 *
 * Reads each question aloud using your operating system's built-in speech
 * voices — no Python, no server, no downloads. Just drag in and enable.
 *
 * Pick a voice in the settings: on macOS the "Enhanced"/"Premium" voices (and
 * Siri voices) sound very natural. If you only see robotic ones, add better
 * voices once in System Settings → Accessibility → Spoken Content → System
 * Voice → Manage Voices (that's an OS feature — still no coding/installing).
 *
 * Settings:
 *   - Voice                            which system voice to use
 *   - Show question text while reading on = synced "karaoke" text; off = audio only
 *   - Speed                            speech rate (0.5 slow … 2 fast)
 */
QB.registerPlugin({
  id: "system-tts",
  name: "System Voice TTS",
  version: "1.1.0",
  author: "OfflineQuiz",
  description: "Reads questions aloud with your OS voices — zero setup. Voice picker + text synced word-by-word to the speech.",
  settings: [
    {
      key: "voiceURI", label: "Voice", type: "select", default: "",
      options: function () {
        try {
          var vs = window.speechSynthesis.getVoices();
          var list = [{ value: "", label: "System default" }];
          vs.forEach(function (v) { list.push({ value: v.voiceURI, label: v.name + " (" + v.lang + ")" + (v.localService ? "" : " · online") }); });
          return list;
        } catch (e) { return [{ value: "", label: "System default" }]; }
      },
    },
    { key: "showText", label: "Show question text while reading", type: "toggle", default: true },
    { key: "rate", label: "Speed (0.5 slow – 2 fast)", type: "number", default: 1.0 },
  ],
  onEnable(ctx) {
    var synth = window.speechSynthesis;
    var karaoke = null, words = [];

    if (ctx.host && ctx.host.setReadingHold) ctx.host.setReadingHold(true);
    // ensure the voice list is populated for the settings dropdown
    try { synth.getVoices(); synth.onvoiceschanged = function () {}; } catch (e) {}

    function nativeText() { return document.getElementById("question-text"); }
    function hideNative() { var el = nativeText(); if (el) el.style.visibility = "hidden"; }
    function showNative() { var el = nativeText(); if (el) el.style.visibility = ""; }
    function removeKaraoke() { if (karaoke) { karaoke.remove(); karaoke = null; } words = []; }
    function cleanup() { try { synth.cancel(); } catch (e) {} removeKaraoke(); showNative(); }
    ctx._cleanup = cleanup;

    function esc(w) { return w.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"); }

    function buildKaraoke(text) {
      removeKaraoke();
      var anchor = nativeText();
      var parent = anchor && anchor.parentNode ? anchor.parentNode : (document.getElementById("question-content") || document.getElementById("question-area"));
      if (!parent) return;
      words = [];
      var re = /\S+/g, m;
      while ((m = re.exec(text))) words.push({ text: m[0], start: m.index, end: m.index + m[0].length });
      karaoke = document.createElement("div");
      karaoke.className = "tts-karaoke";
      karaoke.style.cssText = "font-size:18px;line-height:1.7;margin:6px 0;color:var(--text)";
      karaoke.innerHTML = words.map(function (w, i) { return '<span class="tts-w" data-i="' + i + '" style="opacity:.35">' + esc(w.text) + "</span>"; }).join(" ");
      if (anchor) parent.insertBefore(karaoke, anchor); else parent.appendChild(karaoke);
    }
    function highlightUpTo(charIndex) {
      if (!karaoke) return;
      var spans = karaoke.querySelectorAll(".tts-w");
      for (var i = 0; i < words.length; i++) {
        if (words[i].start <= charIndex && charIndex < words[i].end) { spans[i].style.opacity = "1"; spans[i].style.color = "var(--accent)"; }
        else if (words[i].end <= charIndex) { spans[i].style.opacity = "1"; spans[i].style.color = "var(--text)"; }
        else { spans[i].style.opacity = ".35"; spans[i].style.color = "var(--text)"; }
      }
    }
    function highlightAll() { if (!karaoke) return; karaoke.querySelectorAll(".tts-w").forEach(function (s) { s.style.opacity = "1"; s.style.color = "var(--text)"; }); }

    function pickVoice() {
      var uri = ctx.getSetting("voiceURI");
      if (!uri) return null;
      var vs = synth.getVoices();
      for (var i = 0; i < vs.length; i++) if (vs[i].voiceURI === uri) return vs[i];
      return null;
    }

    function read(text) {
      cleanup();
      if (!text) return;
      var showText = ctx.getSetting("showText");
      hideNative();
      if (showText) buildKaraoke(text);
      var u = new SpeechSynthesisUtterance(text);
      var v = pickVoice(); if (v) u.voice = v;
      var rate = parseFloat(ctx.getSetting("rate")); if (!isNaN(rate)) u.rate = rate;
      u.onboundary = function (e) { if (e.name === "word" || e.charIndex != null) highlightUpTo(e.charIndex || 0); };
      u.onend = function () { highlightAll(); removeKaraoke(); showNative(); };
      u.onerror = function () { removeKaraoke(); showNative(); };
      synth.speak(u);
    }

    ctx.on("question:render", function (q) {
      if (!q || !q.question) return;
      var text = q.type === "tossup"
        ? (q.question.question_sanitized || q.question.question || "")
        : (q.question.leadin_sanitized || q.question.leadin || "");
      read(text.split("(*)").join(" "));
    });
    ctx.on("buzz", cleanup);
    ctx.on("answer:result", cleanup);
    ctx.on("bonus:result", cleanup);
    ctx.on("screen:change", cleanup);
    ctx.on("session:end", cleanup);

    ctx.toast("System Voice TTS enabled — pick a voice in its settings.");
  },
  onDisable(ctx) {
    if (ctx.host && ctx.host.setReadingHold) ctx.host.setReadingHold(false);
    if (ctx._cleanup) ctx._cleanup();
    var el = document.getElementById("question-text"); if (el) el.style.visibility = "";
  },
});
