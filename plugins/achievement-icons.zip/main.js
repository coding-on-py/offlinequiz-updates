QB.registerPlugin({
  id: "achievement-icons",
  name: "Achievement Icons",
  version: "3.0.0",
  author: "OfflineQuiz",
  description: "Topic-drawn minimal line icons for every achievement — a whale for Moby Dick, a raven for Poe, a crown for the House of Capet.",
  onEnable: __qbMain,
  onDisable: function () {},
});
