/**
 * OfflineQuiz plugin: Reading Style
 *
 * How the question text looks while it's read: a font for the questions alone, a cursor at the reading
 * point, the line width, the alignment and a book-like first letter. It only changes how things look.
 */
QB.registerPlugin({
  id: "reading-style",
  name: "Reading Style",
  version: "1.0.2",
  author: "OfflineQuiz",
  description: "A font for the questions, a cursor that follows the reading and a book-like first letter.",
  settings: [
    {
      "key": "font",
      "label": "Question font",
      "type": "select",
      "default": "book",
      "location": "appearance",
      "options": [
        {
          "value": "app",
          "label": "The app's font"
        },
        {
          "value": "book",
          "label": "Book"
        },
        {
          "value": "classic",
          "label": "Classic"
        },
        {
          "value": "typewriter",
          "label": "Typewriter"
        },
        {
          "value": "rounded",
          "label": "Rounded"
        },
        {
          "value": "clear",
          "label": "Clear (easy to read)"
        }
      ]
    },
    {
      "key": "cursor",
      "label": "Reading cursor",
      "type": "select",
      "default": "bar",
      "location": "appearance",
      "options": [
        {
          "value": "bar",
          "label": "Bar"
        },
        {
          "value": "block",
          "label": "Block"
        },
        {
          "value": "underline",
          "label": "Underline"
        },
        {
          "value": "none",
          "label": "None"
        }
      ]
    },
    {
      "key": "initial",
      "label": "First letter",
      "type": "select",
      "default": "plain",
      "location": "appearance",
      "options": [
        {
          "value": "plain",
          "label": "Plain"
        },
        {
          "value": "accent",
          "label": "In color"
        },
        {
          "value": "drop",
          "label": "Drop cap"
        }
      ]
    },
    {
      "key": "align",
      "label": "Alignment",
      "type": "select",
      "default": "left",
      "location": "appearance",
      "options": [
        {
          "value": "left",
          "label": "Left"
        },
        {
          "value": "justify",
          "label": "Justified"
        }
      ]
    },
    {
      "key": "width",
      "label": "Line width",
      "type": "select",
      "default": "wide",
      "location": "appearance",
      "options": [
        {
          "value": "wide",
          "label": "Wide"
        },
        {
          "value": "comfortable",
          "label": "Comfortable"
        }
      ]
    }
  ],
  onEnable: __qbMain,
  onDisable: function (ctx) { if (ctx._cleanup) ctx._cleanup(); },
});
