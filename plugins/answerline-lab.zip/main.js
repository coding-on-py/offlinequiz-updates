/**
 * OfflineQuiz plugin: Answerline Lab
 *
 * An "Answerline Lab" page (title menu → Extra). Pull a tossup's answer line,
 * type an answer, and the app's checker tells you ACCEPT / PROMPT / INCORRECT —
 * a way to learn answerlines/prompts or sanity-check the checker. The question
 * has a movable read-position bar so you can test "accept X until/after Y" and
 * partial-answer prompts. Evaluation uses /api/evaluate-tossup (records nothing).
 *
 * It borrows the practice filter panel (category/difficulty/year), so "New
 * answer line" and the SEARCH box both draw from the same filtered subset.
 * Other plugins' "Open in Answer Lab" (the + save menu) load a specific
 * question here, fully revealed.
 */
QB.registerPlugin({
  id: "answerline-lab",
  name: "Answerline Lab",
  version: "1.9.0",
  author: "OfflineQuiz",
  description: "Practice/test answer acceptance: shows an answer line, you type an answer, it tells you accept / prompt / incorrect. Filter + search for specific questions.",
  hotkeys: [{ id: "next", label: "New answer line", default: "n" }],
  onEnable: __qbMain,
  onDisable: function (ctx) { if (ctx._cleanup) ctx._cleanup(); },
});
