function __qbMain(ctx) {
    var body = null, page = null, current = null, strictness = 10;
    var borrowedPanel = null, panelHome = null;

    function esc(s) { return (s == null ? "" : String(s)).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"); }

    // Build a query string from the practice filters (so the Lab is scoped the
    // same way as practice — categories/subcats/alts/difficulties/years).
    function filtersToQuery(f) {
      f = f || {}; var p = [];
      if (f.standard) p.push("standard=1");
      if (f.categories && f.categories.length) p.push("categories=" + encodeURIComponent(f.categories.join(",")));
      if (f.subcategories && f.subcategories.length) p.push("subcategories=" + encodeURIComponent(f.subcategories.join(",")));
      if (f.alternateSubcategories && f.alternateSubcategories.length) p.push("alternateSubcategories=" + encodeURIComponent(f.alternateSubcategories.join(",")));
      if (f.difficulties && f.difficulties.length) p.push("difficulties=" + f.difficulties.join(","));
      if (f.yearMin != null) p.push("yearMin=" + f.yearMin);
      if (f.yearMax != null) p.push("yearMax=" + f.yearMax);
      return p.join("&");
    }
    function activeFilters() { try { return (ctx.host.getActiveFilters && ctx.host.getActiveFilters()) || {}; } catch (e) { return {}; } }

    page = ctx.registerPage({
      id: "lab", navLabel: "Answerline Lab", title: "ANSWERLINE LAB",
      onShow: function (el) {
        body = el;
        // Coming back: the runtime never wipes our DOM, so leave the search box,
        // the results list, the read-position slider and the typed answer exactly
        // as the user left them. Only re-borrow the filter panel, which onHide
        // (and screen:change) handed back when we left.
        // `current` is null only when a load failed or matched nothing, and the
        // old code retried on every visit — don't let the guard swallow that.
        if (current && body.querySelector("#al-search")) { borrowPanel(); return; }
        if (!current) loadNext(); else render();
      },
      onHide: function () { returnPanel(); },
    });
    function active() { return page && page.screenEl && page.screenEl.classList.contains("active"); }
    ctx.on("screen:change", function () { setTimeout(function () { if (!active()) returnPanel(); }, 0); });
    ctx.onHotkey("next", function () { if (active()) loadNext(); });

    // Borrow the real practice filter panel (category/difficulty/year) so the
    // Lab is filtered like practice. MODE is forced to random here.
    function borrowPanel() {
      var layout = body && body.querySelector(".al-layout");
      if (!layout) return;
      try { if (ctx.host && ctx.host.ensureFiltersLoaded) ctx.host.ensureFiltersLoaded(); } catch (e) {}
      var panel = document.getElementById("filters-panel") || borrowedPanel;
      if (!panel || panel.parentNode === layout) return;
      var ms = document.getElementById("mode-select");
      if (ms && ms.value !== "random") { ms.value = "random"; ms.dispatchEvent(new Event("change", { bubbles: true })); }
      if (!panelHome) panelHome = { parent: panel.parentNode, next: panel.nextSibling };
      panel.classList.add("al-borrowed");
      layout.insertBefore(panel, layout.firstChild);
      borrowedPanel = panel;
    }
    function returnPanel() {
      if (!borrowedPanel || !panelHome) return;
      borrowedPanel.classList.remove("al-borrowed");
      try { panelHome.parent.insertBefore(borrowedPanel, panelHome.next); } catch (e) {}
      borrowedPanel = null;
    }

    async function loadNext() {
      if (!body) return;
      renderShell('<div class="al-card"><div class="text-muted">Loading a random answer line…</div></div>');
      try {
        var qs = filtersToQuery(activeFilters());
        var d = await ctx.api.get("/api/tossups/random?random=1&limit=1" + (qs ? "&" + qs : "&standard=1"));
        current = d.tossup;
        if (!current) { renderShell('<div class="al-card"><div class="text-muted">No question matched the filters — broaden them on the left.</div></div>'); return; }
        render();
      } catch (e) {
        renderShell('<div class="al-card"><div class="text-muted">Couldn\'t load a question: ' + esc(e.message || e) + "</div></div>");
      }
    }

    // Load a SPECIFIC question (from "Open in Answer Lab"), fully revealed.
    async function loadSpecific(q) {
      if (q && q.answer_sanitized != null) { current = q; render(); return; }
      try { var d = await ctx.api.get("/api/tossups/" + encodeURIComponent(q && q.id ? q.id : q)); if (d.tossup) { current = d.tossup; render(); } } catch (e) {}
    }

    // CRITICAL: hand the borrowed panel back before innerHTML wipes the body,
    // then re-borrow — otherwise the filter panel is detached for good.
    function renderShell(inner) {
      returnPanel();
      body.innerHTML = '<div class="practice-layout al-layout"><main class="question-area"><div class="al-wrap">' + searchCardHtml() + inner + "</div></main></div>";
      wireSearch();
      borrowPanel();
    }

    function searchCardHtml() {
      return '<div class="al-card al-searchcard">' +
        '<div class="al-label">FIND A QUESTION <span class="text-muted" style="font-weight:400">· searches within the filters on the left</span></div>' +
        '<div class="al-searchrow"><input type="text" id="al-search" class="mode-input" placeholder="Search answer or question text…" autocomplete="off" spellcheck="false">' +
        '<button class="btn btn-primary" id="al-search-go">Search</button>' +
        '<button class="btn" id="al-random">[N] Random</button></div>' +
        '<div class="al-results" id="al-results"></div>' +
      "</div>";
    }
    function wireSearch() {
      var inp = body.querySelector("#al-search");
      var go = function () { runSearch(); };
      if (inp) inp.addEventListener("keydown", function (e) { if (e.key === "Enter") { e.preventDefault(); go(); } });
      var gb = body.querySelector("#al-search-go"); if (gb) gb.onclick = go;
      var rb = body.querySelector("#al-random"); if (rb) rb.onclick = loadNext;
    }
    async function runSearch() {
      var inp = body.querySelector("#al-search"), out = body.querySelector("#al-results");
      if (!inp || !out) return;
      var text = (inp.value || "").trim();
      if (!text) { out.innerHTML = '<div class="text-muted" style="font-size:12px">Type something to search.</div>'; return; }
      out.innerHTML = '<div class="text-muted" style="font-size:12px">Searching…</div>';
      var qs = filtersToQuery(activeFilters());
      var rows = [];
      try { rows = (await ctx.api.get("/api/tossups/search?query=" + encodeURIComponent(text) + "&limit=40" + (qs ? "&" + qs : ""))).rows || []; }
      catch (e) { out.innerHTML = '<div class="text-muted" style="font-size:12px">Search failed: ' + esc(e.message || e) + "</div>"; return; }
      if (!rows.length) { out.innerHTML = '<div class="text-muted" style="font-size:12px">No matches in this filter subset.</div>'; return; }
      out.innerHTML = rows.map(function (q, i) {
        var ans = (q.answer_sanitized || "").split(/[\[(]/)[0].trim();
        return '<div class="al-rrow" data-i="' + i + '"><span class="al-rans">' + esc(ans) + "</span>" +
          '<span class="al-rmeta">' + esc(q.category || "") + (q.subcategory ? " / " + esc(q.subcategory) : "") + " · d" + esc(q.difficulty != null ? q.difficulty : "?") + "</span>" +
          ((ctx.host && ctx.host.openSaveMenu) ? '<span class="al-save" data-i="' + i + '" title="Save to review / folders">+</span>' : "") +
          "</div>";
      }).join("");
      out.querySelectorAll(".al-save").forEach(function (b) {
        b.addEventListener("click", function (ev) {
          ev.stopPropagation();
          var q = rows[parseInt(b.dataset.i)];
          if (q && ctx.host && ctx.host.openSaveMenu) ctx.host.openSaveMenu(q, "tossup", b);
        });
      });
      out.querySelectorAll(".al-rrow").forEach(function (row) {
        row.addEventListener("click", function () { current = rows[parseInt(row.dataset.i)]; render(); });
      });
    }

    function render() {
      if (!body || !current) return;
      renderShell(
        '<div class="al-card">' +
          '<div class="al-label">ANSWER LINE' +
            '<span class="text-muted" style="font-weight:400"> · ' + esc(current.category || "") + (current.subcategory ? " / " + esc(current.subcategory) : "") + " · diff " + esc(current.difficulty != null ? current.difficulty : "?") + "</span></div>" +
          '<div class="al-answerline">' + (current.answer || esc(current.answer_sanitized || "")) + "</div>" +
          '<div class="al-lists" id="al-lists"><span class="text-muted">Parsing…</span></div>' +
        "</div>" +
        '<div class="al-card">' +
          '<div class="al-label">QUESTION <span class="text-muted" style="font-weight:400">· drag to set how much has been read</span></div>' +
          '<div class="al-question question-text" id="al-question"></div>' +
          '<div class="al-strict slider-group" style="margin-top:10px"><span style="font-size:11px;min-width:120px">Read position</span>' +
            '<input type="range" id="al-readpos" min="0" max="100" step="1" value="100"><span class="slider-value" id="al-readpos-val">100%</span></div>' +
        "</div>" +
        '<div class="al-card">' +
          '<div class="al-label">YOUR ANSWER</div>' +
          '<div class="buzz-prompt"><span class="prompt-symbol">&gt;</span>' +
            '<input type="text" id="al-input" placeholder="type an answer and press Enter…" autocomplete="off" autocorrect="off" spellcheck="false"></div>' +
          '<div class="al-strict slider-group"><span style="font-size:11px;min-width:120px">Strictness (0–20)</span>' +
            '<input type="range" id="al-strict" min="0" max="20" step="1" value="' + strictness + '"><span class="slider-value" id="al-strict-val">' + strictness + "</span></div>" +
          '<div class="al-actions"><button class="btn btn-primary" id="al-check">Check</button>' +
            '<button class="btn" id="al-next">[N] New answer line</button></div>' +
          '<div class="al-result" id="al-result"></div>' +
        "</div>"
      );

      var input = body.querySelector("#al-input");
      input.addEventListener("keydown", function (e) { if (e.key === "Enter") check(); });
      body.querySelector("#al-check").onclick = check;
      body.querySelector("#al-next").onclick = loadNext;
      var st = body.querySelector("#al-strict");
      st.addEventListener("input", function (e) { strictness = parseInt(e.target.value); body.querySelector("#al-strict-val").textContent = strictness; });
      var rp = body.querySelector("#al-readpos");
      rp.addEventListener("input", function () { paintQuestion(); });
      paintQuestion();
      loadLists();
    }

    function qText() { return (current && (current.question_sanitized || "")).split("(*)").join("") || ""; }
    function readChars() {
      var rp = body && body.querySelector("#al-readpos");
      var pct = rp ? parseInt(rp.value) : 100;
      var v = body && body.querySelector("#al-readpos-val"); if (v) v.textContent = pct + "%";
      return Math.round(qText().length * pct / 100);
    }
    function paintQuestion() {
      var el = body && body.querySelector("#al-question"); if (!el) return;
      var text = qText(), n = readChars();
      el.innerHTML = '<span class="revealed">' + esc(text.slice(0, n)) + '</span><span class="al-unread">' + esc(text.slice(n)) + "</span>";
    }

    async function loadLists() {
      var el = body && body.querySelector("#al-lists");
      if (!el || !current) return;
      try {
        var d = await ctx.api.post("/api/parse-answerline", { answerline: current.answer || "", sanitized: current.answer_sanitized || "" });
        var row = function (cls, label, items) {
          return '<div class="al-list-row"><span class="al-tag ' + cls + '">' + label + "</span>" +
            (items.length
              ? '<span class="al-terms">' + items.map(function (t) { return '<span class="al-term">' + esc(t) + "</span>"; }).join("") + "</span>"
              : '<span class="text-muted" style="font-size:11px">(none)</span>') +
            "</div>";
        };
        var promptShow = (d.prompt || []).map(function (p) {
          var t = p.target === "__partial__" ? "(partial answers)" : p.target;
          return t + (p.ask ? " → “" + p.ask + "”" : "") + (p.until ? " [until " + (p.until === "__self__" ? "read" : p.until) + "]" : "") + (p.after ? " [after " + p.after + "]" : "");
        });
        var acceptShow = (d.accept || []).map(function (t) {
          var q = (d.qualifiers || {})[t];
          return t + (q && q.until ? " [until " + (q.until === "__self__" ? "read" : q.until) + "]" : "") + (q && q.after ? " [after " + q.after + "]" : "");
        });
        var rejectShow = (d.reject || []).map(function (t) { return t === "__partial__" ? "(partial answers)" : t; });
        el.innerHTML =
          row("accept", "ACCEPT", acceptShow) +
          row("prompt", "PROMPT", promptShow) +
          row("antiprompt", "ANTI-PROMPT", (d.antiprompt || []).map(function (p) { return p.target + (p.ask ? " → “" + p.ask + "”" : ""); })) +
          row("reject", "REJECT", rejectShow);
      } catch (e) {
        el.innerHTML = '<span class="text-muted" style="font-size:11px">Couldn’t parse: ' + esc(e.message || e) + "</span>";
      }
    }

    async function check() {
      if (!current) return;
      var input = body.querySelector("#al-input");
      var resEl = body.querySelector("#al-result");
      var answer = (input.value || "").trim();
      if (!answer) { resEl.innerHTML = '<div class="al-verdict reject">Type an answer first.</div>'; return; }
      resEl.innerHTML = '<div class="text-muted">Checking…</div>';
      try {
        var r = await ctx.api.post("/api/evaluate-tossup", { questionId: current.id, answer: answer, strictness: strictness, buzzPosition: readChars() });
        var v = { status: r.status, prompt: r.prompt, antiprompt: !!r.antiprompt };
        var overridden = false;
        try {
          if (window.QB && window.QB.applyAnswerRules) {
            var qlen = (current.question_sanitized || current.question || "").length;
            var out = window.QB.applyAnswerRules({ status: r.status, prompt: r.prompt, antiprompt: !!r.antiprompt },
              { userAnswer: answer, question: current, buzzPosition: readChars(), fullyRead: readChars() >= qlen, strictness: strictness });
            if (out && out.status) { overridden = out.status !== r.status; v = out; }
          }
        } catch (e) {}
        var ruleBadge = overridden ? ' <span class="al-ruled">(Answer Rules override)</span>' : "";
        var html;
        if (v.status === "accept") html = '<div class="al-verdict accept">✓ CORRECT — that answer would be accepted.' + ruleBadge + "</div>";
        else if (v.status === "prompt" && v.antiprompt) html = '<div class="al-verdict antiprompt">◐ ANTI-PROMPT' + (v.prompt && v.prompt.ask ? " — " + esc(v.prompt.ask) : " — too specific, be less specific") + ruleBadge + "</div>";
        else if (v.status === "prompt") html = '<div class="al-verdict prompt">◑ PROMPT' + (v.prompt && v.prompt.ask ? " — " + esc(v.prompt.ask) : "") + ruleBadge + "</div>";
        else html = '<div class="al-verdict reject">✗ INCORRECT — that answer would not be accepted (at this read position).' + ruleBadge + "</div>";
        html += '<div class="al-reveal text-muted">Accepted answer: <span style="color:var(--green)">' + (current.answer ? current.answer.replace(/<(?!\/?(b|u|i|em|strong)\b)[^>]*>/gi, "") : esc(r.answer || current.answer_sanitized || "")) + "</span></div>";
        resEl.innerHTML = html;
      } catch (e) {
        resEl.innerHTML = '<div class="al-verdict reject">Error: ' + esc(e.message || e) + "</div>";
      }
    }

    // "+ save" menu entry app-wide: open this tossup in the Lab, fully revealed.
    ctx.registerSaveAction(function (q, type) {
      if (type !== "tossup") return [];
      return [{ label: "Open in Answer Lab", onClick: function () {
        loadSpecific(q);
        try { window.QB.showPage("answerline-lab::lab"); } catch (e) {}
      } }];
    });


    ctx._cleanup = function () { returnPanel(); };
    ctx.toast("Answerline Lab enabled");
  }
