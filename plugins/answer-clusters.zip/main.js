/**
 * OfflineQuiz plugin: Answer Clusters
 *
 * Pick an answer and see the answers whose tossups share its clues: Monet with Manet and Renoir,
 * the Iliad with the Aeneid. Open any pair for the clues only one of them has, then practice them
 * together. Your own mix-ups, from your negs, are one click away.
 */
QB.registerPlugin({
  id: "answer-clusters",
  name: "Answer Clusters",
  version: "1.1.1",
  author: "OfflineQuiz",
  description: "See which answers share clues with one you know, and the clues that tell them apart.",
  onEnable: __qbMain,
  onDisable: function (ctx) { if (ctx._cleanup) ctx._cleanup(); },
});
