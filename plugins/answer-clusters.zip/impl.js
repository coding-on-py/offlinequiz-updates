function __qbMain(ctx) {
  // ── the kit the 15.62 plugins share (text, icons, questions, judging, history) ──
  function esc(s) { return (s == null ? "" : String(s)).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
  var IC = {
    play: '<path d="M7 4l13 8-13 8z"/>',
    pause: '<path d="M8 5v14M16 5v14"/>',
    left: '<path d="M15 6l-6 6 6 6"/>',
    right: '<path d="M9 6l6 6-6 6"/>',
    next: '<path d="M6 5l9 7-9 7zM18 5v14"/>',
    refresh: '<path d="M20 11a8 8 0 10-2.3 5.7M20 4v7h-7"/>',
    x: '<path d="M6 6l12 12M18 6L6 18"/>',
    check: '<path d="M5 12l5 5 9-10"/>',
    mic: '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
    volume: '<path d="M4 9v6h4l5 4V5L8 9z"/><path d="M16 9a4 4 0 0 1 0 6M19 6a8 8 0 0 1 0 12"/>',
    copy: '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h3"/>',
    edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="M13.5 6.5l4 4"/>',
    bolt: '<path d="M13 3L5 14h6l-1 7 8-11h-6z"/>',
    flag: '<path d="M5 21V4M5 4h11l-2 4 2 4H5"/>',
    users: '<circle cx="9" cy="8" r="3"/><path d="M3 20a6 6 0 0 1 12 0M16 4a3 3 0 0 1 0 6M21 20a6 6 0 0 0-4-5.6"/>',
    target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
    down: '<path d="M6 9l6 6 6-6"/>',
    up: '<path d="M6 15l6-6 6 6"/>',
    quote: '<path d="M7 7h4v4c0 3-1.5 5-4 6M15 7h4v4c0 3-1.5 5-4 6"/>',
    grid: '<rect x="3" y="3" width="8" height="10" rx="2"/><rect x="13" y="3" width="8" height="6" rx="2"/><rect x="13" y="11" width="8" height="10" rx="2"/><rect x="3" y="15" width="8" height="6" rx="2"/>',
    ear: '<path d="M7 9a5 5 0 0 1 10 0c0 3-3 4-3 7a3 3 0 0 1-6 0"/><path d="M10 9a2 2 0 0 1 4 0"/>',
  };
  function ic(name, size) {
    var s = size || 16;
    return '<svg width="' + s + '" height="' + s + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (IC[name] || "") + "</svg>";
  }
  function loading(label) { return '<div class="pk-loading">' + (ctx.loadingBarHtml ? ctx.loadingBarHtml(label) : esc(label)) + "</div>"; }
  function norm(s) { return String(s || "").toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[^a-z0-9]+/g, " ").trim(); }
  function pct(a, n) { return n ? Math.round(100 * a / n) : 0; }
  function fmt(n) { return Number(n || 0).toLocaleString(); }
  function plural(n, one, many) { return fmt(n) + " " + (n === 1 ? one : (many || one + "s")); }
  function shuffle(a) { for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)), t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
  function inField(e) { var t = e && e.target; return !!t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT" || t.isContentEditable); }
  function dayKey(t) { var d = new Date(t || Date.now()); return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0"); }
  var DAY = 86400000;

  // the practice setup (Setup panel): its filters and reading settings
  function cfg() { try { return (ctx.host && ctx.host.getPracticeConfig && ctx.host.getPracticeConfig()) || {}; } catch (e) { return {}; } }
  // filters → query parameters, the ones the app sends for a random question
  function filtersQuery(f, extra) {
    f = f || {}; var p = [];
    var add = function (k, v) { p.push(k + "=" + encodeURIComponent(v)); };
    if (f.categories && f.categories.length) add("categories", f.categories.join(","));
    if (f.categoryIds && f.categoryIds.length) add("categoryIds", f.categoryIds.join(","));
    if (f.difficulties && f.difficulties.length) add("difficulties", f.difficulties.join(","));
    if (f.setNames && f.setNames.length) add("setNames", f.setNames.join(","));
    if (f.packetNumbers && f.packetNumbers.length) add("packetNumbers", f.packetNumbers.join(","));
    if (f.yearMin != null) add("yearMin", f.yearMin);
    if (f.yearMax != null) add("yearMax", f.yearMax);
    if (f.powermarkOnly) add("powermarkOnly", "true");
    if (f.canon && f.canon.length) add("canon", f.canon.join(","));
    add("cleanOnly", "1");
    Object.keys(extra || {}).forEach(function (k) { if (extra[k] != null && extra[k] !== false) add(k, extra[k]); });
    return p.join("&");
  }
  // the practice filters without a set (a drill draws from everything the player picked)
  function practiceFilters() { var f = Object.assign({}, cfg().filters || {}); delete f.setNames; delete f.packetNumbers; delete f.setIds; return f; }
  async function getTossups(n, f, extra) {
    try { var d = await ctx.api.get("/api/tossups/query?" + filtersQuery(f || practiceFilters(), Object.assign({ random: 1, limit: n }, extra || {}))); return (d && d.rows) || []; } catch (e) { return []; }
  }
  async function getBonuses(n, f, extra) {
    try { var d = await ctx.api.get("/api/bonuses/query?" + filtersQuery(f || practiceFilters(), Object.assign({ random: 1, limit: n }, extra || {}))); return (d && d.rows) || []; } catch (e) { return []; }
  }
  async function getTossup(id) { try { return (await ctx.api.get("/api/tossups/" + encodeURIComponent(id))).tossup || null; } catch (e) { return null; } }
  async function getBonus(id) { try { return (await ctx.api.get("/api/bonuses/" + encodeURIComponent(id))).bonus || null; } catch (e) { return null; } }
  async function searchTossups(query, limit, f) {
    try { var d = await ctx.api.get("/api/tossups/search?query=" + encodeURIComponent(query) + "&limit=" + (limit || 20) + (f ? "&" + filtersQuery(f) : "")); return { rows: (d && d.rows) || [], total: (d && d.total) || 0 }; } catch (e) { return { rows: [], total: 0 }; }
  }
  // tossups whose answer line names an answer
  async function tossupsOn(answer, limit) { return (await searchTossups('answer_sanitized : ("' + String(answer).replace(/"/g, "") + '")', limit || 20)).rows; }

  // ── the voice plugins' files (15.69: Kokoro Voice, Voice Answers) ──
  // Worker code: a plugin's worker source starts with "(" + voiceFilesWorker + ")(cfg);". fetch() in that worker then
  // serves the model, voice and code files from IndexedDB once they've been fetched, so they load in a moment and work
  // offline. The first time, each comes from our server (onlinequiz.net/voice/, a copy of Hugging Face's and
  // jsDelivr's files by the same paths: server.js, scripts/publish-voice.mjs) or else its own host, in 4 MB ranges six at a time, each range kept as
  // it arrives: one long download over a slow line kept breaking off and starting again, so Kokoro never got ready.
  // cfg: { mirror: our copy's address (the website's own /voice/; the app's www.onlinequiz.net/voice/), db: the IndexedDB name (1.x/2.x kept whole files there by their address, and those are used), sizes: { url:
  // bytes } }. self.voiceFiles: plan(urls) totals what's still to fetch (progress goes to the page as { t: "progress",
  // loaded, total }), file(url), has(url) (kept already), blobUrl(url, type), importCode(url, fallback), route(fn) (fn(url)
  // → a Response promise for a file it makes itself, or null).
  // where our copy is: the website's own, else the live site's
  function voiceMirror() { return (window.QB_WEB && /^https?:/.test(location.origin) ? location.origin : "https://www.onlinequiz.net") + "/voice/"; }
  function voiceFilesWorker(cfg) {
    var MIRROR = cfg.mirror || "https://www.onlinequiz.net/voice/", HOSTS = [["https://huggingface.co/", "hf/"], ["https://cdn.jsdelivr.net/npm/", "npm/"]];
    var CHUNK = 4 << 20, LANES = 6, real = self.fetch.bind(self), sizes = cfg.sizes || {}, got = 0, want = 0, inflight = {};
    var dbp = null;
    function db() {
      return dbp || (dbp = new Promise(function (res, rej) { var r = indexedDB.open(cfg.db, 1); r.onupgradeneeded = function () { r.result.createObjectStore("files"); }; r.onsuccess = function () { res(r.result); }; r.onerror = function () { rej(r.error); }; }));
    }
    function get(k) { return db().then(function (d) { return new Promise(function (res) { try { var g = d.transaction("files").objectStore("files").get(k); g.onsuccess = function () { res(g.result); }; g.onerror = function () { res(undefined); }; } catch (e) { res(undefined); } }); }); }
    function put(k, v) { return db().then(function (d) { return new Promise(function (res) { try { var tx = d.transaction("files", "readwrite"); tx.objectStore("files").put(v, k); tx.oncomplete = function () { res(true); }; tx.onerror = tx.onabort = function () { res(false); }; } catch (e) { res(false); } }); }); }
    function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
    function mirrorOf(url) { for (var i = 0; i < HOSTS.length; i++) if (url.indexOf(HOSTS[i][0]) === 0) return MIRROR + HOSTS[i][1] + url.slice(HOSTS[i][0].length); return null; }
    function report() { if (want) postMessage({ t: "progress", loaded: Math.min(got, want), total: want }); }
    // kept: a small file whole, a big one as its ranges
    async function kept(url) {
      var whole = await get(url); if (whole) return whole;
      var meta = await get(url + "#meta"); if (!meta || !meta.done) return null;
      var all = new Uint8Array(meta.total), o = 0;
      for (var i = 0; i < meta.n; i++) { var p = await get(url + "#" + i); if (!p) return null; all.set(new Uint8Array(p), o); o += p.byteLength; }
      return all.buffer;
    }
    async function sizeAt(src) {
      var r = await real(src, { headers: { Range: "bytes=0-0" } });
      var m = /\/(\d+)\s*$/.exec(r.headers.get("Content-Range") || ""), n = m ? +m[1] : r.status === 200 ? +(r.headers.get("Content-Length") || 0) : 0;
      try { if (r.body) await r.body.cancel(); } catch (e) {}
      if (!n) throw new Error("HTTP " + r.status);
      return n;
    }
    async function pull(src, url, total) {
      // in one piece: a small file, and jsDelivr's (served compressed, so its ranges aren't the file's)
      if (total <= 2 * CHUNK || /^https:\/\/cdn\.jsdelivr\.net\//.test(src)) {
        var r = await real(src); if (!r.ok) throw new Error("HTTP " + r.status);
        var b = await r.arrayBuffer(); if (sizes[url] && b.byteLength !== sizes[url]) throw new Error("cut short");
        got += b.byteLength; report(); await put(url, b); return b;
      }
      var n = Math.ceil(total / CHUNK), parts = new Array(n), meta = await get(url + "#meta");
      if (meta && meta.total === total) { for (var i = 0; i < n; i++) { var p = await get(url + "#" + i); if (p && p.byteLength === Math.min(total, (i + 1) * CHUNK) - i * CHUNK) { parts[i] = p; got += p.byteLength; } } }
      else await put(url + "#meta", { total: total, n: n, done: false });
      report();
      var next = 0;
      async function lane() {
        for (;;) {
          var k = -1; while (next < n) { if (!parts[next]) { k = next++; break; } next++; }
          if (k < 0) return;
          var a = k * CHUNK, z = Math.min(total, a + CHUNK) - 1;
          for (var t = 0; ; t++) {
            try {
              var rr = await real(src, { headers: { Range: "bytes=" + a + "-" + z } });
              if (rr.status !== 206) throw new Error("HTTP " + rr.status);
              var buf = await rr.arrayBuffer(); if (buf.byteLength !== z - a + 1) throw new Error("cut short");
              await put(url + "#" + k, buf); parts[k] = buf; got += buf.byteLength; report(); break;
            } catch (e) { if (t >= 6) throw e; await sleep(700 * (t + 1)); }
          }
        }
      }
      var lanes = []; for (var j = 0; j < Math.min(LANES, n); j++) lanes.push(lane());
      await Promise.all(lanes);
      await put(url + "#meta", { total: total, n: n, done: true });
      var all = new Uint8Array(total), o = 0; for (var q = 0; q < n; q++) { all.set(new Uint8Array(parts[q]), o); o += parts[q].byteLength; }
      return all.buffer;
    }
    function file(url) {
      if (inflight[url]) return inflight[url];
      return (inflight[url] = (async function () {
        var k = await kept(url); if (k) return k;
        var srcs = [mirrorOf(url), url].filter(Boolean), last = null;
        for (var i = 0; i < srcs.length; i++) {
          try { var total = sizes[url] || (/^https:\/\/cdn\.jsdelivr\.net\//.test(srcs[i]) ? 1 : await sizeAt(srcs[i])); return await pull(srcs[i], url, total); }
          catch (e) { last = e; }
        }
        throw last || new Error("unreachable");
      })().finally(function () { delete inflight[url]; }));
    }
    // what loading still needs, so the progress is of the whole download
    async function plan(urls) {
      for (var i = 0; i < urls.length; i++) if (!(await has(urls[i]))) want += sizes[urls[i]] || 0;
      report();
    }
    async function has(url) {
      var n = await db().then(function (d) { return new Promise(function (res) { try { var c = d.transaction("files").objectStore("files").count(url); c.onsuccess = function () { res(c.result); }; c.onerror = function () { res(0); }; } catch (e) { res(0); } }); });
      if (n) return true;
      var meta = await get(url + "#meta"); return !!(meta && meta.done);
    }
    var routes = [];
    async function blobUrl(url, type) { return URL.createObjectURL(new Blob([await file(url)], { type: type || "application/octet-stream" })); }
    async function importCode(url, fallback) {
      try { return await import(await blobUrl(url, "text/javascript")); }
      catch (e) { if (fallback) return import(fallback); throw e; }
    }
    // a jsDelivr "+esm" module with the modules it imports ("/npm/…/+esm"), each kept, their imports pointed at the kept
    // copies (Voice Answers' transformers.js: it, onnxruntime-web and onnxruntime-common)
    var esm = {};
    function esmUrl(url) {
      return esm[url] || (esm[url] = (async function () {
        var text = new TextDecoder().decode(await file(url)), deps = {}, re = /(?:from|import)\s*\(?\s*"(\/npm\/[^"]+)"/g, m;
        while ((m = re.exec(text))) deps[m[1]] = 1;
        for (var d in deps) text = text.split('"' + d + '"').join('"' + await esmUrl("https://cdn.jsdelivr.net" + d) + '"');
        return URL.createObjectURL(new Blob([text], { type: "text/javascript" }));
      })());
    }
    async function importEsm(url) {
      try { return await import(await esmUrl(url)); }
      catch (e) { return import(url); }   // (online: as jsDelivr serves it)
    }
    // the libraries' own fetches (models, voices) come here; a browser cache they'd keep copies in is one that keeps nothing
    self.fetch = function (input, init) {
      var url = typeof input === "string" ? input : input && input.href ? input.href : input && input.url;
      for (var i = 0; url && i < routes.length; i++) { var made = routes[i](url); if (made) return made; }
      if (url && /^https:\/\/(huggingface\.co\/[^?#]+\/resolve\/|cdn\.jsdelivr\.net\/npm\/)/.test(url)) {
        return file(url).then(function (b) { return new Response(b, { status: 200, headers: { "content-length": String(b.byteLength) } }); });
      }
      return real(input, init);
    };
    var none = { match: async function () {}, put: async function () {}, delete: async function () { return false; }, keys: async function () { return []; } };
    try { Object.defineProperty(self, "caches", { configurable: true, value: { open: async function () { return none; }, has: async function () { return false; }, delete: async function () { return false; }, keys: async function () { return []; }, match: async function () {} } }); } catch (e) {}
    self.voiceFiles = { plan: plan, file: file, has: has, blobUrl: blobUrl, importCode: importCode, importEsm: importEsm, route: function (fn) { routes.push(fn); } };
  }

  // a record's text as practice reads it (notes and pronunciation guides per the player's settings)
  function readText(q) {
    try { if (ctx.host && ctx.host.questionText) { var t = ctx.host.questionText(q, "question"); if (t != null) return String(t).replace(/\(\*\)/g, "").replace(/\s{2,}/g, " ").trim(); } } catch (e) {}
    return String((q && q.question_sanitized) || "").replace(/\(\*\)/g, "").trim();
  }
  function powerAt(q) { return String((q && q.question_sanitized) || "").indexOf("(*)"); }
  // sentences, without breaking at "St." or an initial ("J. R. R. Tolkien")
  var ABBR = /(?:\b(?:St|Ste|Mt|Mts|Dr|Mr|Mrs|Ms|Mme|Prof|Sr|Jr|Rev|Fr|Gen|Col|Capt|Lt|Sgt|Maj|Adm|Hon|Pres|Gov|Sen|Rep|vs|etc|cf|ca|al|Inc|Co|Corp|Ltd|Bros|approx|No|Nos|Op|op|no|Vol|vol|Ch|ch|Fig|fig|Ft|Pt|pt|Ave|[A-Za-z])\.["”’']?)$/;
  function sentences(text) {
    var parts = String(text || "").split(/(?<=[.?!]["”’)]*)\s+(?=["“(]?[A-Z0-9])/), out = [], cur = "";
    for (var i = 0; i < parts.length; i++) {
      cur = cur ? cur + " " + parts[i] : parts[i];
      if (i < parts.length - 1 && ABBR.test(cur.trim())) continue;
      out.push(cur.trim()); cur = "";
    }
    if (cur.trim()) out.push(cur.trim());
    return out.filter(Boolean);
  }
  // where each sentence of a text ends (indexes into it)
  function sentenceEnds(text) {
    var at = 0, out = []; text = String(text || "");
    sentences(text).forEach(function (x) { var i = text.indexOf(x, at); if (i < 0) return; at = i + x.length; out.push(at); });
    return out;
  }
  // ── categories (15.63): the app's own picker, its picks kept under `key` ([] = every category) ──
  // mountCats(root, key, onChange) puts it in root's [data-cats] (made once, moved into each new render);
  // inCats(pk, e): a history entry or question in the picks; with no picks, all are
  var PICKERS = {};
  // opts.label: "" for just the picks, in a row that has its own label
  function catPicker(key, onChange, opts) {
    if (PICKERS[key]) return PICKERS[key];
    if (!ctx.host || !ctx.host.categoryPicker) return null;
    var o = { selected: ctx.storage.get(key) || [], onChange: function (ids) { ctx.storage.set(key, ids); if (onChange) onChange(ids); } };
    if (opts && opts.label != null) o.label = opts.label;
    var pk = ctx.host.categoryPicker(null, o);
    PICKERS[key] = pk;
    // the picks match nothing until the tree is in: draw again once it is
    if (pk.ready && (ctx.storage.get(key) || []).length) pk.ready.then(function () { if (onChange) onChange(pk.get()); });
    return pk;
  }
  function mountCats(root, key, onChange, opts) {
    var pk = catPicker(key, onChange, opts), host = root && root.querySelector("[data-cats]");
    if (pk && host) host.appendChild(pk.el);
    return pk;
  }
  function inCats(pk, e) {
    if (!pk || !pk.get().length) return true;
    return pk.matches(String((e && (e.category_path || e.path || e.category || e.root)) || ""));
  }
  // ── the app's reader on a page titled for the plugin (15.63: ctx.host.playPractice). Its Setup picks the categories ──
  function canRead() { return !!(ctx.host && ctx.host.playPractice); }
  function onReader() { return !!(ctx.host && ctx.host.onPracticePage && ctx.host.onPracticePage()); }
  // a plugin's start page: an icon, what it is, a Start button (data-pk="start"), a note under it
  function heroHtml(icon, title, text, start, note) {
    return '<div class="pk-hero"><span class="pk-hero-ico">' + ic(icon, 26) + "</span><h2>" + esc(title) + "</h2><p>" + esc(text) + "</p>" +
      '<div class="pk-actions pk-center"><button type="button" class="btn btn-primary" data-pk="start">' + ic("play", 14) + esc(start || "Start") + "</button></div>" +
      (note ? '<div class="pk-muted pk-small">' + note + "</div>" : "") + "</div>";
  }
  // the answer line, with its bold and underlining (nothing else of the HTML)
  function answerHtml(q) {
    var h = String((q && q.answer) || "");
    if (!/<\/?(b|u|strong|em|i)\b/i.test(h)) return esc((q && q.answer_sanitized) || h);
    return h.replace(/<(\/?)(b|u|strong|em|i)\b[^>]*>/gi, "\u0001$1$2\u0002").replace(/<[^>]*>/g, "").replace(/&(?!(?:amp|lt|gt|quot|#\d+);)/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/\u0001(\/?)(\w+)\u0002/g, "<$1$2>");
  }
  function primary(q) {
    var a = "";
    try { if (ctx.host && ctx.host.extractPrimaryAnswer) a = ctx.host.extractPrimaryAnswer((q && q.answer) || "", (q && q.answer_sanitized) || ""); } catch (e) {}
    return a || String((q && q.answer_sanitized) || "").replace(/\s*[\[(].*$/, "").trim();
  }
  // an answer as a person reads it in a list: the line up to its first bracket ("Mary, Queen of Scots"), where primary()
  // runs the bold parts together for matching ("Mary, Queen of Scots Mary Stuart")
  function answerName(q) { return String((q && q.answer_sanitized) || "").replace(/\s*[\[(].*$/, "").trim() || primary(q); }
  // judged right here, like practice (judge.js); { status: "accept" | "prompt" | "reject", prompt }. opts.asAnswer: as the
  // answer box would judge the question on screen now (the player's strictness, the buzz, a prompt's answer; 15.92)
  async function judge(q, answer, opts) {
    opts = opts || {};
    try {
      if (ctx.host && ctx.host.judgeTossup) return (await ctx.host.judgeTossup(q, answer, { strictness: opts.strictness != null ? opts.strictness : (cfg().strictness || 10), buzzPosition: opts.buzzPosition, previous: opts.previous || null, asAnswer: !!opts.asAnswer })) || { status: "reject" };
      return (await ctx.api.post("/api/evaluate-tossup", { questionId: q.id, answer: answer, strictness: cfg().strictness || 10, buzzPosition: opts.buzzPosition, previous: opts.previous || null })) || { status: "reject" };
    } catch (e) { return { status: "reject" }; }
  }
  async function judgePart(b, part, answer, opts) {
    opts = opts || {};
    try {
      if (ctx.host && ctx.host.judgeBonusPart) return (await ctx.host.judgeBonusPart(b, part, answer, { strictness: cfg().strictness || 10, previous: opts.previous || null, asAnswer: !!opts.asAnswer })) || { status: "reject" };
      return (await ctx.api.post("/api/evaluate-bonus-part", { questionId: b.id, part: part, answer: answer, strictness: cfg().strictness || 10 })) || { status: "reject" };
    } catch (e) { return { status: "reject" }; }
  }
  async function judgeLine(line, sani, answer, opts) {
    opts = opts || {};
    try {
      if (ctx.host && ctx.host.judgeAnswerLine) return (await ctx.host.judgeAnswerLine(line, sani, answer, { strictness: cfg().strictness || 10, previous: opts.previous || null })) || { status: "reject" };
      return (await ctx.api.post("/api/evaluate-answer", { answerline: line, answer: answer, strictness: cfg().strictness || 10 })) || { status: "reject" };
    } catch (e) { return { status: "reject" }; }
  }
  function bonusParts(b) { try { return JSON.parse((b && (b.parts_sanitized || b.parts)) || "[]"); } catch (e) { return []; } }
  function bonusAnswers(b) { try { return JSON.parse((b && b.answers) || "[]"); } catch (e) { return []; } }
  function bonusAnswersSani(b) { try { return JSON.parse((b && b.answers_sanitized) || "[]"); } catch (e) { return []; } }

  // the player's answers (Stats' history), only the fields asked for
  async function history(fields) {
    try { return ((await ctx.api.get("/api/sessions/all-entries?" + (/\banswer\b/.test(fields || "") ? "answers=1&" : "") + "fields=" + encodeURIComponent(fields || ""))).entries) || []; } catch (e) { return []; }
  }
  // record a tossup answered on a plugin's page into the player's stats (the path Coach Mode uses)
  function record(q, r) {
    try {
      ctx.api.post("/api/check-tossup", { questionId: q.id, answer: r.answer || "", buzzPosition: r.buzzPosition || 0, sessionId: r.session, overriding: true,
        correct: !!r.correct, isPower: !!r.power, points: r.points || 0, celerity: r.celerity != null ? r.celerity : 1 }).catch(function () {});
    } catch (e) {}
  }

  var ROOT_COLOR = { "Literature": "#bc8cff", "Science": "#58a6ff", "Math": "#a5e05b", "Pop Culture": "#ff7b72", "Sports": "#ff6f91", "Fine Arts": "#f778ba", "History": "#e3b341", "Geography": "#56d364", "Mythology": "#ffa657", "Social Science": "#3dd6a3", "Philosophy": "#39c5cf", "Theology": "#8e9bff", "Current Events": "#c9d16b", "Miscellaneous": "#8b949e" };
  // NAQT's high school distribution, per 24 tossups / bonuses (naqt.com/hs/distribution.jsp)
  var NAQT = [["Literature", 3.9, 3.8], ["Science", 4.5, 4.3], ["Math", 1.0, 1.0], ["Fine Arts", 2.0, 2.0], ["History", 4.6, 4.5], ["Geography", 1.9, 1.9], ["Mythology", 0.6, 0.7],
    ["Pop Culture", 1.0, 0.9], ["Sports", 0.7, 0.7], ["Social Science", 0.6, 0.6], ["Philosophy", 0.3, 0.3], ["Theology", 0.4, 0.4], ["Current Events", 1.5, 1.4], ["Miscellaneous", 1.0, 1.5]];
  function rootOf(e) { return String((e && (e.category_path || e.category)) || "").split(" > ")[0] || "Miscellaneous"; }
  function dot(root) { return '<span class="pk-dot" style="--c:' + (ROOT_COLOR[root] || "#8b949e") + '"></span>'; }
  var _roots = null;
  async function roots() {
    if (_roots) return _roots;
    try { var t = ctx.host && ctx.host.getCategoryTree ? await ctx.host.getCategoryTree("tossups") : (await ctx.api.get("/api/category-tree?type=tossups")).tree; _roots = (t || []).map(function (n) { return { id: n.id, name: n.name, count: n.count }; }); }
    catch (e) { _roots = []; }
    return _roots;
  }
  var DIFF_NAME = { 1: "Middle school", 2: "Easy high school", 3: "Regular high school", 4: "Hard high school", 5: "National high school", 6: "Easy college", 7: "Medium college", 8: "Regionals college", 9: "Nationals college", 10: "Open" };

  function tile(value, label, cls) { return '<div class="pk-tile' + (cls ? " " + cls : "") + '"><b class="num">' + value + "</b><span>" + esc(label) + "</span></div>"; }
  function segHtml(name, items, on) {
    return '<div class="seg pk-seg" role="group">' + items.map(function (it) {
      return '<button type="button" data-' + name + '="' + esc(it[0]) + '" aria-pressed="' + (String(on) === String(it[0])) + '">' + esc(it[1]) + "</button>";
    }).join("") + "</div>";
  }
  function emptyHtml(text) { return '<div class="db-empty pk-empty">' + esc(text) + "</div>"; }
  // square toggles 1 to 10 (no 0, unrated: 15.134), Setup's difficulty look (the app's .diff-toggles), `on` the ones picked; diffsIn reads them
  function diffHtml(name, on) {
    var h = '<div class="diff-toggles pk-diffs" role="group" aria-label="Difficulty">';
    for (var d = 1; d <= 10; d++) h += '<label title="' + esc(DIFF_NAME[d]) + '"><input type="checkbox" data-' + name + '="' + d + '"' + ((on || []).indexOf(d) >= 0 ? " checked" : "") + "><span>" + d + "</span></label>";
    return h + "</div>";
  }
  function diffsIn(root, name) { return [].slice.call(root.querySelectorAll("[data-" + name + "]")).filter(function (i) { return i.checked; }).map(function (i) { return Number(i.getAttribute("data-" + name)); }); }
  // a list of difficulties in a few words: [2, 3, 4, 5] → "2 to 5"
  function diffWords(ds) {
    ds = (ds || []).map(Number).filter(function (d) { return d >= 1 && d <= 10; }).sort(function (a, b) { return a - b; });
    if (!ds.length) return "any difficulty";
    var run = ds.every(function (d, i) { return !i || d === ds[i - 1] + 1; });
    return ds.length === 1 ? "difficulty " + ds[0] : run ? "difficulty " + ds[0] + " to " + ds[ds.length - 1] : "difficulty " + ds.join(", ");
  }
  function playList(kind, ids, title) {
    if (!ids || !ids.length) return false;
    try { return !!(ctx.host && ctx.host.launchQuestions && ctx.host.launchQuestions(kind, ids, { title: title })); } catch (e) { return false; }
  }

  // a reader: shows `text` a character at a time at the practice reading speed. start(), pause(), go(), stop();
  // at() is how far it is; onEnd once it's all shown
  function Reader(el, text, opts) {
    opts = opts || {};
    var ms = opts.ms != null ? opts.ms : (Number(cfg().revealSpeed) || 25), idx = 0, raf = 0, last = 0, on = false;
    var paint = function () { el.innerHTML = '<span class="pk-read">' + esc(text.slice(0, idx)) + '</span><span class="pk-unread" aria-hidden="true">' + esc(text.slice(idx)) + "</span>"; };
    var step = function (t) {
      raf = 0; if (!on) return;
      if (!last) last = t;
      var n = ms > 0 ? Math.floor((t - last) / ms) : text.length;
      if (n > 0) { idx = Math.min(text.length, idx + n); last += n * ms; paint(); if (opts.onTick) opts.onTick(idx); }
      if (idx >= text.length) { on = false; if (opts.onEnd) opts.onEnd(); return; }
      raf = requestAnimationFrame(step);
    };
    paint();
    return {
      start: function () { if (on) return; on = true; last = 0; raf = requestAnimationFrame(step); },
      pause: function () { on = false; if (raf) cancelAnimationFrame(raf); raf = 0; },
      stop: function () { on = false; if (raf) cancelAnimationFrame(raf); raf = 0; },
      showAll: function () { this.stop(); idx = text.length; el.textContent = text; },
      at: function () { return idx; },
      running: function () { return on; },
    };
  }
  // a reader's position in the displayed text → the record's question_sanitized (what judging and stats count)
  function serverPos(q, display, pos) {
    try { if (ctx.host && ctx.host.mapDisplayPos) return ctx.host.mapDisplayPos(display, (q && q.question_sanitized) || "", pos); } catch (e) {}
    return pos;
  }

  // ── Answer Clusters: answers that share clues with one answer, and the clues that tell them apart ──
  // An answer's clues are the words and names that come up most in its tossups. The ones that say most about it are
  // searched for in its own part of the database (its category two levels down, like Fine Arts > Visual), and the
  // answers of the tossups found are counted by the clues they share, each clue weighted by how telling it is. When the
  // topic tags know what kind of thing the answer is, only answers of that kind stay: painters with a painter, epics with
  // an epic (1.2.0: a composer's cluster was his own works, a painter's the cities he painted).
  var body = null, page = null, entries = null;
  var view = { q: "", cur: null, open: null, busy: false };
  var STOP = new Set(("a an the and or but nor so of in on at to for with by from as is are was were be been being this that these those its it his her their they them he she him " +
    "who whom which what when where while after before during under over into onto about above below between through than then there here also only one two three four five " +
    "first second third last other another such some many most more much each every both either neither same any all not no yet still even once upon within without " +
    "points point name names named give identify ftp work works figure title titled author called known describes described description features feature featured includes include " +
    "included including character characters novel novels poem poems play plays story stories book books piece pieces man woman men women people person thing things way ways year years " +
    "time times called used uses using use like later early late part parts number group made make makes making became become becomes found finds wrote written writes said says " +
    "new old great large small long short high low many several whose would could should might will can must may did does done had has have having just well very").split(" "));
  function terms(rows, skip) {
    var df = {}, names = {}, skipW = new Set(norm(skip).split(" "));
    rows.forEach(function (q) {
      var t = String(q.question_sanitized || "").replace(/\(\*\)/g, ""), seen = {};
      (t.toLowerCase().match(/[a-z][a-z'-]{3,}/g) || []).forEach(function (w) { w = w.replace(/'s$/, ""); if (STOP.has(w) || skipW.has(w) || seen[w]) return; seen[w] = 1; df[w] = (df[w] || 0) + 1; });
      // names: two or more capitalized words not at the start of a sentence ("Water Lilies", "Claude Debussy")
      var m, re = /(?:^|[^.?!]\s)((?:[A-Z][a-z'’]+\s){1,3}[A-Z][a-z'’]+)/g;
      while ((m = re.exec(t))) { var n = m[1].trim(); if (n.split(" ").some(function (w) { return skipW.has(norm(w)); }) || seen["#" + n]) continue; seen["#" + n] = 1; names[n] = (names[n] || 0) + 1; }
    });
    var out = Object.keys(names).filter(function (n) { return names[n] >= 2; }).map(function (n) { return { t: n, n: names[n] * 1.5, name: true }; })
      .concat(Object.keys(df).filter(function (w) { return df[w] >= 2; }).map(function (w) { return { t: w, n: df[w] }; }));
    return out.sort(function (a, b) { return b.n - a.n; });
  }
  var bare = function (s) { return norm(s).replace(/^(the|a|an) /, ""); };
  // one answer inside another, word for word ("monet" in "claude monet", never "art" in "artemis")
  var within = function (a, b) { return !!a && !!b && (" " + b + " ").indexOf(" " + a + " ") >= 0; };
  function sameAnswer(a, b) { a = bare(a); b = bare(b); return !!a && !!b && (a === b || within(a, b) || within(b, a)); }
  // an answer as its line writes it, with what's in brackets taken out ("Wassily [Vasily Vasileyevich] Kandinsky" is
  // Wassily Kandinsky, not "Wassily"); the short name it's judged by when the line says something else
  function nameOf(q) {
    var t = String((q && q.answer_sanitized) || "").replace(/\[[^\]]*\]?|\([^)]*\)?/g, " ").replace(/\s+/g, " ").replace(/^[\s,;:.-]+|[\s,;:.-]+$/g, "").trim(), p = primary(q);
    var has = function (x) { return !!x && x.length <= 60 && bare(p).split(" ").every(function (w) { return within(w, bare(x)); }); };
    var one = t.split(/\s+or\s+/i)[0];   // "Catullus 64 or his epyllion": the first way it's written
    return has(one) ? one : has(t) ? t : p;
  }
  function commonest(list) { var n = {}, best = "", bn = 0; list.forEach(function (x) { if (!x) return; n[x] = (n[x] || 0) + 1; if (n[x] > bn) { bn = n[x]; best = x; } }); return best; }
  function uniq(ids) { var seen = {}; return ids.filter(function (id) { if (seen[id]) return false; seen[id] = 1; return true; }); }
  // (1.2.0) the tossups whose answer IS this one: the search finds every answer line that names it, "triangle [from
  // Concerning the Spiritual in Art by Kandinsky]" too, and Practice these two read those. The best match by name, and
  // with a topic tag, the tossups on that tag (Mercury the god, not the planet)
  async function rowsFor(answer, entity, limit) {
    var want = bare(answer); if (!want) return [];
    var found = await tossupsOn(String(answer).replace(/^(the|a|an)\s+/i, ""), limit || 60);
    var score = function (q) { var k = bare(primary(q)); return !k ? 0 : k === want ? 3 : within(want, k) || within(k, want) ? 2 : want.split(" ").every(function (w) { return within(w, k); }) ? 1 : 0; };
    var best = found.reduce(function (m, q) { return Math.max(m, score(q)); }, 0);
    var ent = entity || commonest(found.filter(function (q) { return best && score(q) === best; }).map(function (q) { return q.answer_entity; }));
    if (!best && !ent) return [];
    // with a tag, a tossup without one has to be on the very name ("Adams" isn't "Abigail Adams and John Adams")
    return found.filter(function (q) { if (ent) return q.answer_entity ? q.answer_entity === ent : score(q) === 3; return best >= 2 ? score(q) >= 2 : best > 0 && score(q) === best; });
  }
  // a related answer's tossups: by the name its tossups give it ("Ansel Adams"), else the short one they're judged by
  async function rowsOfAnswer(r, limit) {
    var a = await rowsFor(r.answer, r.entity, limit);
    if (a.length >= 3 || !r.key || bare(r.key) === bare(r.answer)) return a;
    var b = await rowsFor(r.key, r.entity, limit);
    return b.length > a.length ? b : a;
  }
  // the tree node at a category path ("Fine Arts > Visual"), for searching inside it
  var _paths = null;
  async function scopeId(path) {
    if (!path) return "";
    if (!_paths) _paths = (async function () {
      var m = {};
      try { var t = ctx.host && ctx.host.getCategoryTree ? await ctx.host.getCategoryTree("tossups") : (await ctx.api.get("/api/category-tree?type=tossups")).tree; (function walk(ns) { (ns || []).forEach(function (n) { if (n && n.path) m[n.path] = n.id; if (n) walk(n.children); }); })(t); } catch (e) {}
      return m;
    })();
    return (await _paths)[path] || "";
  }
  async function cluster(answer, extra) {
    var rowsA = (await rowsFor(answer, "", 60)).slice(0, 40);
    if (!rowsA.length) return { answer: answer, rows: [], related: [], clues: [] };
    var entA = commonest(rowsA.map(function (q) { return q.answer_entity; })), keyA = bare(primary(rowsA[0]));
    var keysA = new Set(rowsA.map(function (q) { return bare(primary(q)); }));
    var head = commonest(rowsA.map(nameOf)) || primary(rowsA[0]) || answer;
    var scored = await distinctive(terms(rowsA, head + " " + primary(rowsA[0])).slice(0, 30), 30);
    var scope = await scopeId(commonest(rowsA.map(function (q) { return String(q.category_path || "").split(" > ").slice(0, 2).join(" > "); })));
    var mine = function (q, k) { return keysA.has(k) || within(keyA, k) || within(k, keyA) || (entA && q.answer_entity === entA); };
    // the answers found: by topic tag (else by name), each with the clues it shares and the names its tossups give it
    var tally = {};
    var entry = function (key, q) {
      var x = tally[key] = tally[key] || { keys: [], names: [], shared: [], w: 0, root: rootOf(q), entity: q.answer_entity || "" };
      x.keys.push(primary(q)); x.names.push(nameOf(q));
      return x;
    };
    var keyOf = function (q) { var p = primary(q), k = bare(p); return !k || mine(q, k) ? "" : q.answer_entity ? "e:" + q.answer_entity : "k:" + k; };
    await Promise.all(scored.slice(0, 16).map(async function (c) {
      var r = await searchTossups('"' + c.t.replace(/"/g, "") + '"', 40, scope ? { categoryIds: [scope] } : null), seenHere = {};
      r.rows.forEach(function (q) {
        var key = keyOf(q); if (!key || seenHere[key]) return; seenHere[key] = 1;
        var x = entry(key, q); x.shared.push(c); x.w += c.score;
      });
    }));
    // and the answers beside it in its own category (Impressionism & Post-Impressionism for Monet: Renoir, Pissarro,
    // Degas), each with the clues its tossups share. The search above finds the answers its rarest clues lead to; these
    // are the ones a question can sound like
    var deep = commonest(rowsA.map(function (q) { return q.category_id; }));
    // its newest 250, the same each time (a random 250 gave a different cluster on each search)
    var near = [];
    if (deep) try { near = ((await ctx.api.get("/api/tossups/query?" + filtersQuery({ categoryIds: [deep] }, { limit: 250 }))) || {}).rows || []; } catch (e) {}
    var groups = {};
    near.forEach(function (q) {
      var key = keyOf(q); if (!key) return;
      var g = groups[key] = groups[key] || { rows: [], text: " " };
      g.rows.push(q); g.text += norm(q.question_sanitized) + " ";
    });
    Object.keys(groups).forEach(function (key) {
      var g = groups[key], hits = scored.filter(function (c) { return g.text.indexOf(" " + norm(c.t) + " ") >= 0; });
      if (!hits.length && !tally[key]) return;
      var fresh = !tally[key], x = fresh ? entry(key, g.rows[0]) : tally[key];
      g.rows.forEach(function (q, i) { if (fresh && !i) return; x.keys.push(primary(q)); x.names.push(nameOf(q)); });
      hits.forEach(function (c) { if (x.shared.indexOf(c) < 0) { x.shared.push(c); x.w += c.score; } });
      // being beside it in its category says something too, more the more it comes up there
      x.near = true; x.w += 20 + 5 * Math.min(g.rows.length, 4);
    });
    // each answer named the way most of its tossups write it, the same answer (with a tag and without) once, and its
    // shared clues the most telling first
    var all = [], byKey = {};
    Object.keys(tally).forEach(function (k) {
      var x = tally[k]; x.key = commonest(x.keys); x.answer = commonest(x.names) || x.key;
      var y = byKey[bare(x.key)];
      if (y) { x.shared.forEach(function (c) { if (y.shared.indexOf(c) < 0) { y.shared.push(c); y.w += c.score; } }); if (!y.entity) y.entity = x.entity; if (x.near && !y.near) { y.near = true; y.w += 20; } return; }
      byKey[bare(x.key)] = x; all.push(x);
    });
    all.forEach(function (x) { x.shared = x.shared.sort(function (a, b) { return b.score - a.score; }).map(function (c) { return c.t; }); });
    // two telling clues in common, or one for an answer beside it in its category
    var cand = all.filter(function (x) { return x.shared.length >= 2 || (x.near && x.shared.length >= 1); }).sort(function (a, b) { return b.w - a.w; }).slice(0, 40);
    // the same kind of thing as the answer, when the topic tags know it; answers of another kind go (a composer's works,
    // the cities a painter painted), ones the tags don't know stay only while there are few of its kind
    var kindA = await kindOf(entA);
    if (kindA) {
      var kinds = await Promise.all(cand.map(function (x) { return kindOf(x.entity); }));
      var same = cand.filter(function (x, i) { return kinds[i] === kindA; }), unknown = cand.filter(function (x, i) { return !kinds[i]; });
      cand = same.length >= 3 ? same : same.concat(unknown);
    }
    // a part of an answer above it goes ("the opening line of The Odyssey" under The Odyssey)
    cand = cand.filter(function (x, i) { return !cand.slice(0, i).some(function (y) { return within(bare(y.key), bare(x.key)); }); });
    var related = cand.slice(0, 8);
    // your mix-up: first and marked, found among the answers or looked up on its own
    if (extra) {
      var isIt = function (x) { return sameAnswer(x.key, extra) || sameAnswer(x.answer, extra); };
      var at = related.findIndex(isIt);
      var mx = at >= 0 ? related.splice(at, 1)[0] : all.find(isIt);
      if (!mx) { var rx = await rowsFor(extra, "", 20); mx = rx.length ? { key: primary(rx[0]) || extra, answer: commonest(rx.map(nameOf)) || primary(rx[0]) || extra, shared: [], w: 0, root: rootOf(rx[0]), entity: rx[0].answer_entity || "" } : { key: extra, answer: extra, shared: [], w: 0, root: rootOf(rowsA[0]), entity: "", none: true }; }
      mx.mixup = true;
      related = [mx].concat(related.filter(function (x) { return x !== mx; })).slice(0, 8);
    }
    return { answer: head, rows: rowsA, related: related, clues: scored.slice(0, 9), root: rootOf(rowsA[0]) };
  }
  // (15.65) the clues that say most about an answer: common in its tossups and rare in the rest ("Rouen Cathedral",
  // "haystacks"), each scored by how often its tossups use it times how rare it is in the whole database. Ranked by
  // count alone, every painter shared "artist" and "painted" with every other
  var _total = {};
  function dbCount(t) { if (!_total[t]) _total[t] = searchTossups('"' + t.replace(/"/g, "") + '"', 1).then(function (r) { return r.total || 0; }); return _total[t]; }
  async function distinctive(cand, n) {
    var totals = await Promise.all(cand.map(function (c) { return dbCount(c.t); }));
    return cand.map(function (c, i) { return Object.assign({}, c, { score: c.n * Math.log(250000 / (Math.max(totals[i], c.n) + 20)) }); })
      // (1.2.0) under 1,200 tossups in all: "painted", "green" and "different" (4,000 and more) filled every painter's list
      .filter(function (c, i) { return totals[i] > 0 && totals[i] < 1200; })
      .sort(function (a, b) { return b.score - a.score; })
      // one clue once: "havre" goes under "Le Havre", "rouen" under "Rouen Cathedral"
      .filter(function (c, i, all) { var t = norm(c.t); return !all.slice(0, i).some(function (d) { var u = norm(d.t); return within(t, u) || within(u, t); }); })
      .slice(0, n);
  }
  var _kinds = {};
  function kindOf(id) {
    if (!id) return Promise.resolve("");
    if (!_kinds[id]) _kinds[id] = ctx.api.get("/api/topics/tag?id=" + encodeURIComponent(id)).then(function (d) { return (d && d.tag && d.tag.kind) || ""; }).catch(function () { return ""; });
    return _kinds[id];
  }
  // the clues for each of two answers that the other's tossups don't have
  async function apart(A, B) {
    var rowsB = B.none ? [] : await rowsOfAnswer(B, 40);
    if (!rowsB.length) return { rowsB: [], onlyA: [], onlyB: [] };
    // a clue the two share is in neither column (the list above says they share it)
    var both0 = (B.shared || []).map(function (t) { return t.toLowerCase(); });
    var tA = terms(A.rows, A.answer), tB = terms(rowsB, B.answer), inB = new Set(tB.map(function (x) { return x.t.toLowerCase(); }).concat(both0)), inA = new Set(tA.map(function (x) { return x.t.toLowerCase(); }).concat(both0));
    var both = await Promise.all([distinctive(tA.filter(function (x) { return !inB.has(x.t.toLowerCase()); }).slice(0, 18), 6), distinctive(tB.filter(function (x) { return !inA.has(x.t.toLowerCase()); }).slice(0, 18), 6)]);
    return { rowsB: rowsB, onlyA: both[0], onlyB: both[1] };
  }

  function mixups() {
    var pairs = {};
    (entries || []).forEach(function (e) {
      if ((e.points || 0) >= 0 || !e.given_answer || !e.answer) return;
      var g = norm(e.given_answer), a = norm(e.answer); if (!g || g === a || g.length < 3) return;
      var k = g + "|" + a; (pairs[k] = pairs[k] || { given: e.given_answer, answer: e.answer, n: 0, root: rootOf(e) }).n++;
    });
    return Object.keys(pairs).map(function (k) { return pairs[k]; }).sort(function (a, b) { return b.n - a.n; }).slice(0, 12);
  }
  // the page: the search box, then the part under it (redrawn alone, so what's typed in the box stays)
  function render() {
    if (!body) return;
    body.innerHTML = '<div class="pk-wrap ac">' +
      '<form class="pk-bar-top" id="ac-form"><div class="ifield ac-search">' + ic("search", 14) + '<input id="ac-q" placeholder="An answer, like Claude Monet" value="' + esc(view.q) + '" autocomplete="off" spellcheck="false" aria-label="An answer"></div><button type="submit" class="btn btn-primary">Find its cluster</button></form>' +
      '<div id="ac-main"></div></div>';
    var f = body.querySelector("#ac-form"), inp = body.querySelector("#ac-q");
    inp.addEventListener("keydown", function (e) { e.stopPropagation(); });
    f.onsubmit = function (e) { e.preventDefault(); var v = inp.value.trim(); if (v) open(v); };
    renderMain();
  }
  function renderMain() {
    var main = body && body.querySelector("#ac-main"); if (!main) return render();
    var C = view.cur;
    main.innerHTML = C === "loading" ? loading("Finding answers that share its clues…") : C ? clusterHtml(C) : homeHtml();
    main.querySelectorAll("[data-mix]").forEach(function (b) { b.onclick = function () { var m = mixups()[+b.dataset.mix]; if (m) open(m.answer, m.given); }; });
    main.querySelectorAll("[data-rel]").forEach(function (b) { b.onclick = function () { toggle(+b.dataset.rel); }; });
    main.querySelectorAll("[data-go]").forEach(function (b) { b.onclick = function () { open(b.dataset.go, null, b.dataset.alt); }; });
    var pc = main.querySelector("#ac-play"); if (pc) pc.onclick = function () { playCluster(pc); };
    main.querySelectorAll("[data-pair]").forEach(function (b) { b.onclick = function () { playPair(+b.dataset.pair); }; });
  }
  function homeHtml() {
    var mx = mixups();
    return '<div class="pk-card"><div class="pk-strong">Answers that get mixed up</div><div class="pk-muted pk-small" style="margin:4px 0 12px">The answers that share clues with yours, and what tells them apart.</div>' +
      (mx.length ? '<div class="eyebrow" style="margin:6px 0 8px">Your mix-ups</div><div class="list pk-list">' + mx.map(function (m, i) {
        return '<button type="button" class="list-row clickable ac-mix" data-mix="' + i + '">' + dot(m.root) + '<span class="pk-grow">You said <b class="pk-bad">' + esc(m.given) + "</b> for <b>" + esc(m.answer) + '</b></span><span class="pk-muted pk-small">' + plural(m.n, "time") + "</span>" + ic("right", 15) + "</button>";
      }).join("") + "</div>" : '<div class="pk-muted pk-small">' + (entries ? "The answers you neg will show here." : "Loading your mix-ups…") + "</div>") + "</div>";
  }
  function chips(list, cls) { return list.map(function (x) { return '<span class="pk-chip ' + (cls || "") + '">' + esc(x.t || x) + "</span>"; }).join(""); }
  function clusterHtml(C) {
    if (!C.rows.length) return emptyHtml("No tossups have " + C.answer + " as their answer. Try how it's usually written.");
    return '<div class="pk-card ac-head"><div class="pk-grow"><div class="pk-meta">' + dot(C.root) + esc(C.root) + " · " + plural(C.rows.length, "tossup") + '</div><div class="ac-name">' + esc(C.answer) + '</div><div class="ac-chips">' + chips(C.clues.slice(0, 9)) + "</div></div>" +
      (C.related.some(function (r) { return !r.none; }) ? '<button type="button" class="btn btn-primary" id="ac-play"' + (view.busy ? " disabled" : "") + ">" + ic("play", 14) + "Practice the cluster</button>" : "") + "</div>" +
      (C.related.length ? '<div class="pk-sechead"><span class="eyebrow">Answers that share its clues</span></div><div class="list pk-list">' + C.related.map(function (r, i) {
        var o = view.open && view.open.i === i ? view.open : null;
        return '<button type="button" class="list-row clickable ac-rel" data-rel="' + i + '" aria-expanded="' + !!o + '">' + dot(r.root) + '<span class="pk-grow ac-what"><b>' + esc(r.answer) + (r.mixup ? ' <span class="pk-bad pk-small">your mix-up</span>' : "") + "</b>" + (r.shared.length ? '<span class="ac-chips">' + chips(r.shared.slice(0, 6).map(function (t) { return { t: t }; }), "pk-on") + "</span>" : "") + "</span>" + ic(o ? "up" : "down", 15) + "</button>" +
          (o ? '<div class="ac-apart">' + apartHtml(C, r, o, i) + "</div>" : "");
      }).join("") + "</div>" : emptyHtml("No other answer shares enough of its clues."));
  }
  function apartHtml(C, r, o, i) {
    if (o.loading) return loading("");
    if (!o.d.rowsB.length) return '<div class="pk-muted pk-small">No tossups have ' + esc(r.answer) + " as their answer, so there's nothing to tell apart.</div>";
    var col = function (name, list) { return '<div><div class="ac-ch">Only ' + esc(name) + '</div><div class="ac-chips">' + (chips(list) || '<span class="pk-muted pk-small">Nothing stands out</span>') + "</div></div>"; };
    return '<div class="ac-cols">' + col(C.answer, o.d.onlyA) + col(r.answer, o.d.onlyB) + "</div>" +
      '<div class="pk-actions"><button type="button" class="btn btn-sm" data-pair="' + i + '">' + ic("play", 13) + "Practice these two</button><button type=\"button\" class=\"btn btn-sm btn-ghost\" data-go=\"" + esc(r.answer) + '" data-alt="' + esc(r.key || "") + '">Its own cluster</button></div>';
  }
  // alt: another way to write it, tried when the first finds nothing
  async function open(answer, extra, alt) {
    view.q = answer; view.cur = "loading"; view.open = null; render();
    var c;
    try { c = await cluster(answer, extra); if (!c.rows.length && alt && bare(alt) !== bare(answer)) c = await cluster(alt, extra); } catch (e) { c = { answer: answer, rows: [], related: [], clues: [] }; }
    if (view.q !== answer || view.cur !== "loading") return;
    view.cur = c; renderMain();
  }
  async function toggle(i) {
    var C = view.cur; if (!C || C === "loading") return;
    if (view.open && view.open.i === i) { view.open = null; renderMain(); return; }
    C._apart = C._apart || {};
    if (C._apart[i]) { view.open = { i: i, d: C._apart[i] }; renderMain(); return; }
    view.open = { i: i, loading: true }; renderMain();
    var d; try { d = await apart(C, C.related[i]); } catch (e) { d = { rowsB: [], onlyA: [], onlyB: [] }; }
    C._apart[i] = d;
    if (!view.open || view.open.i !== i || view.cur !== C) return;
    view.open = { i: i, d: d }; renderMain();
  }
  function idsOf(rows, n) { return shuffle(rows.slice()).slice(0, n).map(function (q) { return q.id; }); }
  async function playCluster(btn) {
    if (view.busy) return;
    var C = view.cur; if (!C || !C.rows) return;
    view.busy = true; btn.disabled = true; btn.setAttribute("aria-busy", "true");
    try {
      var ids = idsOf(C.rows, 6);
      var more = await Promise.all(C.related.filter(function (r) { return !r.none; }).slice(0, 4).map(function (r) { return rowsOfAnswer(r, 24); }));
      more.forEach(function (rows) { ids = ids.concat(idsOf(rows, 4)); });
      if (view.cur === C) playList("tossups", shuffle(uniq(ids)), "Cluster for " + C.answer);
    } finally { view.busy = false; if (btn.isConnected) { btn.disabled = false; btn.removeAttribute("aria-busy"); } }
  }
  function playPair(i) {
    var C = view.cur, o = view.open; if (!o || !o.d || !o.d.rowsB.length) return;
    playList("tossups", shuffle(uniq(idsOf(C.rows, 8).concat(idsOf(o.d.rowsB, 8)))), C.answer + " or " + C.related[i].answer);
  }

  page = ctx.registerPage({
    id: "answer-clusters", navLabel: "Answer Clusters", title: "Answer Clusters",
    onShow: function (el) {
      body = el; render();
      // your mix-ups again each time, so a neg from just now is there
      history("type,points,given_answer,category_path,category,answer").then(function (es) { entries = es.filter(function (e) { return e.type === "tossup"; }); if (!view.cur && body === el) renderMain(); });
    },
  });
  if (ctx.onBack) ctx.onBack(function () { if (!(page && page.screenEl && page.screenEl.classList.contains("active")) || !view.cur) return false; view.cur = null; view.open = null; view.q = ""; render(); return true; });

}
