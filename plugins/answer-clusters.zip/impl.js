function __qbMain(ctx) {
  // ── the kit the 15.62 plugins share (text, icons, questions, judging, history) ──
  function esc(s) { return (s == null ? "" : String(s)).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
  var IC = {
    play: '<path d="M7 4l13 8-13 8z"/>',
    pause: '<path d="M8 5v14M16 5v14"/>',
    left: '<path d="M15 6l-6 6 6 6"/>',
    right: '<path d="M9 6l6 6-6 6"/>',
    next: '<path d="M6 5l9 7-9 7zM18 5v14"/>',
    refresh: '<path d="M20 11a8 8 0 10-2.3 5.7M20 4v7h-7"/>',
    x: '<path d="M6 6l12 12M18 6L6 18"/>',
    check: '<path d="M5 12l5 5 9-10"/>',
    mic: '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
    volume: '<path d="M4 9v6h4l5 4V5L8 9z"/><path d="M16 9a4 4 0 0 1 0 6M19 6a8 8 0 0 1 0 12"/>',
    copy: '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h3"/>',
    edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="M13.5 6.5l4 4"/>',
    bolt: '<path d="M13 3L5 14h6l-1 7 8-11h-6z"/>',
    flag: '<path d="M5 21V4M5 4h11l-2 4 2 4H5"/>',
    users: '<circle cx="9" cy="8" r="3"/><path d="M3 20a6 6 0 0 1 12 0M16 4a3 3 0 0 1 0 6M21 20a6 6 0 0 0-4-5.6"/>',
    target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
    down: '<path d="M6 9l6 6 6-6"/>',
    up: '<path d="M6 15l6-6 6 6"/>',
    quote: '<path d="M7 7h4v4c0 3-1.5 5-4 6M15 7h4v4c0 3-1.5 5-4 6"/>',
    ear: '<path d="M7 9a5 5 0 0 1 10 0c0 3-3 4-3 7a3 3 0 0 1-6 0"/><path d="M10 9a2 2 0 0 1 4 0"/>',
  };
  function ic(name, size) {
    var s = size || 16;
    return '<svg width="' + s + '" height="' + s + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (IC[name] || "") + "</svg>";
  }
  function loading(label) { return '<div class="pk-loading">' + (ctx.loadingBarHtml ? ctx.loadingBarHtml(label) : esc(label)) + "</div>"; }
  function norm(s) { return String(s || "").toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[^a-z0-9]+/g, " ").trim(); }
  function pct(a, n) { return n ? Math.round(100 * a / n) : 0; }
  function fmt(n) { return Number(n || 0).toLocaleString(); }
  function plural(n, one, many) { return fmt(n) + " " + (n === 1 ? one : (many || one + "s")); }
  function shuffle(a) { for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)), t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
  function inField(e) { var t = e && e.target; return !!t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT" || t.isContentEditable); }
  function dayKey(t) { var d = new Date(t || Date.now()); return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0"); }
  var DAY = 86400000;

  // the practice setup (Setup panel): its filters and reading settings
  function cfg() { try { return (ctx.host && ctx.host.getPracticeConfig && ctx.host.getPracticeConfig()) || {}; } catch (e) { return {}; } }
  // filters → query parameters, the ones the app sends for a random question
  function filtersQuery(f, extra) {
    f = f || {}; var p = [];
    var add = function (k, v) { p.push(k + "=" + encodeURIComponent(v)); };
    if (f.categories && f.categories.length) add("categories", f.categories.join(","));
    if (f.categoryIds && f.categoryIds.length) add("categoryIds", f.categoryIds.join(","));
    if (f.difficulties && f.difficulties.length) add("difficulties", f.difficulties.join(","));
    if (f.setNames && f.setNames.length) add("setNames", f.setNames.join(","));
    if (f.packetNumbers && f.packetNumbers.length) add("packetNumbers", f.packetNumbers.join(","));
    if (f.yearMin != null) add("yearMin", f.yearMin);
    if (f.yearMax != null) add("yearMax", f.yearMax);
    if (f.powermarkOnly) add("powermarkOnly", "true");
    if (f.canon && f.canon.length) add("canon", f.canon.join(","));
    add("cleanOnly", "1");
    Object.keys(extra || {}).forEach(function (k) { if (extra[k] != null && extra[k] !== false) add(k, extra[k]); });
    return p.join("&");
  }
  // the practice filters without a set (a drill draws from everything the player picked)
  function practiceFilters() { var f = Object.assign({}, cfg().filters || {}); delete f.setNames; delete f.packetNumbers; delete f.setIds; return f; }
  async function getTossups(n, f, extra) {
    try { var d = await ctx.api.get("/api/tossups/query?" + filtersQuery(f || practiceFilters(), Object.assign({ random: 1, limit: n }, extra || {}))); return (d && d.rows) || []; } catch (e) { return []; }
  }
  async function getBonuses(n, f, extra) {
    try { var d = await ctx.api.get("/api/bonuses/query?" + filtersQuery(f || practiceFilters(), Object.assign({ random: 1, limit: n }, extra || {}))); return (d && d.rows) || []; } catch (e) { return []; }
  }
  async function getTossup(id) { try { return (await ctx.api.get("/api/tossups/" + encodeURIComponent(id))).tossup || null; } catch (e) { return null; } }
  async function getBonus(id) { try { return (await ctx.api.get("/api/bonuses/" + encodeURIComponent(id))).bonus || null; } catch (e) { return null; } }
  async function searchTossups(query, limit, f) {
    try { var d = await ctx.api.get("/api/tossups/search?query=" + encodeURIComponent(query) + "&limit=" + (limit || 20) + (f ? "&" + filtersQuery(f) : "")); return { rows: (d && d.rows) || [], total: (d && d.total) || 0 }; } catch (e) { return { rows: [], total: 0 }; }
  }
  // tossups whose answer line names an answer
  async function tossupsOn(answer, limit) { return (await searchTossups('answer_sanitized : ("' + String(answer).replace(/"/g, "") + '")', limit || 20)).rows; }

  // a record's text as practice reads it (notes and pronunciation guides per the player's settings)
  function readText(q) {
    try { if (ctx.host && ctx.host.questionText) { var t = ctx.host.questionText(q, "question"); if (t != null) return String(t).replace(/\(\*\)/g, "").replace(/\s{2,}/g, " ").trim(); } } catch (e) {}
    return String((q && q.question_sanitized) || "").replace(/\(\*\)/g, "").trim();
  }
  function powerAt(q) { return String((q && q.question_sanitized) || "").indexOf("(*)"); }
  // sentences, without breaking at "St." or an initial ("J. R. R. Tolkien")
  var ABBR = /(?:\b(?:St|Ste|Mt|Mts|Dr|Mr|Mrs|Ms|Mme|Prof|Sr|Jr|Rev|Fr|Gen|Col|Capt|Lt|Sgt|Maj|Adm|Hon|Pres|Gov|Sen|Rep|vs|etc|cf|ca|al|Inc|Co|Corp|Ltd|Bros|approx|No|Nos|Op|op|no|Vol|vol|Ch|ch|Fig|fig|Ft|Pt|pt|Ave|[A-Za-z])\.["”’']?)$/;
  function sentences(text) {
    var parts = String(text || "").split(/(?<=[.?!]["”’)]*)\s+(?=["“(]?[A-Z0-9])/), out = [], cur = "";
    for (var i = 0; i < parts.length; i++) {
      cur = cur ? cur + " " + parts[i] : parts[i];
      if (i < parts.length - 1 && ABBR.test(cur.trim())) continue;
      out.push(cur.trim()); cur = "";
    }
    if (cur.trim()) out.push(cur.trim());
    return out.filter(Boolean);
  }
  // where each sentence of a text ends (indexes into it)
  function sentenceEnds(text) {
    var at = 0, out = []; text = String(text || "");
    sentences(text).forEach(function (x) { var i = text.indexOf(x, at); if (i < 0) return; at = i + x.length; out.push(at); });
    return out;
  }
  // ── categories (15.63): the app's own picker, its picks kept under `key` ([] = every category) ──
  // mountCats(root, key, onChange) puts it in root's [data-cats] (made once, moved into each new render);
  // inCats(pk, e): a history entry or question in the picks; with no picks, all are
  var PICKERS = {};
  function catPicker(key, onChange) {
    if (PICKERS[key]) return PICKERS[key];
    if (!ctx.host || !ctx.host.categoryPicker) return null;
    var pk = ctx.host.categoryPicker(null, { selected: ctx.storage.get(key) || [], onChange: function (ids) { ctx.storage.set(key, ids); if (onChange) onChange(ids); } });
    PICKERS[key] = pk;
    // the picks match nothing until the tree is in: draw again once it is
    if (pk.ready && (ctx.storage.get(key) || []).length) pk.ready.then(function () { if (onChange) onChange(pk.get()); });
    return pk;
  }
  function mountCats(root, key, onChange) {
    var pk = catPicker(key, onChange), host = root && root.querySelector("[data-cats]");
    if (pk && host) host.appendChild(pk.el);
    return pk;
  }
  function inCats(pk, e) {
    if (!pk || !pk.get().length) return true;
    return pk.matches(String((e && (e.category_path || e.path || e.category || e.root)) || ""));
  }
  // ── the app's reader on a page titled for the plugin (15.63: ctx.host.playPractice). Its Setup picks the categories ──
  function canRead() { return !!(ctx.host && ctx.host.playPractice); }
  function onReader() { return !!(ctx.host && ctx.host.onPracticePage && ctx.host.onPracticePage()); }
  // a plugin's start page: an icon, what it is, a Start button (data-pk="start"), a note under it
  function heroHtml(icon, title, text, start, note) {
    return '<div class="pk-hero"><span class="pk-hero-ico">' + ic(icon, 26) + "</span><h2>" + esc(title) + "</h2><p>" + esc(text) + "</p>" +
      '<div class="pk-actions pk-center"><button type="button" class="btn btn-primary" data-pk="start">' + ic("play", 14) + esc(start || "Start") + "</button></div>" +
      (note ? '<div class="pk-muted pk-small">' + note + "</div>" : "") + "</div>";
  }
  // the answer line, with its bold and underlining (nothing else of the HTML)
  function answerHtml(q) {
    var h = String((q && q.answer) || "");
    if (!/<\/?(b|u|strong|em|i)\b/i.test(h)) return esc((q && q.answer_sanitized) || h);
    return h.replace(/<(\/?)(b|u|strong|em|i)\b[^>]*>/gi, "\u0001$1$2\u0002").replace(/<[^>]*>/g, "").replace(/&(?!(?:amp|lt|gt|quot|#\d+);)/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/\u0001(\/?)(\w+)\u0002/g, "<$1$2>");
  }
  function primary(q) {
    var a = "";
    try { if (ctx.host && ctx.host.extractPrimaryAnswer) a = ctx.host.extractPrimaryAnswer((q && q.answer) || "", (q && q.answer_sanitized) || ""); } catch (e) {}
    return a || String((q && q.answer_sanitized) || "").replace(/\s*[\[(].*$/, "").trim();
  }
  // judged right here, like practice (judge.js); { status: "accept" | "prompt" | "reject", prompt }
  async function judge(q, answer, opts) {
    opts = opts || {};
    try {
      if (ctx.host && ctx.host.judgeTossup) return (await ctx.host.judgeTossup(q, answer, { strictness: opts.strictness != null ? opts.strictness : (cfg().strictness || 10), buzzPosition: opts.buzzPosition, previous: opts.previous || null })) || { status: "reject" };
      return (await ctx.api.post("/api/evaluate-tossup", { questionId: q.id, answer: answer, strictness: cfg().strictness || 10, buzzPosition: opts.buzzPosition, previous: opts.previous || null })) || { status: "reject" };
    } catch (e) { return { status: "reject" }; }
  }
  async function judgePart(b, part, answer, opts) {
    opts = opts || {};
    try {
      if (ctx.host && ctx.host.judgeBonusPart) return (await ctx.host.judgeBonusPart(b, part, answer, { strictness: cfg().strictness || 10, previous: opts.previous || null })) || { status: "reject" };
      return (await ctx.api.post("/api/evaluate-bonus-part", { questionId: b.id, part: part, answer: answer, strictness: cfg().strictness || 10 })) || { status: "reject" };
    } catch (e) { return { status: "reject" }; }
  }
  async function judgeLine(line, sani, answer, opts) {
    opts = opts || {};
    try {
      if (ctx.host && ctx.host.judgeAnswerLine) return (await ctx.host.judgeAnswerLine(line, sani, answer, { strictness: cfg().strictness || 10, previous: opts.previous || null })) || { status: "reject" };
      return (await ctx.api.post("/api/evaluate-answer", { answerline: line, answer: answer, strictness: cfg().strictness || 10 })) || { status: "reject" };
    } catch (e) { return { status: "reject" }; }
  }
  function bonusParts(b) { try { return JSON.parse((b && (b.parts_sanitized || b.parts)) || "[]"); } catch (e) { return []; } }
  function bonusAnswers(b) { try { return JSON.parse((b && b.answers) || "[]"); } catch (e) { return []; } }
  function bonusAnswersSani(b) { try { return JSON.parse((b && b.answers_sanitized) || "[]"); } catch (e) { return []; } }

  // the player's answers (Stats' history), only the fields asked for
  async function history(fields) {
    try { return ((await ctx.api.get("/api/sessions/all-entries?" + (/\banswer\b/.test(fields || "") ? "answers=1&" : "") + "fields=" + encodeURIComponent(fields || ""))).entries) || []; } catch (e) { return []; }
  }
  // record a tossup answered on a plugin's page into the player's stats (the path Coach Mode uses)
  function record(q, r) {
    try {
      ctx.api.post("/api/check-tossup", { questionId: q.id, answer: r.answer || "", buzzPosition: r.buzzPosition || 0, sessionId: r.session, overriding: true,
        correct: !!r.correct, isPower: !!r.power, points: r.points || 0, celerity: r.celerity != null ? r.celerity : 1 }).catch(function () {});
    } catch (e) {}
  }

  var ROOT_COLOR = { "Literature": "#bc8cff", "Science": "#58a6ff", "Math": "#a5e05b", "Pop Culture": "#ff7b72", "Sports": "#ff6f91", "Fine Arts": "#f778ba", "History": "#e3b341", "Geography": "#56d364", "Mythology": "#ffa657", "Social Science": "#3dd6a3", "Philosophy": "#39c5cf", "Theology": "#8e9bff", "Current Events": "#c9d16b", "Miscellaneous": "#8b949e" };
  // NAQT's high school distribution, per 24 tossups / bonuses (naqt.com/hs/distribution.jsp)
  var NAQT = [["Literature", 3.9, 3.8], ["Science", 4.5, 4.3], ["Math", 1.0, 1.0], ["Fine Arts", 2.0, 2.0], ["History", 4.6, 4.5], ["Geography", 1.9, 1.9], ["Mythology", 0.6, 0.7],
    ["Pop Culture", 1.0, 0.9], ["Sports", 0.7, 0.7], ["Social Science", 0.6, 0.6], ["Philosophy", 0.3, 0.3], ["Theology", 0.4, 0.4], ["Current Events", 1.5, 1.4], ["Miscellaneous", 1.0, 1.5]];
  function rootOf(e) { return String((e && (e.category_path || e.category)) || "").split(" > ")[0] || "Miscellaneous"; }
  function dot(root) { return '<span class="pk-dot" style="--c:' + (ROOT_COLOR[root] || "#8b949e") + '"></span>'; }
  var _roots = null;
  async function roots() {
    if (_roots) return _roots;
    try { var t = ctx.host && ctx.host.getCategoryTree ? await ctx.host.getCategoryTree("tossups") : (await ctx.api.get("/api/category-tree?type=tossups")).tree; _roots = (t || []).map(function (n) { return { id: n.id, name: n.name, count: n.count }; }); }
    catch (e) { _roots = []; }
    return _roots;
  }
  var DIFF_NAME = { 0: "Unrated", 1: "Middle school", 2: "Easy high school", 3: "Regular high school", 4: "Hard high school", 5: "National high school", 6: "Easy college", 7: "Medium college", 8: "Regionals college", 9: "Nationals college", 10: "Open" };

  function tile(value, label, cls) { return '<div class="pk-tile' + (cls ? " " + cls : "") + '"><b class="num">' + value + "</b><span>" + esc(label) + "</span></div>"; }
  function segHtml(name, items, on) {
    return '<div class="seg pk-seg" role="group">' + items.map(function (it) {
      return '<button type="button" data-' + name + '="' + esc(it[0]) + '" aria-pressed="' + (String(on) === String(it[0])) + '">' + esc(it[1]) + "</button>";
    }).join("") + "</div>";
  }
  function emptyHtml(text) { return '<div class="db-empty pk-empty">' + esc(text) + "</div>"; }
  function playList(kind, ids, title) {
    if (!ids || !ids.length) return false;
    try { return !!(ctx.host && ctx.host.launchQuestions && ctx.host.launchQuestions(kind, ids, { title: title })); } catch (e) { return false; }
  }

  // a reader: shows `text` a character at a time at the practice reading speed. start(), pause(), go(), stop();
  // at() is how far it is; onEnd once it's all shown
  function Reader(el, text, opts) {
    opts = opts || {};
    var ms = opts.ms != null ? opts.ms : (Number(cfg().revealSpeed) || 25), idx = 0, raf = 0, last = 0, on = false;
    var paint = function () { el.innerHTML = '<span class="pk-read">' + esc(text.slice(0, idx)) + '</span><span class="pk-unread" aria-hidden="true">' + esc(text.slice(idx)) + "</span>"; };
    var step = function (t) {
      raf = 0; if (!on) return;
      if (!last) last = t;
      var n = ms > 0 ? Math.floor((t - last) / ms) : text.length;
      if (n > 0) { idx = Math.min(text.length, idx + n); last += n * ms; paint(); if (opts.onTick) opts.onTick(idx); }
      if (idx >= text.length) { on = false; if (opts.onEnd) opts.onEnd(); return; }
      raf = requestAnimationFrame(step);
    };
    paint();
    return {
      start: function () { if (on) return; on = true; last = 0; raf = requestAnimationFrame(step); },
      pause: function () { on = false; if (raf) cancelAnimationFrame(raf); raf = 0; },
      stop: function () { on = false; if (raf) cancelAnimationFrame(raf); raf = 0; },
      showAll: function () { this.stop(); idx = text.length; el.textContent = text; },
      at: function () { return idx; },
      running: function () { return on; },
    };
  }
  // a reader's position in the displayed text → the record's question_sanitized (what judging and stats count)
  function serverPos(q, display, pos) {
    try { if (ctx.host && ctx.host.mapDisplayPos) return ctx.host.mapDisplayPos(display, (q && q.question_sanitized) || "", pos); } catch (e) {}
    return pos;
  }

  // ── Answer Clusters: answers that share clues with one answer, and the clues that tell them apart ──
  // An answer's clues are the words and names that come up most in its tossups. Each of the strongest is searched
  // for in the whole database, and the other answers those tossups have are counted by how many clues they share.
  var body = null, page = null, entries = null;
  var view = { q: "", cur: null, open: null };
  var STOP = new Set(("a an the and or but nor so of in on at to for with by from as is are was were be been being this that these those its it his her their they them he she him " +
    "who whom which what when where while after before during under over into onto about above below between through than then there here also only one two three four five " +
    "first second third last other another such some many most more much each every both either neither same any all not no yet still even once upon within without " +
    "points point name names named give identify ftp work works figure title titled author called known describes described description features feature featured includes include " +
    "included including character characters novel novels poem poems play plays story stories book books piece pieces man woman men women people person thing things way ways year years " +
    "time times called used uses using use like later early late part parts number group made make makes making became become becomes found finds wrote written writes said says " +
    "new old great large small long short high low many several whose would could should might will can must may did does done had has have having just well very").split(" "));
  function terms(rows, skip) {
    var df = {}, names = {}, skipW = new Set(norm(skip).split(" "));
    rows.forEach(function (q) {
      var t = String(q.question_sanitized || "").replace(/\(\*\)/g, ""), seen = {};
      (t.toLowerCase().match(/[a-z][a-z'-]{3,}/g) || []).forEach(function (w) { w = w.replace(/'s$/, ""); if (STOP.has(w) || skipW.has(w) || seen[w]) return; seen[w] = 1; df[w] = (df[w] || 0) + 1; });
      // names: two or more capitalized words not at the start of a sentence ("Water Lilies", "Claude Debussy")
      var m, re = /(?:^|[^.?!]\s)((?:[A-Z][a-z'’]+\s){1,3}[A-Z][a-z'’]+)/g;
      while ((m = re.exec(t))) { var n = m[1].trim(); if (n.split(" ").some(function (w) { return skipW.has(w.toLowerCase()); }) || seen["#" + n]) continue; seen["#" + n] = 1; names[n] = (names[n] || 0) + 1; }
    });
    var out = Object.keys(names).filter(function (n) { return names[n] >= 2; }).map(function (n) { return { t: n, n: names[n] * 1.5, name: true }; })
      .concat(Object.keys(df).filter(function (w) { return df[w] >= 2; }).map(function (w) { return { t: w, n: df[w] }; }));
    return out.sort(function (a, b) { return b.n - a.n; });
  }
  async function cluster(answer, extra) {
    var found = await tossupsOn(answer, 60);
    // only the tossups whose answer is the one asked for ("The Iliad", not "Chapman's Homer", whose line names it)
    var want = norm(answer).replace(/^(the|a|an) /, ""), score = function (q) { var k = norm(primary(q)).replace(/^(the|a|an) /, ""); return k === want ? 3 : k.indexOf(want) >= 0 || want.indexOf(k) >= 0 ? 2 : want.split(" ").every(function (w) { return k.indexOf(w) >= 0; }) ? 1 : 0; };
    var best = found.reduce(function (m, q) { return Math.max(m, score(q)); }, 0);
    var top = found.find(function (q) { return score(q) === best; });
    var rowsA = found.filter(function (q) { return best ? score(q) === best || (top && top.answer_entity && q.answer_entity === top.answer_entity) : true; }).slice(0, 40);
    if (!rowsA.length) return { answer: answer, rows: [], related: [], clues: [] };
    var head = primary(rowsA[0]) || answer, keyA = norm(head), clues = terms(rowsA, head).slice(0, 9), entA = rowsA[0].answer_entity || "";
    var tally = {};
    await Promise.all(clues.map(async function (c) {
      var r = await searchTossups('"' + c.t.replace(/"/g, "") + '"', 40);
      var seenHere = {};
      r.rows.forEach(function (q) {
        var p = primary(q), k = norm(p); if (!k || k === keyA || keyA.indexOf(k) >= 0 || k.indexOf(keyA) >= 0 || seenHere[k]) return; seenHere[k] = 1;
        if (entA && q.answer_entity === entA) return;   // the same answer, written another way
        var x = tally[k] = tally[k] || { answer: p, shared: [], n: 0, root: rootOf(q), entity: q.answer_entity || "" }; x.shared.push(c.t); x.n++;
        if (!x.entity && q.answer_entity) x.entity = q.answer_entity;
      });
    }));
    var related = Object.keys(tally).map(function (k) { return tally[k]; }).filter(function (x) { return x.shared.length >= 2 || (extra && norm(x.answer) === norm(extra)); })
      .sort(function (a, b) { return b.shared.length - a.shared.length; }).slice(0, 30);
    // the same kind of thing as the answer (painters with a painter, epics with an epic), when the topic tags know it
    var kindA = await kindOf(rowsA[0].answer_entity);
    if (kindA) {
      var kinds = await Promise.all(related.map(function (x) { return kindOf(x.entity); }));
      related.forEach(function (x, i) { x.same = kinds[i] === kindA || (extra && norm(x.answer) === norm(extra)); });
      related.sort(function (a, b) { return (b.same ? 1 : 0) - (a.same ? 1 : 0) || b.shared.length - a.shared.length; });
      var same = related.filter(function (x) { return x.same; });
      if (same.length >= 4) related = same;
    }
    related = related.slice(0, 8);
    if (extra && !related.some(function (x) { return norm(x.answer) === norm(extra); })) related.unshift({ answer: extra, shared: [], n: 0, root: rootOf(rowsA[0]), mixup: true });
    return { answer: head, rows: rowsA, related: related, clues: clues, root: rootOf(rowsA[0]) };
  }
  var _kinds = {};
  function kindOf(id) {
    if (!id) return Promise.resolve("");
    if (!_kinds[id]) _kinds[id] = ctx.api.get("/api/topics/tag?id=" + encodeURIComponent(id)).then(function (d) { return (d && d.tag && d.tag.kind) || ""; }).catch(function () { return ""; });
    return _kinds[id];
  }
  // the clues for each of two answers that the other's tossups don't have
  async function apart(A, B) {
    var rowsB = await tossupsOn(B.answer, 30);
    var tA = terms(A.rows, A.answer), tB = terms(rowsB, B.answer), inB = new Set(tB.map(function (x) { return x.t.toLowerCase(); })), inA = new Set(tA.map(function (x) { return x.t.toLowerCase(); }));
    return { rowsB: rowsB, onlyA: tA.filter(function (x) { return !inB.has(x.t.toLowerCase()); }).slice(0, 6), onlyB: tB.filter(function (x) { return !inA.has(x.t.toLowerCase()); }).slice(0, 6) };
  }

  function mixups() {
    var pairs = {};
    (entries || []).forEach(function (e) {
      if ((e.points || 0) >= 0 || !e.given_answer || !e.answer) return;
      var g = norm(e.given_answer), a = norm(e.answer); if (!g || g === a || g.length < 3) return;
      var k = g + "|" + a; (pairs[k] = pairs[k] || { given: e.given_answer, answer: e.answer, n: 0, root: rootOf(e) }).n++;
    });
    return Object.keys(pairs).map(function (k) { return pairs[k]; }).sort(function (a, b) { return b.n - a.n; }).slice(0, 12);
  }
  function render() {
    if (!body) return;
    var C = view.cur;
    body.innerHTML = '<div class="pk-wrap ac">' +
      '<form class="pk-bar-top" id="ac-form"><div class="ifield ac-search">' + ic("search", 14) + '<input id="ac-q" placeholder="An answer, like Claude Monet" value="' + esc(view.q) + '" autocomplete="off" spellcheck="false"></div><button type="submit" class="btn btn-primary">Find its cluster</button></form>' +
      (C === "loading" ? loading("Finding answers that share its clues…") : C ? clusterHtml(C) : homeHtml()) + "</div>";
    var f = body.querySelector("#ac-form"), inp = body.querySelector("#ac-q");
    inp.addEventListener("keydown", function (e) { e.stopPropagation(); });
    f.onsubmit = function (e) { e.preventDefault(); var v = inp.value.trim(); if (v) open(v); };
    body.querySelectorAll("[data-mix]").forEach(function (b) { b.onclick = function () { var m = mixups()[+b.dataset.mix]; view.q = m.answer; open(m.answer, m.given); }; });
    body.querySelectorAll("[data-rel]").forEach(function (b) { b.onclick = function () { toggle(+b.dataset.rel); }; });
    body.querySelectorAll("[data-go]").forEach(function (b) { b.onclick = function () { open(b.dataset.go); }; });
    var pc = body.querySelector("#ac-play"); if (pc) pc.onclick = playCluster;
    body.querySelectorAll("[data-pair]").forEach(function (b) { b.onclick = function () { playPair(+b.dataset.pair); }; });
  }
  function homeHtml() {
    var mx = mixups();
    return '<div class="pk-card"><div class="pk-strong">Answers that get mixed up</div><div class="pk-muted pk-small" style="margin:4px 0 12px">Type an answer to see the others that share its clues, and the clues that tell them apart.</div>' +
      (mx.length ? '<div class="eyebrow" style="margin:6px 0 8px">Your mix-ups</div><div class="list pk-list">' + mx.map(function (m, i) {
        return '<button type="button" class="list-row clickable ac-mix" data-mix="' + i + '">' + dot(m.root) + '<span class="pk-grow">You said <b class="pk-bad">' + esc(m.given) + "</b> for <b>" + esc(m.answer) + '</b></span><span class="pk-muted pk-small">' + plural(m.n, "time") + "</span>" + ic("right", 15) + "</button>";
      }).join("") + "</div>" : '<div class="pk-muted pk-small">Your negs will show the answers you mix up here.</div>') + "</div>";
  }
  function chips(list, cls) { return list.map(function (x) { return '<span class="pk-chip ' + (cls || "") + '">' + esc(x.t || x) + "</span>"; }).join(""); }
  function clusterHtml(C) {
    if (!C.rows.length) return emptyHtml("No tossups have " + C.answer + " as their answer. Try how it's usually written.");
    return '<div class="pk-card ac-head"><div class="pk-grow"><div class="pk-meta">' + dot(C.root) + esc(C.root) + " · " + plural(C.rows.length, "tossup") + '</div><div class="ac-name">' + esc(C.answer) + '</div><div class="ac-chips">' + chips(C.clues.slice(0, 9)) + "</div></div>" +
      (C.related.length ? '<button type="button" class="btn btn-primary" id="ac-play">' + ic("play", 14) + "Practice the cluster</button>" : "") + "</div>" +
      (C.related.length ? '<div class="pk-sechead"><span class="eyebrow">Answers that share its clues</span></div><div class="list pk-list">' + C.related.map(function (r, i) {
        var o = view.open && view.open.i === i ? view.open : null;
        return '<button type="button" class="list-row clickable ac-rel" data-rel="' + i + '">' + dot(r.root) + '<span class="pk-grow ac-what"><b>' + esc(r.answer) + (r.mixup ? ' <span class="pk-bad pk-small">your mix-up</span>' : "") + '</b><span class="ac-chips">' + chips(r.shared.slice(0, 6).map(function (t) { return { t: t }; }), "pk-on") + "</span></span>" + ic(o ? "up" : "down", 15) + "</button>" +
          (o ? '<div class="ac-apart">' + (o.loading ? loading("") : '<div class="ac-cols"><div><div class="ac-ch">Only ' + esc(C.answer) + '</div><div class="ac-chips">' + (chips(o.d.onlyA) || '<span class="pk-muted pk-small">Nothing stands out</span>') + '</div></div><div><div class="ac-ch">Only ' + esc(r.answer) + '</div><div class="ac-chips">' + (chips(o.d.onlyB) || '<span class="pk-muted pk-small">Nothing stands out</span>') + "</div></div></div>" +
            '<div class="pk-actions"><button type="button" class="btn btn-sm" data-pair="' + i + '">' + ic("play", 13) + "Practice these two</button><button type=\"button\" class=\"btn btn-sm btn-ghost\" data-go=\"" + esc(r.answer) + '">Its own cluster</button></div>') + "</div>" : "");
      }).join("") + "</div>" : emptyHtml("No other answer shares enough of its clues."));
  }
  async function open(answer, extra) {
    view.q = answer; view.cur = "loading"; view.open = null; render();
    var c = await cluster(answer, extra);
    if (view.q !== answer) return;
    view.cur = c; render();
  }
  async function toggle(i) {
    if (view.open && view.open.i === i) { view.open = null; render(); return; }
    var C = view.cur; view.open = { i: i, loading: true }; render();
    var d = await apart(C, C.related[i]);
    if (!view.open || view.open.i !== i || view.cur !== C) return;
    view.open = { i: i, d: d }; render();
  }
  function idsOf(rows, n) { return shuffle(rows.slice()).slice(0, n).map(function (q) { return q.id; }); }
  async function playCluster() {
    var C = view.cur, ids = idsOf(C.rows, 6);
    var more = await Promise.all(C.related.slice(0, 4).map(function (r) { return tossupsOn(r.answer, 12); }));
    more.forEach(function (rows) { ids = ids.concat(idsOf(rows, 4)); });
    playList("tossups", shuffle(ids), "Cluster for " + C.answer);
  }
  function playPair(i) {
    var C = view.cur, o = view.open; if (!o || !o.d) return;
    playList("tossups", shuffle(idsOf(C.rows, 8).concat(idsOf(o.d.rowsB, 8))), C.answer + " or " + C.related[i].answer);
  }

  page = ctx.registerPage({
    id: "answer-clusters", navLabel: "Answer Clusters", title: "Answer Clusters",
    onShow: function (el) {
      body = el; render();
      if (!entries) history("type,points,given_answer,category_path,category,answer").then(function (es) { entries = es.filter(function (e) { return e.type === "tossup"; }); if (!view.cur) render(); });
    },
  });
  if (ctx.onBack) ctx.onBack(function () { if (!(page && page.screenEl && page.screenEl.classList.contains("active")) || !view.cur) return false; view.cur = null; view.open = null; render(); return true; });

}
