function __qbMain(ctx) {
  // ── the kit the 15.62 plugins share (text, icons, questions, judging, history) ──
  function esc(s) { return (s == null ? "" : String(s)).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
  var IC = {
    play: '<path d="M7 4l13 8-13 8z"/>',
    pause: '<path d="M8 5v14M16 5v14"/>',
    left: '<path d="M15 6l-6 6 6 6"/>',
    right: '<path d="M9 6l6 6-6 6"/>',
    next: '<path d="M6 5l9 7-9 7zM18 5v14"/>',
    refresh: '<path d="M20 11a8 8 0 10-2.3 5.7M20 4v7h-7"/>',
    x: '<path d="M6 6l12 12M18 6L6 18"/>',
    check: '<path d="M5 12l5 5 9-10"/>',
    mic: '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
    volume: '<path d="M4 9v6h4l5 4V5L8 9z"/><path d="M16 9a4 4 0 0 1 0 6M19 6a8 8 0 0 1 0 12"/>',
    copy: '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h3"/>',
    edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="M13.5 6.5l4 4"/>',
    bolt: '<path d="M13 3L5 14h6l-1 7 8-11h-6z"/>',
    flag: '<path d="M5 21V4M5 4h11l-2 4 2 4H5"/>',
    users: '<circle cx="9" cy="8" r="3"/><path d="M3 20a6 6 0 0 1 12 0M16 4a3 3 0 0 1 0 6M21 20a6 6 0 0 0-4-5.6"/>',
    target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
    down: '<path d="M6 9l6 6 6-6"/>',
    up: '<path d="M6 15l6-6 6 6"/>',
    quote: '<path d="M7 7h4v4c0 3-1.5 5-4 6M15 7h4v4c0 3-1.5 5-4 6"/>',
    grid: '<rect x="3" y="3" width="8" height="10" rx="2"/><rect x="13" y="3" width="8" height="6" rx="2"/><rect x="13" y="11" width="8" height="10" rx="2"/><rect x="3" y="15" width="8" height="6" rx="2"/>',
    ear: '<path d="M7 9a5 5 0 0 1 10 0c0 3-3 4-3 7a3 3 0 0 1-6 0"/><path d="M10 9a2 2 0 0 1 4 0"/>',
  };
  function ic(name, size) {
    var s = size || 16;
    return '<svg width="' + s + '" height="' + s + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (IC[name] || "") + "</svg>";
  }
  function loading(label) { return '<div class="pk-loading">' + (ctx.loadingBarHtml ? ctx.loadingBarHtml(label) : esc(label)) + "</div>"; }
  function norm(s) { return String(s || "").toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[^a-z0-9]+/g, " ").trim(); }
  function pct(a, n) { return n ? Math.round(100 * a / n) : 0; }
  function fmt(n) { return Number(n || 0).toLocaleString(); }
  function plural(n, one, many) { return fmt(n) + " " + (n === 1 ? one : (many || one + "s")); }
  function shuffle(a) { for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)), t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
  function inField(e) { var t = e && e.target; return !!t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT" || t.isContentEditable); }
  function dayKey(t) { var d = new Date(t || Date.now()); return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0"); }
  var DAY = 86400000;

  // the practice setup (Setup panel): its filters and reading settings
  function cfg() { try { return (ctx.host && ctx.host.getPracticeConfig && ctx.host.getPracticeConfig()) || {}; } catch (e) { return {}; } }
  // filters → query parameters, the ones the app sends for a random question
  function filtersQuery(f, extra) {
    f = f || {}; var p = [];
    var add = function (k, v) { p.push(k + "=" + encodeURIComponent(v)); };
    if (f.categories && f.categories.length) add("categories", f.categories.join(","));
    if (f.categoryIds && f.categoryIds.length) add("categoryIds", f.categoryIds.join(","));
    if (f.difficulties && f.difficulties.length) add("difficulties", f.difficulties.join(","));
    if (f.setNames && f.setNames.length) add("setNames", f.setNames.join(","));
    if (f.packetNumbers && f.packetNumbers.length) add("packetNumbers", f.packetNumbers.join(","));
    if (f.yearMin != null) add("yearMin", f.yearMin);
    if (f.yearMax != null) add("yearMax", f.yearMax);
    if (f.powermarkOnly) add("powermarkOnly", "true");
    if (f.canon && f.canon.length) add("canon", f.canon.join(","));
    add("cleanOnly", "1");
    Object.keys(extra || {}).forEach(function (k) { if (extra[k] != null && extra[k] !== false) add(k, extra[k]); });
    return p.join("&");
  }
  // the practice filters without a set (a drill draws from everything the player picked)
  function practiceFilters() { var f = Object.assign({}, cfg().filters || {}); delete f.setNames; delete f.packetNumbers; delete f.setIds; return f; }
  async function getTossups(n, f, extra) {
    try { var d = await ctx.api.get("/api/tossups/query?" + filtersQuery(f || practiceFilters(), Object.assign({ random: 1, limit: n }, extra || {}))); return (d && d.rows) || []; } catch (e) { return []; }
  }
  async function getBonuses(n, f, extra) {
    try { var d = await ctx.api.get("/api/bonuses/query?" + filtersQuery(f || practiceFilters(), Object.assign({ random: 1, limit: n }, extra || {}))); return (d && d.rows) || []; } catch (e) { return []; }
  }
  async function getTossup(id) { try { return (await ctx.api.get("/api/tossups/" + encodeURIComponent(id))).tossup || null; } catch (e) { return null; } }
  async function getBonus(id) { try { return (await ctx.api.get("/api/bonuses/" + encodeURIComponent(id))).bonus || null; } catch (e) { return null; } }
  async function searchTossups(query, limit, f) {
    try { var d = await ctx.api.get("/api/tossups/search?query=" + encodeURIComponent(query) + "&limit=" + (limit || 20) + (f ? "&" + filtersQuery(f) : "")); return { rows: (d && d.rows) || [], total: (d && d.total) || 0 }; } catch (e) { return { rows: [], total: 0 }; }
  }
  // tossups whose answer line names an answer
  async function tossupsOn(answer, limit) { return (await searchTossups('answer_sanitized : ("' + String(answer).replace(/"/g, "") + '")', limit || 20)).rows; }

  // a record's text as practice reads it (notes and pronunciation guides per the player's settings)
  function readText(q) {
    try { if (ctx.host && ctx.host.questionText) { var t = ctx.host.questionText(q, "question"); if (t != null) return String(t).replace(/\(\*\)/g, "").replace(/\s{2,}/g, " ").trim(); } } catch (e) {}
    return String((q && q.question_sanitized) || "").replace(/\(\*\)/g, "").trim();
  }
  function powerAt(q) { return String((q && q.question_sanitized) || "").indexOf("(*)"); }
  // sentences, without breaking at "St." or an initial ("J. R. R. Tolkien")
  var ABBR = /(?:\b(?:St|Ste|Mt|Mts|Dr|Mr|Mrs|Ms|Mme|Prof|Sr|Jr|Rev|Fr|Gen|Col|Capt|Lt|Sgt|Maj|Adm|Hon|Pres|Gov|Sen|Rep|vs|etc|cf|ca|al|Inc|Co|Corp|Ltd|Bros|approx|No|Nos|Op|op|no|Vol|vol|Ch|ch|Fig|fig|Ft|Pt|pt|Ave|[A-Za-z])\.["”’']?)$/;
  function sentences(text) {
    var parts = String(text || "").split(/(?<=[.?!]["”’)]*)\s+(?=["“(]?[A-Z0-9])/), out = [], cur = "";
    for (var i = 0; i < parts.length; i++) {
      cur = cur ? cur + " " + parts[i] : parts[i];
      if (i < parts.length - 1 && ABBR.test(cur.trim())) continue;
      out.push(cur.trim()); cur = "";
    }
    if (cur.trim()) out.push(cur.trim());
    return out.filter(Boolean);
  }
  // where each sentence of a text ends (indexes into it)
  function sentenceEnds(text) {
    var at = 0, out = []; text = String(text || "");
    sentences(text).forEach(function (x) { var i = text.indexOf(x, at); if (i < 0) return; at = i + x.length; out.push(at); });
    return out;
  }
  // ── categories (15.63): the app's own picker, its picks kept under `key` ([] = every category) ──
  // mountCats(root, key, onChange) puts it in root's [data-cats] (made once, moved into each new render);
  // inCats(pk, e): a history entry or question in the picks; with no picks, all are
  var PICKERS = {};
  // opts.label: "" for just the picks, in a row that has its own label
  function catPicker(key, onChange, opts) {
    if (PICKERS[key]) return PICKERS[key];
    if (!ctx.host || !ctx.host.categoryPicker) return null;
    var o = { selected: ctx.storage.get(key) || [], onChange: function (ids) { ctx.storage.set(key, ids); if (onChange) onChange(ids); } };
    if (opts && opts.label != null) o.label = opts.label;
    var pk = ctx.host.categoryPicker(null, o);
    PICKERS[key] = pk;
    // the picks match nothing until the tree is in: draw again once it is
    if (pk.ready && (ctx.storage.get(key) || []).length) pk.ready.then(function () { if (onChange) onChange(pk.get()); });
    return pk;
  }
  function mountCats(root, key, onChange, opts) {
    var pk = catPicker(key, onChange, opts), host = root && root.querySelector("[data-cats]");
    if (pk && host) host.appendChild(pk.el);
    return pk;
  }
  function inCats(pk, e) {
    if (!pk || !pk.get().length) return true;
    return pk.matches(String((e && (e.category_path || e.path || e.category || e.root)) || ""));
  }
  // ── the app's reader on a page titled for the plugin (15.63: ctx.host.playPractice). Its Setup picks the categories ──
  function canRead() { return !!(ctx.host && ctx.host.playPractice); }
  function onReader() { return !!(ctx.host && ctx.host.onPracticePage && ctx.host.onPracticePage()); }
  // a plugin's start page: an icon, what it is, a Start button (data-pk="start"), a note under it
  function heroHtml(icon, title, text, start, note) {
    return '<div class="pk-hero"><span class="pk-hero-ico">' + ic(icon, 26) + "</span><h2>" + esc(title) + "</h2><p>" + esc(text) + "</p>" +
      '<div class="pk-actions pk-center"><button type="button" class="btn btn-primary" data-pk="start">' + ic("play", 14) + esc(start || "Start") + "</button></div>" +
      (note ? '<div class="pk-muted pk-small">' + note + "</div>" : "") + "</div>";
  }
  // the answer line, with its bold and underlining (nothing else of the HTML)
  function answerHtml(q) {
    var h = String((q && q.answer) || "");
    if (!/<\/?(b|u|strong|em|i)\b/i.test(h)) return esc((q && q.answer_sanitized) || h);
    return h.replace(/<(\/?)(b|u|strong|em|i)\b[^>]*>/gi, "\u0001$1$2\u0002").replace(/<[^>]*>/g, "").replace(/&(?!(?:amp|lt|gt|quot|#\d+);)/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/\u0001(\/?)(\w+)\u0002/g, "<$1$2>");
  }
  function primary(q) {
    var a = "";
    try { if (ctx.host && ctx.host.extractPrimaryAnswer) a = ctx.host.extractPrimaryAnswer((q && q.answer) || "", (q && q.answer_sanitized) || ""); } catch (e) {}
    return a || String((q && q.answer_sanitized) || "").replace(/\s*[\[(].*$/, "").trim();
  }
  // judged right here, like practice (judge.js); { status: "accept" | "prompt" | "reject", prompt }
  async function judge(q, answer, opts) {
    opts = opts || {};
    try {
      if (ctx.host && ctx.host.judgeTossup) return (await ctx.host.judgeTossup(q, answer, { strictness: opts.strictness != null ? opts.strictness : (cfg().strictness || 10), buzzPosition: opts.buzzPosition, previous: opts.previous || null })) || { status: "reject" };
      return (await ctx.api.post("/api/evaluate-tossup", { questionId: q.id, answer: answer, strictness: cfg().strictness || 10, buzzPosition: opts.buzzPosition, previous: opts.previous || null })) || { status: "reject" };
    } catch (e) { return { status: "reject" }; }
  }
  async function judgePart(b, part, answer, opts) {
    opts = opts || {};
    try {
      if (ctx.host && ctx.host.judgeBonusPart) return (await ctx.host.judgeBonusPart(b, part, answer, { strictness: cfg().strictness || 10, previous: opts.previous || null })) || { status: "reject" };
      return (await ctx.api.post("/api/evaluate-bonus-part", { questionId: b.id, part: part, answer: answer, strictness: cfg().strictness || 10 })) || { status: "reject" };
    } catch (e) { return { status: "reject" }; }
  }
  async function judgeLine(line, sani, answer, opts) {
    opts = opts || {};
    try {
      if (ctx.host && ctx.host.judgeAnswerLine) return (await ctx.host.judgeAnswerLine(line, sani, answer, { strictness: cfg().strictness || 10, previous: opts.previous || null })) || { status: "reject" };
      return (await ctx.api.post("/api/evaluate-answer", { answerline: line, answer: answer, strictness: cfg().strictness || 10 })) || { status: "reject" };
    } catch (e) { return { status: "reject" }; }
  }
  function bonusParts(b) { try { return JSON.parse((b && (b.parts_sanitized || b.parts)) || "[]"); } catch (e) { return []; } }
  function bonusAnswers(b) { try { return JSON.parse((b && b.answers) || "[]"); } catch (e) { return []; } }
  function bonusAnswersSani(b) { try { return JSON.parse((b && b.answers_sanitized) || "[]"); } catch (e) { return []; } }

  // the player's answers (Stats' history), only the fields asked for
  async function history(fields) {
    try { return ((await ctx.api.get("/api/sessions/all-entries?" + (/\banswer\b/.test(fields || "") ? "answers=1&" : "") + "fields=" + encodeURIComponent(fields || ""))).entries) || []; } catch (e) { return []; }
  }
  // record a tossup answered on a plugin's page into the player's stats (the path Coach Mode uses)
  function record(q, r) {
    try {
      ctx.api.post("/api/check-tossup", { questionId: q.id, answer: r.answer || "", buzzPosition: r.buzzPosition || 0, sessionId: r.session, overriding: true,
        correct: !!r.correct, isPower: !!r.power, points: r.points || 0, celerity: r.celerity != null ? r.celerity : 1 }).catch(function () {});
    } catch (e) {}
  }

  var ROOT_COLOR = { "Literature": "#bc8cff", "Science": "#58a6ff", "Math": "#a5e05b", "Pop Culture": "#ff7b72", "Sports": "#ff6f91", "Fine Arts": "#f778ba", "History": "#e3b341", "Geography": "#56d364", "Mythology": "#ffa657", "Social Science": "#3dd6a3", "Philosophy": "#39c5cf", "Theology": "#8e9bff", "Current Events": "#c9d16b", "Miscellaneous": "#8b949e" };
  // NAQT's high school distribution, per 24 tossups / bonuses (naqt.com/hs/distribution.jsp)
  var NAQT = [["Literature", 3.9, 3.8], ["Science", 4.5, 4.3], ["Math", 1.0, 1.0], ["Fine Arts", 2.0, 2.0], ["History", 4.6, 4.5], ["Geography", 1.9, 1.9], ["Mythology", 0.6, 0.7],
    ["Pop Culture", 1.0, 0.9], ["Sports", 0.7, 0.7], ["Social Science", 0.6, 0.6], ["Philosophy", 0.3, 0.3], ["Theology", 0.4, 0.4], ["Current Events", 1.5, 1.4], ["Miscellaneous", 1.0, 1.5]];
  function rootOf(e) { return String((e && (e.category_path || e.category)) || "").split(" > ")[0] || "Miscellaneous"; }
  function dot(root) { return '<span class="pk-dot" style="--c:' + (ROOT_COLOR[root] || "#8b949e") + '"></span>'; }
  var _roots = null;
  async function roots() {
    if (_roots) return _roots;
    try { var t = ctx.host && ctx.host.getCategoryTree ? await ctx.host.getCategoryTree("tossups") : (await ctx.api.get("/api/category-tree?type=tossups")).tree; _roots = (t || []).map(function (n) { return { id: n.id, name: n.name, count: n.count }; }); }
    catch (e) { _roots = []; }
    return _roots;
  }
  var DIFF_NAME = { 0: "Unrated", 1: "Middle school", 2: "Easy high school", 3: "Regular high school", 4: "Hard high school", 5: "National high school", 6: "Easy college", 7: "Medium college", 8: "Regionals college", 9: "Nationals college", 10: "Open" };

  function tile(value, label, cls) { return '<div class="pk-tile' + (cls ? " " + cls : "") + '"><b class="num">' + value + "</b><span>" + esc(label) + "</span></div>"; }
  function segHtml(name, items, on) {
    return '<div class="seg pk-seg" role="group">' + items.map(function (it) {
      return '<button type="button" data-' + name + '="' + esc(it[0]) + '" aria-pressed="' + (String(on) === String(it[0])) + '">' + esc(it[1]) + "</button>";
    }).join("") + "</div>";
  }
  function emptyHtml(text) { return '<div class="db-empty pk-empty">' + esc(text) + "</div>"; }
  // square toggles 0 to 10, Setup's difficulty look (the app's .diff-toggles), `on` the ones picked; diffsIn reads them
  function diffHtml(name, on) {
    var h = '<div class="diff-toggles pk-diffs" role="group" aria-label="Difficulty">';
    for (var d = 0; d <= 10; d++) h += '<label title="' + esc(DIFF_NAME[d]) + '"><input type="checkbox" data-' + name + '="' + d + '"' + ((on || []).indexOf(d) >= 0 ? " checked" : "") + "><span>" + d + "</span></label>";
    return h + "</div>";
  }
  function diffsIn(root, name) { return [].slice.call(root.querySelectorAll("[data-" + name + "]")).filter(function (i) { return i.checked; }).map(function (i) { return Number(i.getAttribute("data-" + name)); }); }
  // a list of difficulties in a few words: [2, 3, 4, 5] → "2 to 5"
  function diffWords(ds) {
    ds = (ds || []).slice().sort(function (a, b) { return a - b; });
    if (!ds.length) return "any difficulty";
    var run = ds.every(function (d, i) { return !i || d === ds[i - 1] + 1; });
    return ds.length === 1 ? "difficulty " + ds[0] : run ? "difficulty " + ds[0] + " to " + ds[ds.length - 1] : "difficulty " + ds.join(", ");
  }
  function playList(kind, ids, title) {
    if (!ids || !ids.length) return false;
    try { return !!(ctx.host && ctx.host.launchQuestions && ctx.host.launchQuestions(kind, ids, { title: title })); } catch (e) { return false; }
  }

  // a reader: shows `text` a character at a time at the practice reading speed. start(), pause(), go(), stop();
  // at() is how far it is; onEnd once it's all shown
  function Reader(el, text, opts) {
    opts = opts || {};
    var ms = opts.ms != null ? opts.ms : (Number(cfg().revealSpeed) || 25), idx = 0, raf = 0, last = 0, on = false;
    var paint = function () { el.innerHTML = '<span class="pk-read">' + esc(text.slice(0, idx)) + '</span><span class="pk-unread" aria-hidden="true">' + esc(text.slice(idx)) + "</span>"; };
    var step = function (t) {
      raf = 0; if (!on) return;
      if (!last) last = t;
      var n = ms > 0 ? Math.floor((t - last) / ms) : text.length;
      if (n > 0) { idx = Math.min(text.length, idx + n); last += n * ms; paint(); if (opts.onTick) opts.onTick(idx); }
      if (idx >= text.length) { on = false; if (opts.onEnd) opts.onEnd(); return; }
      raf = requestAnimationFrame(step);
    };
    paint();
    return {
      start: function () { if (on) return; on = true; last = 0; raf = requestAnimationFrame(step); },
      pause: function () { on = false; if (raf) cancelAnimationFrame(raf); raf = 0; },
      stop: function () { on = false; if (raf) cancelAnimationFrame(raf); raf = 0; },
      showAll: function () { this.stop(); idx = text.length; el.textContent = text; },
      at: function () { return idx; },
      running: function () { return on; },
    };
  }
  // a reader's position in the displayed text → the record's question_sanitized (what judging and stats count)
  function serverPos(q, display, pos) {
    try { if (ctx.host && ctx.host.mapDisplayPos) return ctx.host.mapDisplayPos(display, (q && q.question_sanitized) || "", pos); } catch (e) {}
    return pos;
  }

  // ── Neg Check: where your negs happen, what they cost, and the patterns behind them ──
  var body = null, page = null;
  var view = Object.assign({ weeks: 12 }, ctx.storage.get("view") || {});
  function saveView() { ctx.storage.set("view", view); }
  var entries = null, open = {};
  var PERIODS = [[4, "4 weeks"], [12, "12 weeks"], [0, "All time"]];

  function med(a) { if (!a.length) return null; var s = a.slice().sort(function (x, y) { return x - y; }); return s[Math.floor(s.length / 2)]; }
  function analyse() {
    var since = view.weeks ? Date.now() - view.weeks * 7 * DAY : 0;
    var pk = catPicker("cats", render), list = entries.filter(function (e) { return e.timestamp >= since && inCats(pk, e); });
    var negs = list.filter(function (e) { return (e.points || 0) < 0; });
    var buzzes = list.filter(function (e) { return e.correct || (e.points || 0) < 0; });
    var thirds = [0, 0, 0];
    negs.forEach(function (e) { var c = e.celerity != null ? e.celerity : 0.5; thirds[Math.min(2, Math.floor(c * 3))]++; });
    var cats = {};
    list.forEach(function (e) {
      var r = rootOf(e), c = cats[r] = cats[r] || { heard: 0, buzz: 0, negs: [], rights: [] };
      c.heard++;
      if ((e.points || 0) < 0) { c.negs.push(e.celerity != null ? e.celerity : 0.5); c.buzz++; }
      else if (e.correct) { if (e.celerity != null) c.rights.push(e.celerity); c.buzz++; }
    });
    var said = {};
    negs.forEach(function (e) { var g = norm(e.given_answer); if (g) { (said[g] = said[g] || { text: e.given_answer, n: 0, rights: [] }).n++; said[g].rights.push(e.answer || ""); } });
    var repeats = Object.keys(said).map(function (k) { return said[k]; }).filter(function (x) { return x.n >= 2; }).sort(function (a, b) { return b.n - a.n; }).slice(0, 6);
    // a plain sentence for each pattern worth knowing about
    var notes = [];
    Object.keys(cats).forEach(function (r) {
      var c = cats[r]; if (c.negs.length < 4) return;
      var mn = med(c.negs), mr = med(c.rights);
      if (mr != null && mn != null && mn < mr - 0.15) notes.push({ w: c.negs.length, html: "In <b>" + esc(r) + "</b> you neg at about " + Math.round(mn * 100) + "% of the question, but get it right at about " + Math.round(mr * 100) + "%. You're buzzing before you know it. Wait one more clue." });
      else if (c.buzz && c.negs.length / c.buzz > 0.3) notes.push({ w: c.negs.length, html: "One buzz in " + Math.max(2, Math.round(c.buzz / c.negs.length)) + " in <b>" + esc(r) + "</b> is a neg. Those are answers you nearly know. Review them below." });
    });
    if (negs.length >= 6 && thirds[0] / negs.length > 0.4) notes.push({ w: 99, html: "Most of your negs come in the first third of the question. Early buzzes win games, but only when you're sure." });
    if (negs.length >= 6 && thirds[2] / negs.length > 0.5) notes.push({ w: 98, html: "Most of your negs come late, when the answer is nearly given. Check the answer line in those. Often it's the right thing said the wrong way." });
    notes.sort(function (a, b) { return b.w - a.w; });
    return { list: list, negs: negs, buzzes: buzzes, thirds: thirds, cats: cats, repeats: repeats, notes: notes.slice(0, 4) };
  }

  function render() {
    if (!body) return;
    if (!entries) { body.innerHTML = '<div class="pk-wrap nc">' + loading("Reading your negs…") + "</div>"; return; }
    var A = analyse(), n = A.negs.length, heard = A.list.length;
    var cats = Object.keys(A.cats).map(function (r) { var c = A.cats[r]; return { r: r, n: c.negs.length, rate: c.buzz ? c.negs.length / c.buzz : 0, buzz: c.buzz }; })
      .filter(function (x) { return x.n > 0; }).sort(function (a, b) { return b.n - a.n; });
    var maxN = Math.max.apply(null, cats.map(function (c) { return c.n; }).concat([1]));
    var recent = A.negs.slice(-40).reverse();
    body.innerHTML = '<div class="pk-wrap nc">' +
      '<div class="pk-bar-top">' + segHtml("weeks", PERIODS, view.weeks) + '<span data-cats></span><span class="spacer"></span>' + (n ? '<button type="button" class="btn" id="nc-play">' + ic("play", 14) + "Play my negs</button>" : "") + "</div>" +
      (!heard ? emptyHtml("No tossups in this period yet.") :
      '<div class="pk-tiles">' + tile(fmt(n), "Negs", "pk-bad") + tile(A.buzzes.length ? pct(n, A.buzzes.length) + "<small>%</small>" : "–", "Of your buzzes") +
        tile(heard ? (n * 5 / heard * 20).toFixed(1) : "0", "Points lost per 20 tossups") + tile(n ? pct(A.thirds[0], n) + "<small>%</small>" : "–", "In the first third") + "</div>" +
      (A.notes.length ? '<div class="pk-card nc-notes">' + A.notes.map(function (x) { return '<p class="nc-note">' + x.html + "</p>"; }).join("") + "</div>" : "") +
      (n ? '<div class="nc-cols"><div class="pk-card"><h3>Where they happen</h3>' + ["First third", "Middle third", "Last third"].map(function (l, i) {
          return '<div class="pk-row nc-third"><span class="nc-tl">' + l + '</span><span class="pk-grow"><span class="pk-meter"><span style="width:' + pct(A.thirds[i], n) + '%;--c:var(--red)"></span></span></span><span class="num nc-tn">' + A.thirds[i] + "</span></div>";
        }).join("") + "</div>" +
        '<div class="pk-card"><h3>By category</h3>' + cats.slice(0, 8).map(function (c) {
          return '<div class="pk-row nc-third">' + dot(c.r) + '<span class="nc-tl">' + esc(c.r) + '</span><span class="pk-grow"><span class="pk-meter"><span style="width:' + (100 * c.n / maxN) + '%;--c:var(--red)"></span></span></span><span class="num nc-tn">' + c.n + '<small class="pk-muted"> · ' + Math.round(c.rate * 100) + "%</small></span></div>";
        }).join("") + "</div></div>" : "") +
      (A.repeats.length ? '<div class="pk-card"><h3>Answers you keep giving</h3>' + A.repeats.map(function (x) {
          var right = x.rights.filter(Boolean).slice(0, 4).map(esc).join(", ");
          return '<div class="nc-rep"><b>“' + esc(x.text) + '”</b> <span class="pk-muted">' + x.n + " times. It was " + (right || "something else") + "</span></div>";
        }).join("") + "</div>" : "") +
      (recent.length ? '<div class="pk-sechead"><span class="eyebrow">Recent negs</span></div><div class="list pk-list">' + recent.map(function (e, i) {
          var k = e.question_id + ":" + e.timestamp;
          return '<div class="list-row clickable nc-row" role="button" tabindex="0" data-k="' + esc(k) + '" data-id="' + esc(e.question_id) + '">' + dot(rootOf(e)) +
            '<span class="pk-grow nc-what"><span><span class="pk-bad">“' + esc(e.given_answer || "?") + '”</span> <span class="pk-muted">for</span> <b>' + esc(e.answer || "") + '</b></span><small class="pk-muted">' + esc(rootOf(e)) + " · at " + Math.round((e.celerity || 0) * 100) + "% · " + new Date(e.timestamp).toLocaleDateString() + "</small></span>" +
            '<span class="pk-muted">' + ic(open[k] ? "up" : "down", 14) + "</span></div>" + (open[k] ? '<div class="nc-clue" data-for="' + esc(k) + '">' + (open[k] === true ? loading("") : open[k]) + "</div>" : "");
        }).join("") + "</div>" : "")) + "</div>";
    mountCats(body, "cats", render);
    body.querySelectorAll("[data-weeks]").forEach(function (b) { b.onclick = function () { view.weeks = Number(b.dataset.weeks); saveView(); render(); }; });
    var pl = body.querySelector("#nc-play"); if (pl) pl.onclick = function () { var seen = {}, ids = A.negs.slice().reverse().map(function (e) { return e.question_id; }).filter(function (id) { if (!id || seen[id]) return false; seen[id] = 1; return true; }).slice(0, 50); playList("tossups", ids, "My negs"); };
    body.querySelectorAll(".nc-row").forEach(function (el) {
      var go = function () { toggle(el.dataset.k, el.dataset.id, A.negs.find(function (e) { return e.question_id + ":" + e.timestamp === el.dataset.k; })); };
      el.onclick = go; el.onkeydown = function (ev) { if (ev.key === "Enter" || ev.key === " ") { ev.preventDefault(); go(); } };
    });
  }
  // the clue you negged on: the question up to your buzz, the sentence you buzzed in marked
  async function toggle(k, id, e) {
    if (open[k]) { delete open[k]; render(); return; }
    open[k] = true; render();
    var q = await getTossup(id);
    if (!q) { open[k] = '<span class="pk-muted">This question is no longer in the database.</span>'; render(); return; }
    var raw = String(q.question_sanitized || ""), at = Math.max(0, Math.min(raw.length, e && e.buzz_position != null ? e.buzz_position : Math.round((e.celerity || 0) * raw.length)));
    var sp = raw.slice(at).search(/\s/); if (sp > 0) at += sp;   // the buzz is after the word it lands in
    var dotAt = raw.lastIndexOf(". ", at - 2), start = dotAt >= 0 ? dotAt + 2 : 0, end = raw.indexOf(". ", at); if (end < 0) end = raw.length; else end += 1;
    var clean = function (s) { return esc(s.replace(/\(\*\)/g, "")); };
    open[k] = '<div class="pk-q nc-q">' + clean(raw.slice(0, start)) + "<mark>" + clean(raw.slice(start, at)) + '<span class="nc-buzz">' + ic("bolt", 12) + "</span>" + clean(raw.slice(at, end)) + "</mark>" + '<span class="pk-muted">' + clean(raw.slice(end)) + "</span></div>" +
      '<div class="pk-answer"><span class="pk-muted">Answer </span>' + answerHtml(q) + "</div>";
    render();
  }

  page = ctx.registerPage({
    id: "neg-check", navLabel: "Neg Check", title: "Neg Check",
    onShow: function (el) {
      body = el; entries = null; open = {}; render();
      history("type,question_id,correct,points,celerity,buzz_position,category_path,category,given_answer,timestamp,answer").then(function (es) { entries = es.filter(function (e) { return e.type === "tossup" && !e.skipped; }); render(); });
    },
  });

}
