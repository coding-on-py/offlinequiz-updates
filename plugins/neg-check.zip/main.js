/**
 * OfflineQuiz plugin: Neg Check
 *
 * Every neg in Stats' history, looked at together: where in the question they happen, which
 * categories, what they cost per 20 tossups, the wrong answers you repeat, and the clue you buzzed
 * on for each one.
 */
QB.registerPlugin({
  id: "neg-check",
  name: "Neg Check",
  version: "1.2.0",
  author: "OfflineQuiz",
  description: "Find out where and why you neg: how early, in which categories, and the answers you keep giving.",
  onEnable: __qbMain,
  onDisable: function (ctx) { if (ctx._cleanup) ctx._cleanup(); },
});
