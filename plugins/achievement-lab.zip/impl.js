function __qbMain(ctx) {
    function esc(s) { return (s == null ? "" : String(s)).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }

    var body = null, page = null, current = null, powered = false;
    var queue = [], qIndex = 0, lastFilters = "";

    function blankLab() { return { counts: {}, classes: {}, total: 0, powers: 0, cats: {}, earned: [] }; }
    function dimOk(v, want) { return !want || (Array.isArray(want) ? want.indexOf(v) >= 0 : v === want); }
    function classCount(classMap, cat, sub, alt) {
      if (!classMap || (!cat && !sub && !alt)) return 0;
      var n = 0;
      Object.keys(classMap).forEach(function (key) {
        var p = key.split("|");
        if (dimOk(p[0], cat) && dimOk(p[1], sub) && dimOk(p[2], alt)) n += classMap[key];
      });
      return n;
    }
    function lab() { var s = ctx.storage.get("lab"); return (s && typeof s === "object") ? s : blankLab(); }
    function saveLab(s) { ctx.storage.set("lab", s); }

    function achList() { try { return (ctx.host && ctx.host.getAchievementList && ctx.host.getAchievementList()) || []; } catch (e) { return []; } }
    function norm(s) { try { return (ctx.host && ctx.host.normalizeAnswerPower) ? ctx.host.normalizeAnswerPower(s) : String(s == null ? "" : s).toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/ß/g, "ss").replace(/æ/g, "ae").replace(/œ/g, "oe").replace(/ø/g, "o").replace(/ð/g, "d").replace(/þ/g, "th").replace(/ł/g, "l").replace(/[^a-z0-9]+/g, " ").trim(); } catch (e) { return ""; } }   // fallback = apFold in the base, diacritic-folding
    function matchAP(a, b) { try { return !!(ctx.host && ctx.host.matchAnswerPower && ctx.host.matchAnswerPower(a, b)); } catch (e) { return false; } }
    function primaryKey(q) {
      var p = "";
      try { if (ctx.host && ctx.host.extractPrimaryAnswer) p = ctx.host.extractPrimaryAnswer(q.answer, q.answer_sanitized); } catch (e) {}
      var k = norm(p);
      if (!k) k = norm(q.answer_sanitized || q.answer || "");
      return k;
    }

    function evalDef(def, s) {
      var progress = 0;
      if (def.type === "total") progress = s.total;
      else if (def.type === "powers") progress = s.powers;
      else if (def.type === "cat") { Object.keys(s.cats).forEach(function (k) { if (s.cats[k] > progress) progress = s.cats[k]; }); }
      else if (def.type === "cat_specific") progress = def.alt ? ((s.alts || {})[def.alt] || 0) : (s.cats[def.category] || 0);
      else if (def.type === "answer_power") {
        // Mirrors computeAchievementData in the base: a target entry is a name
        // or an ALIAS GROUP (array) that counts once; distinct:"questions"
        // counts distinct powered question ids instead of distinct names.
        var groups = (Array.isArray(def.target) ? def.target : [def.target]).map(function (t) { return Array.isArray(t) ? t : [t]; });
        var keys = Object.keys(s.counts);
        var cat = def.cat || null, sub = def.sub || null, alt = def.alt || null;
        var locked = !!(cat || sub || alt);
        var cnt = function (k) { return locked ? classCount(s.classes[k], cat, sub, alt) : (s.counts[k] || 0); };
        var matchesAny = function (k, g) { return g.some(function (t) { return matchAP(k, t); }); };
        if (def.distinct === "questions") {
          var seen = {};
          keys.forEach(function (k) {
            if (!groups.some(function (g) { return matchesAny(k, g); })) return;
            var byClass = (s.qids && s.qids[k]) || {};
            Object.keys(byClass).forEach(function (ck) {
              var p = ck.split("|");
              if (locked && !(dimOk(p[0], cat) && dimOk(p[1], sub) && dimOk(p[2], alt))) return;
              byClass[ck].forEach(function (id) { seen[id] = 1; });
            });
          });
          progress = Object.keys(seen).length;
        } else if (def.distinct && groups.length > 1) {
          groups.forEach(function (g) { if (keys.some(function (k) { return matchesAny(k, g) && cnt(k) > 0; })) progress++; });
        } else {
          keys.forEach(function (k) { if (groups.some(function (g) { return matchesAny(k, g); })) progress += cnt(k); });
        }
      }
      return { progress: progress, earned: progress >= (def.threshold || 1) };
    }

    function iconHtml(def) {
      var ic = def && def.icon != null ? String(def.icon) : "★";
      try {
        var m = window.QB && window.QB._achievementIcons;
        if (m && def && m[def.id]) ic = m[def.id];
        else {
          var f = window.QB && window.QB._achievementIconFn;
          if (typeof f === "function") { var r = f(def); if (r) ic = r; }
        }
      } catch (e) {}
      if (/[぀-鿿]/.test(ic)) ic = "★";
      if (/^\s*</.test(ic)) return '<span class="alab-ic">' + ic + "</span>";
      return '<span class="alab-ic">' + esc(ic) + "</span>";
    }

    function powerCurrent() {
      if (!current || powered) return;
      powered = true;
      var s = lab();
      if (!s.classes) s.classes = {};
      var key = primaryKey(current);
      var cat = current.category || "", sub = current.subcategory || "", alt = current.alternate_subcategory || "";
      s.total++; s.powers++;
      if (key) {
        s.counts[key] = (s.counts[key] || 0) + 1;
        var cm = s.classes[key] || (s.classes[key] = {});
        var ck = cat + "|" + sub + "|" + alt;
        cm[ck] = (cm[ck] || 0) + 1;
        if (current.id) { if (!s.qids) s.qids = {}; var qm = s.qids[key] || (s.qids[key] = {}); var ql = qm[ck] || (qm[ck] = []); if (ql.indexOf(current.id) < 0) ql.push(current.id); }
      }
      if (cat) s.cats[cat] = (s.cats[cat] || 0) + 1;
      if (alt) { if (!s.alts) s.alts = {}; s.alts[alt] = (s.alts[alt] || 0) + 1; }   // Math / CS achievements key on the alternate

      var prev = {}; (s.earned || []).forEach(function (id) { prev[id] = 1; });
      var nowEarned = {}, matched = [], newly = [];
      achList().forEach(function (def) {
        var r = evalDef(def, s);
        if (r.earned) nowEarned[def.id] = 1;
        var isNew = r.earned && !prev[def.id];
        if (isNew) newly.push(def);
        var relevant = false;
        if (def.type === "answer_power") {
          var targets = Array.isArray(def.target) ? def.target : [def.target];
          var dcat = def.cat || null, dsub = def.sub || null, dalt = def.alt || null;
          var classOk = !(dcat || dsub || dalt) || (dimOk(cat, dcat) && dimOk(sub, dsub) && dimOk(alt, dalt));
          relevant = classOk && targets.some(function (t) { return matchAP(key, t); });
        } else if (def.type === "cat_specific") {
          relevant = def.category === cat;
        } else if (isNew) {
          relevant = true;
        }
        if (relevant) matched.push({ def: def, progress: r.progress, earned: r.earned, isNew: isNew });
      });
      s.earned = Object.keys(nowEarned);
      saveLab(s);

      matched.sort(function (a, b) { return (b.isNew - a.isNew) || (b.earned - a.earned) || (b.progress - a.progress); });
      if (newly.length) { try { ctx.toast("Lab: unlocked " + newly.length + " achievement" + (newly.length === 1 ? "" : "s") + "!"); } catch (e) {} if (ctx.playSound) ctx.playSound("power"); }
      else if (ctx.playSound) ctx.playSound("correct");
      render(key, matched);
    }

    // ---- question loading (deterministic order) ----
    function filterQuery() {
      var cat = body && body.querySelector("#alab-cat") ? body.querySelector("#alab-cat").value : "";
      var diffs = body ? [].slice.call(body.querySelectorAll(".alab-diff:checked")).map(function (c) { return c.value; }) : [];
      return (cat ? "&categories=" + encodeURIComponent(cat) : "") + (diffs.length ? "&difficulties=" + diffs.join(",") : "") + "&standard=1";
    }
    async function ensureQueue() {
      var f = filterQuery();
      if (f !== lastFilters) { lastFilters = f; queue = []; qIndex = 0; }
      if (qIndex < queue.length) return true;
      try {
        var d = await ctx.api.get("/api/tossups/query?limit=50&offset=" + queue.length + f);
        var rows = (d && d.rows) || [];
        if (!rows.length) return queue.length > 0 ? "wrap" : false;
        queue = queue.concat(rows);
        return true;
      } catch (e) { return false; }
    }
    async function loadNext() {
      if (!body) return;
      var r = await ensureQueue();
      if (r === "wrap") { qIndex = 0; }
      else if (!r) { current = null; powered = false; render(null, [], "No matching questions"); return; }
      current = queue[qIndex] || null;
      qIndex++;
      powered = false;
      render(null, []);
    }
    async function loadSearch(text) {
      if (!body) return;
      var f = filterQuery();
      try {
        var d = await ctx.api.get("/api/tossups/search?query=" + encodeURIComponent(text) + "&limit=1" + f);
        var rows = (d && d.rows) || [];
        if (!rows.length) { render(null, [], "No question matched “" + esc(text) + "” in this filter."); return; }
        current = rows[0]; powered = false; render(null, []);
      } catch (e) { render(null, [], "Search failed."); }
    }

    function counters() {
      var s = lab();
      return '<div class="alab-counts">▶ Powers: <strong>' + s.powers + "</strong> · Questions: <strong>" + s.total + "</strong> · Unlocked here: <strong>" + (s.earned || []).length + '</strong>' +
        '<button class="btn btn-sm btn-ghost" id="alab-reset">Reset lab</button></div>';
    }
    function trophyStrip() {
      var s = lab(), earned = s.earned || [];
      if (!earned.length) return "";
      var byId = {}; achList().forEach(function (d) { byId[d.id] = d; });
      var items = earned.map(function (id) { var d = byId[id]; return d ? '<span class="alab-trophy" title="' + esc(d.name + " — " + d.desc) + '">' + iconHtml(d) + "</span>" : ""; }).join("");
      return '<div class="alab-card"><div class="alab-label">UNLOCKED IN THIS LAB (' + earned.length + ')</div><div class="alab-trophies">' + items + "</div></div>";
    }

    function resultPanel(key, matched) {
      if (key == null) return "";
      if (!matched.length) {
        return '<div class="alab-card"><div class="alab-key">Powered: <strong>' + esc(key || "—") + '</strong></div><div class="text-muted" style="font-size:12px">No matching achievements</div></div>';
      }
      var rows = matched.map(function (m) {
        var d = m.def;
        var badge = m.isNew ? '<span class="alab-badge new">UNLOCKED</span>' : (m.earned ? '<span class="alab-badge">done</span>' : '<span class="alab-badge prog">' + m.progress + "/" + (d.threshold || 1) + "</span>");
        return '<div class="alab-ach' + (m.isNew ? " new" : "") + '">' + iconHtml(d) +
          '<div class="alab-ach-txt"><div class="alab-ach-name">' + esc(d.name) + "</div><div class=\"alab-ach-desc\">" + esc(d.desc || "") + "</div></div>" + badge + "</div>";
      }).join("");
      return '<div class="alab-card"><div class="alab-key">Powered: <strong>' + esc(key || "—") + "</strong></div>" + rows + "</div>";
    }

    function questionCard() {
      if (!current) return '<div class="alab-card"><div class="text-muted">Loading…</div></div>';
      var ans = powered ? ('<div class="alab-answerline">ANSWER: ' + (current.answer || esc(current.answer_sanitized || "")) + "</div>") : '<div class="text-muted" style="font-size:12px">[Space] power</div>';
      return '<div class="alab-card">' +
        '<div class="alab-label">QUESTION <span class="text-muted" style="font-weight:400">· ' + esc(current.category || "") + (current.subcategory ? " / " + esc(current.subcategory) : "") + " · diff " + esc(current.difficulty != null ? current.difficulty : "?") + "</span></div>" +
        '<div class="alab-question">' + esc(current.question_sanitized || current.question || "") + "</div>" + ans +
        '<div class="alab-actions"><button class="btn btn-primary" id="alab-power"' + (powered ? " disabled" : "") + ">Power ▸ (Space)</button>" +
        '<button class="btn" id="alab-next">Next question (N)</button></div></div>';
    }

    function controls() {
      return '<div class="alab-card">' +
        '<div class="alab-row"><span class="alab-label2">Category</span><select id="alab-cat" class="mode-input"><option value="">All categories</option></select>' +
        '<input type="text" id="alab-search" class="mode-input" placeholder="Search answer / clue" autocomplete="off" spellcheck="false"><button class="btn btn-sm" id="alab-find">Find</button></div>' +
        '<div class="alab-row"><span class="alab-label2">Difficulty</span><span id="alab-diffs" class="alab-diffs"></span></div>' +
        "</div>";
    }

    function render(key, matched, note) {
      if (!body) return;
      body.innerHTML = '<div class="alab-wrap">' + counters() + controls() +
        (note ? '<div class="alab-card"><div class="text-muted">' + esc(note) + "</div></div>" : questionCard()) +
        resultPanel(key, matched || []) + trophyStrip() + "</div>";
      wire();
    }

    var _cats = null;
    function wire() {
      var diffWrap = body.querySelector("#alab-diffs");
      if (diffWrap) { var h = ""; for (var d = 0; d <= 10; d++) h += '<label class="alab-diffchip"><input type="checkbox" class="alab-diff" value="' + d + '"' + (lastDiffs.indexOf(String(d)) >= 0 ? " checked" : "") + ">" + d + "</label>"; diffWrap.innerHTML = h; }
      var catSel = body.querySelector("#alab-cat");
      if (catSel) {
        function fillCats(cats) { cats.forEach(function (c) { var o = document.createElement("option"); o.value = c.category; o.textContent = c.category; catSel.appendChild(o); }); if (lastCat) catSel.value = lastCat; }
        if (_cats) fillCats(_cats);
        else { try { ctx.api.get("/api/categories?type=tossups").then(function (r) { _cats = r.categories || []; fillCats(_cats); }).catch(function () {}); } catch (e) {} }
        catSel.addEventListener("change", function () { lastCat = catSel.value; queue = []; qIndex = 0; lastFilters = ""; loadNext(); });
      }
      body.querySelectorAll(".alab-diff").forEach(function (cb) { cb.addEventListener("change", function () {
        lastDiffs = [].slice.call(body.querySelectorAll(".alab-diff:checked")).map(function (x) { return x.value; });
        queue = []; qIndex = 0; lastFilters = ""; loadNext();
      }); });
      var pw = body.querySelector("#alab-power"); if (pw) pw.onclick = powerCurrent;
      var nx = body.querySelector("#alab-next"); if (nx) nx.onclick = loadNext;
      var rs = body.querySelector("#alab-reset"); if (rs) rs.onclick = function () {
        var doReset = function () { saveLab(blankLab()); render(null, []); };
        if (ctx.host && ctx.host.confirm) ctx.host.confirm("Reset the Achievement Lab tally? (Your real achievements are not affected.)", doReset, { yes: "Reset" });
        else doReset();
      };
      var fb = body.querySelector("#alab-find"), si = body.querySelector("#alab-search");
      if (fb && si) fb.onclick = function () { var t = (si.value || "").trim(); if (t) loadSearch(t); };
      if (si) si.addEventListener("keydown", function (e) { if (e.key === "Enter") { e.preventDefault(); var t = (si.value || "").trim(); if (t) loadSearch(t); } });
    }
    var lastCat = "";
    var lastDiffs = []; // difficulty chips survive the per-question re-render

    page = ctx.registerPage({
      id: "lab", navLabel: "Achievement Lab", title: "ACHIEVEMENT LAB",
      onShow: function (el) { body = el; if (current && body.querySelector("#alab-cat")) return; if (!current) loadNext(); else render(null, []); },
      onHide: function () {},
    });
    function active() { return page && page.screenEl && page.screenEl.classList.contains("active"); }

    function onKey(e) {
      if (!active()) return;
      var t = e.target;
      if (t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT")) return;
      if (e.key === " " || e.code === "Space") { e.preventDefault(); powerCurrent(); }
      else if (e.key === "n" || e.key === "N") { e.preventDefault(); loadNext(); }
    }
    document.addEventListener("keydown", onKey, true);
    ctx._unsub.push(function () { document.removeEventListener("keydown", onKey, true); });


    ctx.toast("Achievement Lab enabled");
  }
