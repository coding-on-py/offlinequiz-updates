function __qbMain(ctx) {
    function esc(s) { return (s == null ? "" : String(s)).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }

    var body = null, page = null, current = null, powered = false;
    var queue = [], qIndex = 0, lastFilters = "";

    // Lab tally, v2: answer classes keyed by the question's category PATH
    // ("Science and Math > Math > …"), plus subtree counts per path prefix.
    // A tally saved before the category tree (cat|sub|alt keys, old root
    // names) is dropped once — it cannot be matched against the new paths.
    var LAB_V = 2;
    function blankLab() { return { v: LAB_V, counts: {}, classes: {}, qids: {}, total: 0, powers: 0, cats: {}, paths: {}, alts: {}, earned: [] }; }
    function dimOk(v, want) { return !want || (Array.isArray(want) ? want.indexOf(v) >= 0 : v === want); }
    function keyPath(k) { k = String(k || ""); return k.indexOf("|") >= 0 ? k.split("|").filter(Boolean).join(" > ") : k; }
    function qPath(q) { return (q && q.category_path) || [q.category, q.subcategory, q.alternate_subcategory].filter(Boolean).join(" > "); }
    // An achievement's class lock — mirrors computeAchievementData in the
    // base: def.path (a category-path prefix, or several) when the base
    // supplies one (a lone def.cat is read the same way, as the base does);
    // else the old category / sub / alternate fields, as levels 1–3 of the path.
    function lockOf(def) {
      if (def.path) return { path: def.path };
      var cat = def.cat || null, sub = def.sub || null, alt = def.alt || null;
      if (cat && !sub && !alt) return { path: cat };
      return (cat || sub || alt) ? { cat: cat, sub: sub, alt: alt } : null;
    }
    function pathOk(key, lock) {
      if (!lock) return true;
      var p = keyPath(key);
      if (lock.path) return (Array.isArray(lock.path) ? lock.path : [lock.path]).some(function (l) { return p === l || p.indexOf(l + " > ") === 0; });
      var lv = p.split(" > ");
      return dimOk(lv[0], lock.cat) && dimOk(lv[1], lock.sub) && dimOk(lv[2], lock.alt);
    }
    function classCount(classMap, lock) {
      if (!classMap || !lock) return 0;
      var n = 0;
      Object.keys(classMap).forEach(function (key) { if (pathOk(key, lock)) n += classMap[key]; });
      return n;
    }
    function lab() { var s = ctx.storage.get("lab"); return (s && typeof s === "object" && s.v === LAB_V) ? s : blankLab(); }
    function saveLab(s) { ctx.storage.set("lab", s); }
    (function () { var s = ctx.storage.get("lab"); if (s && typeof s === "object" && s.v !== LAB_V) saveLab(blankLab()); })();
    function flatTargets(def) {
      var out = [];
      (Array.isArray(def.target) ? def.target : [def.target]).forEach(function (t) { (Array.isArray(t) ? t : [t]).forEach(function (x) { if (x) out.push(x); }); });
      return out;
    }

    function achList() { try { return (ctx.host && ctx.host.getAchievementList && ctx.host.getAchievementList()) || []; } catch (e) { return []; } }
    function norm(s) { try { return (ctx.host && ctx.host.normalizeAnswerPower) ? ctx.host.normalizeAnswerPower(s) : String(s == null ? "" : s).toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/ß/g, "ss").replace(/æ/g, "ae").replace(/œ/g, "oe").replace(/ø/g, "o").replace(/ð/g, "d").replace(/þ/g, "th").replace(/ł/g, "l").replace(/[^a-z0-9]+/g, " ").trim(); } catch (e) { return ""; } }   // fallback = apFold in the base, diacritic-folding
    function matchAP(a, b) { try { return !!(ctx.host && ctx.host.matchAnswerPower && ctx.host.matchAnswerPower(a, b)); } catch (e) { return false; } }
    function primaryKey(q) {
      var p = "";
      try { if (ctx.host && ctx.host.extractPrimaryAnswer) p = ctx.host.extractPrimaryAnswer(q.answer, q.answer_sanitized); } catch (e) {}
      var k = norm(p);
      if (!k) k = norm(q.answer_sanitized || q.answer || "");
      return k;
    }

    function evalDef(def, s) {
      var progress = 0;
      if (def.type === "total") progress = s.total;
      else if (def.type === "powers") progress = s.powers;
      else if (def.type === "cat") { Object.keys(s.cats).forEach(function (k) { if (s.cats[k] > progress) progress = s.cats[k]; }); }
      else if (def.type === "cat_specific") progress = def.path ? ((s.paths || {})[def.path] || 0) : def.alt ? ((s.alts || {})[def.alt] || 0) : (s.cats[def.category] || 0);
      else if (def.type === "answer_power") {
        // Mirrors computeAchievementData in the base: a target entry is a name
        // or an ALIAS GROUP (array) that counts once; distinct:"questions"
        // counts distinct powered question ids instead of distinct names.
        var groups = (Array.isArray(def.target) ? def.target : [def.target]).map(function (t) { return Array.isArray(t) ? t : [t]; });
        var keys = Object.keys(s.counts);
        var lock = lockOf(def), locked = !!lock;
        var cnt = function (k) { return locked ? classCount(s.classes[k], lock) : (s.counts[k] || 0); };
        var matchesAny = function (k, g) { return g.some(function (t) { return matchAP(k, t); }); };
        if (def.distinct === "questions") {
          var seen = {};
          keys.forEach(function (k) {
            if (!groups.some(function (g) { return matchesAny(k, g); })) return;
            var byClass = (s.qids && s.qids[k]) || {};
            Object.keys(byClass).forEach(function (ck) {
              if (locked && !pathOk(ck, lock)) return;
              byClass[ck].forEach(function (id) { seen[id] = 1; });
            });
          });
          progress = Object.keys(seen).length;
        } else if (def.distinct && groups.length > 1) {
          groups.forEach(function (g) { if (keys.some(function (k) { return matchesAny(k, g) && cnt(k) > 0; })) progress++; });
        } else {
          keys.forEach(function (k) { if (groups.some(function (g) { return matchesAny(k, g); })) progress += cnt(k); });
        }
      }
      return { progress: progress, earned: progress >= (def.threshold || 1) };
    }

    function iconHtml(def) {
      var ic = def && def.icon != null ? String(def.icon) : "★";
      try {
        var m = window.QB && window.QB._achievementIcons;
        if (m && def && m[def.id]) ic = m[def.id];
        else {
          var f = window.QB && window.QB._achievementIconFn;
          if (typeof f === "function") { var r = f(def); if (r) ic = r; }
        }
      } catch (e) {}
      if (/[぀-鿿]/.test(ic)) ic = "★";
      if (/^\s*</.test(ic)) return '<span class="alab-ic">' + ic + "</span>";
      return '<span class="alab-ic">' + esc(ic) + "</span>";
    }

    function powerCurrent() {
      if (!current || powered) return;
      powered = true;
      var s = lab();
      if (!s.classes) s.classes = {};
      var key = primaryKey(current);
      var cat = current.category || "", alt = current.alternate_subcategory || "";
      var path = qPath(current);
      s.total++; s.powers++;
      if (key) {
        s.counts[key] = (s.counts[key] || 0) + 1;
        var cm = s.classes[key] || (s.classes[key] = {});
        cm[path] = (cm[path] || 0) + 1;
        if (current.id) { if (!s.qids) s.qids = {}; var qm = s.qids[key] || (s.qids[key] = {}); var ql = qm[path] || (qm[path] = []); if (ql.indexOf(current.id) < 0) ql.push(current.id); }
      }
      if (cat) s.cats[cat] = (s.cats[cat] || 0) + 1;
      // subtree counts per path prefix (cat_specific achievements carry a path)
      if (path) { if (!s.paths) s.paths = {}; var lv = path.split(" > "); for (var i = 1; i <= lv.length; i++) { var pk = lv.slice(0, i).join(" > "); s.paths[pk] = (s.paths[pk] || 0) + 1; } }
      if (alt) { if (!s.alts) s.alts = {}; s.alts[alt] = (s.alts[alt] || 0) + 1; }   // older bases: Math / CS keyed on the alternate

      var prev = {}; (s.earned || []).forEach(function (id) { prev[id] = 1; });
      var nowEarned = {}, matched = [], newly = [];
      achList().forEach(function (def) {
        var r = evalDef(def, s);
        if (r.earned) nowEarned[def.id] = 1;
        var isNew = r.earned && !prev[def.id];
        if (isNew) newly.push(def);
        var relevant = false;
        if (def.type === "answer_power") {
          relevant = pathOk(path, lockOf(def)) && flatTargets(def).some(function (t) { return matchAP(key, t); });
        } else if (def.type === "cat_specific") {
          relevant = def.path ? pathOk(path, { path: def.path }) : def.category === cat;
        } else if (isNew) {
          relevant = true;
        }
        if (relevant) matched.push({ def: def, progress: r.progress, earned: r.earned, isNew: isNew });
      });
      s.earned = Object.keys(nowEarned);
      saveLab(s);

      matched.sort(function (a, b) { return (b.isNew - a.isNew) || (b.earned - a.earned) || (b.progress - a.progress); });
      if (newly.length) { try { ctx.toast("Lab: unlocked " + newly.length + " achievement" + (newly.length === 1 ? "" : "s") + "!"); } catch (e) {} if (ctx.playSound) ctx.playSound("power"); }
      else if (ctx.playSound) ctx.playSound("correct");
      render(key, matched);
    }

    // ---- question loading (deterministic order) ----
    function filterQuery() {
      var diffs = body ? [].slice.call(body.querySelectorAll(".alab-diff:checked")).map(function (c) { return c.value; }) : [];
      var catQ;
      if (catPicker()) catQ = lastCatIds.length ? "&categoryIds=" + encodeURIComponent(lastCatIds.join(",")) : "";
      else { var cat = body && body.querySelector("#alab-cat") ? body.querySelector("#alab-cat").value : ""; catQ = cat ? "&categories=" + encodeURIComponent(cat) : ""; }
      return catQ + (diffs.length ? "&difficulties=" + diffs.join(",") : "") + "&standard=1";
    }
    async function ensureQueue() {
      var f = filterQuery();
      if (f !== lastFilters) { lastFilters = f; queue = []; qIndex = 0; }
      if (qIndex < queue.length) return true;
      try {
        var d = await ctx.api.get("/api/tossups/query?limit=50&offset=" + queue.length + f);
        var rows = (d && d.rows) || [];
        if (!rows.length) return queue.length > 0 ? "wrap" : false;
        queue = queue.concat(rows);
        return true;
      } catch (e) { return false; }
    }
    async function loadNext() {
      if (!body) return;
      var r = await ensureQueue();
      if (r === "wrap") { qIndex = 0; }
      else if (!r) { current = null; powered = false; render(null, [], "No matching questions"); return; }
      current = queue[qIndex] || null;
      qIndex++;
      powered = false;
      render(null, []);
    }
    async function loadSearch(text) {
      if (!body) return;
      var f = filterQuery();
      try {
        var d = await ctx.api.get("/api/tossups/search?query=" + encodeURIComponent(text) + "&limit=1" + f);
        var rows = (d && d.rows) || [];
        if (!rows.length) { render(null, [], "No question matched “" + esc(text) + "” in this filter."); return; }
        current = rows[0]; powered = false; render(null, []);
      } catch (e) { render(null, [], "Search failed."); }
    }

    function counters() {
      var s = lab();
      return '<div class="alab-counts">▶ Powers: <strong>' + s.powers + "</strong> · Questions: <strong>" + s.total + "</strong> · Unlocked here: <strong>" + (s.earned || []).length + '</strong>' +
        '<button class="btn btn-sm btn-ghost" id="alab-reset">Reset lab</button></div>';
    }
    function trophyStrip() {
      var s = lab(), earned = s.earned || [];
      if (!earned.length) return "";
      var byId = {}; achList().forEach(function (d) { byId[d.id] = d; });
      var items = earned.map(function (id) { var d = byId[id]; return d ? '<span class="alab-trophy" title="' + esc(d.name + " — " + d.desc) + '">' + iconHtml(d) + "</span>" : ""; }).join("");
      return '<div class="alab-card"><div class="alab-label">UNLOCKED IN THIS LAB (' + earned.length + ')</div><div class="alab-trophies">' + items + "</div></div>";
    }

    function resultPanel(key, matched) {
      if (key == null) return "";
      if (!matched.length) {
        return '<div class="alab-card"><div class="alab-key">Powered: <strong>' + esc(key || "—") + '</strong></div><div class="text-muted" style="font-size:12px">No matching achievements</div></div>';
      }
      var rows = matched.map(function (m) {
        var d = m.def;
        var badge = m.isNew ? '<span class="alab-badge new">UNLOCKED</span>' : (m.earned ? '<span class="alab-badge">done</span>' : '<span class="alab-badge prog">' + m.progress + "/" + (d.threshold || 1) + "</span>");
        return '<div class="alab-ach' + (m.isNew ? " new" : "") + '">' + iconHtml(d) +
          '<div class="alab-ach-txt"><div class="alab-ach-name">' + esc(d.name) + "</div><div class=\"alab-ach-desc\">" + esc(d.desc || "") + "</div></div>" + badge + "</div>";
      }).join("");
      return '<div class="alab-card"><div class="alab-key">Powered: <strong>' + esc(key || "—") + "</strong></div>" + rows + "</div>";
    }

    // The record's text as the practice screen reads it (notes / guides per
    // the user's settings); older bases: the plain copy.
    function questionText(q) {
      var t = null;
      try { if (ctx.host && ctx.host.questionText) t = ctx.host.questionText(q, "question"); } catch (e) { t = null; }
      return t == null ? (q.question_sanitized || q.question || "") : t;
    }
    function questionCard() {
      if (!current) return '<div class="alab-card"><div class="text-muted">Loading…</div></div>';
      var ans = powered ? ('<div class="alab-answerline">ANSWER: ' + (current.answer || esc(current.answer_sanitized || "")) + "</div>") : '<div class="text-muted" style="font-size:12px">[Space] power</div>';
      return '<div class="alab-card">' +
        '<div class="alab-label">QUESTION <span class="text-muted" style="font-weight:400">· ' + esc(current.category || "") + (current.subcategory ? " / " + esc(current.subcategory) : "") + " · diff " + esc(current.difficulty != null ? current.difficulty : "?") + "</span></div>" +
        '<div class="alab-question">' + esc(questionText(current)) + "</div>" + ans +
        '<div class="alab-actions"><button class="btn btn-primary" id="alab-power"' + (powered ? " disabled" : "") + ">Power ▸ (Space)</button>" +
        '<button class="btn" id="alab-next">Next question (N)</button></div></div>';
    }

    function controls() {
      var catHtml = catPicker() ? '<span id="alab-cat-slot"></span>'
        : '<span class="alab-label2">Category</span><select id="alab-cat" class="mode-input"><option value="">All categories</option></select>';
      return '<div class="alab-card">' +
        '<div class="alab-row">' + catHtml +
        '<input type="text" id="alab-search" class="mode-input" placeholder="Search answer / clue" autocomplete="off" spellcheck="false"><button class="btn btn-sm" id="alab-find">Find</button></div>' +
        '<div class="alab-row"><span class="alab-label2">Difficulty</span><span id="alab-diffs" class="alab-diffs"></span></div>' +
        "</div>";
    }

    function render(key, matched, note) {
      if (!body) return;
      body.innerHTML = '<div class="alab-wrap">' + counters() + controls() +
        (note ? '<div class="alab-card"><div class="text-muted">' + esc(note) + "</div></div>" : questionCard()) +
        resultPanel(key, matched || []) + trophyStrip() + "</div>";
      wire();
    }

    // The app's category picker (host.categoryPicker): ONE button built once and
    // re-inserted after every re-render, so its picks survive the per-question
    // innerHTML rebuild. Picks = whole-subtree node ids → categoryIds=a,b.
    // Older bases without it keep the root <select> below.
    var _catPick = null, _catPickFailed = false, lastCatIds = [];
    function catPicker() {
      if (_catPick) return _catPick;
      if (_catPickFailed || !ctx.host || typeof ctx.host.categoryPicker !== "function") return null;
      try {
        _catPick = ctx.host.categoryPicker(null, {
          selected: lastCatIds.slice(), type: "tossups",
          onChange: function (ids) { lastCatIds = (ids || []).map(String); queue = []; qIndex = 0; lastFilters = ""; loadNext(); },
        });
        if (_catPick && _catPick.el) _catPick.el.classList.add("alab-catbtn");
        else { _catPick = null; _catPickFailed = true; }
      } catch (e) { _catPick = null; _catPickFailed = true; }
      return _catPick;
    }
    // Root select (older bases): the category tree's roots (value = node id → categories=<id>).
    var _cats = null;
    async function loadRoots() {
      var roots = null;
      try {
        if (ctx.host && ctx.host.getCategoryTree) roots = await ctx.host.getCategoryTree("tossups");
        else roots = (await ctx.api.get("/api/category-tree?type=tossups")).tree;
      } catch (e) { roots = null; }
      if (roots && roots.length) return roots.map(function (r) { return { key: r.id, name: r.name }; });
      try {   // older base without the tree: level-1 names
        return ((await ctx.api.get("/api/categories?type=tossups")).categories || []).map(function (c) { return { key: c.category, name: c.category }; });
      } catch (e) { return []; }
    }
    function wire() {
      var diffWrap = body.querySelector("#alab-diffs");
      if (diffWrap) { var h = ""; for (var d = 0; d <= 10; d++) h += '<label class="alab-diffchip"><input type="checkbox" class="alab-diff" value="' + d + '"' + (lastDiffs.indexOf(String(d)) >= 0 ? " checked" : "") + ">" + d + "</label>"; diffWrap.innerHTML = h; }
      var catSlot = body.querySelector("#alab-cat-slot");
      if (catSlot && _catPick && _catPick.el) catSlot.parentNode.replaceChild(_catPick.el, catSlot);
      var catSel = body.querySelector("#alab-cat");
      if (catSel) {
        function fillCats(cats) {
          if (!catSel.isConnected) return;
          cats.forEach(function (c) { var o = document.createElement("option"); o.value = c.key; o.textContent = c.name; if (c.key === lastCat) o.selected = true; catSel.appendChild(o); });
        }
        if (_cats) fillCats(_cats);
        else loadRoots().then(function (cats) { if (cats.length) _cats = cats; fillCats(cats); }).catch(function () {});
        catSel.addEventListener("change", function () { lastCat = catSel.value; queue = []; qIndex = 0; lastFilters = ""; loadNext(); });
      }
      body.querySelectorAll(".alab-diff").forEach(function (cb) { cb.addEventListener("change", function () {
        lastDiffs = [].slice.call(body.querySelectorAll(".alab-diff:checked")).map(function (x) { return x.value; });
        queue = []; qIndex = 0; lastFilters = ""; loadNext();
      }); });
      var pw = body.querySelector("#alab-power"); if (pw) pw.onclick = powerCurrent;
      var nx = body.querySelector("#alab-next"); if (nx) nx.onclick = loadNext;
      var rs = body.querySelector("#alab-reset"); if (rs) rs.onclick = function () {
        var doReset = function () { saveLab(blankLab()); render(null, []); };
        if (ctx.host && ctx.host.confirm) ctx.host.confirm("Reset the Achievement Lab tally? (Your real achievements are not affected.)", doReset, { yes: "Reset" });
        else doReset();
      };
      var fb = body.querySelector("#alab-find"), si = body.querySelector("#alab-search");
      if (fb && si) fb.onclick = function () { var t = (si.value || "").trim(); if (t) loadSearch(t); };
      if (si) si.addEventListener("keydown", function (e) { if (e.key === "Enter") { e.preventDefault(); var t = (si.value || "").trim(); if (t) loadSearch(t); } });
    }
    var lastCat = "";
    var lastDiffs = []; // difficulty chips survive the per-question re-render

    page = ctx.registerPage({
      id: "lab", navLabel: "Achievement Lab", title: "ACHIEVEMENT LAB",
      onShow: function (el) { body = el; if (current && body.querySelector("#alab-cat, .alab-catbtn")) return; if (!current) loadNext(); else render(null, []); },
      onHide: function () {},
    });
    function active() { return page && page.screenEl && page.screenEl.classList.contains("active"); }

    function onKey(e) {
      if (!active()) return;
      var t = e.target;
      if (t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT")) return;
      var ov = document.querySelector(".cat-ovl:not(.hidden)");   // the category picker window is open
      if (ov && ov.getClientRects().length) return;
      if (e.key === " " || e.code === "Space") { e.preventDefault(); powerCurrent(); }
      else if (e.key === "n" || e.key === "N") { e.preventDefault(); loadNext(); }
    }
    document.addEventListener("keydown", onKey, true);
    ctx._unsub.push(function () { document.removeEventListener("keydown", onKey, true); });


    ctx.toast("Achievement Lab enabled");
  }
