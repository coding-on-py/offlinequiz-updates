QB.registerPlugin({
  id: "achievement-lab",
  name: "Achievement Lab",
  version: "1.2.1",
  author: "OfflineQuiz",
  description: "Step through questions and press Space to power them. Previews exactly which achievements that power would unlock or advance — on an isolated tally that never touches your real achievements.",
  onEnable: __qbMain,
  onDisable: function () {},
});
