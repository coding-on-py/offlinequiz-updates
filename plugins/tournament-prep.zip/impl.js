function __qbMain(ctx) {
  // ── the kit the 15.62 plugins share (text, icons, questions, judging, history) ──
  function esc(s) { return (s == null ? "" : String(s)).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
  var IC = {
    play: '<path d="M7 4l13 8-13 8z"/>',
    pause: '<path d="M8 5v14M16 5v14"/>',
    left: '<path d="M15 6l-6 6 6 6"/>',
    right: '<path d="M9 6l6 6-6 6"/>',
    next: '<path d="M6 5l9 7-9 7zM18 5v14"/>',
    refresh: '<path d="M20 11a8 8 0 10-2.3 5.7M20 4v7h-7"/>',
    x: '<path d="M6 6l12 12M18 6L6 18"/>',
    check: '<path d="M5 12l5 5 9-10"/>',
    mic: '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
    volume: '<path d="M4 9v6h4l5 4V5L8 9z"/><path d="M16 9a4 4 0 0 1 0 6M19 6a8 8 0 0 1 0 12"/>',
    copy: '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h3"/>',
    edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="M13.5 6.5l4 4"/>',
    bolt: '<path d="M13 3L5 14h6l-1 7 8-11h-6z"/>',
    flag: '<path d="M5 21V4M5 4h11l-2 4 2 4H5"/>',
    users: '<circle cx="9" cy="8" r="3"/><path d="M3 20a6 6 0 0 1 12 0M16 4a3 3 0 0 1 0 6M21 20a6 6 0 0 0-4-5.6"/>',
    target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
    down: '<path d="M6 9l6 6 6-6"/>',
    up: '<path d="M6 15l6-6 6 6"/>',
    quote: '<path d="M7 7h4v4c0 3-1.5 5-4 6M15 7h4v4c0 3-1.5 5-4 6"/>',
    ear: '<path d="M7 9a5 5 0 0 1 10 0c0 3-3 4-3 7a3 3 0 0 1-6 0"/><path d="M10 9a2 2 0 0 1 4 0"/>',
  };
  function ic(name, size) {
    var s = size || 16;
    return '<svg width="' + s + '" height="' + s + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (IC[name] || "") + "</svg>";
  }
  function loading(label) { return '<div class="pk-loading">' + (ctx.loadingBarHtml ? ctx.loadingBarHtml(label) : esc(label)) + "</div>"; }
  function norm(s) { return String(s || "").toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[^a-z0-9]+/g, " ").trim(); }
  function pct(a, n) { return n ? Math.round(100 * a / n) : 0; }
  function fmt(n) { return Number(n || 0).toLocaleString(); }
  function plural(n, one, many) { return fmt(n) + " " + (n === 1 ? one : (many || one + "s")); }
  function shuffle(a) { for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)), t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
  function inField(e) { var t = e && e.target; return !!t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT" || t.isContentEditable); }
  function dayKey(t) { var d = new Date(t || Date.now()); return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0"); }
  var DAY = 86400000;

  // the practice setup (Setup panel): its filters and reading settings
  function cfg() { try { return (ctx.host && ctx.host.getPracticeConfig && ctx.host.getPracticeConfig()) || {}; } catch (e) { return {}; } }
  // filters → query parameters, the ones the app sends for a random question
  function filtersQuery(f, extra) {
    f = f || {}; var p = [];
    var add = function (k, v) { p.push(k + "=" + encodeURIComponent(v)); };
    if (f.categories && f.categories.length) add("categories", f.categories.join(","));
    if (f.categoryIds && f.categoryIds.length) add("categoryIds", f.categoryIds.join(","));
    if (f.difficulties && f.difficulties.length) add("difficulties", f.difficulties.join(","));
    if (f.setNames && f.setNames.length) add("setNames", f.setNames.join(","));
    if (f.packetNumbers && f.packetNumbers.length) add("packetNumbers", f.packetNumbers.join(","));
    if (f.yearMin != null) add("yearMin", f.yearMin);
    if (f.yearMax != null) add("yearMax", f.yearMax);
    if (f.powermarkOnly) add("powermarkOnly", "true");
    if (f.canon && f.canon.length) add("canon", f.canon.join(","));
    add("cleanOnly", "1");
    Object.keys(extra || {}).forEach(function (k) { if (extra[k] != null && extra[k] !== false) add(k, extra[k]); });
    return p.join("&");
  }
  // the practice filters without a set (a drill draws from everything the player picked)
  function practiceFilters() { var f = Object.assign({}, cfg().filters || {}); delete f.setNames; delete f.packetNumbers; delete f.setIds; return f; }
  async function getTossups(n, f, extra) {
    try { var d = await ctx.api.get("/api/tossups/query?" + filtersQuery(f || practiceFilters(), Object.assign({ random: 1, limit: n }, extra || {}))); return (d && d.rows) || []; } catch (e) { return []; }
  }
  async function getBonuses(n, f, extra) {
    try { var d = await ctx.api.get("/api/bonuses/query?" + filtersQuery(f || practiceFilters(), Object.assign({ random: 1, limit: n }, extra || {}))); return (d && d.rows) || []; } catch (e) { return []; }
  }
  async function getTossup(id) { try { return (await ctx.api.get("/api/tossups/" + encodeURIComponent(id))).tossup || null; } catch (e) { return null; } }
  async function getBonus(id) { try { return (await ctx.api.get("/api/bonuses/" + encodeURIComponent(id))).bonus || null; } catch (e) { return null; } }
  async function searchTossups(query, limit, f) {
    try { var d = await ctx.api.get("/api/tossups/search?query=" + encodeURIComponent(query) + "&limit=" + (limit || 20) + (f ? "&" + filtersQuery(f) : "")); return { rows: (d && d.rows) || [], total: (d && d.total) || 0 }; } catch (e) { return { rows: [], total: 0 }; }
  }
  // tossups whose answer line names an answer
  async function tossupsOn(answer, limit) { return (await searchTossups('answer_sanitized : ("' + String(answer).replace(/"/g, "") + '")', limit || 20)).rows; }

  // a record's text as practice reads it (notes and pronunciation guides per the player's settings)
  function readText(q) {
    try { if (ctx.host && ctx.host.questionText) { var t = ctx.host.questionText(q, "question"); if (t != null) return String(t).replace(/\(\*\)/g, "").replace(/\s{2,}/g, " ").trim(); } } catch (e) {}
    return String((q && q.question_sanitized) || "").replace(/\(\*\)/g, "").trim();
  }
  function powerAt(q) { return String((q && q.question_sanitized) || "").indexOf("(*)"); }
  // sentences, without breaking at "St." or an initial ("J. R. R. Tolkien")
  var ABBR = /(?:\b(?:St|Ste|Mt|Mts|Dr|Mr|Mrs|Ms|Mme|Prof|Sr|Jr|Rev|Fr|Gen|Col|Capt|Lt|Sgt|Maj|Adm|Hon|Pres|Gov|Sen|Rep|vs|etc|cf|ca|al|Inc|Co|Corp|Ltd|Bros|approx|No|Nos|Op|op|no|Vol|vol|Ch|ch|Fig|fig|Ft|Pt|pt|Ave|[A-Za-z])\.["”’']?)$/;
  function sentences(text) {
    var parts = String(text || "").split(/(?<=[.?!]["”’)]*)\s+(?=["“(]?[A-Z0-9])/), out = [], cur = "";
    for (var i = 0; i < parts.length; i++) {
      cur = cur ? cur + " " + parts[i] : parts[i];
      if (i < parts.length - 1 && ABBR.test(cur.trim())) continue;
      out.push(cur.trim()); cur = "";
    }
    if (cur.trim()) out.push(cur.trim());
    return out.filter(Boolean);
  }
  // where each sentence of a text ends (indexes into it)
  function sentenceEnds(text) {
    var at = 0, out = []; text = String(text || "");
    sentences(text).forEach(function (x) { var i = text.indexOf(x, at); if (i < 0) return; at = i + x.length; out.push(at); });
    return out;
  }
  // ── categories (15.63): the app's own picker, its picks kept under `key` ([] = every category) ──
  // mountCats(root, key, onChange) puts it in root's [data-cats] (made once, moved into each new render);
  // inCats(pk, e): a history entry or question in the picks; with no picks, all are
  var PICKERS = {};
  function catPicker(key, onChange) {
    if (PICKERS[key]) return PICKERS[key];
    if (!ctx.host || !ctx.host.categoryPicker) return null;
    var pk = ctx.host.categoryPicker(null, { selected: ctx.storage.get(key) || [], onChange: function (ids) { ctx.storage.set(key, ids); if (onChange) onChange(ids); } });
    PICKERS[key] = pk;
    // the picks match nothing until the tree is in: draw again once it is
    if (pk.ready && (ctx.storage.get(key) || []).length) pk.ready.then(function () { if (onChange) onChange(pk.get()); });
    return pk;
  }
  function mountCats(root, key, onChange) {
    var pk = catPicker(key, onChange), host = root && root.querySelector("[data-cats]");
    if (pk && host) host.appendChild(pk.el);
    return pk;
  }
  function inCats(pk, e) {
    if (!pk || !pk.get().length) return true;
    return pk.matches(String((e && (e.category_path || e.path || e.category || e.root)) || ""));
  }
  // ── the app's reader on a page titled for the plugin (15.63: ctx.host.playPractice). Its Setup picks the categories ──
  function canRead() { return !!(ctx.host && ctx.host.playPractice); }
  function onReader() { return !!(ctx.host && ctx.host.onPracticePage && ctx.host.onPracticePage()); }
  // a plugin's start page: an icon, what it is, a Start button (data-pk="start"), a note under it
  function heroHtml(icon, title, text, start, note) {
    return '<div class="pk-hero"><span class="pk-hero-ico">' + ic(icon, 26) + "</span><h2>" + esc(title) + "</h2><p>" + esc(text) + "</p>" +
      '<div class="pk-actions pk-center"><button type="button" class="btn btn-primary" data-pk="start">' + ic("play", 14) + esc(start || "Start") + "</button></div>" +
      (note ? '<div class="pk-muted pk-small">' + note + "</div>" : "") + "</div>";
  }
  // the answer line, with its bold and underlining (nothing else of the HTML)
  function answerHtml(q) {
    var h = String((q && q.answer) || "");
    if (!/<\/?(b|u|strong|em|i)\b/i.test(h)) return esc((q && q.answer_sanitized) || h);
    return h.replace(/<(\/?)(b|u|strong|em|i)\b[^>]*>/gi, "\u0001$1$2\u0002").replace(/<[^>]*>/g, "").replace(/&(?!(?:amp|lt|gt|quot|#\d+);)/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/\u0001(\/?)(\w+)\u0002/g, "<$1$2>");
  }
  function primary(q) {
    var a = "";
    try { if (ctx.host && ctx.host.extractPrimaryAnswer) a = ctx.host.extractPrimaryAnswer((q && q.answer) || "", (q && q.answer_sanitized) || ""); } catch (e) {}
    return a || String((q && q.answer_sanitized) || "").replace(/\s*[\[(].*$/, "").trim();
  }
  // judged right here, like practice (judge.js); { status: "accept" | "prompt" | "reject", prompt }
  async function judge(q, answer, opts) {
    opts = opts || {};
    try {
      if (ctx.host && ctx.host.judgeTossup) return (await ctx.host.judgeTossup(q, answer, { strictness: opts.strictness != null ? opts.strictness : (cfg().strictness || 10), buzzPosition: opts.buzzPosition, previous: opts.previous || null })) || { status: "reject" };
      return (await ctx.api.post("/api/evaluate-tossup", { questionId: q.id, answer: answer, strictness: cfg().strictness || 10, buzzPosition: opts.buzzPosition, previous: opts.previous || null })) || { status: "reject" };
    } catch (e) { return { status: "reject" }; }
  }
  async function judgePart(b, part, answer, opts) {
    opts = opts || {};
    try {
      if (ctx.host && ctx.host.judgeBonusPart) return (await ctx.host.judgeBonusPart(b, part, answer, { strictness: cfg().strictness || 10, previous: opts.previous || null })) || { status: "reject" };
      return (await ctx.api.post("/api/evaluate-bonus-part", { questionId: b.id, part: part, answer: answer, strictness: cfg().strictness || 10 })) || { status: "reject" };
    } catch (e) { return { status: "reject" }; }
  }
  async function judgeLine(line, sani, answer, opts) {
    opts = opts || {};
    try {
      if (ctx.host && ctx.host.judgeAnswerLine) return (await ctx.host.judgeAnswerLine(line, sani, answer, { strictness: cfg().strictness || 10, previous: opts.previous || null })) || { status: "reject" };
      return (await ctx.api.post("/api/evaluate-answer", { answerline: line, answer: answer, strictness: cfg().strictness || 10 })) || { status: "reject" };
    } catch (e) { return { status: "reject" }; }
  }
  function bonusParts(b) { try { return JSON.parse((b && (b.parts_sanitized || b.parts)) || "[]"); } catch (e) { return []; } }
  function bonusAnswers(b) { try { return JSON.parse((b && b.answers) || "[]"); } catch (e) { return []; } }
  function bonusAnswersSani(b) { try { return JSON.parse((b && b.answers_sanitized) || "[]"); } catch (e) { return []; } }

  // the player's answers (Stats' history), only the fields asked for
  async function history(fields) {
    try { return ((await ctx.api.get("/api/sessions/all-entries?" + (/\banswer\b/.test(fields || "") ? "answers=1&" : "") + "fields=" + encodeURIComponent(fields || ""))).entries) || []; } catch (e) { return []; }
  }
  // record a tossup answered on a plugin's page into the player's stats (the path Coach Mode uses)
  function record(q, r) {
    try {
      ctx.api.post("/api/check-tossup", { questionId: q.id, answer: r.answer || "", buzzPosition: r.buzzPosition || 0, sessionId: r.session, overriding: true,
        correct: !!r.correct, isPower: !!r.power, points: r.points || 0, celerity: r.celerity != null ? r.celerity : 1 }).catch(function () {});
    } catch (e) {}
  }

  var ROOT_COLOR = { "Literature": "#bc8cff", "Science": "#58a6ff", "Math": "#a5e05b", "Pop Culture": "#ff7b72", "Sports": "#ff6f91", "Fine Arts": "#f778ba", "History": "#e3b341", "Geography": "#56d364", "Mythology": "#ffa657", "Social Science": "#3dd6a3", "Philosophy": "#39c5cf", "Theology": "#8e9bff", "Current Events": "#c9d16b", "Miscellaneous": "#8b949e" };
  // NAQT's high school distribution, per 24 tossups / bonuses (naqt.com/hs/distribution.jsp)
  var NAQT = [["Literature", 3.9, 3.8], ["Science", 4.5, 4.3], ["Math", 1.0, 1.0], ["Fine Arts", 2.0, 2.0], ["History", 4.6, 4.5], ["Geography", 1.9, 1.9], ["Mythology", 0.6, 0.7],
    ["Pop Culture", 1.0, 0.9], ["Sports", 0.7, 0.7], ["Social Science", 0.6, 0.6], ["Philosophy", 0.3, 0.3], ["Theology", 0.4, 0.4], ["Current Events", 1.5, 1.4], ["Miscellaneous", 1.0, 1.5]];
  function rootOf(e) { return String((e && (e.category_path || e.category)) || "").split(" > ")[0] || "Miscellaneous"; }
  function dot(root) { return '<span class="pk-dot" style="--c:' + (ROOT_COLOR[root] || "#8b949e") + '"></span>'; }
  var _roots = null;
  async function roots() {
    if (_roots) return _roots;
    try { var t = ctx.host && ctx.host.getCategoryTree ? await ctx.host.getCategoryTree("tossups") : (await ctx.api.get("/api/category-tree?type=tossups")).tree; _roots = (t || []).map(function (n) { return { id: n.id, name: n.name, count: n.count }; }); }
    catch (e) { _roots = []; }
    return _roots;
  }
  var DIFF_NAME = { 0: "Unrated", 1: "Middle school", 2: "Easy high school", 3: "Regular high school", 4: "Hard high school", 5: "National high school", 6: "Easy college", 7: "Medium college", 8: "Regionals college", 9: "Nationals college", 10: "Open" };

  function tile(value, label, cls) { return '<div class="pk-tile' + (cls ? " " + cls : "") + '"><b class="num">' + value + "</b><span>" + esc(label) + "</span></div>"; }
  function segHtml(name, items, on) {
    return '<div class="seg pk-seg" role="group">' + items.map(function (it) {
      return '<button type="button" data-' + name + '="' + esc(it[0]) + '" aria-pressed="' + (String(on) === String(it[0])) + '">' + esc(it[1]) + "</button>";
    }).join("") + "</div>";
  }
  function emptyHtml(text) { return '<div class="db-empty pk-empty">' + esc(text) + "</div>"; }
  function playList(kind, ids, title) {
    if (!ids || !ids.length) return false;
    try { return !!(ctx.host && ctx.host.launchQuestions && ctx.host.launchQuestions(kind, ids, { title: title })); } catch (e) { return false; }
  }

  // a reader: shows `text` a character at a time at the practice reading speed. start(), pause(), go(), stop();
  // at() is how far it is; onEnd once it's all shown
  function Reader(el, text, opts) {
    opts = opts || {};
    var ms = opts.ms != null ? opts.ms : (Number(cfg().revealSpeed) || 25), idx = 0, raf = 0, last = 0, on = false;
    var paint = function () { el.innerHTML = '<span class="pk-read">' + esc(text.slice(0, idx)) + '</span><span class="pk-unread" aria-hidden="true">' + esc(text.slice(idx)) + "</span>"; };
    var step = function (t) {
      raf = 0; if (!on) return;
      if (!last) last = t;
      var n = ms > 0 ? Math.floor((t - last) / ms) : text.length;
      if (n > 0) { idx = Math.min(text.length, idx + n); last += n * ms; paint(); if (opts.onTick) opts.onTick(idx); }
      if (idx >= text.length) { on = false; if (opts.onEnd) opts.onEnd(); return; }
      raf = requestAnimationFrame(step);
    };
    paint();
    return {
      start: function () { if (on) return; on = true; last = 0; raf = requestAnimationFrame(step); },
      pause: function () { on = false; if (raf) cancelAnimationFrame(raf); raf = 0; },
      stop: function () { on = false; if (raf) cancelAnimationFrame(raf); raf = 0; },
      showAll: function () { this.stop(); idx = text.length; el.textContent = text; },
      at: function () { return idx; },
      running: function () { return on; },
    };
  }
  // a reader's position in the displayed text → the record's question_sanitized (what judging and stats count)
  function serverPos(q, display, pos) {
    try { if (ctx.host && ctx.host.mapDisplayPos) return ctx.host.mapDisplayPos(display, (q && q.question_sanitized) || "", pos); } catch (e) {}
    return pos;
  }

  // ── Tournament Prep: a daily set until a tournament, at its level, weighted to your weak categories ──
  // Each day's set follows NAQT's distribution, with categories you miss more getting more (weighed by your accuracy
  // at the tournament's level, ±1, over the last 90 days). A day is done once you've played that many tossups.
  var body = null, page = null, entries = null, editing = false, busy = false;
  var plan = ctx.storage.get("plan") || null;   // { name, date: "YYYY-MM-DD", level, perDay, start }
  function save() { ctx.storage.set("plan", plan); }
  function daysTo(dateStr) { var d = new Date(dateStr + "T00:00:00"), t = new Date(); t.setHours(0, 0, 0, 0); return Math.round((d - t) / DAY); }
  function dayStart(t) { var d = new Date(t || Date.now()); d.setHours(0, 0, 0, 0); return d.getTime(); }
  function playedOn(start) { return (entries || []).filter(function (e) { return e.timestamp >= start && e.timestamp < start + DAY; }).length; }
  function near(e) { return plan && e.difficulty != null && Math.abs(e.difficulty - plan.level) <= 1; }
  // accuracy per category at the level, and how many of each a day's set gets
  function weights() {
    var since = Date.now() - 90 * DAY, by = {};
    (entries || []).forEach(function (e) { if (e.timestamp < since || !near(e)) return; var r = rootOf(e), b = by[r] = by[r] || { n: 0, r: 0 }; b.n++; if (e.correct) b.r++; });
    return NAQT.map(function (c) { var b = by[c[0]], acc = b && b.n >= 8 ? b.r / b.n : 0.5; return { name: c[0], acc: acc, n: b ? b.n : 0, w: c[1] * (0.6 + (1 - acc)) }; });
  }
  function mix(n) {
    var ws = weights(), sum = ws.reduce(function (s, x) { return s + x.w; }, 0);
    var m = ws.map(function (x) { return { name: x.name, k: Math.round(n * x.w / sum), acc: x.acc, n: x.n }; });
    var diff = n - m.reduce(function (s, x) { return s + x.k; }, 0);
    m.sort(function (a, b) { return a.acc - b.acc; });
    for (var i = 0; diff !== 0 && i < 50; i++) { var x = m[i % m.length]; if (diff > 0) { x.k++; diff--; } else if (x.k > 0) { x.k--; diff++; } }
    return m.filter(function (x) { return x.k > 0; });
  }
  function accAt(from, to) {
    var n = 0, r = 0;
    (entries || []).forEach(function (e) { if (e.timestamp >= from && e.timestamp < to && near(e)) { n++; if (e.correct) r++; } });
    return n >= 10 ? r / n : null;
  }

  function render() {
    if (!body) return;
    if (!plan || editing) return renderSetup();
    if (!entries) { body.innerHTML = '<div class="pk-wrap tp">' + loading("Getting your plan ready…") + "</div>"; return; }
    var left = daysTo(plan.date), today = dayStart(), played = playedOn(today);
    var lastDay = left === 1, n = lastDay ? Math.ceil(plan.perDay / 2) : plan.perDay, doneToday = played >= n;
    var days = [], s = dayStart(plan.start), total = Math.max(1, Math.round((new Date(plan.date + "T00:00:00") - s) / DAY));
    for (var t = s, i = 0; t <= today && i < 120; t += DAY, i++) days.push({ t: t, n: playedOn(t) });
    var hit = days.filter(function (d) { return d.n >= plan.perDay / (d.t === today ? 1 : 1); }).length;
    var before = accAt(plan.start - 60 * DAY, plan.start), since = accAt(plan.start, Date.now() + 1);
    var m = mix(n);
    body.innerHTML = '<div class="pk-wrap tp">' +
      '<div class="pk-card tp-head"><div class="tp-count"><b class="num">' + (left > 0 ? left : 0) + "</b><span>" + (left === 1 ? "day" : "days") + '</span></div><div class="pk-grow"><div class="pk-strong">' +
        (left > 0 ? "to " + esc(plan.name || "your tournament") : left === 0 ? esc(plan.name || "Your tournament") + " is today. Good luck" : esc(plan.name || "Your tournament") + " is over") + '</div><div class="pk-muted pk-small">' +
        esc(DIFF_NAME[plan.level]) + " · " + plural(plan.perDay, "tossup") + " a day · " + new Date(plan.date + "T00:00:00").toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric" }) + "</div></div>" +
        '<button type="button" class="btn btn-ghost" id="tp-edit">' + ic("edit", 14) + "Change</button></div>" +
      (left > 0 ? '<div class="pk-card tp-today"><div class="pk-row"><h3 class="pk-grow" style="margin:0">Today' + (lastDay ? ", a lighter day" : "") + '</h3><span class="' + (doneToday ? "pk-good" : "pk-muted") + ' pk-small">' + (doneToday ? ic("check", 13) + " Done. " + played + " played" : played + " of " + n + " played") + "</span></div>" +
        '<div class="tp-mix">' + m.map(function (x) { return '<span class="pk-chip">' + dot(x.name) + esc(x.name) + " <b>&nbsp;" + x.k + "</b></span>"; }).join("") + "</div>" +
        '<div class="pk-muted pk-small">More from the categories you miss most at this level.</div>' +
        '<div class="pk-actions"><button type="button" class="btn btn-primary" id="tp-go">' + ic("play", 14) + "Play today's " + n + "</button></div></div>" : "") +
      '<div class="pk-tiles">' + tile(hit + "<small>/" + days.length + "</small>", "Days done") +
        tile(since != null ? Math.round(since * 100) + "<small>%</small>" : "–", "Right at this level since you started", "pk-good") +
        tile(before != null ? Math.round(before * 100) + "<small>%</small>" : "–", "Before") + "</div>" +
      '<div class="pk-card"><h3>Your days</h3><div class="tp-days">' + Array.from({ length: Math.min(total + 1, 60) }, function (_, k) {
        var t2 = s + k * DAY, d = days.find(function (x) { return x.t === t2; }), future = t2 > today, isT = t2 === dayStart(new Date(plan.date + "T00:00:00"));
        var ok = d && d.n >= plan.perDay;
        return '<span class="tp-day' + (ok ? " ok" : "") + (future ? " future" : "") + (t2 === today ? " today" : "") + (isT ? " t" : "") + '" title="' + new Date(t2).toLocaleDateString(undefined, { month: "short", day: "numeric" }) + (d ? ", " + d.n + " played" : "") + '">' + (isT ? ic("flag", 11) : new Date(t2).getDate()) + "</span>";
      }).join("") + "</div></div></div>";
    body.querySelector("#tp-edit").onclick = function () { editing = true; render(); };
    var go = body.querySelector("#tp-go"); if (go) go.onclick = function () { play(m, n, days.length); };
  }
  function renderSetup() {
    var p = plan || { name: "", date: dayKey(Date.now() + 21 * DAY), level: 3, perDay: 40 };
    body.innerHTML = '<div class="pk-wrap tp"><div class="pk-card"><h3>' + (plan ? "Change your tournament" : "What are you preparing for?") + '</h3><div class="tp-form">' +
      '<label class="pk-field"><span>Tournament</span><input id="tp-name" maxlength="60" placeholder="For example, HSNCT" value="' + esc(p.name) + '"></label>' +
      '<label class="pk-field"><span>Date</span><input id="tp-date" type="date" value="' + esc(p.date) + '" min="' + dayKey() + '"></label>' +
      '<label class="pk-field"><span>Level</span><select id="tp-level">' + [1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map(function (l) { return '<option value="' + l + '"' + (l === p.level ? " selected" : "") + ">" + l + ", " + esc(DIFF_NAME[l]) + "</option>"; }).join("") + "</select></label>" +
      '<label class="pk-field"><span>Tossups a day</span><select id="tp-per">' + [20, 30, 40, 60, 80].map(function (n) { return '<option value="' + n + '"' + (n === p.perDay ? " selected" : "") + ">" + n + "</option>"; }).join("") + "</select></label>" +
      '</div><div class="pk-actions" style="margin-top:16px">' + (plan ? '<button type="button" class="btn btn-ghost" id="tp-cancel">Cancel</button><button type="button" class="btn btn-ghost" id="tp-clear">Remove the plan</button>' : "") + '<button type="button" class="btn btn-primary" id="tp-save">' + (plan ? "Save" : "Make my plan") + "</button></div></div></div>";
    body.querySelectorAll("input,select").forEach(function (el) { el.addEventListener("keydown", function (e) { e.stopPropagation(); }); });
    body.querySelector("#tp-save").onclick = function () {
      var date = body.querySelector("#tp-date").value;
      if (!date || daysTo(date) < 0) { body.querySelector("#tp-date").focus(); return; }
      plan = { name: body.querySelector("#tp-name").value.trim(), date: date, level: Number(body.querySelector("#tp-level").value), perDay: Number(body.querySelector("#tp-per").value), start: plan && plan.date === date ? plan.start : dayStart() };
      save(); editing = false; render();
    };
    var c = body.querySelector("#tp-cancel"); if (c) c.onclick = function () { editing = false; render(); };
    var cl = body.querySelector("#tp-clear"); if (cl) cl.onclick = function () { plan = null; ctx.storage.set("plan", null); editing = false; render(); };
  }
  async function play(m, n, dayNo) {
    if (busy) return; busy = true;
    var btn = body.querySelector("#tp-go"); if (btn) { btn.disabled = true; btn.lastChild.textContent = "Building…"; }
    var rs = await roots(), byName = {}; rs.forEach(function (r) { byName[r.name] = r.id; });
    var f = practiceFilters(); delete f.categories; delete f.categoryIds;
    f.difficulties = [plan.level - 1, plan.level, plan.level + 1].filter(function (d) { return d >= 1 && d <= 10; });
    var ids = [];
    await Promise.all(m.map(function (x) { return byName[x.name] ? getTossups(x.k, Object.assign({}, f, { categoryIds: [byName[x.name]] })).then(function (q) { q.forEach(function (t) { ids.push(t.id); }); }) : null; }));
    busy = false; if (btn) { btn.disabled = false; btn.lastChild.textContent = "Play today's " + n; }
    playList("tossups", shuffle(ids), (plan.name ? plan.name + ", " : "") + "day " + dayNo);
  }

  page = ctx.registerPage({
    id: "tournament-prep", navLabel: "Tournament Prep", title: "Tournament Prep",
    onShow: function (el) {
      body = el; entries = null; editing = false; render();
      history("type,correct,points,difficulty,category_path,category,timestamp").then(function (es) { entries = es.filter(function (e) { return e.type === "tossup"; }); render(); });
    },
  });

}
