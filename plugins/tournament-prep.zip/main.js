/**
 * OfflineQuiz plugin: Tournament Prep
 *
 * Name a tournament, its date and its level. Every day until then you get a set of tossups at that
 * level, spread like NAQT's distribution, with more from the categories you miss most there. It
 * counts down, ticks off the days you practice and shows how your accuracy has moved.
 */
QB.registerPlugin({
  id: "tournament-prep",
  name: "Tournament Prep",
  version: "1.0.3",
  author: "OfflineQuiz",
  description: "A daily practice set until your next tournament, at its level, weighted to your weak spots.",
  onEnable: __qbMain,
  onDisable: function (ctx) { if (ctx._cleanup) ctx._cleanup(); },
});
