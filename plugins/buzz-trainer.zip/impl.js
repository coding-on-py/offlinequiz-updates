function __qbMain(ctx) {
  var body = null, page = null;
  function esc(s) { return (s == null ? "" : String(s)).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
  function ansHtml(raw, fallback) {
    var src = (raw && String(raw).trim()) ? String(raw) : String(fallback || "");
    var html = esc(src).replace(/&lt;(\/?)(b|u|i|em|strong)&gt;/gi, "<$1$2>");
    var d = document.createElement("div"); d.innerHTML = html; return d.innerHTML;
  }

  var bests = ctx.storage.get("bests") || {};       // qid -> earliest CORRECT buzz char (sanitized coords)
  var totals = ctx.storage.get("totals") || { attempts: 0, beats: 0, saved: 0 };

  // ── queue: your real buzz history, worst targets first ──────────────────
  // Latest tossup entry per question that had a buzz: negs (buzzed wrong) and
  // plain 10s (buzzed late enough to miss power). Powers are already wins.
  var queue = null;
  async function loadQueue() {
    var latest = {};
    try {
      var d = await ctx.api.get("/api/sessions/all-entries?answers=1");
      (d.entries || []).forEach(function (e) {
        if (e.type !== "tossup" || !e.question_id || e.buzz_position == null) return;
        var cur = latest[e.question_id];
        if (!cur || new Date(e.timestamp) > new Date(cur.timestamp)) latest[e.question_id] = e;
      });
    } catch (e) {}
    var out = [];
    Object.keys(latest).forEach(function (qid) {
      var e = latest[qid];
      var neg = (e.points || 0) < 0;
      var lateTen = e.correct && (e.points || 0) === 10;
      if (!neg && !lateTen) return;
      var target = e.buzz_position;
      var b = bests[qid];
      if (b != null && b < target) target = b;     // keep pushing past your trainer best
      out.push({ qid: qid, target: target, neg: neg, when: e.timestamp, answer: e.answer });   // BSON hex ids — never numeric
    });
    out.sort(function (a, b) { return (b.neg - a.neg) || (b.target - a.target); });   // negs first, latest buzzes first
    return out;
  }

  // ── round state ─────────────────────────────────────────────────────────
  var phase = "list";   // list | reading | buzzed | result
  var item = null, tossup = null, disp = "", flagAt = 0, powerAt = -1;
  var revealIdx = 0, revealTimer = null, revealStart = 0, revealSpeed = 50, buzzChar = 0, windowTimer = null;

  // Map a question_sanitized index into our display text (which only strips
  // "(*)"), via the same greedy subsequence walk the app uses in reverse.
  function origToDisp(orig, dispText, pos) {
    var oi = 0, di = 0;
    while (oi < pos && oi < orig.length) {
      if (orig[oi] === dispText[di]) { oi++; di++; } else oi++;
    }
    return Math.min(di, dispText.length);
  }

  function stopTimers() {
    if (revealTimer) { clearInterval(revealTimer); revealTimer = null; }
    if (windowTimer) { clearTimeout(windowTimer); windowTimer = null; }
  }

  function cfgSpeed() {
    try {
      var v = ctx.host.getPracticeConfig && ctx.host.getPracticeConfig().revealSpeed;
      return v == null ? 50 : v;
    } catch (e) { return 50; }
  }

  async function startItem(it) {
    stopTimers();
    item = it; tossup = null; phase = "reading"; revealIdx = 0; buzzChar = 0;
    paint();
    try { tossup = (await ctx.api.get("/api/tossups/" + it.qid)).tossup; } catch (e) {}
    if (!tossup) { ctx.toast("Couldn't load that question", "error"); phase = "list"; paint(); return; }
    var orig = tossup.question_sanitized || tossup.question || "";
    disp = orig.replace(/\s*\(\*\)\s*/g, " ");
    flagAt = origToDisp(orig, disp, it.target);
    var star = orig.indexOf("(*)");
    powerAt = star >= 0 ? origToDisp(orig, disp, star) : -1;
    revealSpeed = cfgSpeed();
    revealStart = Date.now();
    paint();
    if (revealSpeed === 0) { revealIdx = disp.length; fullyRead(); return; }
    revealTimer = setInterval(function () {
      // Wall-clock, not per-tick — background throttling can't slow the read.
      var idx = Math.min(disp.length, Math.floor((Date.now() - revealStart) / revealSpeed));
      if (idx !== revealIdx) { revealIdx = idx; paintQuestion(); }
      if (revealIdx >= disp.length) fullyRead();
    }, 30);
  }

  function fullyRead() {
    stopTimers();
    paintQuestion();
    var hint = body && body.querySelector("#bt-hint");
    if (hint) hint.textContent = "Question over — 5s to buzz…";
    windowTimer = setTimeout(function () {
      if (phase === "reading") { buzzChar = disp.length; finish(false, "", true); }
    }, 5000);
  }

  function buzz() {
    if (phase !== "reading") return;
    stopTimers();
    phase = "buzzed"; buzzChar = revealIdx;
    paint();
    var inp = body && body.querySelector("#bt-input"); if (inp) inp.focus();
  }

  async function submit(text) {
    if (phase !== "buzzed") return;
    phase = "result";
    var ok = false, prompted = false;
    if (String(text || "").trim()) {
      try {
        var strict = (ctx.host.getPracticeConfig && ctx.host.getPracticeConfig().strictness) || 10;
        var r = await ctx.api.post("/api/evaluate-answer", { answerline: tossup.answer, sanitized: tossup.answer_sanitized, answer: String(text).trim(), strictness: strict });
        ok = r.status === "accept" || r.status === "prompt";
        prompted = r.status === "prompt";
      } catch (e) {}
    }
    finish(ok, String(text || "").trim(), false, prompted);
  }

  function finish(ok, given, timedOut, prompted) {
    stopTimers();
    phase = "result";
    totals.attempts++;
    var beat = ok && buzzChar < flagAt;
    if (beat) {
      totals.beats++;
      totals.saved += flagAt - buzzChar;
      bests[item.qid] = Math.min(bests[item.qid] != null ? bests[item.qid] : Infinity, dispToOrigApprox(buzzChar));
      ctx.storage.set("bests", bests);
      ctx.playSound(powerAt >= 0 && buzzChar <= powerAt ? "power" : "correct");
    } else if (ok) {
      ctx.playSound("correct");
    } else {
      ctx.playSound("incorrect");
    }
    ctx.storage.set("totals", totals);
    item._res = { ok: ok, beat: beat, given: given, timedOut: timedOut, prompted: prompted, power: ok && powerAt >= 0 && buzzChar <= powerAt };
    paint();
  }

  function dispToOrigApprox(dPos) {
    var orig = (tossup && (tossup.question_sanitized || tossup.question)) || disp;
    var oi = 0, di = 0;
    while (di < dPos && oi < orig.length) {
      if (orig[oi] === disp[di]) { oi++; di++; } else oi++;
    }
    return oi;
  }

  // ── rendering ───────────────────────────────────────────────────────────
  function questionHtml() {
    var upTo = phase === "result" ? disp.length : revealIdx;
    var pieces = [], cursor = 0;
    var stops = [];
    if (powerAt >= 0 && powerAt <= upTo) stops.push({ at: powerAt, html: '<span class="bt-power-mark">(*)</span>' });
    if (flagAt <= upTo) stops.push({ at: flagAt, html: '<span class="bt-flag" title="Your previous buzz">⚑</span>' });
    if (phase === "result" && buzzChar <= upTo) stops.push({ at: buzzChar, html: '<span class="bt-you" title="This buzz">▼</span>' });
    stops.sort(function (a, b) { return a.at - b.at; });
    stops.forEach(function (s) {
      pieces.push(esc(disp.slice(cursor, s.at)) + s.html);
      cursor = s.at;
    });
    pieces.push(esc(disp.slice(cursor, upTo)));
    return pieces.join("");
  }
  function paintQuestion() {
    var el = body && body.querySelector("#bt-q");
    if (el) el.innerHTML = questionHtml();
  }

  function pct(part, whole) { return whole ? Math.round(100 * part / whole) : 0; }

  function paint() {
    if (!body) return;
    if (phase === "list") { paintList(); return; }
    var res = item && item._res;
    var head =
      '<div class="bt-head">' +
        '<button class="btn btn-sm btn-ghost" id="bt-quit">‹ Queue</button>' +
        '<span class="pill' + (item.neg ? " pill-red" : "") + '">' + (item.neg ? "you NEGGED here" : "you buzzed late here") + "</span>" +
        (tossup ? '<span class="pill">' + esc(tossup.category || "") + "</span>" : "") +
        '<span class="text-muted" id="bt-hint" style="font-size:12px;margin-left:auto">' +
          (phase === "reading" ? "[Space] buzz before the ⚑" : phase === "buzzed" ? "answer + Enter" : "[N] next · [R] retry") + "</span>" +
      "</div>";
    var mainHtml = '<div class="bt-qbox"><div id="bt-q" class="bt-qtext">' + (tossup ? questionHtml() : '<span class="text-muted">loading…</span>') + "</div></div>";
    if (phase === "buzzed") {
      mainHtml += '<div class="buzz-prompt"><span class="prompt-symbol">&gt;</span><input type="text" id="bt-input" placeholder="answer… (Enter)" autocomplete="off" autocorrect="off" spellcheck="false"></div>';
    }
    if (phase === "result" && res) {
      var saved = flagAt - buzzChar;
      var verdict = res.beat
        ? '<div class="result-banner correct">' + (res.power ? "⚡ POWER — " : "") + "BEAT IT — " + saved + " chars (" + pct(saved, disp.length) + "% of the question) earlier" + (res.prompted ? " (on a prompt)" : "") + "</div>"
        : res.ok
          ? '<div class="result-banner correct">Right, but not earlier than your ⚑</div>'
          : '<div class="result-banner incorrect">' + (res.timedOut ? "No buzz" : "✗ “" + esc(res.given) + "”") + "</div>";
      mainHtml += verdict +
        '<div class="result-answer">ANSWER: <span class="actual">' + ansHtml(tossup.answer, tossup.answer_sanitized) + "</span></div>";
    }
    body.innerHTML = '<div class="bt-wrap">' + head + mainHtml + "</div>";
    body.querySelector("#bt-quit").onclick = function () { stopTimers(); phase = "list"; paint(); };
    var inp = body.querySelector("#bt-input");
    if (inp) {
      inp.focus();
      inp.addEventListener("keydown", function (e) { if (e.key === "Enter") { e.stopPropagation(); submit(inp.value); } });
    }
  }

  function paintList() {
    var rows = (queue || []).map(function (it, i) {
      var res = it._res;
      return '<tr><td class="text-muted">' + (i + 1) + "</td>" +
        "<td><strong>" + esc(it.answer || "?") + "</strong></td>" +
        '<td><span class="pill ' + (it.neg ? "pill-red" : "") + '">' + (it.neg ? "neg" : "late buzz") + "</span></td>" +
        '<td class="text-muted">buzzed at char ' + it.target + "</td>" +
        "<td>" + (res ? (res.beat ? '<span class="pill pill-green">beaten</span>' : res.ok ? '<span class="pill">right, not earlier</span>' : '<span class="pill pill-red">missed</span>') : "") + "</td>" +
        '<td><button class="btn btn-sm bt-go" data-i="' + i + '">Replay</button></td></tr>';
    }).join("");
    body.innerHTML =
      '<div class="bt-wrap">' +
        '<div class="bt-head"><span class="bt-title">BEAT YOUR BUZZ</span><span class="qb-info" data-tip="Every question below is one you negged or converted late, replayed at your reading speed with a ⚑ where you buzzed last time. Get there first — with the right answer.">i</span>' +
          '<span class="pill">beaten ' + totals.beats + "/" + totals.attempts + '</span>' +
          '<span class="pill" title="Total characters of reading you no longer need">' + totals.saved + ' chars earlier</span>' +
          '<button class="btn btn-sm btn-ghost" id="bt-refresh" style="margin-left:auto">Refresh</button></div>' +
        (queue === null
          ? '<div class="text-muted" style="padding:16px">Reading your buzz history…</div>'
          : queue.length
            ? '<table class="stats-table"><thead><tr><th>#</th><th>Answer</th><th>Why</th><th>Previous buzz</th><th>This visit</th><th></th></tr></thead><tbody>' + rows + "</tbody></table>"
            : '<div class="text-muted" style="padding:16px">Nothing to beat yet.</div>') +
      "</div>";
    body.querySelector("#bt-refresh").onclick = function () { queue = null; paintList(); boot(); };
    body.querySelectorAll(".bt-go").forEach(function (b) {
      b.onclick = function () { startItem(queue[parseInt(b.dataset.i)]); };
    });
  }

  async function boot() {
    queue = await loadQueue();
    if (body && phase === "list") paintList();
  }

  function active() { return page && page.screenEl && page.screenEl.classList.contains("active"); }

  function keyHandler(e) {
    if (!active()) return;
    var tag = (e.target && e.target.tagName) || "";
    if (e.key === " " && phase === "reading") { e.preventDefault(); buzz(); return; }
    if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return;
    if ((e.key === "n" || e.key === "N") && phase === "result") { e.preventDefault(); nextUnbeaten(); }
    if ((e.key === "r" || e.key === "R") && phase === "result") { e.preventDefault(); startItem(item); }
  }
  document.addEventListener("keydown", keyHandler, true);

  function nextUnbeaten() {
    var i = queue.indexOf(item);
    for (var k = 1; k <= queue.length; k++) {
      var cand = queue[(i + k) % queue.length];
      if (!cand._res || !cand._res.beat) { startItem(cand); return; }
    }
    stopTimers(); phase = "list"; paint();
    ctx.toast("Queue clear — every buzz beaten 🎉");
  }

  page = ctx.registerPage({
    id: "buzz", navLabel: "Beat Your Buzz", title: "BEAT YOUR BUZZ",
    onShow: function (el, info) {
      body = el;
      if (info && info.back && queue) { paint(); return; }
      phase = "list"; queue = null; paint(); boot();
    },
    onHide: function () { stopTimers(); },
  });

  if (ctx.onBack) ctx.onBack(function () {
    if (!active() || phase === "list") return false;
    stopTimers(); phase = "list"; paint();
    return true;
  });

  ctx._cleanup = function () {
    stopTimers();
    document.removeEventListener("keydown", keyHandler, true);
  };

  ctx.toast("Beat Your Buzz enabled");
}
