/**
 * OfflineQuiz plugin: Beat Your Buzz
 *
 * Celerity training against your own history. Every neg and every late (non-
 * power) conversion from real practice becomes a rematch: the question is re-
 * read at your speed with a flag planted where you buzzed before, and the goal
 * is simple — buzz earlier, and be right. Nothing here touches real stats.
 */
QB.registerPlugin({
  id: "buzz-trainer",
  name: "Beat Your Buzz",
  version: "1.2.0",
  author: "OfflineQuiz",
  description: "Replays your negs and late buzzes with a flag at your old buzz point — beat it with the right answer and watch your celerity climb.",
  onEnable: __qbMain,
  onDisable: function (ctx) { if (ctx._cleanup) ctx._cleanup(); },
});
