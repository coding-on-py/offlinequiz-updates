/**
 * OfflineQuiz plugin: First Lines
 *
 * A drill for the lead-in. Each tossup shows only its first sentence: name it there for 3
 * points, or take another line for 2, then 1. It keeps your first-line rate by category.
 */
QB.registerPlugin({
  id: "first-lines",
  name: "First Lines",
  version: "2.1.1",
  author: "OfflineQuiz",
  description: "Answer tossups from their first lines, to learn the hard clues that win powers.",
  onEnable: __qbMain,
  onDisable: function (ctx) { if (ctx._cleanup) ctx._cleanup(); },
});
