/**
 * OfflineQuiz plugin: Fast Calculations
 *
 * Endless quick math problems like the computation tossups ask for: 41 × 49, the slope between two points,
 * the third angle of a triangle, the number that makes an average come out. Timed rounds or untimed practice,
 * three difficulties, and the shortcut for each one.
 */
QB.registerPlugin({
  id: "fast-calculations",
  name: "Fast Calculations",
  version: "1.1.0",
  author: "OfflineQuiz",
  description: "Quick pencil-and-paper math, made fresh every time: products, slopes, angles, averages and more.",
  onEnable: __qbMain,
  onDisable: function (ctx) { if (ctx._cleanup) ctx._cleanup(); },
});
