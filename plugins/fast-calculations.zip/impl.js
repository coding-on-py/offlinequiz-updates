function __qbMain(ctx) {
  // ── the kit the 15.62 plugins share (text, icons, questions, judging, history) ──
  function esc(s) { return (s == null ? "" : String(s)).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
  var IC = {
    play: '<path d="M7 4l13 8-13 8z"/>',
    pause: '<path d="M8 5v14M16 5v14"/>',
    left: '<path d="M15 6l-6 6 6 6"/>',
    right: '<path d="M9 6l6 6-6 6"/>',
    next: '<path d="M6 5l9 7-9 7zM18 5v14"/>',
    refresh: '<path d="M20 11a8 8 0 10-2.3 5.7M20 4v7h-7"/>',
    x: '<path d="M6 6l12 12M18 6L6 18"/>',
    check: '<path d="M5 12l5 5 9-10"/>',
    mic: '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
    volume: '<path d="M4 9v6h4l5 4V5L8 9z"/><path d="M16 9a4 4 0 0 1 0 6M19 6a8 8 0 0 1 0 12"/>',
    copy: '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h3"/>',
    edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="M13.5 6.5l4 4"/>',
    bolt: '<path d="M13 3L5 14h6l-1 7 8-11h-6z"/>',
    flag: '<path d="M5 21V4M5 4h11l-2 4 2 4H5"/>',
    users: '<circle cx="9" cy="8" r="3"/><path d="M3 20a6 6 0 0 1 12 0M16 4a3 3 0 0 1 0 6M21 20a6 6 0 0 0-4-5.6"/>',
    target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
    down: '<path d="M6 9l6 6 6-6"/>',
    up: '<path d="M6 15l6-6 6 6"/>',
    quote: '<path d="M7 7h4v4c0 3-1.5 5-4 6M15 7h4v4c0 3-1.5 5-4 6"/>',
    grid: '<rect x="3" y="3" width="8" height="10" rx="2"/><rect x="13" y="3" width="8" height="6" rx="2"/><rect x="13" y="11" width="8" height="10" rx="2"/><rect x="3" y="15" width="8" height="6" rx="2"/>',
    ear: '<path d="M7 9a5 5 0 0 1 10 0c0 3-3 4-3 7a3 3 0 0 1-6 0"/><path d="M10 9a2 2 0 0 1 4 0"/>',
  };
  function ic(name, size) {
    var s = size || 16;
    return '<svg width="' + s + '" height="' + s + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (IC[name] || "") + "</svg>";
  }
  function loading(label) { return '<div class="pk-loading">' + (ctx.loadingBarHtml ? ctx.loadingBarHtml(label) : esc(label)) + "</div>"; }
  function norm(s) { return String(s || "").toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[^a-z0-9]+/g, " ").trim(); }
  function pct(a, n) { return n ? Math.round(100 * a / n) : 0; }
  function fmt(n) { return Number(n || 0).toLocaleString(); }
  function plural(n, one, many) { return fmt(n) + " " + (n === 1 ? one : (many || one + "s")); }
  function shuffle(a) { for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)), t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
  function inField(e) { var t = e && e.target; return !!t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT" || t.isContentEditable); }
  function dayKey(t) { var d = new Date(t || Date.now()); return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0"); }
  var DAY = 86400000;

  // the practice setup (Setup panel): its filters and reading settings
  function cfg() { try { return (ctx.host && ctx.host.getPracticeConfig && ctx.host.getPracticeConfig()) || {}; } catch (e) { return {}; } }
  // filters → query parameters, the ones the app sends for a random question
  function filtersQuery(f, extra) {
    f = f || {}; var p = [];
    var add = function (k, v) { p.push(k + "=" + encodeURIComponent(v)); };
    if (f.categories && f.categories.length) add("categories", f.categories.join(","));
    if (f.categoryIds && f.categoryIds.length) add("categoryIds", f.categoryIds.join(","));
    if (f.difficulties && f.difficulties.length) add("difficulties", f.difficulties.join(","));
    if (f.setNames && f.setNames.length) add("setNames", f.setNames.join(","));
    if (f.packetNumbers && f.packetNumbers.length) add("packetNumbers", f.packetNumbers.join(","));
    if (f.yearMin != null) add("yearMin", f.yearMin);
    if (f.yearMax != null) add("yearMax", f.yearMax);
    if (f.powermarkOnly) add("powermarkOnly", "true");
    if (f.canon && f.canon.length) add("canon", f.canon.join(","));
    add("cleanOnly", "1");
    Object.keys(extra || {}).forEach(function (k) { if (extra[k] != null && extra[k] !== false) add(k, extra[k]); });
    return p.join("&");
  }
  // the practice filters without a set (a drill draws from everything the player picked)
  function practiceFilters() { var f = Object.assign({}, cfg().filters || {}); delete f.setNames; delete f.packetNumbers; delete f.setIds; return f; }
  async function getTossups(n, f, extra) {
    try { var d = await ctx.api.get("/api/tossups/query?" + filtersQuery(f || practiceFilters(), Object.assign({ random: 1, limit: n }, extra || {}))); return (d && d.rows) || []; } catch (e) { return []; }
  }
  async function getBonuses(n, f, extra) {
    try { var d = await ctx.api.get("/api/bonuses/query?" + filtersQuery(f || practiceFilters(), Object.assign({ random: 1, limit: n }, extra || {}))); return (d && d.rows) || []; } catch (e) { return []; }
  }
  async function getTossup(id) { try { return (await ctx.api.get("/api/tossups/" + encodeURIComponent(id))).tossup || null; } catch (e) { return null; } }
  async function getBonus(id) { try { return (await ctx.api.get("/api/bonuses/" + encodeURIComponent(id))).bonus || null; } catch (e) { return null; } }
  async function searchTossups(query, limit, f) {
    try { var d = await ctx.api.get("/api/tossups/search?query=" + encodeURIComponent(query) + "&limit=" + (limit || 20) + (f ? "&" + filtersQuery(f) : "")); return { rows: (d && d.rows) || [], total: (d && d.total) || 0 }; } catch (e) { return { rows: [], total: 0 }; }
  }
  // tossups whose answer line names an answer
  async function tossupsOn(answer, limit) { return (await searchTossups('answer_sanitized : ("' + String(answer).replace(/"/g, "") + '")', limit || 20)).rows; }

  // ── the voice plugins' files (15.69: Kokoro Voice, Voice Answers) ──
  // Worker code: a plugin's worker source starts with "(" + voiceFilesWorker + ")(cfg);". fetch() in that worker then
  // serves the model, voice and code files from IndexedDB once they've been fetched, so they load in a moment and work
  // offline. The first time, each comes from our server (onlinequiz.net/voice/, a copy of Hugging Face's and
  // jsDelivr's files by the same paths: server.js, scripts/publish-voice.mjs) or else its own host, in 4 MB ranges six at a time, each range kept as
  // it arrives: one long download over a slow line kept breaking off and starting again, so Kokoro never got ready.
  // cfg: { mirror: our copy's address (the website's own /voice/; the app's www.onlinequiz.net/voice/), db: the IndexedDB name (1.x/2.x kept whole files there by their address, and those are used), sizes: { url:
  // bytes } }. self.voiceFiles: plan(urls) totals what's still to fetch (progress goes to the page as { t: "progress",
  // loaded, total }), file(url), has(url) (kept already), blobUrl(url, type), importCode(url, fallback), route(fn) (fn(url)
  // → a Response promise for a file it makes itself, or null).
  // where our copy is: the website's own, else the live site's
  function voiceMirror() { return (window.QB_WEB && /^https?:/.test(location.origin) ? location.origin : "https://www.onlinequiz.net") + "/voice/"; }
  function voiceFilesWorker(cfg) {
    var MIRROR = cfg.mirror || "https://www.onlinequiz.net/voice/", HOSTS = [["https://huggingface.co/", "hf/"], ["https://cdn.jsdelivr.net/npm/", "npm/"]];
    var CHUNK = 4 << 20, LANES = 6, real = self.fetch.bind(self), sizes = cfg.sizes || {}, got = 0, want = 0, inflight = {};
    var dbp = null;
    function db() {
      return dbp || (dbp = new Promise(function (res, rej) { var r = indexedDB.open(cfg.db, 1); r.onupgradeneeded = function () { r.result.createObjectStore("files"); }; r.onsuccess = function () { res(r.result); }; r.onerror = function () { rej(r.error); }; }));
    }
    function get(k) { return db().then(function (d) { return new Promise(function (res) { try { var g = d.transaction("files").objectStore("files").get(k); g.onsuccess = function () { res(g.result); }; g.onerror = function () { res(undefined); }; } catch (e) { res(undefined); } }); }); }
    function put(k, v) { return db().then(function (d) { return new Promise(function (res) { try { var tx = d.transaction("files", "readwrite"); tx.objectStore("files").put(v, k); tx.oncomplete = function () { res(true); }; tx.onerror = tx.onabort = function () { res(false); }; } catch (e) { res(false); } }); }); }
    function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
    function mirrorOf(url) { for (var i = 0; i < HOSTS.length; i++) if (url.indexOf(HOSTS[i][0]) === 0) return MIRROR + HOSTS[i][1] + url.slice(HOSTS[i][0].length); return null; }
    function report() { if (want) postMessage({ t: "progress", loaded: Math.min(got, want), total: want }); }
    // kept: a small file whole, a big one as its ranges
    async function kept(url) {
      var whole = await get(url); if (whole) return whole;
      var meta = await get(url + "#meta"); if (!meta || !meta.done) return null;
      var all = new Uint8Array(meta.total), o = 0;
      for (var i = 0; i < meta.n; i++) { var p = await get(url + "#" + i); if (!p) return null; all.set(new Uint8Array(p), o); o += p.byteLength; }
      return all.buffer;
    }
    async function sizeAt(src) {
      var r = await real(src, { headers: { Range: "bytes=0-0" } });
      var m = /\/(\d+)\s*$/.exec(r.headers.get("Content-Range") || ""), n = m ? +m[1] : r.status === 200 ? +(r.headers.get("Content-Length") || 0) : 0;
      try { if (r.body) await r.body.cancel(); } catch (e) {}
      if (!n) throw new Error("HTTP " + r.status);
      return n;
    }
    async function pull(src, url, total) {
      // in one piece: a small file, and jsDelivr's (served compressed, so its ranges aren't the file's)
      if (total <= 2 * CHUNK || /^https:\/\/cdn\.jsdelivr\.net\//.test(src)) {
        var r = await real(src); if (!r.ok) throw new Error("HTTP " + r.status);
        var b = await r.arrayBuffer(); if (sizes[url] && b.byteLength !== sizes[url]) throw new Error("cut short");
        got += b.byteLength; report(); await put(url, b); return b;
      }
      var n = Math.ceil(total / CHUNK), parts = new Array(n), meta = await get(url + "#meta");
      if (meta && meta.total === total) { for (var i = 0; i < n; i++) { var p = await get(url + "#" + i); if (p && p.byteLength === Math.min(total, (i + 1) * CHUNK) - i * CHUNK) { parts[i] = p; got += p.byteLength; } } }
      else await put(url + "#meta", { total: total, n: n, done: false });
      report();
      var next = 0;
      async function lane() {
        for (;;) {
          var k = -1; while (next < n) { if (!parts[next]) { k = next++; break; } next++; }
          if (k < 0) return;
          var a = k * CHUNK, z = Math.min(total, a + CHUNK) - 1;
          for (var t = 0; ; t++) {
            try {
              var rr = await real(src, { headers: { Range: "bytes=" + a + "-" + z } });
              if (rr.status !== 206) throw new Error("HTTP " + rr.status);
              var buf = await rr.arrayBuffer(); if (buf.byteLength !== z - a + 1) throw new Error("cut short");
              await put(url + "#" + k, buf); parts[k] = buf; got += buf.byteLength; report(); break;
            } catch (e) { if (t >= 6) throw e; await sleep(700 * (t + 1)); }
          }
        }
      }
      var lanes = []; for (var j = 0; j < Math.min(LANES, n); j++) lanes.push(lane());
      await Promise.all(lanes);
      await put(url + "#meta", { total: total, n: n, done: true });
      var all = new Uint8Array(total), o = 0; for (var q = 0; q < n; q++) { all.set(new Uint8Array(parts[q]), o); o += parts[q].byteLength; }
      return all.buffer;
    }
    function file(url) {
      if (inflight[url]) return inflight[url];
      return (inflight[url] = (async function () {
        var k = await kept(url); if (k) return k;
        var srcs = [mirrorOf(url), url].filter(Boolean), last = null;
        for (var i = 0; i < srcs.length; i++) {
          try { var total = sizes[url] || (/^https:\/\/cdn\.jsdelivr\.net\//.test(srcs[i]) ? 1 : await sizeAt(srcs[i])); return await pull(srcs[i], url, total); }
          catch (e) { last = e; }
        }
        throw last || new Error("unreachable");
      })().finally(function () { delete inflight[url]; }));
    }
    // what loading still needs, so the progress is of the whole download
    async function plan(urls) {
      for (var i = 0; i < urls.length; i++) if (!(await has(urls[i]))) want += sizes[urls[i]] || 0;
      report();
    }
    async function has(url) {
      var n = await db().then(function (d) { return new Promise(function (res) { try { var c = d.transaction("files").objectStore("files").count(url); c.onsuccess = function () { res(c.result); }; c.onerror = function () { res(0); }; } catch (e) { res(0); } }); });
      if (n) return true;
      var meta = await get(url + "#meta"); return !!(meta && meta.done);
    }
    var routes = [];
    async function blobUrl(url, type) { return URL.createObjectURL(new Blob([await file(url)], { type: type || "application/octet-stream" })); }
    async function importCode(url, fallback) {
      try { return await import(await blobUrl(url, "text/javascript")); }
      catch (e) { if (fallback) return import(fallback); throw e; }
    }
    // a jsDelivr "+esm" module with the modules it imports ("/npm/…/+esm"), each kept, their imports pointed at the kept
    // copies (Voice Answers' transformers.js: it, onnxruntime-web and onnxruntime-common)
    var esm = {};
    function esmUrl(url) {
      return esm[url] || (esm[url] = (async function () {
        var text = new TextDecoder().decode(await file(url)), deps = {}, re = /(?:from|import)\s*\(?\s*"(\/npm\/[^"]+)"/g, m;
        while ((m = re.exec(text))) deps[m[1]] = 1;
        for (var d in deps) text = text.split('"' + d + '"').join('"' + await esmUrl("https://cdn.jsdelivr.net" + d) + '"');
        return URL.createObjectURL(new Blob([text], { type: "text/javascript" }));
      })());
    }
    async function importEsm(url) {
      try { return await import(await esmUrl(url)); }
      catch (e) { return import(url); }   // (online: as jsDelivr serves it)
    }
    // the libraries' own fetches (models, voices) come here; a browser cache they'd keep copies in is one that keeps nothing
    self.fetch = function (input, init) {
      var url = typeof input === "string" ? input : input && input.href ? input.href : input && input.url;
      for (var i = 0; url && i < routes.length; i++) { var made = routes[i](url); if (made) return made; }
      if (url && /^https:\/\/(huggingface\.co\/[^?#]+\/resolve\/|cdn\.jsdelivr\.net\/npm\/)/.test(url)) {
        return file(url).then(function (b) { return new Response(b, { status: 200, headers: { "content-length": String(b.byteLength) } }); });
      }
      return real(input, init);
    };
    var none = { match: async function () {}, put: async function () {}, delete: async function () { return false; }, keys: async function () { return []; } };
    try { Object.defineProperty(self, "caches", { configurable: true, value: { open: async function () { return none; }, has: async function () { return false; }, delete: async function () { return false; }, keys: async function () { return []; }, match: async function () {} } }); } catch (e) {}
    self.voiceFiles = { plan: plan, file: file, has: has, blobUrl: blobUrl, importCode: importCode, importEsm: importEsm, route: function (fn) { routes.push(fn); } };
  }

  // a record's text as practice reads it (notes and pronunciation guides per the player's settings)
  function readText(q) {
    try { if (ctx.host && ctx.host.questionText) { var t = ctx.host.questionText(q, "question"); if (t != null) return String(t).replace(/\(\*\)/g, "").replace(/\s{2,}/g, " ").trim(); } } catch (e) {}
    return String((q && q.question_sanitized) || "").replace(/\(\*\)/g, "").trim();
  }
  function powerAt(q) { return String((q && q.question_sanitized) || "").indexOf("(*)"); }
  // sentences, without breaking at "St." or an initial ("J. R. R. Tolkien")
  var ABBR = /(?:\b(?:St|Ste|Mt|Mts|Dr|Mr|Mrs|Ms|Mme|Prof|Sr|Jr|Rev|Fr|Gen|Col|Capt|Lt|Sgt|Maj|Adm|Hon|Pres|Gov|Sen|Rep|vs|etc|cf|ca|al|Inc|Co|Corp|Ltd|Bros|approx|No|Nos|Op|op|no|Vol|vol|Ch|ch|Fig|fig|Ft|Pt|pt|Ave|[A-Za-z])\.["”’']?)$/;
  function sentences(text) {
    var parts = String(text || "").split(/(?<=[.?!]["”’)]*)\s+(?=["“(]?[A-Z0-9])/), out = [], cur = "";
    for (var i = 0; i < parts.length; i++) {
      cur = cur ? cur + " " + parts[i] : parts[i];
      if (i < parts.length - 1 && ABBR.test(cur.trim())) continue;
      out.push(cur.trim()); cur = "";
    }
    if (cur.trim()) out.push(cur.trim());
    return out.filter(Boolean);
  }
  // where each sentence of a text ends (indexes into it)
  function sentenceEnds(text) {
    var at = 0, out = []; text = String(text || "");
    sentences(text).forEach(function (x) { var i = text.indexOf(x, at); if (i < 0) return; at = i + x.length; out.push(at); });
    return out;
  }
  // ── categories (15.63): the app's own picker, its picks kept under `key` ([] = every category) ──
  // mountCats(root, key, onChange) puts it in root's [data-cats] (made once, moved into each new render);
  // inCats(pk, e): a history entry or question in the picks; with no picks, all are
  var PICKERS = {};
  // opts.label: "" for just the picks, in a row that has its own label
  function catPicker(key, onChange, opts) {
    if (PICKERS[key]) return PICKERS[key];
    if (!ctx.host || !ctx.host.categoryPicker) return null;
    var o = { selected: ctx.storage.get(key) || [], onChange: function (ids) { ctx.storage.set(key, ids); if (onChange) onChange(ids); } };
    if (opts && opts.label != null) o.label = opts.label;
    var pk = ctx.host.categoryPicker(null, o);
    PICKERS[key] = pk;
    // the picks match nothing until the tree is in: draw again once it is
    if (pk.ready && (ctx.storage.get(key) || []).length) pk.ready.then(function () { if (onChange) onChange(pk.get()); });
    return pk;
  }
  function mountCats(root, key, onChange, opts) {
    var pk = catPicker(key, onChange, opts), host = root && root.querySelector("[data-cats]");
    if (pk && host) host.appendChild(pk.el);
    return pk;
  }
  function inCats(pk, e) {
    if (!pk || !pk.get().length) return true;
    return pk.matches(String((e && (e.category_path || e.path || e.category || e.root)) || ""));
  }
  // ── the app's reader on a page titled for the plugin (15.63: ctx.host.playPractice). Its Setup picks the categories ──
  function canRead() { return !!(ctx.host && ctx.host.playPractice); }
  function onReader() { return !!(ctx.host && ctx.host.onPracticePage && ctx.host.onPracticePage()); }
  // a plugin's start page: an icon, what it is, a Start button (data-pk="start"), a note under it
  function heroHtml(icon, title, text, start, note) {
    return '<div class="pk-hero"><span class="pk-hero-ico">' + ic(icon, 26) + "</span><h2>" + esc(title) + "</h2><p>" + esc(text) + "</p>" +
      '<div class="pk-actions pk-center"><button type="button" class="btn btn-primary" data-pk="start">' + ic("play", 14) + esc(start || "Start") + "</button></div>" +
      (note ? '<div class="pk-muted pk-small">' + note + "</div>" : "") + "</div>";
  }
  // the answer line, with its bold and underlining (nothing else of the HTML)
  function answerHtml(q) {
    var h = String((q && q.answer) || "");
    if (!/<\/?(b|u|strong|em|i)\b/i.test(h)) return esc((q && q.answer_sanitized) || h);
    return h.replace(/<(\/?)(b|u|strong|em|i)\b[^>]*>/gi, "\u0001$1$2\u0002").replace(/<[^>]*>/g, "").replace(/&(?!(?:amp|lt|gt|quot|#\d+);)/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/\u0001(\/?)(\w+)\u0002/g, "<$1$2>");
  }
  function primary(q) {
    var a = "";
    try { if (ctx.host && ctx.host.extractPrimaryAnswer) a = ctx.host.extractPrimaryAnswer((q && q.answer) || "", (q && q.answer_sanitized) || ""); } catch (e) {}
    return a || String((q && q.answer_sanitized) || "").replace(/\s*[\[(].*$/, "").trim();
  }
  // an answer as a person reads it in a list: the line up to its first bracket ("Mary, Queen of Scots"), where primary()
  // runs the bold parts together for matching ("Mary, Queen of Scots Mary Stuart")
  function answerName(q) { return String((q && q.answer_sanitized) || "").replace(/\s*[\[(].*$/, "").trim() || primary(q); }
  // judged right here, like practice (judge.js); { status: "accept" | "prompt" | "reject", prompt }. opts.asAnswer: as the
  // answer box would judge the question on screen now (the player's strictness, the buzz, a prompt's answer; 15.92)
  async function judge(q, answer, opts) {
    opts = opts || {};
    try {
      if (ctx.host && ctx.host.judgeTossup) return (await ctx.host.judgeTossup(q, answer, { strictness: opts.strictness != null ? opts.strictness : (cfg().strictness || 10), buzzPosition: opts.buzzPosition, previous: opts.previous || null, asAnswer: !!opts.asAnswer })) || { status: "reject" };
      return (await ctx.api.post("/api/evaluate-tossup", { questionId: q.id, answer: answer, strictness: cfg().strictness || 10, buzzPosition: opts.buzzPosition, previous: opts.previous || null })) || { status: "reject" };
    } catch (e) { return { status: "reject" }; }
  }
  async function judgePart(b, part, answer, opts) {
    opts = opts || {};
    try {
      if (ctx.host && ctx.host.judgeBonusPart) return (await ctx.host.judgeBonusPart(b, part, answer, { strictness: cfg().strictness || 10, previous: opts.previous || null, asAnswer: !!opts.asAnswer })) || { status: "reject" };
      return (await ctx.api.post("/api/evaluate-bonus-part", { questionId: b.id, part: part, answer: answer, strictness: cfg().strictness || 10 })) || { status: "reject" };
    } catch (e) { return { status: "reject" }; }
  }
  async function judgeLine(line, sani, answer, opts) {
    opts = opts || {};
    try {
      if (ctx.host && ctx.host.judgeAnswerLine) return (await ctx.host.judgeAnswerLine(line, sani, answer, { strictness: cfg().strictness || 10, previous: opts.previous || null })) || { status: "reject" };
      return (await ctx.api.post("/api/evaluate-answer", { answerline: line, answer: answer, strictness: cfg().strictness || 10 })) || { status: "reject" };
    } catch (e) { return { status: "reject" }; }
  }
  function bonusParts(b) { try { return JSON.parse((b && (b.parts_sanitized || b.parts)) || "[]"); } catch (e) { return []; } }
  function bonusAnswers(b) { try { return JSON.parse((b && b.answers) || "[]"); } catch (e) { return []; } }
  function bonusAnswersSani(b) { try { return JSON.parse((b && b.answers_sanitized) || "[]"); } catch (e) { return []; } }

  // the player's answers (Stats' history), only the fields asked for
  async function history(fields) {
    try { return ((await ctx.api.get("/api/sessions/all-entries?" + (/\banswer\b/.test(fields || "") ? "answers=1&" : "") + "fields=" + encodeURIComponent(fields || ""))).entries) || []; } catch (e) { return []; }
  }
  // record a tossup answered on a plugin's page into the player's stats (the path Coach Mode uses)
  function record(q, r) {
    try {
      ctx.api.post("/api/check-tossup", { questionId: q.id, answer: r.answer || "", buzzPosition: r.buzzPosition || 0, sessionId: r.session, overriding: true,
        correct: !!r.correct, isPower: !!r.power, points: r.points || 0, celerity: r.celerity != null ? r.celerity : 1 }).catch(function () {});
    } catch (e) {}
  }

  var ROOT_COLOR = { "Literature": "#bc8cff", "Science": "#58a6ff", "Math": "#a5e05b", "Pop Culture": "#ff7b72", "Sports": "#ff6f91", "Fine Arts": "#f778ba", "History": "#e3b341", "Geography": "#56d364", "Mythology": "#ffa657", "Social Science": "#3dd6a3", "Philosophy": "#39c5cf", "Theology": "#8e9bff", "Current Events": "#c9d16b", "Miscellaneous": "#8b949e" };
  // NAQT's high school distribution, per 24 tossups / bonuses (naqt.com/hs/distribution.jsp)
  var NAQT = [["Literature", 3.9, 3.8], ["Science", 4.5, 4.3], ["Math", 1.0, 1.0], ["Fine Arts", 2.0, 2.0], ["History", 4.6, 4.5], ["Geography", 1.9, 1.9], ["Mythology", 0.6, 0.7],
    ["Pop Culture", 1.0, 0.9], ["Sports", 0.7, 0.7], ["Social Science", 0.6, 0.6], ["Philosophy", 0.3, 0.3], ["Theology", 0.4, 0.4], ["Current Events", 1.5, 1.4], ["Miscellaneous", 1.0, 1.5]];
  function rootOf(e) { return String((e && (e.category_path || e.category)) || "").split(" > ")[0] || "Miscellaneous"; }
  function dot(root) { return '<span class="pk-dot" style="--c:' + (ROOT_COLOR[root] || "#8b949e") + '"></span>'; }
  var _roots = null;
  async function roots() {
    if (_roots) return _roots;
    try { var t = ctx.host && ctx.host.getCategoryTree ? await ctx.host.getCategoryTree("tossups") : (await ctx.api.get("/api/category-tree?type=tossups")).tree; _roots = (t || []).map(function (n) { return { id: n.id, name: n.name, count: n.count }; }); }
    catch (e) { _roots = []; }
    return _roots;
  }
  var DIFF_NAME = { 1: "Middle school", 2: "Easy high school", 3: "Regular high school", 4: "Hard high school", 5: "National high school", 6: "Easy college", 7: "Medium college", 8: "Regionals college", 9: "Nationals college", 10: "Open" };

  function tile(value, label, cls) { return '<div class="pk-tile' + (cls ? " " + cls : "") + '"><b class="num">' + value + "</b><span>" + esc(label) + "</span></div>"; }
  function segHtml(name, items, on) {
    return '<div class="seg pk-seg" role="group">' + items.map(function (it) {
      return '<button type="button" data-' + name + '="' + esc(it[0]) + '" aria-pressed="' + (String(on) === String(it[0])) + '">' + esc(it[1]) + "</button>";
    }).join("") + "</div>";
  }
  function emptyHtml(text) { return '<div class="db-empty pk-empty">' + esc(text) + "</div>"; }
  // square toggles 1 to 10 (no 0, unrated: 15.134), Setup's difficulty look (the app's .diff-toggles), `on` the ones picked; diffsIn reads them
  function diffHtml(name, on) {
    var h = '<div class="diff-toggles pk-diffs" role="group" aria-label="Difficulty">';
    for (var d = 1; d <= 10; d++) h += '<label title="' + esc(DIFF_NAME[d]) + '"><input type="checkbox" data-' + name + '="' + d + '"' + ((on || []).indexOf(d) >= 0 ? " checked" : "") + "><span>" + d + "</span></label>";
    return h + "</div>";
  }
  function diffsIn(root, name) { return [].slice.call(root.querySelectorAll("[data-" + name + "]")).filter(function (i) { return i.checked; }).map(function (i) { return Number(i.getAttribute("data-" + name)); }); }
  // a list of difficulties in a few words: [2, 3, 4, 5] → "2 to 5"
  function diffWords(ds) {
    ds = (ds || []).map(Number).filter(function (d) { return d >= 1 && d <= 10; }).sort(function (a, b) { return a - b; });
    if (!ds.length) return "any difficulty";
    var run = ds.every(function (d, i) { return !i || d === ds[i - 1] + 1; });
    return ds.length === 1 ? "difficulty " + ds[0] : run ? "difficulty " + ds[0] + " to " + ds[ds.length - 1] : "difficulty " + ds.join(", ");
  }
  function playList(kind, ids, title) {
    if (!ids || !ids.length) return false;
    try { return !!(ctx.host && ctx.host.launchQuestions && ctx.host.launchQuestions(kind, ids, { title: title })); } catch (e) { return false; }
  }

  // a reader: shows `text` a character at a time at the practice reading speed. start(), pause(), go(), stop();
  // at() is how far it is; onEnd once it's all shown
  function Reader(el, text, opts) {
    opts = opts || {};
    var ms = opts.ms != null ? opts.ms : (Number(cfg().revealSpeed) || 25), idx = 0, raf = 0, last = 0, on = false;
    var paint = function () { el.innerHTML = '<span class="pk-read">' + esc(text.slice(0, idx)) + '</span><span class="pk-unread" aria-hidden="true">' + esc(text.slice(idx)) + "</span>"; };
    var step = function (t) {
      raf = 0; if (!on) return;
      if (!last) last = t;
      var n = ms > 0 ? Math.floor((t - last) / ms) : text.length;
      if (n > 0) { idx = Math.min(text.length, idx + n); last += n * ms; paint(); if (opts.onTick) opts.onTick(idx); }
      if (idx >= text.length) { on = false; if (opts.onEnd) opts.onEnd(); return; }
      raf = requestAnimationFrame(step);
    };
    paint();
    return {
      start: function () { if (on) return; on = true; last = 0; raf = requestAnimationFrame(step); },
      pause: function () { on = false; if (raf) cancelAnimationFrame(raf); raf = 0; },
      stop: function () { on = false; if (raf) cancelAnimationFrame(raf); raf = 0; },
      showAll: function () { this.stop(); idx = text.length; el.textContent = text; },
      at: function () { return idx; },
      running: function () { return on; },
    };
  }
  // a reader's position in the displayed text → the record's question_sanitized (what judging and stats count)
  function serverPos(q, display, pos) {
    try { if (ctx.host && ctx.host.mapDisplayPos) return ctx.host.mapDisplayPos(display, (q && q.question_sanitized) || "", pos); } catch (e) {}
    return pos;
  }

  // ── Fast Calculations: quick pencil-and-paper math, an endless supply ──
  // (15.148) The kind of computation a math tossup asks for in thirty seconds: 41 × 49, the slope between two points,
  // the third angle of a triangle, the number that makes an average come out. Every problem is made on the spot with a
  // clean answer and the shortcut that gets there. A timed round (60 s, 2 min, 5 min) or untimed practice; three
  // difficulties; pick the topics. Answers: whole numbers, fractions (3/4), decimals, multiples of π (16pi) and points (2, 5).
  var body = null, page = null;
  var TOPICS = [["arith", "Arithmetic"], ["frac", "Fractions and percents"], ["geo", "Geometry"], ["alg", "Algebra and lines"], ["stats", "Averages"], ["num", "Number theory"], ["count", "Counting and probability"]];
  var MODES = [["free", "Practice"], ["60", "60 s"], ["120", "2 min"], ["300", "5 min"]];
  var DIFFS = [[1, "Easy"], [2, "Medium"], [3, "Hard"]];
  var st = Object.assign({ mode: "60", diff: 2, topics: TOPICS.map(function (t) { return t[0]; }), best: {}, bestStreak: 0, solved: 0, tries: 0, by: {}, rounds: 0 }, ctx.storage.get("fastcalc") || {});
  var saveT = 0;
  function save() { clearTimeout(saveT); saveT = setTimeout(function () { ctx.storage.set("fastcalc", st); }, 400); }

  // ── numbers: whole, fractions, π, points ──
  function gcd(a, b) { a = Math.abs(a); b = Math.abs(b); while (b) { var t = a % b; a = b; b = t; } return a; }
  function lcm(a, b) { return a / gcd(a, b) * b; }
  function R(n, d) { d = d == null ? 1 : d; if (d < 0) { n = -n; d = -d; } var g = gcd(n, d) || 1; return { n: n / g, d: d / g }; }
  function rStr(r) { return (r.n < 0 ? "−" : "") + Math.abs(r.n) + (r.d === 1 ? "" : "/" + r.d); }
  // a fraction's value as a decimal ("9.6"), for an answer that reads better that way
  function dStr(r) { var v = Math.round(r.n / r.d * 10000) / 10000; return (v < 0 ? "−" : "") + String(Math.abs(v)); }
  function rEq(a, b) { return a.n === b.n && a.d === b.d; }
  var NUM = function (r) { return { t: "n", v: r }; }, DEC = function (r) { return { t: "n", v: r, dec: true }; }, PI = function (r) { return { t: "pi", v: r }; }, PT = function (a, b) { return { t: "pt", v: [a, b] }; };
  function show(a) { return a.t === "pi" ? (a.v.n === 1 && a.v.d === 1 ? "π" : a.v.d === 1 ? a.v.n + "π" : a.v.n + "π/" + a.v.d) : a.t === "pt" ? "(" + rStr(a.v[0]) + ", " + rStr(a.v[1]) + ")" : (a.dec && a.v.d !== 1 ? dStr(a.v) : rStr(a.v).replace(/^(−?)(\d+)$/, function (m, sg, x) { return sg + (+x >= 10000 ? Number(x).toLocaleString("en-US") : x); })); }
  // what was typed, as a number: "2,009", "-3/4", "2 1/2", "0.75" (a decimal is kept as one, to compare closely)
  function readNum(s) {
    s = String(s).trim().replace(/\s+/g, " ");
    var m;
    if (/^-?\d{1,3}(,\d{3})+$/.test(s)) s = s.replace(/,/g, "");
    if ((m = s.match(/^(-?\d+)$/))) return { r: R(+m[1]) };
    if ((m = s.match(/^(-?\d+)\s*\/\s*(-?\d+)$/)) && +m[2] !== 0) return { r: R(+m[1], +m[2]) };
    if ((m = s.match(/^(-?)(\d+) (\d+)\/(\d+)$/)) && +m[4] !== 0) { var w = +m[2], fr = R(+m[3], +m[4]); return { r: R((m[1] ? -1 : 1) * (w * fr.d + fr.n), fr.d) }; }
    if ((m = s.match(/^-?(\d+\.?\d*|\.\d+)$/))) return { x: parseFloat(s) };
    return null;
  }
  function numOk(got, want) {
    if (!got) return false;
    if (got.r) return rEq(got.r, want);
    var v = want.n / want.d;
    if (want.d === 1) return Math.abs(got.x - v) < 1e-9;
    return Math.abs(got.x - v) <= Math.max(0.006, Math.abs(v) * 0.002);   // 2/3 as 0.67 or 0.667
  }
  function clean(s) { return String(s || "").toLowerCase().replace(/[−–—]/g, "-").replace(/°|degrees?|\bdeg\b|units?\b|square|sq\.?|cm|inches|feet|ft\b|\bm\b|%|\$/g, "").replace(/\s+/g, " ").trim(); }
  function judge(input, a) {
    var s = clean(input); if (!s) return false;
    if (a.t === "pi") {
      var m = s.replace(/\s*\*\s*/g, "").match(/^(.*?)\s*(?:π|pi)\s*(?:\/\s*(\d+))?$/);
      if (!m) return false;
      var c = m[1].trim() === "" ? { r: R(1) } : m[1].trim() === "-" ? { r: R(-1) } : readNum(m[1]);
      if (!c || !c.r) return false;
      var v = m[2] ? R(c.r.n, c.r.d * +m[2]) : c.r;
      return rEq(v, a.v);
    }
    if (a.t === "pt") {
      var parts = s.replace(/[()]/g, "").split(/\s*,\s*|\s+/).filter(Boolean);
      return parts.length === 2 && numOk(readNum(parts[0]), a.v[0]) && numOk(readNum(parts[1]), a.v[1]);
    }
    return numOk(readNum(s), a.v);
  }

  // ── the problems ──
  function ri(a, b) { return a + Math.floor(Math.random() * (b - a + 1)); }
  function pick(xs) { return xs[Math.floor(Math.random() * xs.length)]; }
  function nz(a, b) { var x = 0; while (!x) x = ri(a, b); return x; }
  function sgn(x) { return x < 0 ? "− " + Math.abs(x) : "+ " + x; }
  function neg(x) { return x < 0 ? "−" + Math.abs(x) : String(x); }
  function pt(x, y) { return "(" + neg(x) + ", " + neg(y) + ")"; }
  function coef(a) { return a === 1 ? "" : a === -1 ? "−" : neg(a); }   // 1x is x, −1x is −x
  function par(x) { return x < 0 ? "(" + neg(x) + ")" : String(x); }
  function an(n) { return /^(8|11|18|8\d)$/.test(String(n)) ? "an " : "a "; }
  var TRIPLES = [[3, 4, 5], [5, 12, 13], [8, 15, 17], [7, 24, 25], [20, 21, 29], [9, 40, 41]];
  var G = {
    arith: [
      function (d) {   // a product: near a square (41 × 49), or plain
        if (d >= 2 && Math.random() < 0.55) { var m = ri(d === 3 ? 31 : 15, d === 3 ? 95 : 60), k = ri(1, d === 3 ? 9 : 5); if (m % 10 && Math.random() < 0.5) m = Math.round(m / 5) * 5; return { q: (m - k) + " × " + (m + k), a: NUM(R((m - k) * (m + k))), how: (m - k) + " × " + (m + k) + " = " + m + "² − " + k + "² = " + m * m + " − " + k * k + " = " + ((m - k) * (m + k)).toLocaleString("en-US") + "." }; }
        var a = d === 1 ? ri(12, 99) : d === 2 ? ri(13, 99) : ri(102, 399), b = d === 1 ? ri(3, 9) : ri(12, 49), t = Math.floor(a / 10) * 10;
        return { q: a + " × " + b, a: NUM(R(a * b)), how: d === 1 ? t + " × " + b + " + " + (a - t) + " × " + b + " = " + t * b + " + " + (a - t) * b + " = " + a * b + "." : a + " × " + b + " = " + a + " × " + (b - b % 10) + " + " + a + " × " + (b % 10) + " = " + (a * b).toLocaleString("en-US") + "." };
      },
      function (d) {   // a square, the 5s by n(n + 1)
        if (Math.random() < 0.35) { var n = ri(d === 1 ? 1 : 3, d === 3 ? 19 : 9), x = n * 10 + 5; return { q: x + "²", a: NUM(R(x * x)), how: "It ends in 5, so " + n + " × " + (n + 1) + " = " + n * (n + 1) + ", then 25, so " + (x * x).toLocaleString("en-US") + "." }; }
        var y = d === 1 ? ri(11, 25) : d === 2 ? ri(26, 99) : ri(101, 140), r = Math.round(y / 10) * 10, e = y - r;
        return { q: y + "²", a: NUM(R(y * y)), how: "(" + r + (e < 0 ? " − " + -e : " + " + e) + ")² = " + r * r + (e < 0 ? " − " : " + ") + Math.abs(2 * r * e) + " + " + e * e + " = " + (y * y).toLocaleString("en-US") + "." };
      },
      function (d) {   // an exact division
        var b = d === 1 ? ri(3, 9) : ri(12, 39), q = d === 3 ? ri(41, 299) : ri(12, 99), n = b * q;
        return { q: n.toLocaleString("en-US") + " ÷ " + b, a: NUM(R(q)), how: b + " × " + q + " = " + n.toLocaleString("en-US") + "." };
      },
      function (d) {   // a power
        var base = pick(d === 1 ? [2, 3, 5, 10] : [2, 3, 4, 5, 6, 7, 11]), e = base === 2 ? ri(d === 1 ? 5 : 8, d === 3 ? 16 : 12) : base === 10 ? ri(3, 6) : ri(3, base <= 5 ? 6 : 4);
        var v = Math.pow(base, e); return { q: base + "^" + e, a: NUM(R(v)), how: base + " multiplied by itself " + e + " times is " + v.toLocaleString("en-US") + "." };
      },
      function (d) {   // order of operations
        var a = ri(2, 12), b = ri(2, 9), c = ri(2, 5), e = ri(2, 9), f = pick([2, 3, 4, 5, 6]), g = f * ri(2, 9);
        if (d === 1) return { q: a + " + " + b + " × " + c, a: NUM(R(a + b * c)), how: "Multiply first. " + b + " × " + c + " = " + b * c + ", then " + a + " + " + b * c + " = " + (a + b * c) + "." };
        return { q: a + " + " + b + " × " + c + "² − " + g + " ÷ " + f, a: NUM(R(a + b * c * c - g / f)), how: c + "² = " + c * c + ", " + b + " × " + c * c + " = " + b * c * c + ", " + g + " ÷ " + f + " = " + g / f + ", so " + a + " + " + b * c * c + " − " + g / f + " = " + (a + b * c * c - g / f) + "." };
      },
    ],
    frac: [
      function (d) {   // add or take away fractions
        var b = ri(2, d === 1 ? 6 : 12), e = ri(2, d === 1 ? 6 : 12), a = ri(1, b - 1), c = ri(1, e - 1), plus = d === 1 || Math.random() < 0.6;
        var v = R(a * e + (plus ? 1 : -1) * c * b, b * e), L = lcm(b, e);
        return { q: a + "/" + b + (plus ? " + " : " − ") + c + "/" + e, a: NUM(v), how: "Over " + L + ", " + a * L / b + "/" + L + (plus ? " + " : " − ") + c * L / e + "/" + L + " = " + rStr(R(a * L / b + (plus ? 1 : -1) * c * L / e, L)) + "." };
      },
      function (d) {   // multiply or divide fractions
        var a = ri(1, 9), b = ri(2, 12), c = ri(1, 9), e = ri(2, 12), div = d >= 2 && Math.random() < 0.5;
        var v = div ? R(a * e, b * c) : R(a * c, b * e);
        return { q: a + "/" + b + (div ? " ÷ " : " × ") + c + "/" + e, a: NUM(v), how: div ? "Flip and multiply, " + a + "/" + b + " × " + e + "/" + c + " = " + rStr(v) + "." : a * c + "/" + b * e + " = " + rStr(v) + "." };
      },
      function (d) {   // a percent of a number
        var p = pick(d === 1 ? [10, 20, 25, 50, 75] : [5, 12, 15, 35, 45, 60, 65, 85, 120, 150]), n = pick(d === 1 ? [40, 60, 80, 120, 200, 360] : [40, 80, 120, 160, 240, 360, 480, 640, 720]);
        if (d === 3) { p = pick([2.5, 7.5, 12.5, 17.5, 37.5, 62.5]); n = pick([80, 160, 240, 320, 480, 640]); }
        var v = p * n / 100; return { q: "What is " + p + "% of " + n + "?", a: DEC(Number.isInteger(v) ? R(v) : R(Math.round(v * 10), 10)), how: p + "% of " + n + " = " + n + " × " + p + "/100 = " + v + "." };
      },
      function (d) {   // a percent change
        var a = pick([20, 40, 50, 60, 80, 120, 150, 200, 250, 400]), p = pick(d === 1 ? [10, 20, 25, 50] : [5, 15, 30, 35, 40, 60, 75]) * (Math.random() < 0.5 ? -1 : 1), b = a + a * p / 100;
        if (!Number.isInteger(b)) { p = 50; b = a * 1.5; }
        return { q: "A price goes from $" + a + " to $" + b + ". By what percent did it " + (p < 0 ? "fall" : "rise") + "?", a: NUM(R(Math.abs(p))), how: "The change is " + Math.abs(b - a) + ", and " + Math.abs(b - a) + "/" + a + " = " + Math.abs(p) + "%." };
      },
      function (d) {   // what percent one number is of another
        var b = pick([20, 25, 40, 50, 80, 125, 200, 250, 400]), p = pick(d === 1 ? [10, 20, 25, 50, 75] : [4, 8, 12, 15, 35, 45, 64, 140]), a = b * p / 100;
        if (!Number.isInteger(a)) { b = 200; a = 2 * p; }
        return { q: a + " is what percent of " + b + "?", a: NUM(R(p)), how: a + "/" + b + " = " + p + "/100, so " + p + "%." };
      },
    ],
    geo: [
      function (d) {   // the third angle of a triangle
        var a = ri(20, 95), b = ri(15, 160 - a);
        if (d === 1) { a = ri(3, 12) * 5; b = ri(3, Math.floor((175 - a) / 5)) * 5; }
        return { q: "Two angles of a triangle are " + a + "° and " + b + "°. What is the third angle, in degrees?", a: NUM(R(180 - a - b)), how: "180 − " + a + " − " + b + " = " + (180 - a - b) + "." };
      },
      function (d) {   // a rectangle: perimeter, area, or a side
        var l = ri(4, d === 1 ? 15 : 40), w = ri(2, l - 1), kind = d === 1 ? ri(0, 1) : ri(0, 3);
        if (kind === 0) return { q: "What is the perimeter of a " + l + " by " + w + " rectangle?", a: NUM(R(2 * (l + w))), how: "2 × (" + l + " + " + w + ") = " + 2 * (l + w) + "." };
        if (kind === 1) return { q: "What is the area of a " + l + " by " + w + " rectangle?", a: NUM(R(l * w)), how: l + " × " + w + " = " + l * w + "." };
        if (kind === 2) return { q: "A rectangle has perimeter " + 2 * (l + w) + " and one side " + l + ". How long is the other side?", a: NUM(R(w)), how: "Half the perimeter is " + (l + w) + ", and " + (l + w) + " − " + l + " = " + w + "." };
        return { q: "A rectangle has area " + l * w + " and one side " + w + ". What is its perimeter?", a: NUM(R(2 * (l + w))), how: "The other side is " + l * w + " ÷ " + w + " = " + l + ", so 2 × (" + l + " + " + w + ") = " + 2 * (l + w) + "." };
      },
      function (d) {   // the Pythagorean theorem
        var t = pick(d === 1 ? TRIPLES.slice(0, 2) : TRIPLES), k = d === 1 ? 1 : ri(1, d === 3 ? 4 : 3), a = t[0] * k, b = t[1] * k, c = t[2] * k;
        if (d >= 2 && Math.random() < 0.5) return { q: "A right triangle has hypotenuse " + c + " and one leg " + a + ". How long is the other leg?", a: NUM(R(b)), how: "√(" + c + "² − " + a + "²) = √" + (c * c - a * a) + " = " + b + " (a " + t.join("-") + " triangle" + (k > 1 ? " times " + k : "") + ")." };
        return { q: "A right triangle has legs " + a + " and " + b + ". How long is its hypotenuse?", a: NUM(R(c)), how: "√(" + a + "² + " + b + "²) = √" + (a * a + b * b) + " = " + c + " (a " + t.join("-") + " triangle" + (k > 1 ? " times " + k : "") + ")." };
      },
      function (d) {   // a circle, in terms of π
        var r = ri(2, d === 1 ? 9 : 15), byD = d >= 2 && Math.random() < 0.5, area = Math.random() < 0.6;
        if (d === 3 && Math.random() < 0.4) { var C = 2 * r; return { q: "A circle's circumference is " + C + "π. What is its area, in terms of π?", a: PI(R(r * r)), how: "The radius is " + C + "π ÷ 2π = " + r + ", so the area is " + r + "²π = " + r * r + "π." }; }
        var given = byD ? "diameter " + 2 * r : "radius " + r;
        return area ? { q: "What is the area of a circle with " + given + ", in terms of π?", a: PI(R(r * r)), how: "πr² with r = " + r + " is " + r * r + "π." } : { q: "What is the circumference of a circle with " + given + ", in terms of π?", a: PI(R(2 * r)), how: "2πr with r = " + r + " is " + 2 * r + "π." };
      },
      function (d) {   // a polygon's angles
        var n = pick([5, 6, 8, 9, 10, 12, 15, 18, 20]), kind = d === 1 ? 0 : ri(0, 2);
        if (kind === 0) return { q: "What is the sum of the interior angles of " + an(n) + n + "-sided polygon, in degrees?", a: NUM(R(180 * (n - 2))), how: "180 × (" + n + " − 2) = " + 180 * (n - 2) + "." };
        if (kind === 1) return { q: "What is each interior angle of a regular " + n + "-gon, in degrees?", a: NUM(R(180 * (n - 2), n)), how: "180 × (" + n + " − 2) ÷ " + n + " = " + rStr(R(180 * (n - 2), n)) + ", or 180 − 360/" + n + "." };
        var e = pick([10, 12, 15, 18, 20, 24, 30, 36, 40, 45, 60, 72]); return { q: "Each exterior angle of a regular polygon is " + e + "°. How many sides does it have?", a: NUM(R(360 / e)), how: "360 ÷ " + e + " = " + 360 / e + "." };
      },
      function (d) {   // a triangle's or trapezoid's area
        if (d === 3 && Math.random() < 0.5) { var a = ri(3, 15), b = ri(a + 1, 25), h = ri(1, 6) * 2; return { q: "A trapezoid has bases " + a + " and " + b + " and height " + h + ". What is its area?", a: NUM(R((a + b) * h / 2)), how: "(" + a + " + " + b + ") ÷ 2 × " + h + " = " + (a + b) * h / 2 + "." }; }
        var base = ri(3, d === 1 ? 14 : 30), ht = ri(2, d === 1 ? 12 : 24); return { q: "A triangle has base " + base + " and height " + ht + ". What is its area?", a: NUM(R(base * ht, 2)), how: base + " × " + ht + " ÷ 2 = " + rStr(R(base * ht, 2)) + "." };
      },
      function (d) {   // a box or a cube
        if (Math.random() < 0.5) { var a = ri(2, 9), b = ri(2, 9), c = ri(2, d === 1 ? 6 : 12); return { q: "What is the volume of a " + a + " by " + b + " by " + c + " box?", a: NUM(R(a * b * c)), how: a + " × " + b + " × " + c + " = " + a * b * c + "." }; }
        var s = ri(2, d === 1 ? 6 : 12); return Math.random() < 0.5 ? { q: "What is the surface area of a cube with edge " + s + "?", a: NUM(R(6 * s * s)), how: "6 faces of " + s * s + " make " + 6 * s * s + "." } : { q: "A cube has volume " + s * s * s + ". What is its surface area?", a: NUM(R(6 * s * s)), how: "The edge is " + s + ", so 6 × " + s * s + " = " + 6 * s * s + "." };
      },
    ],
    alg: [
      function (d) {   // the slope between two points
        var x1 = ri(-9, 9), y1 = ri(-9, 9), dx = nz(-8, 8), dy = d === 1 ? dx * nz(-4, 4) : ri(-12, 12), x2 = x1 + dx, y2 = y1 + dy;
        return { q: "What is the slope of the line through " + pt(x1, y1) + " and " + pt(x2, y2) + "?", a: NUM(R(dy, dx)), how: "(" + neg(y2) + " − " + par(y1) + ") ÷ (" + neg(x2) + " − " + par(x1) + ") = " + neg(dy) + " ÷ " + par(dx) + " = " + rStr(R(dy, dx)) + "." };
      },
      function (d) {   // the distance between two points
        var t = pick(d === 1 ? TRIPLES.slice(0, 2) : TRIPLES.slice(0, 4)), k = d === 3 ? ri(1, 2) : 1, x1 = ri(-6, 6), y1 = ri(-6, 6), sx = Math.random() < 0.5 ? 1 : -1, sy = Math.random() < 0.5 ? 1 : -1, sw = Math.random() < 0.5;
        var dx = (sw ? t[1] : t[0]) * k * sx, dy = (sw ? t[0] : t[1]) * k * sy;
        return { q: "How far apart are " + pt(x1, y1) + " and " + pt(x1 + dx, y1 + dy) + "?", a: NUM(R(t[2] * k)), how: "√(" + Math.abs(dx) + "² + " + Math.abs(dy) + "²) = " + t[2] * k + "." };
      },
      function (d) {   // the midpoint
        var x1 = ri(-10, 10), y1 = ri(-10, 10), x2 = ri(-10, 10), y2 = ri(-10, 10);
        if (d === 1) { x2 = x1 + 2 * ri(-5, 5); y2 = y1 + 2 * ri(-5, 5); }
        return { q: "What is the midpoint of " + pt(x1, y1) + " and " + pt(x2, y2) + "?", a: PT(R(x1 + x2, 2), R(y1 + y2, 2)), how: "Average each one, (" + rStr(R(x1 + x2, 2)) + ", " + rStr(R(y1 + y2, 2)) + ")." };
      },
      function (d) {   // solve for x
        var x = ri(-12, 15), a = nz(d === 1 ? 2 : -9, 9), b = ri(-20, 20);
        if (d === 3) { var c = nz(-6, 6); while (c === a) c = nz(-6, 6); var e = a * (x + b) - c * x; return { q: "Solve " + (a === 1 ? "" : coef(a)) + "(x " + sgn(b) + ") = " + coef(c) + "x " + sgn(e) + " for x.", a: NUM(R(x)), how: coef(a) + "x " + sgn(a * b) + " = " + coef(c) + "x " + sgn(e) + ", so " + coef(a - c) + "x = " + neg(e - a * b) + " and x = " + neg(x) + "." }; }
        if (b === 0) b = ri(1, 20);
        return { q: "Solve " + coef(a) + "x " + sgn(b) + " = " + neg(a * x + b) + " for x.", a: NUM(R(x)), how: coef(a) + "x = " + neg(a * x + b) + " " + sgn(-b) + " = " + neg(a * x) + (a === 1 ? "" : ", so x = " + neg(a * x) + " ÷ " + par(a) + " = " + neg(x)) + "." };
      },
      function (d) {   // a function's value, or a line's y-intercept
        if (d >= 2 && Math.random() < 0.5) { var x1 = ri(-5, 5), m = nz(-4, 4), b = ri(-10, 10), x2 = x1 + nz(1, 4); return { q: "A line passes through " + pt(x1, m * x1 + b) + " and " + pt(x2, m * x2 + b) + ". What is its y-intercept?", a: NUM(R(b)), how: "The slope is " + neg(m) + ", so b = " + neg(m * x1 + b) + " − " + par(m) + " × " + par(x1) + " = " + neg(b) + "." }; }
        var a = nz(-3, 4), bb = ri(-9, 9), c = ri(-10, 10), x = ri(-5, 5), v = a * x * x + bb * x + c;
        return { q: "If f(x) = " + coef(a) + "x² " + sgn(bb) + "x " + sgn(c) + ", what is f(" + neg(x) + ")?", a: NUM(R(v)), how: (a === 1 ? "" : neg(a) + " × ") + par(x) + "² " + sgn(bb) + " × " + par(x) + " " + sgn(c) + " = " + neg(v) + "." };
      },
      function (d) {   // an arithmetic sequence
        var a = ri(d === 1 ? 1 : -5, 12), s = nz(d === 1 ? 1 : -4, 7), n = ri(d === 1 ? 5 : 8, d === 3 ? 40 : 20);
        if (d >= 2 && Math.random() < 0.5) { var sum = n * (2 * a + (n - 1) * s) / 2; return { q: "What is the sum of the first " + n + " terms of " + [a, a + s, a + 2 * s].map(neg).join(", ") + ", …?", a: NUM(R(sum)), how: "The last term is " + neg(a + (n - 1) * s) + ", so " + n + " × (" + neg(a) + " + " + par(a + (n - 1) * s) + ") ÷ 2 = " + neg(sum) + "." }; }
        return { q: "What is term " + n + " of " + [a, a + s, a + 2 * s].map(neg).join(", ") + ", …?", a: NUM(R(a + (n - 1) * s)), how: neg(a) + " + (" + n + " − 1) × " + par(s) + " = " + neg(a + (n - 1) * s) + "." };
      },
    ],
    stats: [
      function (d) {   // the missing number for an average
        var k = ri(d === 1 ? 3 : 4, d === 3 ? 7 : 5), avg = ri(8, d === 1 ? 20 : 90), xs = []; for (var i = 0; i < k - 1; i++) xs.push(ri(Math.max(1, avg - 15), avg + 15));
        var need = avg * k - xs.reduce(function (a, b) { return a + b; }, 0);
        if (need < 0) { xs = xs.map(function () { return avg; }); need = avg; }
        return { q: "The average of " + xs.join(", ") + " and x is " + avg + ". What is x?", a: NUM(R(need)), how: "All " + k + " add to " + avg + " × " + k + " = " + avg * k + ", so x = " + avg * k + " − " + (avg * k - need) + " = " + need + "." };
      },
      function (d) {   // the mean of a list
        var k = ri(4, d === 1 ? 5 : 8), avg = ri(5, 60), xs = []; for (var i = 0; i < k - 1; i++) xs.push(ri(Math.max(0, avg - 12), avg + 12));
        var last = avg * k - xs.reduce(function (a, b) { return a + b; }, 0); if (last < 0) last = avg;
        xs.push(last); var total = xs.reduce(function (a, b) { return a + b; }, 0);
        return { q: "What is the mean of " + xs.join(", ") + "?", a: DEC(R(total, k)), how: total + " ÷ " + k + " = " + rStr(R(total, k)) + "." };
      },
      function (d) {   // the median
        var k = d === 1 ? ri(2, 3) * 2 + 1 : ri(5, 9), xs = []; for (var i = 0; i < k; i++) xs.push(ri(1, 60));
        var s = xs.slice().sort(function (a, b) { return a - b; }), med = k % 2 ? R(s[(k - 1) / 2]) : R(s[k / 2 - 1] + s[k / 2], 2);
        return { q: "What is the median of " + xs.join(", ") + "?", a: NUM(med), how: "In order, " + s.join(", ") + ". " + (k % 2 ? "The middle one is " + rStr(med) : "Halfway between " + s[k / 2 - 1] + " and " + s[k / 2] + " is " + rStr(med)) + "." };
      },
      function (d) {   // the new average after one more
        var n = ri(3, 9), avg = ri(10, 50), add = ri(0, 90), na = R(n * avg + add, n + 1), DECN = true;
        if (d === 1) { add = avg + (n + 1) * ri(1, 5); na = R(n * avg + add, n + 1); }
        return { q: "The average of " + n + " numbers is " + avg + ". With " + add + " added, what is the new average?", a: DECN && (n + 1) % 3 && (n + 1) % 7 && (n + 1) % 9 ? DEC(na) : NUM(na), how: "(" + n + " × " + avg + " + " + add + ") ÷ " + (n + 1) + " = " + (n * avg + add) + "/" + (n + 1) + (na.d === n + 1 ? "" : " = " + rStr(na)) + "." };
      },
    ],
    num: [
      function (d) {   // greatest common divisor
        var g = ri(2, d === 1 ? 12 : 30), a = ri(2, 12), b = ri(2, 12); while (gcd(a, b) !== 1) b = ri(2, 13);
        return { q: "What is the greatest common divisor of " + g * a + " and " + g * b + "?", a: NUM(R(g)), how: g * a + " = " + g + " × " + a + " and " + g * b + " = " + g + " × " + b + ", so " + g + "." };
      },
      function (d) {   // least common multiple
        var a = ri(4, d === 1 ? 15 : 40), b = ri(4, d === 1 ? 15 : 40); while (a === b) b = ri(4, 40);
        return { q: "What is the least common multiple of " + a + " and " + b + "?", a: NUM(R(lcm(a, b))), how: a + " × " + b + " ÷ " + gcd(a, b) + " = " + lcm(a, b) + "." };
      },
      function (d) {   // how many divisors
        var ps = [2, 3, 5, 7, 11], n = 1, f = [], k = d === 1 ? 2 : 3;
        for (var i = 0; i < k; i++) { var p = ps[i], e = ri(i < 2 ? 1 : 0, d === 3 ? 4 : 3); if (e) { n *= Math.pow(p, e); f.push([p, e]); } }
        if (n === 1 || n > 5000) { n = 72; f = [[2, 3], [3, 2]]; }
        var cnt = f.reduce(function (a, x) { return a * (x[1] + 1); }, 1);
        return { q: "How many positive divisors does " + n.toLocaleString("en-US") + " have?", a: NUM(R(cnt)), how: n + " = " + f.map(function (x) { return x[0] + (x[1] > 1 ? "^" + x[1] : ""); }).join(" × ") + ", so " + f.map(function (x) { return "(" + x[1] + " + 1)"; }).join(" × ") + " = " + cnt + "." };
      },
      function (d) {   // a remainder
        var m = ri(3, d === 1 ? 9 : 17), n = ri(d === 1 ? 20 : 100, d === 3 ? 9999 : 999), r = n % m;
        return { q: "What is the remainder when " + n.toLocaleString("en-US") + " is divided by " + m + "?", a: NUM(R(r)), how: m + " × " + Math.floor(n / m) + " = " + (n - r) + ", and " + n + " − " + (n - r) + " = " + r + "." };
      },
      function (d) {   // the largest prime factor
        var P = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47], a = pick(P.slice(0, d === 1 ? 6 : 10)), b = pick(P.slice(d === 1 ? 2 : 4)), c = d === 3 ? pick(P.slice(0, 5)) : 1;
        var n = a * b * c, big = Math.max(a, b, c);
        return { q: "What is the largest prime factor of " + n.toLocaleString("en-US") + "?", a: NUM(R(big)), how: n + " = " + [a, b, c].filter(function (x) { return x > 1; }).sort(function (x, y) { return x - y; }).join(" × ") + "." };
      },
    ],
    count: [
      function (d) {   // choose
        var n = ri(4, d === 1 ? 7 : 12), k = ri(2, Math.min(4, n - 1)), v = 1; for (var i = 0; i < k; i++) v = v * (n - i) / (i + 1);
        return { q: "In how many ways can you choose " + k + " people from " + n + "?", a: NUM(R(Math.round(v))), how: n + " choose " + k + " = " + Math.round(v) + "." };
      },
      function (d) {   // arrangements, in order
        var n = ri(4, d === 1 ? 6 : 10), k = ri(2, Math.min(4, n)), v = 1; for (var i = 0; i < k; i++) v *= n - i;
        return { q: "In how many ways can " + n + " runners finish " + (k === 2 ? "first and second" : "first through " + ["", "", "", "third", "fourth"][k]) + "?", a: NUM(R(v)), how: Array.from({ length: k }, function (_, i) { return n - i; }).join(" × ") + " = " + v + "." };
      },
      function (d) {   // a word's letters
        var w = pick(d === 1 ? ["MATH", "QUIZ", "PLANT", "LEVEL", "TOOTH"] : ["BANANA", "LETTER", "BALLOON", "COFFEE", "PEPPER", "MISSISSIPPI", "STATISTICS", "BOOKKEEPER"]);
        var c = {}; w.split("").forEach(function (x) { c[x] = (c[x] || 0) + 1; });
        var f = function (n) { var r = 1; for (var i = 2; i <= n; i++) r *= i; return r; }, v = f(w.length); Object.keys(c).forEach(function (x) { v /= f(c[x]); });
        var rep = Object.keys(c).filter(function (x) { return c[x] > 1; });
        return { q: "How many ways can the letters of " + w + " be arranged?", a: NUM(R(v)), how: w.length + "!" + (rep.length ? " ÷ (" + rep.map(function (x) { return c[x] + "!"; }).join(" × ") + ")" : "") + " = " + v.toLocaleString("en-US") + "." };
      },
      function (d) {   // two dice
        var s = ri(2, 12), ways = 6 - Math.abs(s - 7);
        if (d === 1 || Math.random() < 0.6) return { q: "Two fair dice are rolled. What is the probability their sum is " + s + "?", a: NUM(R(ways, 36)), how: ways + " of the 36 rolls " + (ways === 1 ? "gives " : "give ") + s + ", so " + rStr(R(ways, 36)) + "." };
        var t = ri(5, 9), w2 = 0; for (var a = 1; a <= 6; a++) for (var b = 1; b <= 6; b++) if (a + b >= t) w2++;
        return { q: "Two fair dice are rolled. What is the probability their sum is at least " + t + "?", a: NUM(R(w2, 36)), how: w2 + " of the 36 rolls, so " + rStr(R(w2, 36)) + "." };
      },
      function (d) {   // coins
        var n = ri(3, d === 1 ? 4 : 6), k = ri(0, n), c = 1; for (var i = 0; i < k; i++) c = c * (n - i) / (i + 1); c = Math.round(c);
        return { q: "A fair coin is flipped " + n + " times. What is the probability of exactly " + k + " head" + (k === 1 ? "" : "s") + "?", a: NUM(R(c, Math.pow(2, n))), how: n + " choose " + k + " = " + c + " of the " + Math.pow(2, n) + " outcomes, so " + rStr(R(c, Math.pow(2, n))) + "." };
      },
    ],
  };
  var NAME = {}; TOPICS.forEach(function (t) { NAME[t[0]] = t[1]; });
  // the next problem: a topic picked, then one of its kinds, never the same text twice in a row
  var lastQ = "";
  function make() {
    var tops = st.topics.filter(function (t) { return G[t]; }); if (!tops.length) tops = TOPICS.map(function (t) { return t[0]; });
    for (var tries = 0; tries < 20; tries++) {
      var tp = pick(tops), p;
      try { p = pick(G[tp])(st.diff); } catch (e) { continue; }
      if (!p || !p.a || p.q === lastQ) continue;
      if (p.a.t === "n" && !isFinite(p.a.v.n / p.a.v.d)) continue;
      lastQ = p.q; p.topic = tp; return p;
    }
    return { q: "17 × 3", a: NUM(R(51)), how: "17 × 3 = 51.", topic: "arith" };
  }
  // a little typesetting: x^2 as a superscript
  function qHtml(s) { return esc(s).replace(/\^(\d+)/g, "<sup>$1</sup>"); }

  // ── a round ──
  var run = null, tick = 0, autoT = 0;
  function start() {
    clearInterval(tick); clearTimeout(autoT);
    var len = st.mode === "free" ? 0 : Number(st.mode);
    run = { len: len, ends: len ? Date.now() + len * 1000 : 0, right: 0, tries: 0, streak: 0, bestStreak: 0, cur: null, answered: false, over: false, times: [], missed: [] };
    if (len) tick = setInterval(clockTick, 200);
    next();
  }
  function next() {
    if (!run || run.over) return;
    clearTimeout(autoT);
    run.cur = make(); run.answered = false; run.t0 = Date.now();
    paintPlay();
  }
  function clockTick() {
    if (!run || run.over) { clearInterval(tick); return; }
    var left = Math.max(0, Math.ceil((run.ends - Date.now()) / 1000)), el = body && body.querySelector(".fc-time");
    if (el) el.textContent = left >= 60 ? Math.floor(left / 60) + ":" + String(left % 60).padStart(2, "0") : left + "s";
    if (Date.now() >= run.ends) finish();
  }
  function submit(text, skipped) {
    if (!run || run.over || run.answered) return;
    var p = run.cur, ok = !skipped && judge(text, p.a), secs = (Date.now() - run.t0) / 1000;
    run.answered = true; run.tries++;
    var b = st.by[p.topic] = st.by[p.topic] || [0, 0]; b[1]++; st.tries++;
    if (ok) { run.right++; run.streak++; run.bestStreak = Math.max(run.bestStreak, run.streak); b[0]++; st.solved++; run.times.push(secs); }
    else { run.streak = 0; run.missed.push(p); }
    save();
    var fb = body.querySelector(".fc-fb"), inp = body.querySelector(".fc-in");
    if (inp) inp.disabled = true;
    if (fb) fb.innerHTML = ok
      ? '<b class="pk-good">Right</b> <span class="pk-muted">in ' + secs.toFixed(1) + " s</span>"
      : '<b class="pk-bad">' + (skipped ? "Skipped." : "Not quite.") + "</b> It's <b>" + esc(show(p.a)) + '</b>. <span class="pk-muted">' + qHtml(p.how) + "</span>";
    var nx = body.querySelector('[data-fc="next"]'), sk = body.querySelector('[data-fc="skip"]'), ck = body.querySelector('[data-fc="check"]');
    if (sk) sk.hidden = true; if (ck) ck.hidden = true; if (nx) { nx.hidden = false; nx.focus(); }
    paintScore();
    // in a timed round a right answer goes on by itself
    if (ok && run.len) autoT = setTimeout(next, 450);
  }
  function finish() {
    if (!run || run.over) return;
    clearInterval(tick); clearTimeout(autoT);
    run.over = true;
    if (run.len) {
      st.rounds++;
      var key = run.len + ":" + st.diff, prev = st.best[key] || 0;
      run.newBest = run.right > prev && run.right > 0;
      st.best[key] = Math.max(prev, run.right);
    }
    st.bestStreak = Math.max(st.bestStreak || 0, run.bestStreak);
    save();
    paintDone();
  }
  function quit() { clearInterval(tick); clearTimeout(autoT); run = null; render(); }

  // ── the pages ──
  function modeName(m) { return (MODES.find(function (x) { return x[0] === String(m); }) || [0, m])[1]; }
  function diffName(d) { return (DIFFS.find(function (x) { return x[0] === Number(d); }) || [0, d])[1]; }
  function render() {
    if (!body) return;
    if (run && !run.over) { paintPlay(); return; }
    var acc = st.tries ? Math.round(100 * st.solved / st.tries) + "%" : "—", best = st.mode === "free" ? null : st.best[st.mode + ":" + st.diff] || 0;
    var chips = TOPICS.map(function (t) { var on = st.topics.indexOf(t[0]) >= 0; return '<button type="button" class="fc-topic' + (on ? " on" : "") + '" aria-pressed="' + on + '" data-topic="' + t[0] + '">' + esc(t[1]) + "</button>"; }).join("");
    var weak = TOPICS.map(function (t) { var b = st.by[t[0]]; return b && b[1] >= 5 ? { t: t[1], a: b[0] / b[1], n: b[1] } : null; }).filter(Boolean).sort(function (a, b) { return a.a - b.a; });
    body.innerHTML = '<div class="pk-wrap pk-narrow fc">' +
      heroHtml("bolt", "Quick math, pencil and paper", "The computation a math tossup asks for, from products and slopes to angles and averages, made fresh every time.", "Start",
        '<div class="fc-set">' + segHtml("mode", MODES, st.mode) + segHtml("diff", DIFFS, st.diff) + '</div><div class="fc-topics" role="group" aria-label="Topics">' + chips + "</div>") +
      '<div class="pk-tiles">' + tile(fmt(st.solved), "Solved") + (best != null ? tile(fmt(best), "Best in " + modeName(st.mode) + ", " + diffName(st.diff).toLowerCase(), "pk-good") : tile(acc, "Accuracy", "pk-good")) + tile(fmt(st.bestStreak || 0), "Best streak", "pk-gold") + "</div>" +
      (weak.length ? '<div class="pk-card fc-acc"><h3>By topic</h3>' + weak.map(function (w) { return '<div class="fc-row"><span>' + esc(w.t) + '</span><span class="pk-muted pk-small">' + plural(w.n, "try", "tries") + '</span><b class="num">' + Math.round(w.a * 100) + "%</b></div>"; }).join("") + "</div>" : "") +
      "</div>";
    body.querySelectorAll("[data-mode]").forEach(function (b) { b.onclick = function () { st.mode = b.dataset.mode; save(); render(); }; });
    body.querySelectorAll("[data-diff]").forEach(function (b) { b.onclick = function () { st.diff = Number(b.dataset.diff); save(); render(); }; });
    body.querySelectorAll("[data-topic]").forEach(function (b) { b.onclick = function () {
      var t = b.dataset.topic, i = st.topics.indexOf(t);
      if (i >= 0) { if (st.topics.length === 1) return; st.topics.splice(i, 1); } else st.topics.push(t);
      save(); render();
    }; });
    var g = body.querySelector('[data-pk="start"]'); if (g) g.onclick = start;
  }
  function scoreHtml() {
    return '<span class="fc-stat"><b class="num fc-time">' + (run.len ? (run.len >= 60 ? Math.floor(run.len / 60) + ":00" : run.len + "s") : "Practice") + '</b></span>' +
      '<span class="fc-stat"><span class="pk-muted">Right</span> <b class="num">' + run.right + "</b>" + (run.tries ? '<span class="pk-muted"> of ' + run.tries + "</span>" : "") + "</span>" +
      '<span class="fc-stat"><span class="pk-muted">Streak</span> <b class="num">' + run.streak + "</b></span>";
  }
  function paintScore() { var s = body && body.querySelector(".fc-score"); if (s) { s.innerHTML = scoreHtml(); if (run.len) clockTick(); } }
  function paintPlay() {
    if (!body || !run) return;
    var p = run.cur;
    body.innerHTML = '<div class="pk-wrap pk-narrow fc fc-play">' +
      '<div class="fc-bar"><div class="fc-score">' + scoreHtml() + '</div><button type="button" class="btn btn-sm btn-ghost" data-fc="end">' + (run.len ? "End" : "Done") + "</button></div>" +
      '<div class="pk-card fc-card"><div class="fc-kind">' + esc(NAME[p.topic] || "") + '</div><div class="fc-q">' + qHtml(p.q) + "</div>" +
      '<form class="fc-form" autocomplete="off"><input class="fc-in" inputmode="text" spellcheck="false" aria-label="Your answer" placeholder="Your answer">' +
      '<button type="submit" class="btn btn-primary" data-fc="check">Check</button><button type="button" class="btn btn-primary" data-fc="next" hidden>Next</button></form>' +
      '<div class="fc-fb" aria-live="polite"></div><div class="fc-foot"><button type="button" class="btn btn-sm btn-ghost" data-fc="skip">Skip</button>' +
      '<span class="pk-muted pk-small">Fractions as 3/4, π as pi, a point as (2, 5). Enter checks.</span></div></div></div>';
    if (run.len) clockTick();
    var f = body.querySelector(".fc-form"), inp = body.querySelector(".fc-in");
    var go = function () { if (run.answered) { next(); return; } if (inp.value.trim()) submit(inp.value); };
    // Enter checks (handled here, not left to the form), every other key stays in the box (the app's keys don't fire)
    inp.addEventListener("keydown", function (e) { if (e.key === "Enter") { e.preventDefault(); e.stopPropagation(); go(); return; } if (e.key !== "Escape") e.stopPropagation(); });
    f.onsubmit = function (e) { e.preventDefault(); go(); };
    body.querySelector('[data-fc="next"]').onclick = next;
    body.querySelector('[data-fc="skip"]').onclick = function () { submit("", true); };
    body.querySelector('[data-fc="end"]').onclick = function () { if (run.tries || run.len) finish(); else quit(); };
    // Enter on Next, or anywhere once answered, goes on
    body.querySelector('[data-fc="next"]').addEventListener("keydown", function (e) { if (e.key === "Enter") { e.preventDefault(); e.stopPropagation(); next(); } });
    inp.focus({ preventScroll: true });
  }
  function paintDone() {
    if (!body || !run) return;
    var avg = run.times.length ? (run.times.reduce(function (a, b) { return a + b; }, 0) / run.times.length).toFixed(1) + " s" : "—";
    var best = run.len ? st.best[run.len + ":" + st.diff] || 0 : null;
    body.innerHTML = '<div class="pk-wrap pk-narrow fc">' +
      '<div class="pk-card fc-done"><div class="fc-big"><b class="num">' + run.right + '</b><span>right' + (run.len ? " in " + esc(modeName(String(run.len))) : "") + ", " + esc(diffName(st.diff).toLowerCase()) + "</span></div>" +
      (run.newBest ? '<div class="pk-good fc-note">A new best</div>' : "") +
      '<div class="pk-tiles">' + tile(run.tries ? Math.round(100 * run.right / run.tries) + "%" : "—", "Accuracy") + tile(avg, "Per right answer") + tile(fmt(run.bestStreak), "Best streak", "pk-gold") + (best != null ? tile(fmt(best), "Your best", "pk-good") : "") + "</div>" +
      (run.missed.length ? '<div class="fc-missed"><div class="eyebrow">Missed</div>' + run.missed.slice(-6).map(function (p) { return '<div class="fc-miss"><span>' + qHtml(p.q) + '</span><b class="num">' + esc(show(p.a)) + "</b></div>"; }).join("") + "</div>" : "") +
      '<div class="pk-actions"><button type="button" class="btn" data-fc="home">Done</button><button type="button" class="btn btn-primary" data-fc="again">' + ic("play", 14) + "Again</button></div></div></div>";
    body.querySelector('[data-fc="again"]').onclick = start;
    body.querySelector('[data-fc="home"]').onclick = quit;
    body.querySelector('[data-fc="again"]').focus({ preventScroll: true });
  }
  ctx._cleanup = function () { clearInterval(tick); clearTimeout(autoT); };
  page = ctx.registerPage({
    id: "fast-calculations", navLabel: "Fast Calculations", title: "Fast Calculations",
    onShow: function (el) { body = el; render(); },
    onHide: function () { if (run && !run.over) { clearInterval(tick); clearTimeout(autoT); run = null; } },
  });
  // Esc in a round ends it (its score first); on the score, back to the start
  if (ctx.onBack) ctx.onBack(function () {
    if (!(page && page.screenEl && page.screenEl.classList.contains("active")) || !run) return false;
    if (!run.over && (run.tries || run.len)) finish(); else quit();
    return true;
  });
  // for checks (tests/fastcalc): the judge and the problems
  ctx.__fc = { judge: judge, make: make, G: G, show: show, st: st };

}
