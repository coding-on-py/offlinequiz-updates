function __qbMain(ctx) {
    var body = null, page = null;
    var packet = null;          // { tossups: [], bonuses: [] }
    var run = null;             // { items: [{type,q}], idx, score, phase, ... }
    var revealTimer = null, revealI = 0, buzzed = false, fullyRead = false;

    function esc(s) { return (s == null ? "" : String(s)).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
    function ansHtml(raw, fallback) {
      var src = (raw && String(raw).trim()) ? String(raw) : String(fallback || "");
      var html = esc(src).replace(/&lt;(\/?)(b|u|i|em|strong)&gt;/gi, "<$1$2>");
      var d = document.createElement("div"); d.innerHTML = html; return d.innerHTML;
    }
    function shuffle(a) { for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)); var t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
    function cfg() { try { return ctx.host.getPracticeConfig() || {}; } catch (e) { return {}; } }
    function readText(t) {
      t = String(t || "").replace(/\(\*\)/g, "");
      var c = cfg();
      if (c.hidePron && ctx.host.stripPronunciations) t = ctx.host.stripPronunciations(t);
      return t.replace(/\s+/g, " ").trim();
    }

    page = ctx.registerPage({
      id: "builder", navLabel: "Packet Builder", title: "PACKET BUILDER",
      onShow: function (el) { body = el; if (!body.querySelector(".pb-wrap")) renderBuilder(); },
      onHide: function () { stopReveal(); stopPbTimer(); returnPanel(); },
    });
    function active() { return page && page.screenEl && page.screenEl.classList.contains("active"); }
    ctx.on("screen:change", function () { setTimeout(function () { if (!active()) { stopReveal(); stopPbTimer(); returnPanel(); } }, 0); });
    ctx._cleanup = function () { stopReveal(); stopPbTimer(); };

    // Esc inside the packet goes UP one level (view/run → chooser), not home.
    var pbView = "builder";
    ctx.onBack(function () {
      if (!active()) return false;
      if (pbView === "view" || pbView === "run") { renderChooser(); return true; }
      return false;
    });

    // The chooser/view/run screens borrow the REAL practice filter panel as a
    // settings sidebar: reading speed, strictness, buzz window + answer timer,
    // and the OPTIONS toggles (hide pronunciations, …) all live there.
    var borrowedPanel = null, panelHome = null;
    function borrowPanel() {
      var layout = body.querySelector(".pb-layout"); if (!layout) return;
      try { if (ctx.host && ctx.host.ensureFiltersLoaded) ctx.host.ensureFiltersLoaded(); } catch (e) {}
      var panel = document.getElementById("filters-panel"); if (!panel) return;
      if (!panelHome) panelHome = { parent: panel.parentNode, next: panel.nextSibling };
      panel.classList.add("pb-borrowed");
      layout.insertBefore(panel, layout.firstChild);
      borrowedPanel = panel;
    }
    function returnPanel() {
      if (!borrowedPanel) return;
      borrowedPanel.classList.remove("pb-borrowed");
      if (panelHome) panelHome.parent.insertBefore(borrowedPanel, panelHome.next);
      borrowedPanel = null;
    }
    function shell(inner) {
      return '<div class="practice-layout pb-layout"><main class="question-area">' + inner + "</main></div>";
    }
    // Read a practice-panel slider live (works while the panel is borrowed).
    function panelVal(id, dflt) {
      var el = document.getElementById(id);
      var v = el ? parseInt(el.value) : NaN;
      return isNaN(v) ? dflt : v;
    }
    var pbTimer = null, pbTick = null;
    function stopPbTimer() {
      if (pbTimer) { clearTimeout(pbTimer); pbTimer = null; }
      if (pbTick) { clearInterval(pbTick); pbTick = null; }
    }
    function countdown(el, secs) {
      if (!el) return;
      var end = Date.now() + secs * 1000;
      function paint() { el.textContent = Math.max(0, Math.ceil((end - Date.now()) / 1000)) + "s"; }
      paint();
      pbTick = setInterval(paint, 200);
    }

    // ── builder form: NAQT-weighted category shares ──
    // NAQT's high-school template distribution, top-level weights (TU / B).
    var NAQT_W = {
      "Literature": [38, 38], "Science": [54, 54], "Fine Arts": [20, 20],
      "History": [46, 46], "Geography": [19, 19], "Mythology": [6, 6],
      "Pop Culture": [16, 16], "Social Science": [6, 6], "Philosophy": [3, 3],
      "Religion": [4, 4], "Current Events": [15, 15], "Other Academic": [10, 16],
    };
    function quotas(weights, total) {
      var sum = weights.reduce(function (s, w) { return s + w; }, 0);
      if (sum <= 0 || total <= 0) return weights.map(function () { return 0; });
      return weights.map(function (w) { return (w / sum) * total; });
    }
    // Randomized apportionment with a balance guard: every category gets the
    // floor of its fair share for sure, and the leftover seats are drawn at
    // random weighted by the fractional remainders (no category ever exceeds
    // its share rounded up). Small categories like Religion (~0.3 of a
    // 20-tossup packet) land in roughly a third of built packets instead of
    // being deterministically rounded to 0.
    function allocRandom(weights, total) {
      var q = quotas(weights, total);
      var out = q.map(function (x) { return Math.floor(x); });
      var rem = total - out.reduce(function (s, n) { return s + n; }, 0);
      var pool = q.map(function (x, i) { return { i: i, f: x - Math.floor(x) }; })
        .filter(function (x) { return x.f > 0; });
      while (rem > 0 && pool.length) {
        var tot = pool.reduce(function (s, x) { return s + x.f; }, 0);
        var r = Math.random() * tot, acc = 0, pick = 0;
        for (var k = 0; k < pool.length; k++) { acc += pool[k].f; if (r <= acc) { pick = k; break; } }
        out[pool[pick].i]++; pool.splice(pick, 1); rem--;
      }
      for (var j = 0; rem > 0 && weights.some(function (w) { return w > 0; }); j = (j + 1) % weights.length) {
        if (weights[j] > 0) { out[j]++; rem--; }
      }
      return out;
    }

    async function renderBuilder() {
      stopReveal(); stopPbTimer(); returnPanel(); run = null; pbView = "builder";
      body.innerHTML = '<div class="pb-wrap"><div class="text-muted">Loading categories…</div></div>';
      var cats = [];
      try { cats = (await ctx.api.get("/api/categories?type=tossups")).categories || []; } catch (e) {}
      if (!cats.length) { body.innerHTML = '<div class="pb-wrap"><div class="text-muted">Couldn’t load categories.</div></div>'; return; }
      var defs = cats.map(function (c) {
        var w = NAQT_W[c.category] || [5, 5];
        return { cat: c.category, wtu: w[0], wb: w[1] };
      });
      var diffBoxes = "";
      for (var d = 0; d <= 10; d++) diffBoxes += '<label class="pb-diff"><input type="checkbox" class="pb-diff-cb" value="' + d + '"' + (d >= 2 && d <= 5 ? " checked" : "") + ">" + d + "</label>";
      body.innerHTML =
        '<div class="pb-wrap">' +
          '<div class="pb-card">' +
            '<div class="pb-row"><span class="pb-label">Packet size</span><span class="qb-info" data-tip="weights default to NAQT’s HS distribution — each build draws counts at random around the fair shares below, never above a share rounded up, so small categories still appear in some packets">i</span>' +
              '<label class="pb-diff">Tossups <input type="number" id="pb-total-tu" class="mode-input" min="0" max="200" value="20" style="width:64px"></label>' +
              '<label class="pb-diff">Bonuses <input type="number" id="pb-total-b" class="mode-input" min="0" max="200" value="20" style="width:64px"></label>' +
            "</div>" +
            '<table class="stats-table pb-table"><thead><tr><th>Category</th><th>TU weight</th><th>B weight</th><th>TU share</th><th>B share</th></tr></thead><tbody>' +
            defs.map(function (df) {
              return "<tr><td>" + esc(df.cat) + '</td>' +
                '<td><input type="number" class="pb-wtu mode-input" data-cat="' + esc(df.cat) + '" min="0" max="999" value="' + df.wtu + '"></td>' +
                '<td><input type="number" class="pb-wb mode-input" data-cat="' + esc(df.cat) + '" min="0" max="999" value="' + df.wb + '"></td>' +
                '<td class="pb-ctu" data-cat="' + esc(df.cat) + '">0</td>' +
                '<td class="pb-cb" data-cat="' + esc(df.cat) + '">0</td></tr>';
            }).join("") +
            "</tbody></table>" +
            '<div class="pb-row"><span class="pb-label">Difficulty</span>' + diffBoxes + "</div>" +
            '<div class="pb-row"><span class="pb-label">Years</span>' +
              '<div class="dual-range pb-dual"><div class="dual-range-track"><div class="dual-range-fill" id="pb-yfill"></div></div>' +
                '<input type="range" id="pb-ymin" min="2000" max="2026" value="2010">' +
                '<input type="range" id="pb-ymax" min="2000" max="2026" value="2026"></div>' +
              '<span class="pb-label" id="pb-year-val" style="min-width:84px;text-align:right"></span>' +
            "</div>" +
            '<div class="pb-row"><button class="btn btn-primary" id="pb-build">Build packet</button><span class="text-muted" id="pb-status" style="font-size:12px"></span></div>' +
          "</div>" +
        "</div>";
      var lo = body.querySelector("#pb-ymin"), hi = body.querySelector("#pb-ymax");
      function paintYears() {
        var a = parseInt(lo.value), b = parseInt(hi.value);
        var mn = Math.min(a, b), mx = Math.max(a, b);
        body.querySelector("#pb-year-val").textContent = mn + " – " + mx;
        var fill = body.querySelector("#pb-yfill");
        if (fill) { fill.style.left = ((mn - 2000) / 26) * 100 + "%"; fill.style.right = ((2026 - mx) / 26) * 100 + "%"; }
      }
      lo.addEventListener("input", paintYears); hi.addEventListener("input", paintYears); paintYears();
      function recompute() {
        var wtuIn = [].slice.call(body.querySelectorAll(".pb-wtu"));
        var wbIn = [].slice.call(body.querySelectorAll(".pb-wb"));
        var tT = parseInt(body.querySelector("#pb-total-tu").value) || 0;
        var tB = parseInt(body.querySelector("#pb-total-b").value) || 0;
        var qtu = quotas(wtuIn.map(function (x) { return Math.max(0, parseInt(x.value) || 0); }), tT);
        var qb = quotas(wbIn.map(function (x) { return Math.max(0, parseInt(x.value) || 0); }), tB);
        body.querySelectorAll(".pb-ctu").forEach(function (td, i) { td.textContent = qtu[i].toFixed(1); });
        body.querySelectorAll(".pb-cb").forEach(function (td, i) { td.textContent = qb[i].toFixed(1); });
      }
      body.querySelectorAll(".pb-wtu, .pb-wb, #pb-total-tu, #pb-total-b").forEach(function (inp) {
        inp.addEventListener("input", recompute);
      });
      recompute();
      body.querySelector("#pb-build").onclick = build;
    }

    async function fetchCat(kind, cat, n, common, seen) {
      if (n <= 0) return [];
      var out = [];
      try {
        var r = await ctx.api.get("/api/" + kind + "/query?random=1&limit=" + Math.min(200, n * 2) +
          "&categories=" + encodeURIComponent(cat) + common);
        (r.rows || []).forEach(function (q) {
          if (out.length < n && !seen[q.id]) { seen[q.id] = 1; out.push(q); }
        });
      } catch (e) {}
      return out;
    }

    async function build() {
      var st = body.querySelector("#pb-status");
      st.textContent = "Building…";
      var diffs = [].slice.call(body.querySelectorAll(".pb-diff-cb:checked")).map(function (c) { return c.value; });
      var ya = parseInt(body.querySelector("#pb-ymin").value), yb = parseInt(body.querySelector("#pb-ymax").value);
      var ymin = Math.min(ya, yb), ymax = Math.max(ya, yb);
      var common = (diffs.length ? "&difficulties=" + diffs.join(",") : "") +
        (ymin > 2000 ? "&yearMin=" + ymin : "") + (ymax < 2026 ? "&yearMax=" + ymax : "");
      var wtuIn = [].slice.call(body.querySelectorAll(".pb-wtu"));
      var wbIn = [].slice.call(body.querySelectorAll(".pb-wb"));
      var tT = parseInt(body.querySelector("#pb-total-tu").value) || 0;
      var tB = parseInt(body.querySelector("#pb-total-b").value) || 0;
      var ctu = allocRandom(wtuIn.map(function (x) { return Math.max(0, parseInt(x.value) || 0); }), tT);
      var cb = allocRandom(wbIn.map(function (x) { return Math.max(0, parseInt(x.value) || 0); }), tB);
      var wantTU = wtuIn.map(function (inp, i) { return { cat: inp.dataset.cat, n: ctu[i] }; });
      var wantB = wbIn.map(function (inp, i) { return { cat: inp.dataset.cat, n: cb[i] }; });
      var tus = [], bos = [], seenTU = {}, seenB = {}, short = [];

      async function gather(kind, want, into, seen) {
        var deficit = 0;
        for (var i = 0; i < want.length; i++) {
          var got = await fetchCat(kind, want[i].cat, want[i].n, common, seen);
          got.forEach(function (q) { into.push(q); });
          if (got.length < want[i].n) {
            deficit += want[i].n - got.length;
            short.push(want[i].cat + " (" + (kind === "tossups" ? "TU" : "B") + " −" + (want[i].n - got.length) + ")");
          }
        }
        // top up the shortfall from the biggest remaining categories so the
        // packet still hits the requested total
        for (var j = 0; deficit > 0 && j < want.length; j++) {
          if (want[j].n <= 0) continue;
          var extra = await fetchCat(kind, want[j].cat, deficit, common, seen);
          extra.forEach(function (q) { into.push(q); });
          deficit -= extra.length;
        }
      }
      await gather("tossups", wantTU, tus, seenTU);
      await gather("bonuses", wantB, bos, seenB);

      if (!tus.length && !bos.length) { st.textContent = "Nothing matched — loosen the filters."; return; }
      packet = { tossups: shuffle(tus), bonuses: shuffle(bos) };
      packet.shortNote = short.length ? "Short on " + short.join(", ") : "";
      renderChooser();
    }

    function exportPacket() {
      if (!packet) return;
      var d = new Date();
      function p2(n) { return (n < 10 ? "0" : "") + n; }
      var stamp = d.getFullYear() + p2(d.getMonth() + 1) + p2(d.getDate()) + "-" + p2(d.getHours()) + p2(d.getMinutes());
      var data = {
        format: "offlinequiz-packet", version: 1,
        name: "Packet " + stamp, created: d.toISOString(),
        tossups: packet.tossups, bonuses: packet.bonuses,
      };
      var blob = new Blob([JSON.stringify(data, null, 1)], { type: "application/json" });
      var a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = "packet-" + stamp + ".json";
      document.body.appendChild(a); a.click();
      setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500);
    }

    function renderChooser() {
      stopReveal(); stopPbTimer(); returnPanel(); run = null; pbView = "chooser";
      body.innerHTML = shell(
        '<div class="pb-wrap"><div class="pb-card" style="text-align:center">' +
          '<div class="pb-built">' + packet.tossups.length + " tossups · " + packet.bonuses.length + " bonuses</div>" +
          (packet.shortNote ? '<div class="text-muted" style="font-size:12px">' + esc(packet.shortNote) + "</div>" : "") +
          '<div class="pb-row" style="justify-content:center">' +
            (packet.tossups.length ? '<button class="btn btn-primary" id="pb-run-tu">Run tossups</button>' : "") +
            (packet.bonuses.length ? '<button class="btn btn-primary" id="pb-run-b">Run bonuses</button>' : "") +
            (packet.tossups.length && packet.bonuses.length ? '<button class="btn btn-primary" id="pb-run-both">Run TU + Bonus</button>' : "") +
            '<button class="btn" id="pb-view">View all</button>' +
            '<button class="btn" id="pb-export">Export file</button>' +
            '<button class="btn btn-ghost" id="pb-back">New packet</button>' +
          "</div></div></div>");
      returnPanel();
      var t = body.querySelector("#pb-run-tu"); if (t) t.onclick = function () { startRun("tu"); };
      var b = body.querySelector("#pb-run-b"); if (b) b.onclick = function () { startRun("b"); };
      var tb = body.querySelector("#pb-run-both"); if (tb) tb.onclick = function () { startRun("both"); };
      body.querySelector("#pb-view").onclick = renderView;
      body.querySelector("#pb-export").onclick = exportPacket;
      body.querySelector("#pb-back").onclick = renderBuilder;
    }

    // ── view all: TU BO TU BO ──
    function renderView() {
      returnPanel(); pbView = "view";
      var items = interleave("both");
      // Number like a real packet: Tossup 1, Bonus 1, Tossup 2… — each type
      // keeps its own count, so uneven TU/B totals still read right.
      var tuN = 0, boN = 0;
      items.forEach(function (it) { it._label = it.type === "tu" ? "Tossup " + (++tuN) : "Bonus " + (++boN); });
      body.innerHTML = shell(
        '<div class="pb-wrap">' +
          '<div class="pb-row"><button class="btn btn-sm btn-ghost" id="pb-back">← Packet</button>' +
          '<button class="btn btn-sm btn-ghost" id="pb-compact">Compact all</button>' +
          '<button class="btn btn-sm btn-ghost" id="pb-expand">Expand all</button></div>' +
          '<div class="pb-list">' +
          items.map(function (it, i) {
            var q = it.q;
            var head = '<div class="qcard-head"><span class="qcard-chev" aria-hidden="true"></span>' +
              '<span class="qcard-meta"><span>' + it._label + "</span><span>" + esc(q.category || "") + (q.subcategory ? " / " + esc(q.subcategory) : "") + "</span><span>Diff " + esc(String(q.difficulty != null ? q.difficulty : "?")) + "</span></span>" +
              '<span class="qcard-side"><span class="star-btn save-plus pb-save" data-qid="' + esc(q.id) + '" data-type="' + (it.type === "tu" ? "tossup" : "bonus") + '" title="Save to review / folders">+</span><span class="qb-star" data-qid="' + esc(q.id) + '" data-type="' + (it.type === "tu" ? "tossup" : "bonus") + '">☆</span></span></div>';
            if (it.type === "tu") {
              return '<div class="qcard expanded" data-i="' + i + '">' + head +
                '<div class="qcard-answer">Answer: <span class="ans">' + ansHtml(q.answer, q.answer_sanitized) + "</span></div>" +
                '<div class="qcard-body"><div class="qcard-text">' + esc(q.question_sanitized || "") + "</div></div></div>";
            }
            var parts = [], answers = [], rawAnswers = [];
            try { parts = JSON.parse(q.parts_sanitized || "[]"); } catch (e) {}
            try { answers = JSON.parse(q.answers_sanitized || "[]"); } catch (e) {}
            try { rawAnswers = JSON.parse(q.answers || "[]"); } catch (e) {}
            return '<div class="qcard expanded" data-i="' + i + '">' + head +
              '<div class="qcard-body"><div class="qcard-text">' + esc(q.leadin_sanitized || "") + "</div>" +
              parts.map(function (pt, k) {
                return '<div class="qcard-part">[10] ' + esc(pt) + '<br><span class="ans">ANSWER: ' + ansHtml(rawAnswers[k], answers[k] || "") + "</span></div>";
              }).join("") + "</div></div>";
          }).join("") +
        "</div></div>");
      returnPanel();
      body.querySelectorAll(".pb-save").forEach(function (b) {
        b.addEventListener("click", function (e) {
          e.stopPropagation();
          var it = items[parseInt(b.closest(".qcard").getAttribute("data-i"))];
          if (it && ctx.host && ctx.host.openSaveMenu) ctx.host.openSaveMenu(it.q, it.type === "tu" ? "tossup" : "bonus", b);
        });
      });
      body.querySelector("#pb-back").onclick = renderChooser;
      body.querySelector("#pb-compact").onclick = function () { body.querySelectorAll(".qcard").forEach(function (c) { c.classList.add("compact"); c.classList.remove("expanded"); }); };
      body.querySelector("#pb-expand").onclick = function () { body.querySelectorAll(".qcard").forEach(function (c) { c.classList.remove("compact"); c.classList.add("expanded"); }); };
    }

    function interleave(mode) {
      var items = [];
      if (mode === "tu") packet.tossups.forEach(function (q) { items.push({ type: "tu", q: q }); });
      else if (mode === "b") packet.bonuses.forEach(function (q) { items.push({ type: "b", q: q }); });
      else {
        var n = Math.max(packet.tossups.length, packet.bonuses.length);
        for (var i = 0; i < n; i++) {
          if (packet.tossups[i]) items.push({ type: "tu", q: packet.tossups[i] });
          if (packet.bonuses[i]) items.push({ type: "b", q: packet.bonuses[i] });
        }
      }
      return items;
    }

    // ── run ──
    function startRun(mode) {
      run = { items: interleave(mode), idx: 0, score: 0, done: false };
      pbView = "run";
      serve();
    }
    function stopReveal() { if (revealTimer) { clearInterval(revealTimer); revealTimer = null; } }

    function serve() {
      stopReveal(); stopPbTimer(); returnPanel(); buzzed = false; fullyRead = false; revealI = 0;
      if (!run || run.idx >= run.items.length) {
        body.innerHTML = shell('<div class="pb-wrap"><div class="pb-card" style="text-align:center">' +
          '<div class="pb-built">Packet finished — score ' + (run ? run.score : 0) + "</div>" +
          '<div class="pb-row" style="justify-content:center"><button class="btn btn-primary" id="pb-back">Back to packet</button></div></div></div>');
        borrowPanel();
        body.querySelector("#pb-back").onclick = renderChooser;
        return;
      }
      var it = run.items[run.idx];
      var headBar = '<div class="pb-row"><span class="pill">' + (run.idx + 1) + "/" + run.items.length + '</span><span class="pill pill-green">Score: ' + run.score + '</span>' +
        '<button class="btn btn-sm btn-ghost" id="pb-skip">[S] Skip</button><button class="btn btn-sm btn-ghost" id="pb-quit">End run</button></div>';
      if (it.type === "tu") {
        body.innerHTML = shell('<div class="pb-wrap">' + headBar +
          '<div class="pb-card"><div class="question-text" id="pb-qtext"></div>' +
          '<div class="buzz-hints hidden" id="pb-bwin">Question finished \u2014 buzz now! <span id="pb-bwin-left"></span></div>' +
          '<div class="buzz-area hidden" id="pb-buzz"><div class="buzz-prompt"><span class="prompt-symbol">&gt;</span>' +
          '<input type="text" id="pb-input" placeholder="type your answer\u2026" autocomplete="off" autocorrect="off" spellcheck="false"></div>' +
          '<div class="buzz-hints" id="pb-ans-hint"><span id="pb-ans-left"></span></div></div>' +
          '<div class="result-area hidden" id="pb-result"></div></div></div>');
        borrowPanel();
        beginReveal(readText(it.q.question_sanitized || it.q.question));
      } else {
        var parts = [];
        try { parts = JSON.parse(it.q.parts_sanitized || "[]"); } catch (e) {}
        body.innerHTML = shell('<div class="pb-wrap">' + headBar +
          '<div class="pb-card"><div class="question-text" style="flex:0 0 auto">' + esc(readText(it.q.leadin_sanitized)) + "</div>" +
          parts.map(function (pt, k) {
            return '<div class="pb-part' + (k > 0 ? " pb-hidden" : "") + '" data-k="' + k + '">' +
              '<div class="bonus-part-text">[10] ' + esc(readText(pt)) + "</div>" +
              '<div class="buzz-prompt"><span class="prompt-symbol">&gt;</span><input type="text" class="pb-binput" data-k="' + k + '" placeholder="answer for part ' + (k + 1) + '\u2026"' + (k > 0 ? " disabled" : "") + ' autocomplete="off" autocorrect="off" spellcheck="false"></div>' +
              '<div class="pb-bans hidden" data-k="' + k + '"></div></div>';
          }).join("") +
          '<div class="result-area hidden" id="pb-result"></div></div></div>');
        borrowPanel();
        wireBonus(it.q, parts.length);
      }
      body.querySelector("#pb-skip").onclick = function () { run.idx++; serve(); };
      body.querySelector("#pb-quit").onclick = renderChooser;
    }

    function paintTU(text) {
      var el = body.querySelector("#pb-qtext"); if (!el) return;
      var pre = esc(text.slice(0, revealI));
      var rest = esc(text.slice(revealI).replace(/\S/g, "·"));
      el.innerHTML = '<span class="revealed">' + pre + '</span><span class="unrevealed" aria-hidden="true">' + rest + "</span>";
    }
    function beginReveal(text) {
      run._text = text;
      var sp = cfg().revealSpeed; if (typeof sp !== "number") sp = 50;
      if (sp === 0) { revealI = text.length; fullyRead = true; paintTU(text); startBuzzWin(); return; }
      paintTU(text);
      revealTimer = setInterval(function () {
        if (buzzed) return;
        revealI++;
        if (revealI >= text.length) { revealI = text.length; fullyRead = true; stopReveal(); startBuzzWin(); }
        paintTU(text);
      }, Math.max(8, sp));
    }
    // Question finished — the practice panel's Buzz Window slider gives the
    // seconds to buzz before the question goes dead (0 = unlimited).
    function startBuzzWin() {
      var secs = panelVal("panel-buzz-window", 10);
      if (secs <= 0 || buzzed) return;
      var hint = body.querySelector("#pb-bwin");
      if (hint) { hint.classList.remove("hidden"); countdown(body.querySelector("#pb-bwin-left"), secs); }
      pbTimer = setTimeout(function () {
        if (buzzed || !run) return;
        buzzed = true; stopPbTimer();
        if (hint) hint.classList.add("hidden");
        var it = run.items[run.idx];
        var res = body.querySelector("#pb-result"); if (!res) return;
        res.classList.remove("hidden");
        res.innerHTML = '<div class="result-banner incorrect">TIME \u2014 no buzz (0)</div>' +
          '<div class="result-answer">Answer: <span class="ans">' + ansHtml(it.q.answer, it.q.answer_sanitized) + "</span></div>" +
          '<div class="result-next"><button class="btn btn-primary" id="pb-next">[N] Next</button></div>';
        body.querySelector("#pb-next").onclick = function () { run.idx++; serve(); };
      }, secs * 1000);
    }
    function buzz() {
      if (buzzed || !run) return;
      var it = run.items[run.idx];
      if (!it || it.type !== "tu") return;
      buzzed = true; stopReveal(); stopPbTimer();
      var bw = body.querySelector("#pb-bwin"); if (bw) bw.classList.add("hidden");
      var bz = body.querySelector("#pb-buzz"); if (!bz) return;
      bz.classList.remove("hidden");
      var inp = body.querySelector("#pb-input"); inp.focus();
      var settled = false;
      async function settle(text) {
        if (settled) return; settled = true;
        stopPbTimer(); inp.disabled = true;
        var verdict = "reject";
        if (text) {
          try {
            var r = await ctx.api.post("/api/evaluate-tossup", { questionId: it.q.id, answer: text, strictness: cfg().strictness || 10, buzzPosition: revealI });
            verdict = r.status;
          } catch (err) {}
        }
        var ok = verdict === "accept" || verdict === "prompt";
        var pts = ok ? 10 : (fullyRead ? 0 : -5);
        run.score += pts;
        revealI = (run._text || "").length; paintTU(run._text || "");
        bz.classList.add("hidden");
        var res = body.querySelector("#pb-result");
        res.classList.remove("hidden");
        res.innerHTML = '<div class="result-banner ' + (ok ? "correct" : "incorrect") + '">' + (ok ? "CORRECT +" + pts : (text ? "" : "TIME \u2014 ")) + (ok ? "" : (pts < 0 ? "NEG " + pts : "INCORRECT (0)")) + "</div>" +
          '<div class="result-answer">Answer: <span class="ans">' + ansHtml(it.q.answer, it.q.answer_sanitized) + '</span> <span class="star-btn save-plus pb-rsave" title="Save to review / folders">+</span></div>' +
          '<div class="result-next"><button class="btn btn-primary" id="pb-next">[N] Next</button></div>';
        var rsv = res.querySelector(".pb-rsave"); if (rsv) rsv.onclick = function () { if (ctx.host && ctx.host.openSaveMenu) ctx.host.openSaveMenu(it.q, "tossup", rsv); };
        body.querySelector("#pb-next").onclick = function () { run.idx++; serve(); };
      }
      // Buzz Answer Timer (practice panel slider): seconds to answer (0 = unlimited).
      var secs = panelVal("panel-buzz-timer", 10);
      if (secs > 0) {
        countdown(body.querySelector("#pb-ans-left"), secs);
        pbTimer = setTimeout(function () { settle(""); }, secs * 1000);
      }
      inp.addEventListener("keydown", function (e) {
        if (e.key !== "Enter") return;
        e.preventDefault();
        settle(inp.value.trim());
      });
    }

    function wireBonus(q, nParts) {
      var answers = [], rawAnswers = [];
      try { answers = JSON.parse(q.answers_sanitized || "[]"); } catch (e) {}
      try { rawAnswers = JSON.parse(q.answers || "[]"); } catch (e) {}
      var got = 0, doneParts = 0;
      body.querySelectorAll(".pb-binput").forEach(function (inp) {
        inp.addEventListener("keydown", async function (e) {
          if (e.key !== "Enter") return;
          e.preventDefault(); inp.disabled = true;
          var k = parseInt(inp.dataset.k);
          var ok = false;
          try {
            var r = await ctx.api.post("/api/evaluate-answer", { answerline: rawAnswers[k] || "", sanitized: answers[k] || "", answer: inp.value.trim(), strictness: cfg().strictness || 10 });
            ok = r.status === "accept" || r.status === "prompt";
          } catch (err) {}
          if (ok) { got++; run.score += 10; }
          var ans = body.querySelector('.pb-bans[data-k="' + k + '"]');
          ans.classList.remove("hidden");
          ans.innerHTML = (ok ? '<span class="bonus-verdict correct">✓ </span>' : '<span class="bonus-verdict incorrect">✗ </span>') + 'ANSWER: <span class="ans">' + ansHtml(rawAnswers[k], answers[k] || "") + "</span>";
          doneParts++;
          if (k + 1 < nParts) {
            var nx = body.querySelector('.pb-part[data-k="' + (k + 1) + '"]');
            nx.classList.remove("pb-hidden");
            var ni = nx.querySelector(".pb-binput"); ni.disabled = false; ni.focus();
          } else {
            var res = body.querySelector("#pb-result");
            res.classList.remove("hidden");
            res.innerHTML = '<div class="result-banner ' + (got > 0 ? "correct" : "incorrect") + '">BONUS: ' + (got * 10) + "/30</div>" +
              '<div class="result-next"><button class="btn btn-primary" id="pb-next">[N] Next</button></div>';
            body.querySelector("#pb-next").onclick = function () { run.idx++; serve(); };
          }
        });
      });
      var first = body.querySelector('.pb-binput[data-k="0"]'); if (first) first.focus();
    }

    function onKey(e) {
      if (!active() || !run) return;
      var t = e.target.tagName; if (t === "INPUT" || t === "TEXTAREA") return;
      if (e.code === "Space") { e.preventDefault(); buzz(); }
      else if (e.key === "n" || e.key === "N") {
        e.preventDefault();
        var nx = body.querySelector("#pb-next"); if (nx) nx.click();
      } else if (e.key === "s" || e.key === "S") {
        e.preventDefault();
        var sk = body.querySelector("#pb-skip"); if (sk) sk.click();
      }
    }
    document.addEventListener("keydown", onKey);
    ctx._cleanup = function () { stopReveal(); document.removeEventListener("keydown", onKey); };

    ctx.toast("Packet Builder enabled.");
  }
