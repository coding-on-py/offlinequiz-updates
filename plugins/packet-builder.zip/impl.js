function __qbMain(ctx) {
    var body = null, page = null;
    var packet = null;          // { tossups: [], bonuses: [], shortNote, built }
    var run = null;             // { items: [{type,q}], idx, score, tally, ... }
    var revealTimer = null, revealI = 0, buzzed = false, fullyRead = false;

    function esc(s) { return (s == null ? "" : String(s)).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
    function ansHtml(raw, fallback) {
      var src = (raw && String(raw).trim()) ? String(raw) : String(fallback || "");
      var html = esc(src).replace(/&lt;(\/?)(b|u|i|em|strong)&gt;/gi, "<$1$2>");
      var d = document.createElement("div"); d.innerHTML = html; return d.innerHTML;
    }
    function plainAnswer(raw, fallback) {
      var d = document.createElement("div"); d.innerHTML = ansHtml(raw, fallback);
      return (d.textContent || "").replace(/\s+/g, " ").trim();
    }
    function primaryAnswer(raw, sani) {
      var t = "";
      try { if (ctx.host && ctx.host.extractPrimaryAnswer) t = ctx.host.extractPrimaryAnswer(raw || "", sani || "") || ""; } catch (e) { t = ""; }
      if (!t) t = String(sani || plainAnswer(raw, "")).replace(/\s*[\[(].*$/, "").trim();
      return t || "?";
    }
    function shuffle(a) { for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)); var t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
    function cfg() { try { return ctx.host.getPracticeConfig() || {}; } catch (e) { return {}; } }
    function jsonArr(v) { if (Array.isArray(v)) return v; try { var a = JSON.parse(v || "[]"); return Array.isArray(a) ? a : []; } catch (e) { return []; } }
    // A record's text as the practice screen reads it (moderator notes hidden,
    // pronunciation guides per the user's setting) — kind: "question" |
    // "leadin" | "part" (+ index). Older bases: the plain copy + hidePron.
    function plainText(q, kind, part) {
      var t = null;
      try { if (ctx.host && ctx.host.questionText) t = ctx.host.questionText(q, kind, part); } catch (e) { t = null; }
      if (t == null) {
        t = kind === "leadin" ? (q.leadin_sanitized || q.leadin)
          : kind === "part" ? (jsonArr(q.parts_sanitized)[part] || jsonArr(q.parts)[part])
          : (q.question_sanitized || q.question);
        t = String(t || "");
        var c = cfg();
        if (c.hidePron && ctx.host && ctx.host.stripPronunciations) t = ctx.host.stripPronunciations(t);
      }
      return String(t || "");
    }
    function readText(q, kind, part) {
      return plainText(q, kind, part).replace(/\(\*\)/g, "").replace(/\s+/g, " ").trim();
    }
    function powerMarks(h) {
      var mark = '<span class="power-mark-inline">(*)</span>', i = h.indexOf("(*)");
      if (i < 0) return h;
      return '<strong class="pre-power">' + h.slice(0, i) + "</strong>" + mark + h.slice(i + 3).replace(/\(\*\)/g, mark);
    }
    // Per-part point values (any number of parts; 10 each when none stated).
    function bonusVals(q, n) {
      var bv = null;
      try { if (ctx.host && ctx.host.bonusValues) bv = ctx.host.bonusValues(q); } catch (e) { bv = null; }
      var vals = bv && Array.isArray(bv.values) ? bv.values.slice() : jsonArr(q.point_values);
      var out = [];
      for (var i = 0; i < n; i++) out.push(Number(vals[i]) > 0 ? Number(vals[i]) : 10);
      return { values: out, max: out.reduce(function (s, v) { return s + v; }, 0) };
    }
    // Buzz index in the displayed text → index in question_sanitized AS
    // STORED (with its "(*)"), the coordinates the server judges and records.
    function judgePos(q, shown, pos) {
      var orig = String(q.question_sanitized || q.question || "");
      try { if (ctx.host && ctx.host.mapDisplayPos) return ctx.host.mapDisplayPos(shown, orig, pos); } catch (e) {}
      return pos;
    }

    var IC = {
      play: '<path d="M7 4l13 8-13 8z"/>',
      left: '<path d="M15 6l-6 6 6 6"/>',
      download: '<path d="M12 4v11M7 10l5 5 5-5M4 20h16"/>',
      list: '<path d="M8 6h12M8 12h12M8 18h12M4 6h.01M4 12h.01M4 18h.01"/>',
      shuffle: '<path d="M4 7h3c5 0 5 10 10 10h3M17 14l3 3-3 3M4 17h3c1.8 0 3-1.3 4-3M13 10c1-1.7 2.2-3 4-3h3M17 4l3 3-3 3"/>',
      sliders: '<path d="M4 6h10M18 6h2M4 12h4M12 12h8M4 18h12"/><circle cx="16" cy="6" r="2"/><circle cx="10" cy="12" r="2"/><circle cx="18" cy="18" r="2"/>',
      reset: '<path d="M4 12a8 8 0 1 0 2.3-5.7M4 4v5h5"/>',
      x: '<path d="M6 6l12 12M18 6L6 18"/>',
    };
    function ic(name, size) {
      var s = size || 16;
      return '<svg width="' + s + '" height="' + s + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (IC[name] || "") + "</svg>";
    }
    var ROOT_COLOR = { "Literature": "#bc8cff", "Science and Math": "#58a6ff", "Fine Arts": "#f778ba", "History": "#e3b341", "Geography": "#56d364", "Mythology": "#ffa657", "Pop Culture Sports": "#ff7b72", "Social Science": "#3dd6a3", "Philosophy": "#39c5cf", "Theology": "#8e9bff", "Current Events": "#c9d16b", "Miscellaneous": "#8b949e" };
    function rootOf(q) { return String(q.category_path || q.category || "").split(" > ")[0] || "Other"; }

    page = ctx.registerPage({
      id: "builder", navLabel: "Packet Builder", title: "Packet Builder",
      onShow: function (el) {
        body = el;
        if (!body.querySelector(".pb-page, .pb-layout")) renderBuilder();
        // Timers stopped when the page was left: read the current item again —
        // or the next one when this one was already buzzed / answered.
        else if (pbView === "run" && run) { if (run.touched[run.idx]) run.idx++; serve(); }
      },
      onHide: function () { stopReveal(); stopPbTimer(); returnPanel(); },
    });
    function active() { return page && page.screenEl && page.screenEl.classList.contains("active"); }
    ctx.on("screen:change", function () { setTimeout(function () { if (!active()) { stopReveal(); stopPbTimer(); returnPanel(); } }, 0); });

    // Esc inside the packet goes UP one level (view/run → the packet), not home.
    var pbView = "builder";
    ctx.onBack(function () {
      if (!active()) return false;
      if (pbView === "view" || pbView === "run") { renderChooser(); return true; }
      return false;
    });

    // While a packet runs, the practice settings that apply to it (reading
    // speed, buzz window, answer and bonus-part time, strictness, hide guides /
    // notes) open beside it: the REAL practice panel is borrowed (and returned
    // before every innerHTML wipe — see the borrowed-panel rule).
    var borrowedPanel = null, panelHome = null;
    var settingsOpen = !!ctx.storage.get("settingsOpen");
    function borrowPanel() {
      var slot = body.querySelector(".pb-side"); if (!slot) return;
      try { if (ctx.host && ctx.host.ensureFiltersLoaded) ctx.host.ensureFiltersLoaded(); } catch (e) {}
      var panel = document.getElementById("filters-panel"); if (!panel) return;
      if (!panelHome) panelHome = { parent: panel.parentNode, next: panel.nextSibling };
      panel.classList.add("pb-borrowed");
      slot.appendChild(panel);
      borrowedPanel = panel;
    }
    function returnPanel() {
      if (!borrowedPanel) return;
      borrowedPanel.classList.remove("pb-borrowed");
      if (panelHome && panelHome.parent) panelHome.parent.insertBefore(borrowedPanel, panelHome.next && panelHome.next.parentNode === panelHome.parent ? panelHome.next : null);
      borrowedPanel = null;
    }
    function syncSettings() {
      var lay = body.querySelector(".pb-layout"), btn = body.querySelector("#pb-settings");
      if (btn) btn.setAttribute("aria-pressed", String(settingsOpen));
      if (!lay) return;
      lay.classList.toggle("pb-side-open", settingsOpen);
      if (settingsOpen) borrowPanel(); else returnPanel();
    }
    // Read a practice-panel slider live (works whether or not it is borrowed).
    function panelVal(id, dflt) {
      var el = document.getElementById(id);
      var v = el ? parseInt(el.value) : NaN;
      return isNaN(v) ? dflt : v;
    }
    var pbTimer = null, pbTick = null;
    function stopPbTimer() {
      if (pbTimer) { clearTimeout(pbTimer); pbTimer = null; }
      if (pbTick) { clearInterval(pbTick); pbTick = null; }
    }
    function countdown(el, secs) {
      if (!el) return;
      var end = Date.now() + secs * 1000;
      function paint() { el.textContent = Math.max(0, Math.ceil((end - Date.now()) / 1000)) + "s"; }
      paint();
      pbTick = setInterval(paint, 200);
    }

    // ── builder form: NAQT-weighted category shares ──
    // NAQT's High School Subject Distribution, top-level weights (TU / B) —
    // the 12 roots of the category tree are exactly NAQT's top-level nodes.
    var NAQT_W = {
      "Literature": [38, 38], "Science and Math": [54, 54], "Fine Arts": [20, 20],
      "History": [46, 46], "Geography": [19, 19], "Mythology": [6, 6],
      "Pop Culture Sports": [16, 16], "Social Science": [6, 6], "Philosophy": [3, 3],
      "Theology": [4, 4], "Current Events": [15, 15], "Miscellaneous": [10, 16],
    };
    // QBReader-era root names (an older base without the tree) → new roots.
    var OLD_ROOT = { "Science": "Science and Math", "Religion": "Theology", "Pop Culture": "Pop Culture Sports", "Trash": "Pop Culture Sports", "Other Academic": "Miscellaneous" };
    var YEAR_MIN = 2000, YEAR_MAX = 2026;
    var DEFAULT_FORM = { tu: 20, b: 20, diffs: [2, 3, 4, 5], ymin: 2010, ymax: YEAR_MAX, w: {} };
    function loadForm() {
      var f = ctx.storage.get("form");
      f = Object.assign({}, DEFAULT_FORM, f && typeof f === "object" ? f : {});
      if (!Array.isArray(f.diffs)) f.diffs = DEFAULT_FORM.diffs.slice();
      if (!f.w || typeof f.w !== "object") f.w = {};
      return f;
    }
    function defaultW(name) { return NAQT_W[name] || NAQT_W[OLD_ROOT[name]] || [5, 5]; }
    // Roots of the category tree: value = node id (sent as categories=<id>).
    async function loadRoots() {
      var roots = null;
      try {
        if (ctx.host && ctx.host.getCategoryTree) roots = await ctx.host.getCategoryTree("tossups");
        else roots = (await ctx.api.get("/api/category-tree?type=tossups")).tree;
      } catch (e) { roots = null; }
      if (roots && roots.length) return roots.map(function (r) { return { key: r.id, name: r.name }; });
      try {
        return ((await ctx.api.get("/api/categories?type=tossups")).categories || []).map(function (c) { return { key: c.category, name: c.category }; });
      } catch (e) { return []; }
    }
    function quotas(weights, total) {
      var sum = weights.reduce(function (s, w) { return s + w; }, 0);
      if (sum <= 0 || total <= 0) return weights.map(function () { return 0; });
      return weights.map(function (w) { return (w / sum) * total; });
    }
    // Randomized apportionment with a balance guard: every category gets the
    // floor of its fair share for sure, and the leftover seats are drawn at
    // random weighted by the fractional remainders (no category ever exceeds
    // its share rounded up). Small categories like Theology (~0.3 of a
    // 20-tossup packet) land in roughly a third of built packets instead of
    // being deterministically rounded to 0.
    function allocRandom(weights, total) {
      var q = quotas(weights, total);
      var out = q.map(function (x) { return Math.floor(x); });
      var rem = total - out.reduce(function (s, n) { return s + n; }, 0);
      var pool = q.map(function (x, i) { return { i: i, f: x - Math.floor(x) }; })
        .filter(function (x) { return x.f > 0; });
      while (rem > 0 && pool.length) {
        var tot = pool.reduce(function (s, x) { return s + x.f; }, 0);
        var r = Math.random() * tot, acc = 0, pick = 0;
        for (var k = 0; k < pool.length; k++) { acc += pool[k].f; if (r <= acc) { pick = k; break; } }
        out[pool[pick].i]++; pool.splice(pick, 1); rem--;
      }
      for (var j = 0; rem > 0 && weights.some(function (w) { return w > 0; }); j = (j + 1) % weights.length) {
        if (weights[j] > 0) { out[j]++; rem--; }
      }
      return out;
    }
    function clampInt(v, lo, hi, dflt) { var n = parseInt(v, 10); if (isNaN(n)) return dflt; return Math.max(lo, Math.min(hi, n)); }

    var CATS = null, savePbForm = null;
    async function renderBuilder() {
      stopReveal(); stopPbTimer(); returnPanel(); run = null; pbView = "builder";
      body.innerHTML = '<div class="pb-page"><div class="pb-loading">' + (ctx.loadingBarHtml ? ctx.loadingBarHtml("Loading categories…") : "Loading…") + "</div></div>";
      if (!CATS || !CATS.length) CATS = await loadRoots();
      if (!active() && !body.isConnected) return;
      if (!CATS.length) { body.innerHTML = '<div class="pb-page"><div class="db-empty">Couldn’t load categories</div></div>'; return; }
      var f = loadForm();
      var diffBoxes = "";
      for (var d = 0; d <= 10; d++) diffBoxes += '<label title="Difficulty ' + d + '"><input type="checkbox" class="pb-diff-cb" value="' + d + '"' + (f.diffs.indexOf(d) >= 0 ? " checked" : "") + "><span>" + d + "</span></label>";
      var rows = CATS.map(function (c) {
        var w = f.w[c.name] || defaultW(c.name);
        var col = ROOT_COLOR[c.name] || ROOT_COLOR[OLD_ROOT[c.name]] || "#8b949e";
        return '<div class="pb-wrow" data-cat="' + esc(c.key) + '">' +
          '<span class="pb-wname"><span class="pb-dot" style="--c:' + col + '"></span><span class="pb-wtext"><b>' + esc(c.name) + '</b><small class="num"><span class="pb-ctu">0</span> TU · <span class="pb-cb">0</span> B</small></span></span>' +
          '<input type="number" inputmode="numeric" class="mode-input pb-wtu" aria-label="' + esc(c.name) + ' tossup weight" data-cat="' + esc(c.key) + '" data-name="' + esc(c.name) + '" min="0" max="999" value="' + w[0] + '">' +
          '<input type="number" inputmode="numeric" class="mode-input pb-wb" aria-label="' + esc(c.name) + ' bonus weight" data-cat="' + esc(c.key) + '" data-name="' + esc(c.name) + '" min="0" max="999" value="' + w[1] + '">' +
          "</div>";
      }).join("");
      body.innerHTML =
        '<div class="pb-page pb-builder">' +
          '<section class="pb-card pb-setup">' +
            '<h2 class="pb-h">Packet</h2>' +
            '<div class="pb-size">' +
              '<label class="ifield"><span>Tossups</span><input type="number" inputmode="numeric" id="pb-total-tu" min="0" max="200" value="' + f.tu + '"></label>' +
              '<label class="ifield"><span>Bonuses</span><input type="number" inputmode="numeric" id="pb-total-b" min="0" max="200" value="' + f.b + '"></label>' +
            "</div>" +
            '<div class="pb-field"><span class="pb-lbl">Difficulty</span><div class="diff-toggles pb-diffs" role="group" aria-label="Difficulty">' + diffBoxes + "</div></div>" +
            '<div class="pb-field"><span class="pb-lbl">Years <span class="accent-val num" id="pb-year-val"></span></span>' +
              '<div class="dual-range pb-dual"><div class="dual-range-track"><div class="dual-range-fill" id="pb-yfill"></div></div>' +
                '<input type="range" id="pb-ymin" min="' + YEAR_MIN + '" max="' + YEAR_MAX + '" value="' + f.ymin + '" aria-label="From year">' +
                '<input type="range" id="pb-ymax" min="' + YEAR_MIN + '" max="' + YEAR_MAX + '" value="' + f.ymax + '" aria-label="To year"></div>' +
            "</div>" +
            '<div class="pb-buildrow"><button type="button" class="btn btn-primary btn-md pb-buildbtn" id="pb-build">Build packet</button></div>' +
            '<div class="pb-status" id="pb-status" role="status"></div>' +
          "</section>" +
          '<section class="pb-card pb-weights">' +
            '<div class="pb-whead"><h2 class="pb-h">Category weights</h2><button type="button" class="btn btn-ghost btn-sm" id="pb-reset">' + ic("reset", 14) + "Reset</button></div>" +
            '<div class="pb-wcols"><span></span><span>Tossups</span><span>Bonuses</span></div>' +
            '<div class="pb-wlist">' + rows + "</div>" +
          "</section>" +
        "</div>";
      var lo = body.querySelector("#pb-ymin"), hi = body.querySelector("#pb-ymax");
      function paintYears() {
        var a = parseInt(lo.value), b = parseInt(hi.value);
        var mn = Math.min(a, b), mx = Math.max(a, b);
        body.querySelector("#pb-year-val").textContent = mn === mx ? String(mn) : mn + " – " + mx;
        var fill = body.querySelector("#pb-yfill");
        if (fill) { fill.style.left = ((mn - YEAR_MIN) / (YEAR_MAX - YEAR_MIN)) * 100 + "%"; fill.style.right = ((YEAR_MAX - mx) / (YEAR_MAX - YEAR_MIN)) * 100 + "%"; }
      }
      function recompute() {
        var wtuIn = [].slice.call(body.querySelectorAll(".pb-wtu"));
        var wbIn = [].slice.call(body.querySelectorAll(".pb-wb"));
        var tT = parseInt(body.querySelector("#pb-total-tu").value) || 0;
        var tB = parseInt(body.querySelector("#pb-total-b").value) || 0;
        var qtu = quotas(wtuIn.map(function (x) { return Math.max(0, parseInt(x.value) || 0); }), tT);
        var qb = quotas(wbIn.map(function (x) { return Math.max(0, parseInt(x.value) || 0); }), tB);
        body.querySelectorAll(".pb-ctu").forEach(function (el, i) { el.textContent = fmtShare(qtu[i]); });
        body.querySelectorAll(".pb-cb").forEach(function (el, i) { el.textContent = fmtShare(qb[i]); });
      }
      function fmtShare(x) { return x >= 9.95 ? String(Math.round(x)) : (Math.round(x * 10) / 10).toFixed(1).replace(/\.0$/, ""); }
      function persist() {
        if (!body.querySelector("#pb-total-tu")) return;
        var g = loadForm();
        g.tu = clampInt(body.querySelector("#pb-total-tu").value, 0, 200, DEFAULT_FORM.tu);
        g.b = clampInt(body.querySelector("#pb-total-b").value, 0, 200, DEFAULT_FORM.b);
        g.diffs = [].slice.call(body.querySelectorAll(".pb-diff-cb:checked")).map(function (c) { return parseInt(c.value, 10); });
        g.ymin = Math.min(parseInt(lo.value), parseInt(hi.value)); g.ymax = Math.max(parseInt(lo.value), parseInt(hi.value));
        var w = {};
        body.querySelectorAll(".pb-wrow").forEach(function (row) {
          var name = row.querySelector(".pb-wtu").dataset.name;
          var pair = [clampInt(row.querySelector(".pb-wtu").value, 0, 999, 0), clampInt(row.querySelector(".pb-wb").value, 0, 999, 0)];
          var dw = defaultW(name);
          if (pair[0] !== dw[0] || pair[1] !== dw[1]) w[name] = pair;
        });
        g.w = w;
        ctx.storage.set("form", g);
      }
      savePbForm = persist;
      lo.addEventListener("input", paintYears); hi.addEventListener("input", paintYears);
      lo.addEventListener("change", persist); hi.addEventListener("change", persist);
      paintYears();
      body.querySelectorAll(".pb-wtu, .pb-wb, #pb-total-tu, #pb-total-b").forEach(function (inp) {
        inp.addEventListener("input", function () { recompute(); persist(); });
      });
      body.querySelectorAll(".pb-diff-cb").forEach(function (cb) { cb.addEventListener("change", persist); });
      recompute();
      body.querySelector("#pb-reset").onclick = function () {
        body.querySelectorAll(".pb-wrow").forEach(function (row) {
          var dw = defaultW(row.querySelector(".pb-wtu").dataset.name);
          row.querySelector(".pb-wtu").value = dw[0]; row.querySelector(".pb-wb").value = dw[1];
        });
        recompute(); persist();
      };
      body.querySelector("#pb-build").onclick = build;
    }

    async function fetchCat(kind, cat, n, common, seen) {
      if (n <= 0) return [];
      var out = [];
      try {
        var r = await ctx.api.get("/api/" + kind + "/query?random=1&limit=" + Math.min(200, n * 2) +
          "&categories=" + encodeURIComponent(cat) + common);
        (r.rows || []).forEach(function (q) {
          if (out.length < n && !seen[q.id]) { seen[q.id] = 1; out.push(q); }
        });
      } catch (e) {}
      return out;
    }

    // Draw a packet for the form f (the saved builder settings). null = nothing matched.
    async function draw(f) {
      if (!CATS || !CATS.length) CATS = await loadRoots();
      var diffs = (f.diffs || []).map(String);
      var ymin = Math.min(f.ymin, f.ymax), ymax = Math.max(f.ymin, f.ymax);
      var common = (diffs.length ? "&difficulties=" + diffs.join(",") : "") +
        (ymin > YEAR_MIN ? "&yearMin=" + ymin : "") + (ymax < YEAR_MAX ? "&yearMax=" + ymax : "");
      var W = CATS.map(function (c) { return f.w[c.name] || defaultW(c.name); });
      var ctu = allocRandom(W.map(function (w) { return Math.max(0, w[0] | 0); }), f.tu | 0);
      var cb = allocRandom(W.map(function (w) { return Math.max(0, w[1] | 0); }), f.b | 0);
      var wantTU = CATS.map(function (c, i) { return { cat: c.key, name: c.name, n: ctu[i] }; });
      var wantB = CATS.map(function (c, i) { return { cat: c.key, name: c.name, n: cb[i] }; });
      var tus = [], bos = [], short = [];

      async function gather(kind, want, into) {
        var deficit = 0, seen = {};
        for (var i = 0; i < want.length; i++) {
          var got = await fetchCat(kind, want[i].cat, want[i].n, common, seen);
          got.forEach(function (q) { into.push(q); });
          if (got.length < want[i].n) {
            deficit += want[i].n - got.length;
            short.push(want[i].name + " −" + (want[i].n - got.length) + (kind === "tossups" ? " TU" : " B"));
          }
        }
        // top up the shortfall from the other categories so the packet still
        // hits the requested total
        for (var j = 0; deficit > 0 && j < want.length; j++) {
          if (want[j].n <= 0) continue;
          var extra = await fetchCat(kind, want[j].cat, deficit, common, seen);
          extra.forEach(function (q) { into.push(q); });
          deficit -= extra.length;
        }
      }
      await gather("tossups", wantTU, tus);
      await gather("bonuses", wantB, bos);
      if (!tus.length && !bos.length) return null;
      return { tossups: shuffle(tus), bonuses: shuffle(bos), built: new Date(), shortNote: short.length ? "Short: " + short.join(", ") : "" };
    }
    async function build() {
      var st = body.querySelector("#pb-status"), btn = body.querySelector("#pb-build");
      if (!btn || btn.disabled) return;
      if (savePbForm) savePbForm();
      st.textContent = ""; st.classList.remove("err");
      btn.disabled = true; btn.textContent = "Building…";
      var p = await draw(loadForm());
      if (!body.querySelector("#pb-build")) return;   // left meanwhile
      btn.disabled = false; btn.textContent = "Build packet";
      if (!p) { st.textContent = "Nothing matched"; st.classList.add("err"); return; }
      packet = p;
      renderChooser();
    }
    // Rebuild from the packet screen: a fresh draw with the same settings.
    async function rebuild() {
      var btn = body.querySelector("#pb-rebuild");
      if (!btn || btn.disabled) return;
      btn.disabled = true; var lbl = btn.querySelector("span"); if (lbl) lbl.textContent = "Building…";
      var p = await draw(loadForm());
      if (!body.querySelector("#pb-rebuild") || pbView !== "chooser") return;
      if (p) packet = p;
      renderChooser();
    }

    // A readable copy to print or read aloud: tossups, then bonuses.
    function downloadPacket() {
      if (!packet) return;
      var d = packet.built || new Date();
      function p2(n) { return (n < 10 ? "0" : "") + n; }
      var stamp = d.getFullYear() + "-" + p2(d.getMonth() + 1) + "-" + p2(d.getDate()) + " " + p2(d.getHours()) + ":" + p2(d.getMinutes());
      var src = function (q) { return [String(q.category_path || q.category || "").split(" > ").join(" › "), q.set_name ? q.set_name + (q.set_year ? " (" + q.set_year + ")" : "") : ""].filter(Boolean).join(" · "); };
      var L = ["OfflineQuiz packet — built " + stamp, packet.tossups.length + " tossups · " + packet.bonuses.length + " bonuses", ""];
      if (packet.tossups.length) {
        L.push("TOSSUPS", "");
        packet.tossups.forEach(function (q, i) {
          L.push((i + 1) + ". " + plainText(q, "question").replace(/\s+/g, " ").trim());
          L.push("ANSWER: " + plainAnswer(q.answer, q.answer_sanitized));
          var s = src(q); if (s) L.push("<" + s + ">");
          L.push("");
        });
      }
      if (packet.bonuses.length) {
        L.push("BONUSES", "");
        packet.bonuses.forEach(function (q, i) {
          var parts = jsonArr(q.parts_sanitized), answers = jsonArr(q.answers_sanitized), raws = jsonArr(q.answers);
          var bv = bonusVals(q, parts.length);
          L.push((i + 1) + ". " + plainText(q, "leadin").replace(/\s+/g, " ").trim());
          parts.forEach(function (pt, k) {
            L.push("[" + bv.values[k] + "] " + plainText(q, "part", k).replace(/\s+/g, " ").trim());
            L.push("ANSWER: " + plainAnswer(raws[k], answers[k] || ""));
          });
          var s = src(q); if (s) L.push("<" + s + ">");
          L.push("");
        });
      }
      var blob = new Blob([L.join("\n")], { type: "text/plain;charset=utf-8" });
      var a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = "packet-" + stamp.replace(/[: ]/g, "").replace(/-/g, "") + ".txt";
      document.body.appendChild(a); a.click();
      setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500);
    }

    function breakdownHtml() {
      var by = {}, order = [];
      function add(q, k) { var r = rootOf(q); if (!by[r]) { by[r] = [0, 0]; order.push(r); } by[r][k]++; }
      packet.tossups.forEach(function (q) { add(q, 0); });
      packet.bonuses.forEach(function (q) { add(q, 1); });
      var names = (CATS || []).map(function (c) { return c.name; });
      order.sort(function (a, b) { var ia = names.indexOf(a), ib = names.indexOf(b); return (ia < 0 ? 99 : ia) - (ib < 0 ? 99 : ib); });
      return order.map(function (r) {
        return '<span class="pb-chip"><span class="pb-dot" style="--c:' + (ROOT_COLOR[r] || "#8b949e") + '"></span>' + esc(r) + ' <b class="num">' + by[r][0] + "·" + by[r][1] + "</b></span>";
      }).join("");
    }
    function renderChooser() {
      stopReveal(); stopPbTimer(); returnPanel(); run = null; pbView = "chooser";
      if (!packet) { renderBuilder(); return; }
      var nT = packet.tossups.length, nB = packet.bonuses.length;
      var big = [];
      if (nT && nB) big.push('<button type="button" class="btn btn-lg btn-primary" id="pb-run-both">' + ic("play", 18) + "Tossups + bonuses</button>");
      if (nT) big.push('<button type="button" class="btn btn-lg' + (nB ? "" : " btn-primary") + '" id="pb-run-tu">' + (nB ? "" : ic("play", 18)) + "Tossups only</button>");
      if (nB) big.push('<button type="button" class="btn btn-lg' + (nT ? "" : " btn-primary") + '" id="pb-run-b">' + (nT ? "" : ic("play", 18)) + "Bonuses only</button>");
      body.innerHTML =
        '<div class="pb-page pb-chooser">' +
          '<section class="pb-card pb-ready">' +
            '<div class="pb-ready-head">' +
              '<div class="pb-ready-title"><b class="pb-built">' + nT + " tossup" + (nT === 1 ? "" : "s") + " · " + nB + " bonus" + (nB === 1 ? "" : "es") + "</b>" +
                (packet.shortNote ? '<small class="pb-short">' + esc(packet.shortNote) + "</small>" : "") + "</div>" +
              '<button type="button" class="btn btn-ghost btn-sm" id="pb-back">' + ic("left", 15) + "Edit</button>" +
            "</div>" +
            '<div class="pb-chips">' + breakdownHtml() + "</div>" +
            '<div class="pb-play">' + big.join("") + "</div>" +
            '<div class="pb-more">' +
              '<button type="button" class="btn" id="pb-view">' + ic("list", 16) + "View packet</button>" +
              '<button type="button" class="btn" id="pb-download">' + ic("download", 16) + "Download</button>" +
              '<button type="button" class="btn" id="pb-rebuild">' + ic("shuffle", 16) + "<span>Rebuild</span></button>" +
            "</div>" +
          "</section>" +
        "</div>";
      var t = body.querySelector("#pb-run-tu"); if (t) t.onclick = function () { startRun("tu"); };
      var b = body.querySelector("#pb-run-b"); if (b) b.onclick = function () { startRun("b"); };
      var tb = body.querySelector("#pb-run-both"); if (tb) tb.onclick = function () { startRun("both"); };
      body.querySelector("#pb-view").onclick = renderView;
      body.querySelector("#pb-download").onclick = downloadPacket;
      body.querySelector("#pb-back").onclick = renderBuilder;
      body.querySelector("#pb-rebuild").onclick = rebuild;
    }

    // ── the packet, read in order: Tossup 1, Bonus 1, Tossup 2 … ──
    function renderView() {
      stopReveal(); stopPbTimer(); returnPanel(); pbView = "view";
      var items = interleave("both");
      // Each type keeps its own count, so uneven TU/B totals still read right.
      var tuN = 0, boN = 0;
      items.forEach(function (it) { it._label = it.type === "tu" ? "Tossup " + (++tuN) : "Bonus " + (++boN); });
      body.innerHTML =
        '<div class="pb-page pb-viewpage">' +
          '<div class="pb-viewbar"><button type="button" class="btn btn-ghost btn-sm" id="pb-back">' + ic("left", 15) + "Packet</button>" +
            '<span class="spacer"></span>' +
            '<div class="seg" role="group" aria-label="Card size"><button type="button" id="pb-compact" aria-pressed="false">Compact</button><button type="button" id="pb-expand" aria-pressed="true">Expanded</button></div></div>' +
          '<div class="results pb-list">' +
          items.map(function (it, i) {
            var q = it.q, type = it.type === "tu" ? "tossup" : "bonus";
            var diff = q.difficulty != null && q.difficulty !== "" ? " · Diff " + q.difficulty : "";
            var side = '<span class="star-btn save-plus pb-save" title="Save to review / folders">+</span><span class="qb-star" data-qid="' + esc(q.id) + '" data-type="' + type + '" title="Star">☆</span>';
            var title, bodyHtml;
            if (it.type === "tu") {
              title = esc(primaryAnswer(q.answer, q.answer_sanitized));
              bodyHtml = '<div class="qcard-text">' + powerMarks(esc(plainText(q, "question"))) + "</div>" +
                '<div class="qcard-answer"><span class="ra-k">Answer</span> <span class="ans">' + ansHtml(q.answer, q.answer_sanitized) + "</span></div>";
            } else {
              var parts = jsonArr(q.parts_sanitized), answers = jsonArr(q.answers_sanitized), rawAnswers = jsonArr(q.answers);
              var bv = bonusVals(q, parts.length);
              title = answers.map(function (a, k) { return esc(primaryAnswer(rawAnswers[k], a)); }).join(" / ") || "?";
              bodyHtml = '<div class="qcard-text">' + esc(plainText(q, "leadin")) + "</div>" +
                parts.map(function (pt, k) {
                  return '<div class="qcard-part">[' + bv.values[k] + "] " + esc(plainText(q, "part", k)) + '<br><span class="ans">ANSWER: ' + ansHtml(rawAnswers[k], answers[k] || "") + "</span></div>";
                }).join("");
            }
            var path = String(q.category_path || [q.category, q.subcategory].filter(Boolean).join(" > ")).split(" > ").filter(Boolean);
            var tags = (path.length ? '<span class="badge cat-badge" style="--c:' + (ROOT_COLOR[path[0]] || "#8b949e") + '" title="' + esc(path.join(" › ")) + '"><span class="dot"></span><span class="t">' + esc(path.length > 1 ? path[0] + " › " + path[path.length - 1] : path[0]) + "</span></span>" : "") +
              (q.set_year ? '<span class="badge year-badge">' + esc(String(q.set_year)) + "</span>" : "") +
              (q.set_name ? '<span class="src">' + esc(q.set_name) + "</span>" : "");
            return '<div class="qcard expanded" data-i="' + i + '">' +
              '<div class="qcard-head"><span class="qcard-chev" aria-hidden="true"></span><div class="qcard-title"><span class="pb-num">' + esc(it._label) + '</span><span class="qcard-ans"><span class="ans">' + title + '</span></span>' + (diff ? '<span class="qcard-kind">' + esc(diff.replace(/^ · /, "")) + "</span>" : "") + "</div>" +
              '<span class="qcard-side">' + side + "</span></div>" +
              '<div class="qcard-body">' + bodyHtml + "</div>" +
              (tags ? '<div class="qcard-tags qmeta-row">' + tags + "</div>" : "") + "</div>";
          }).join("") +
        "</div></div>";
      body.querySelectorAll(".pb-save").forEach(function (b) {
        b.addEventListener("click", function (e) {
          e.stopPropagation();
          var it = items[parseInt(b.closest(".qcard").getAttribute("data-i"))];
          if (it && ctx.host && ctx.host.openSaveMenu) ctx.host.openSaveMenu(it.q, it.type === "tu" ? "tossup" : "bonus", b);
        });
      });
      body.querySelector("#pb-back").onclick = renderChooser;
      var setAll = function (compact) {
        body.querySelectorAll(".pb-list .qcard").forEach(function (c) { c.classList.toggle("compact", compact); c.classList.toggle("expanded", !compact); });
        body.querySelector("#pb-compact").setAttribute("aria-pressed", String(compact));
        body.querySelector("#pb-expand").setAttribute("aria-pressed", String(!compact));
      };
      body.querySelector("#pb-compact").onclick = function () { setAll(true); };
      body.querySelector("#pb-expand").onclick = function () { setAll(false); };
    }

    function interleave(mode) {
      var items = [];
      if (mode === "tu") packet.tossups.forEach(function (q) { items.push({ type: "tu", q: q }); });
      else if (mode === "b") packet.bonuses.forEach(function (q) { items.push({ type: "b", q: q }); });
      else {
        var n = Math.max(packet.tossups.length, packet.bonuses.length);
        for (var i = 0; i < n; i++) {
          if (packet.tossups[i]) items.push({ type: "tu", q: packet.tossups[i] });
          if (packet.bonuses[i]) items.push({ type: "b", q: packet.bonuses[i] });
        }
      }
      var tuN = 0, boN = 0;
      items.forEach(function (it) { it.n = it.type === "tu" ? ++tuN : ++boN; });
      return items;
    }

    // ── run ──
    function startRun(mode) {
      var items = interleave(mode);
      run = { items: items, idx: 0, score: 0, done: false, nTU: items.filter(function (x) { return x.type === "tu"; }).length, nB: items.filter(function (x) { return x.type === "b"; }).length,
        tally: { tuRight: 0, negs: 0, bPts: 0, bMax: 0 }, counted: {}, touched: {} };
      pbView = "run";
      serve();
    }
    function stopReveal() { if (revealTimer) { clearInterval(revealTimer); revealTimer = null; } }

    function runShell(inner) {
      var it = run.items[run.idx];
      var pct = Math.round(100 * run.idx / Math.max(1, run.items.length));
      return '<div class="pb-run' + (run.nB ? " pb-has-b" : "") + '">' +
        '<div class="pb-runbar">' +
          '<span class="pb-runpos">' + esc(it.type === "tu" ? "Tossup " + it.n : "Bonus " + it.n) + ' <small class="num">' + (run.idx + 1) + " / " + run.items.length + "</small></span>" +
          '<span class="pb-progress" aria-hidden="true"><span style="width:' + pct + '%"></span></span>' +
          '<span class="pb-score">Score <b class="num" id="pb-score">' + run.score + "</b></span>" +
          '<span class="pb-break" aria-hidden="true"></span>' +
          '<button type="button" class="btn btn-sm" id="pb-skip">Skip <span class="key">S</span></button>' +
          '<button type="button" class="btn btn-sm btn-icon" id="pb-settings" aria-pressed="' + settingsOpen + '" title="Settings" aria-label="Settings">' + ic("sliders", 16) + "</button>" +
          '<button type="button" class="btn btn-sm btn-ghost" id="pb-quit">End</button>' +
        "</div>" +
        '<div class="practice-layout pb-layout' + (settingsOpen ? " pb-side-open" : "") + '">' +
          '<main class="question-area pb-main">' + inner + "</main>" +
          '<aside class="pb-side" aria-label="Settings"></aside>' +
        "</div>" +
      "</div>";
    }
    function wireRunBar() {
      body.querySelector("#pb-skip").onclick = function () { run.idx++; serve(); };
      body.querySelector("#pb-quit").onclick = renderChooser;
      body.querySelector("#pb-settings").onclick = function () { settingsOpen = !settingsOpen; ctx.storage.set("settingsOpen", settingsOpen); syncSettings(); };
      syncSettings();
    }
    function bumpScore() { var s = body.querySelector("#pb-score"); if (s) s.textContent = run.score; }

    function serve() {
      stopReveal(); stopPbTimer(); returnPanel(); buzzed = false; fullyRead = false; revealI = 0;
      if (!run || run.idx >= run.items.length) { renderFinish(); return; }
      var it = run.items[run.idx];
      if (it.type === "tu") {
        body.innerHTML = runShell(
          '<div class="pb-qcard"><div class="question-text" id="pb-qtext"></div>' +
          '<div class="pb-buzzrow" id="pb-buzzrow"><button type="button" class="btn btn-primary btn-md pb-buzzbtn" id="pb-buzz-btn">Buzz <span class="key">Space</span></button>' +
            '<span class="buzz-hints hidden" id="pb-bwin"><span id="pb-bwin-left"></span></span></div>' +
          '<div class="buzz-area hidden" id="pb-buzz"><div class="buzz-prompt"><span class="prompt-symbol">&gt;</span>' +
          '<input type="text" id="pb-input" placeholder="type your answer…" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" enterkeyhint="send"></div>' +
          '<div class="buzz-hints" id="pb-ans-hint"><span id="pb-ans-left"></span></div></div>' +
          '<div class="result-area hidden" id="pb-result"></div></div>');
        wireRunBar();
        body.querySelector("#pb-buzz-btn").onclick = function () { buzz(); };
        beginReveal(readText(it.q, "question"));
      } else {
        var parts = jsonArr(it.q.parts_sanitized);
        var bv = bonusVals(it.q, parts.length);
        if (!run.counted[run.idx]) { run.counted[run.idx] = 1; run.tally.bMax += bv.max; }
        body.innerHTML = runShell(
          '<div class="pb-qcard"><div class="question-text pb-leadin">' + esc(readText(it.q, "leadin")) + "</div>" +
          parts.map(function (pt, k) {
            return '<div class="pb-part' + (k > 0 ? " pb-hidden" : "") + '" data-k="' + k + '">' +
              '<div class="bonus-part-text"><span class="pb-pv">[' + bv.values[k] + "]</span> " + esc(readText(it.q, "part", k)) + "</div>" +
              '<div class="buzz-prompt"><span class="prompt-symbol">&gt;</span><input type="text" class="pb-binput" data-k="' + k + '" placeholder="answer for part ' + (k + 1) + '…"' + (k > 0 ? " disabled" : "") + ' autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" enterkeyhint="send"><span class="pb-ptime num" data-k="' + k + '"></span></div>' +
              '<div class="pb-bans hidden" data-k="' + k + '"></div></div>';
          }).join("") +
          '<div class="result-area hidden" id="pb-result"></div></div>');
        wireRunBar();
        wireBonus(it.q, parts.length, bv);
      }
    }

    function renderFinish() {
      var t = run ? run.tally : { tuRight: 0, negs: 0, bPts: 0, bMax: 0 };
      var stats = [];
      if (run && run.nTU) stats.push('<div class="pb-stat"><b class="num">' + t.tuRight + "/" + run.nTU + "</b><small>tossups</small></div>");
      if (run && run.nTU) stats.push('<div class="pb-stat"><b class="num">' + t.negs + "</b><small>negs</small></div>");
      if (run && run.nB) stats.push('<div class="pb-stat"><b class="num">' + t.bPts + "/" + t.bMax + "</b><small>bonus points</small></div>");
      body.innerHTML =
        '<div class="pb-page pb-finish"><section class="pb-card pb-done">' +
          '<div class="pb-built">Final score <b class="num">' + (run ? run.score : 0) + "</b></div>" +
          (stats.length ? '<div class="pb-stats">' + stats.join("") + "</div>" : "") +
          '<div class="pb-more"><button type="button" class="btn btn-primary" id="pb-back">' + ic("left", 15) + "Back to packet</button></div>" +
        "</section></div>";
      pbView = "done";
      body.querySelector("#pb-back").onclick = renderChooser;
    }

    function paintTU(text) {
      var el = body.querySelector("#pb-qtext"); if (!el) return;
      var pre = esc(text.slice(0, revealI));
      var rest = esc(text.slice(revealI).replace(/\S/g, "·"));
      el.innerHTML = '<span class="revealed">' + pre + '</span><span class="unrevealed" aria-hidden="true">' + rest + "</span>";
    }
    function beginReveal(text) {
      run._text = text;
      var sp = cfg().revealSpeed; if (typeof sp !== "number") sp = 50;
      if (sp === 0) { revealI = text.length; fullyRead = true; paintTU(text); startBuzzWin(); return; }
      paintTU(text);
      revealTimer = setInterval(function () {
        if (buzzed) return;
        revealI++;
        if (revealI >= text.length) { revealI = text.length; fullyRead = true; stopReveal(); startBuzzWin(); }
        paintTU(text);
      }, Math.max(8, sp));
    }
    function hideBuzzRow() { var r = body.querySelector("#pb-buzzrow"); if (r) r.classList.add("hidden"); }
    // Question finished — the practice panel's Buzz window slider gives the
    // seconds to buzz before the question goes dead (0 = unlimited).
    function startBuzzWin() {
      var secs = panelVal("panel-buzz-window", 10);
      if (secs <= 0 || buzzed) return;
      var hint = body.querySelector("#pb-bwin");
      if (hint) { hint.classList.remove("hidden"); countdown(body.querySelector("#pb-bwin-left"), secs); }
      pbTimer = setTimeout(function () {
        if (buzzed || !run) return;
        buzzed = true; stopPbTimer(); run.touched[run.idx] = 1;
        hideBuzzRow();
        var it = run.items[run.idx];
        var res = body.querySelector("#pb-result"); if (!res) return;
        res.classList.remove("hidden");
        res.innerHTML = '<div class="result-banner dead">TIME — no buzz (0)</div>' +
          '<div class="result-answer">Answer: <span class="ans">' + ansHtml(it.q.answer, it.q.answer_sanitized) + "</span></div>" +
          '<div class="result-next"><button type="button" class="btn btn-primary" id="pb-next">Next <span class="key">N</span></button></div>';
        body.querySelector("#pb-next").onclick = function () { run.idx++; serve(); };
      }, secs * 1000);
    }
    function buzz() {
      if (buzzed || !run) return;
      var it = run.items[run.idx];
      if (!it || it.type !== "tu") return;
      buzzed = true; stopReveal(); stopPbTimer(); run.touched[run.idx] = 1;
      hideBuzzRow();
      var bz = body.querySelector("#pb-buzz"); if (!bz) return;
      bz.classList.remove("hidden");
      var inp = body.querySelector("#pb-input"); inp.focus();
      // One prompt per answer: a first prompt reopens the input under a PROMPT
      // banner (answer timer restarted) and the reply is judged with the
      // prompted answer as `previous`. A second prompt, or time running out
      // on the prompt, is wrong.
      var settled = false, judging = false, promptFrom = null;
      async function settle(text) {
        if (settled || judging) return;
        judging = true;
        stopPbTimer(); inp.disabled = true;
        var verdict = "reject", r = null;
        if (text) {
          try {
            // judged right here when the app can (no round trip); an older app asks its backend
            r = ctx.host && ctx.host.judgeTossup
              ? await ctx.host.judgeTossup(it.q, text, { strictness: cfg().strictness || 10, buzzPosition: judgePos(it.q, run._text || "", revealI), previous: promptFrom })
              : await ctx.api.post("/api/evaluate-tossup", { questionId: it.q.id, answer: text, strictness: cfg().strictness || 10, buzzPosition: judgePos(it.q, run._text || "", revealI), previous: promptFrom });
            verdict = (r && r.status) || "reject";
          } catch (err) {}
        }
        judging = false;
        if (!run || !bz.isConnected) { settled = true; return; }   // skipped / run ended while judging
        if (verdict === "prompt" && promptFrom == null) {
          promptFrom = text;
          var ask = (r.prompt && r.prompt.ask) || (r.antiprompt ? "less specific?" : "");
          var banner = bz.querySelector(".buzz-prompt-banner");
          if (!banner) { banner = document.createElement("div"); banner.className = "buzz-prompt-banner"; bz.insertBefore(banner, bz.firstChild); }
          banner.innerHTML = '<span class="prompt-tag">PROMPT</span>' + (ask ? " " + esc(ask) : "");
          inp.value = ""; inp.disabled = false;
          setTimeout(function () { inp.focus(); }, 30);
          startAnswerTimer();
          return;
        }
        settled = true;
        var pb = bz.querySelector(".buzz-prompt-banner"); if (pb) pb.remove();
        var ok = verdict === "accept";
        var pts = ok ? 10 : (fullyRead ? 0 : -5);
        run.score += pts; bumpScore();
        if (ok) run.tally.tuRight++;
        if (pts < 0) run.tally.negs++;
        revealI = (run._text || "").length; paintTU(run._text || "");
        bz.classList.add("hidden");
        var res = body.querySelector("#pb-result");
        res.classList.remove("hidden");
        res.innerHTML = '<div class="result-banner ' + (ok ? "correct" : "incorrect") + '">' + (ok ? "CORRECT +" + pts : (text ? "" : "TIME — ")) + (ok ? "" : (pts < 0 ? "NEG " + pts : "INCORRECT (0)")) + "</div>" +
          (text ? '<div class="result-answer pb-yours">You said: <strong>' + esc(text) + "</strong></div>" : "") +
          '<div class="result-answer">Answer: <span class="ans">' + ansHtml(it.q.answer, it.q.answer_sanitized) + '</span> <span class="star-btn save-plus pb-rsave" title="Save to review / folders">+</span></div>' +
          '<div class="result-next"><button type="button" class="btn btn-primary" id="pb-next">Next <span class="key">N</span></button></div>';
        var rsv = res.querySelector(".pb-rsave"); if (rsv) rsv.onclick = function () { if (ctx.host && ctx.host.openSaveMenu) ctx.host.openSaveMenu(it.q, "tossup", rsv); };
        body.querySelector("#pb-next").onclick = function () { run.idx++; serve(); };
      }
      // Answer time (practice panel slider): seconds to answer (0 = unlimited).
      function startAnswerTimer() {
        var secs = panelVal("panel-buzz-timer", 10);
        if (secs > 0) {
          countdown(body.querySelector("#pb-ans-left"), secs);
          pbTimer = setTimeout(function () { settle(""); }, secs * 1000);
        }
      }
      startAnswerTimer();
      inp.addEventListener("keydown", function (e) {
        if (e.key !== "Enter") return;
        e.preventDefault();
        settle(inp.value.trim());
      });
    }

    function wireBonus(q, nParts, bv) {
      var answers = jsonArr(q.answers_sanitized), rawAnswers = jsonArr(q.answers);
      bv = bv || bonusVals(q, nParts);
      var got = 0, promptFrom = [];
      // A part judged as the app's bonus scoring judges it (evaluate-bonus-part);
      // a record the server can't find falls back to its line.
      async function judgePart(k, text, previous) {
        if (!text) return { status: "reject" };
        var r = null, strict = cfg().strictness || 10;
        try {
          r = ctx.host && ctx.host.judgeBonusPart
            ? await ctx.host.judgeBonusPart(q, k, text, { strictness: strict, previous: previous })
            : await ctx.api.post("/api/evaluate-bonus-part", { questionId: q.id, part: k, answer: text, strictness: strict, previous: previous });
          if (!r || r.error) r = null;
        } catch (err) { r = null; }
        if (!r) {
          try {
            r = ctx.host && ctx.host.judgeAnswerLine
              ? await ctx.host.judgeAnswerLine(rawAnswers[k] || "", answers[k] || "", text, { strictness: strict, previous: previous })
              : await ctx.api.post("/api/evaluate-answer", { answerline: rawAnswers[k] || "", sanitized: answers[k] || "", answer: text, strictness: strict, previous: previous });
          } catch (err) { r = null; }
        }
        return r || { status: "reject" };
      }
      // Bonus part time (practice panel slider; 0 = unlimited): running out
      // marks the part wrong (typed but not entered text is not judged).
      function partTimer(k, inp) {
        stopPbTimer();
        var secs = panelVal("panel-bonus-timer", 0);
        if (!(secs > 0)) return;
        countdown(body.querySelector('.pb-ptime[data-k="' + k + '"]'), secs);
        pbTimer = setTimeout(function () { stopPbTimer(); if (inp.isConnected && !inp.disabled) submit(inp, true); }, secs * 1000);
      }
      async function submit(inp, timedOut) {
        if (inp.disabled) return;
        inp.disabled = true;
        stopPbTimer(); run.touched[run.idx] = 1;
        var k = parseInt(inp.dataset.k);
        var tm = body.querySelector('.pb-ptime[data-k="' + k + '"]'); if (tm) tm.textContent = "";
        var text = timedOut ? "" : inp.value.trim(), prev = promptFrom[k] || null;
        var r = await judgePart(k, text, prev);
        if (!run || !inp.isConnected) return;   // skipped / run ended while judging
        // One prompt per part: a first prompt reopens this part's input under
        // a PROMPT banner; the reply is judged with it. A second prompt is wrong.
        var row = inp.closest(".buzz-prompt");
        if (r.status === "prompt" && prev == null && row) {
          promptFrom[k] = text;
          var ask = (r.prompt && r.prompt.ask) || (r.antiprompt ? "less specific?" : "");
          var banner = row.parentNode.querySelector(".buzz-prompt-banner");
          if (!banner) { banner = document.createElement("div"); banner.className = "buzz-prompt-banner"; row.parentNode.insertBefore(banner, row); }
          banner.innerHTML = '<span class="prompt-tag">PROMPT</span>' + (ask ? " " + esc(ask) : "");
          inp.value = ""; inp.disabled = false;
          setTimeout(function () { inp.focus(); }, 30);
          partTimer(k, inp);
          return;
        }
        var pb = row && row.parentNode.querySelector(".buzz-prompt-banner"); if (pb) pb.remove();
        var ok = r.status === "accept";
        if (ok) { var pv = bv.values[k] || 0; got += pv; run.score += pv; run.tally.bPts += pv; bumpScore(); }
        var ans = body.querySelector('.pb-bans[data-k="' + k + '"]');
        ans.classList.remove("hidden");
        ans.innerHTML = (ok ? '<span class="bonus-verdict correct">✓</span> ' : '<span class="bonus-verdict incorrect">✗</span> ') + 'ANSWER: <span class="ans">' + ansHtml(rawAnswers[k], answers[k] || "") + "</span>";
        if (k + 1 < nParts) {
          var nx = body.querySelector('.pb-part[data-k="' + (k + 1) + '"]');
          nx.classList.remove("pb-hidden");
          var ni = nx.querySelector(".pb-binput"); ni.disabled = false; ni.focus();
          partTimer(k + 1, ni);
        } else {
          var res = body.querySelector("#pb-result");
          res.classList.remove("hidden");
          res.innerHTML = '<div class="result-banner ' + (got > 0 ? "correct" : "incorrect") + '">BONUS: ' + got + "/" + bv.max + "</div>" +
            '<div class="result-next"><button type="button" class="btn btn-primary" id="pb-next">Next <span class="key">N</span></button></div>';
          body.querySelector("#pb-next").onclick = function () { run.idx++; serve(); };
        }
      }
      body.querySelectorAll(".pb-binput").forEach(function (inp) {
        inp.addEventListener("keydown", function (e) {
          if (e.key !== "Enter") return;
          e.preventDefault();
          submit(inp, false);
        });
      });
      var first = body.querySelector('.pb-binput[data-k="0"]');
      if (first) { first.focus(); partTimer(0, first); }
    }

    function onKey(e) {
      if (!active() || !run || pbView !== "run") return;
      if (e.metaKey || e.ctrlKey || e.altKey) return;
      var t = e.target.tagName; if (t === "INPUT" || t === "TEXTAREA" || t === "SELECT" || (e.target.isContentEditable)) return;
      if (e.target.closest && e.target.closest("#filters-panel, .qb-overlay, .confirm-overlay")) return;
      if (e.code === "Space" || e.key === " ") { e.preventDefault(); buzz(); }
      else if (e.key === "n" || e.key === "N") {
        var nx = body.querySelector("#pb-next"); if (nx) { e.preventDefault(); nx.click(); }
      } else if (e.key === "s" || e.key === "S") {
        var sk = body.querySelector("#pb-skip"); if (sk) { e.preventDefault(); sk.click(); }
      }
    }
    document.addEventListener("keydown", onKey);
    ctx._cleanup = function () { stopReveal(); stopPbTimer(); returnPanel(); document.removeEventListener("keydown", onKey); };
  }
