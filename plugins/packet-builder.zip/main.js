/**
 * OfflineQuiz plugin: Packet Builder
 *
 * Build a custom packet: set per-category WEIGHTS (defaults follow NAQT's
 * high-school subject distribution), pick packet totals, difficulties and
 * years. Counts are apportioned at random around each category's fair share
 * (never above it rounded up). Play it — tossups + bonuses, tossups only or
 * bonuses only — read it as a list, or download it as a readable text packet.
 */
QB.registerPlugin({
  id: "packet-builder",
  name: "Packet Builder",
  version: "2.13.0",
  author: "OfflineQuiz",
  description: "Build a balanced custom packet from the database and play it, read it, or download it.",
  onEnable: __qbMain,
  onDisable: function (ctx) { if (ctx._cleanup) ctx._cleanup(); },
});
