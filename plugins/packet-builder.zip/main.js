/**
 * OfflineQuiz plugin: Packet Builder
 *
 * Build a custom packet: set per-category WEIGHTS (defaults follow NAQT's
 * high-school subject distribution), pick packet totals, difficulties and
 * years. Counts are apportioned by largest remainder, so every category gets
 * the floor or ceiling of its exact fair share — never more, never less.
 * Packets can be exported to a .json file and imported in Practice or
 * Multiplayer. Run it — tossups only, bonuses only, alternating TU+B — or
 * view the whole packet in TU/BO order.
 */
QB.registerPlugin({
  id: "packet-builder",
  name: "Packet Builder",
  version: "2.7.0",
  author: "OfflineQuiz",
  description: "Build and play custom packets: NAQT-style category weights, random balanced draws, practice-settings sidebar, answer/buzz timers, export to file.",
  onEnable: __qbMain,
  onDisable: function (ctx) { if (ctx._cleanup) ctx._cleanup(); },
});
