/**
 * OfflineQuiz plugin: Difficulty Ladder
 *
 * An adaptive difficulty: rounds of ten tossups at your level. Seven right moves you up a level and
 * three or fewer moves you down, so you always practice where you're stretched. One ladder for
 * everything, or one per category.
 */
QB.registerPlugin({
  id: "difficulty-ladder",
  name: "Difficulty Ladder",
  version: "1.1.0",
  author: "OfflineQuiz",
  description: "Climb from middle school to open: ten tossups at your level, up a level when you get seven.",
  onEnable: __qbMain,
  onDisable: function (ctx) { if (ctx._cleanup) ctx._cleanup(); },
});
