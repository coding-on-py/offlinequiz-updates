function __qbMain(ctx) {
  // ── the kit the 15.62 plugins share (text, icons, questions, judging, history) ──
  function esc(s) { return (s == null ? "" : String(s)).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
  var IC = {
    play: '<path d="M7 4l13 8-13 8z"/>',
    pause: '<path d="M8 5v14M16 5v14"/>',
    left: '<path d="M15 6l-6 6 6 6"/>',
    right: '<path d="M9 6l6 6-6 6"/>',
    next: '<path d="M6 5l9 7-9 7zM18 5v14"/>',
    refresh: '<path d="M20 11a8 8 0 10-2.3 5.7M20 4v7h-7"/>',
    x: '<path d="M6 6l12 12M18 6L6 18"/>',
    check: '<path d="M5 12l5 5 9-10"/>',
    mic: '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
    volume: '<path d="M4 9v6h4l5 4V5L8 9z"/><path d="M16 9a4 4 0 0 1 0 6M19 6a8 8 0 0 1 0 12"/>',
    copy: '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h3"/>',
    edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="M13.5 6.5l4 4"/>',
    bolt: '<path d="M13 3L5 14h6l-1 7 8-11h-6z"/>',
    flag: '<path d="M5 21V4M5 4h11l-2 4 2 4H5"/>',
    users: '<circle cx="9" cy="8" r="3"/><path d="M3 20a6 6 0 0 1 12 0M16 4a3 3 0 0 1 0 6M21 20a6 6 0 0 0-4-5.6"/>',
    target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
    down: '<path d="M6 9l6 6 6-6"/>',
    up: '<path d="M6 15l6-6 6 6"/>',
  };
  function ic(name, size) {
    var s = size || 16;
    return '<svg width="' + s + '" height="' + s + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (IC[name] || "") + "</svg>";
  }
  function loading(label) { return '<div class="pk-loading">' + (ctx.loadingBarHtml ? ctx.loadingBarHtml(label) : esc(label)) + "</div>"; }
  function norm(s) { return String(s || "").toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[^a-z0-9]+/g, " ").trim(); }
  function pct(a, n) { return n ? Math.round(100 * a / n) : 0; }
  function fmt(n) { return Number(n || 0).toLocaleString(); }
  function plural(n, one, many) { return fmt(n) + " " + (n === 1 ? one : (many || one + "s")); }
  function shuffle(a) { for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)), t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
  function inField(e) { var t = e && e.target; return !!t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT" || t.isContentEditable); }
  function dayKey(t) { var d = new Date(t || Date.now()); return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0"); }
  var DAY = 86400000;

  // the practice setup (Setup panel): its filters and reading settings
  function cfg() { try { return (ctx.host && ctx.host.getPracticeConfig && ctx.host.getPracticeConfig()) || {}; } catch (e) { return {}; } }
  // filters → query parameters, the ones the app sends for a random question
  function filtersQuery(f, extra) {
    f = f || {}; var p = [];
    var add = function (k, v) { p.push(k + "=" + encodeURIComponent(v)); };
    if (f.categories && f.categories.length) add("categories", f.categories.join(","));
    if (f.categoryIds && f.categoryIds.length) add("categoryIds", f.categoryIds.join(","));
    if (f.difficulties && f.difficulties.length) add("difficulties", f.difficulties.join(","));
    if (f.setNames && f.setNames.length) add("setNames", f.setNames.join(","));
    if (f.packetNumbers && f.packetNumbers.length) add("packetNumbers", f.packetNumbers.join(","));
    if (f.yearMin != null) add("yearMin", f.yearMin);
    if (f.yearMax != null) add("yearMax", f.yearMax);
    if (f.powermarkOnly) add("powermarkOnly", "true");
    if (f.canon && f.canon.length) add("canon", f.canon.join(","));
    add("cleanOnly", "1");
    Object.keys(extra || {}).forEach(function (k) { if (extra[k] != null && extra[k] !== false) add(k, extra[k]); });
    return p.join("&");
  }
  // the practice filters without a set (a drill draws from everything the player picked)
  function practiceFilters() { var f = Object.assign({}, cfg().filters || {}); delete f.setNames; delete f.packetNumbers; delete f.setIds; return f; }
  async function getTossups(n, f, extra) {
    try { var d = await ctx.api.get("/api/tossups/query?" + filtersQuery(f || practiceFilters(), Object.assign({ random: 1, limit: n }, extra || {}))); return (d && d.rows) || []; } catch (e) { return []; }
  }
  async function getBonuses(n, f, extra) {
    try { var d = await ctx.api.get("/api/bonuses/query?" + filtersQuery(f || practiceFilters(), Object.assign({ random: 1, limit: n }, extra || {}))); return (d && d.rows) || []; } catch (e) { return []; }
  }
  async function getTossup(id) { try { return (await ctx.api.get("/api/tossups/" + encodeURIComponent(id))).tossup || null; } catch (e) { return null; } }
  async function getBonus(id) { try { return (await ctx.api.get("/api/bonuses/" + encodeURIComponent(id))).bonus || null; } catch (e) { return null; } }
  async function searchTossups(query, limit, f) {
    try { var d = await ctx.api.get("/api/tossups/search?query=" + encodeURIComponent(query) + "&limit=" + (limit || 20) + (f ? "&" + filtersQuery(f) : "")); return { rows: (d && d.rows) || [], total: (d && d.total) || 0 }; } catch (e) { return { rows: [], total: 0 }; }
  }
  // tossups whose answer line names an answer
  async function tossupsOn(answer, limit) { return (await searchTossups('answer_sanitized : ("' + String(answer).replace(/"/g, "") + '")', limit || 20)).rows; }

  // a record's text as practice reads it (notes and pronunciation guides per the player's settings)
  function readText(q) {
    try { if (ctx.host && ctx.host.questionText) { var t = ctx.host.questionText(q, "question"); if (t != null) return String(t).replace(/\(\*\)/g, "").replace(/\s{2,}/g, " ").trim(); } } catch (e) {}
    return String((q && q.question_sanitized) || "").replace(/\(\*\)/g, "").trim();
  }
  function powerAt(q) { return String((q && q.question_sanitized) || "").indexOf("(*)"); }
  // sentences, without breaking at "St." or an initial ("J. R. R. Tolkien")
  var ABBR = /(?:\b(?:St|Ste|Mt|Mts|Dr|Mr|Mrs|Ms|Mme|Prof|Sr|Jr|Rev|Fr|Gen|Col|Capt|Lt|Sgt|Maj|Adm|Hon|Pres|Gov|Sen|Rep|vs|etc|cf|ca|al|Inc|Co|Corp|Ltd|Bros|approx|No|Nos|Op|op|no|Vol|vol|Ch|ch|Fig|fig|Ft|Pt|pt|Ave|[A-Za-z])\.["”’']?)$/;
  function sentences(text) {
    var parts = String(text || "").split(/(?<=[.?!]["”’)]*)\s+(?=["“(]?[A-Z0-9])/), out = [], cur = "";
    for (var i = 0; i < parts.length; i++) {
      cur = cur ? cur + " " + parts[i] : parts[i];
      if (i < parts.length - 1 && ABBR.test(cur.trim())) continue;
      out.push(cur.trim()); cur = "";
    }
    if (cur.trim()) out.push(cur.trim());
    return out.filter(Boolean);
  }
  // the answer line, with its bold and underlining (nothing else of the HTML)
  function answerHtml(q) {
    var h = String((q && q.answer) || "");
    if (!/<\/?(b|u|strong|em|i)\b/i.test(h)) return esc((q && q.answer_sanitized) || h);
    return h.replace(/<(\/?)(b|u|strong|em|i)\b[^>]*>/gi, "\u0001$1$2\u0002").replace(/<[^>]*>/g, "").replace(/&(?!(?:amp|lt|gt|quot|#\d+);)/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/\u0001(\/?)(\w+)\u0002/g, "<$1$2>");
  }
  function primary(q) {
    var a = "";
    try { if (ctx.host && ctx.host.extractPrimaryAnswer) a = ctx.host.extractPrimaryAnswer((q && q.answer) || "", (q && q.answer_sanitized) || ""); } catch (e) {}
    return a || String((q && q.answer_sanitized) || "").replace(/\s*[\[(].*$/, "").trim();
  }
  // judged right here, like practice (judge.js); { status: "accept" | "prompt" | "reject", prompt }
  async function judge(q, answer, opts) {
    opts = opts || {};
    try {
      if (ctx.host && ctx.host.judgeTossup) return (await ctx.host.judgeTossup(q, answer, { strictness: opts.strictness != null ? opts.strictness : (cfg().strictness || 10), buzzPosition: opts.buzzPosition, previous: opts.previous || null })) || { status: "reject" };
      return (await ctx.api.post("/api/evaluate-tossup", { questionId: q.id, answer: answer, strictness: cfg().strictness || 10, buzzPosition: opts.buzzPosition, previous: opts.previous || null })) || { status: "reject" };
    } catch (e) { return { status: "reject" }; }
  }
  async function judgePart(b, part, answer, opts) {
    opts = opts || {};
    try {
      if (ctx.host && ctx.host.judgeBonusPart) return (await ctx.host.judgeBonusPart(b, part, answer, { strictness: cfg().strictness || 10, previous: opts.previous || null })) || { status: "reject" };
      return (await ctx.api.post("/api/evaluate-bonus-part", { questionId: b.id, part: part, answer: answer, strictness: cfg().strictness || 10 })) || { status: "reject" };
    } catch (e) { return { status: "reject" }; }
  }
  async function judgeLine(line, sani, answer, opts) {
    opts = opts || {};
    try {
      if (ctx.host && ctx.host.judgeAnswerLine) return (await ctx.host.judgeAnswerLine(line, sani, answer, { strictness: cfg().strictness || 10, previous: opts.previous || null })) || { status: "reject" };
      return (await ctx.api.post("/api/evaluate-answer", { answerline: line, answer: answer, strictness: cfg().strictness || 10 })) || { status: "reject" };
    } catch (e) { return { status: "reject" }; }
  }
  function bonusParts(b) { try { return JSON.parse((b && (b.parts_sanitized || b.parts)) || "[]"); } catch (e) { return []; } }
  function bonusAnswers(b) { try { return JSON.parse((b && b.answers) || "[]"); } catch (e) { return []; } }
  function bonusAnswersSani(b) { try { return JSON.parse((b && b.answers_sanitized) || "[]"); } catch (e) { return []; } }

  // the player's answers (Stats' history), only the fields asked for
  async function history(fields) {
    try { return ((await ctx.api.get("/api/sessions/all-entries?" + (/\banswer\b/.test(fields || "") ? "answers=1&" : "") + "fields=" + encodeURIComponent(fields || ""))).entries) || []; } catch (e) { return []; }
  }
  // record a tossup answered on a plugin's page into the player's stats (the path Coach Mode uses)
  function record(q, r) {
    try {
      ctx.api.post("/api/check-tossup", { questionId: q.id, answer: r.answer || "", buzzPosition: r.buzzPosition || 0, sessionId: r.session, overriding: true,
        correct: !!r.correct, isPower: !!r.power, points: r.points || 0, celerity: r.celerity != null ? r.celerity : 1 }).catch(function () {});
    } catch (e) {}
  }

  var ROOT_COLOR = { "Literature": "#bc8cff", "Science": "#58a6ff", "Math": "#a5e05b", "Pop Culture": "#ff7b72", "Sports": "#ff6f91", "Fine Arts": "#f778ba", "History": "#e3b341", "Geography": "#56d364", "Mythology": "#ffa657", "Social Science": "#3dd6a3", "Philosophy": "#39c5cf", "Theology": "#8e9bff", "Current Events": "#c9d16b", "Miscellaneous": "#8b949e" };
  // NAQT's high school distribution, per 24 tossups / bonuses (naqt.com/hs/distribution.jsp)
  var NAQT = [["Literature", 3.9, 3.8], ["Science", 4.5, 4.3], ["Math", 1.0, 1.0], ["Fine Arts", 2.0, 2.0], ["History", 4.6, 4.5], ["Geography", 1.9, 1.9], ["Mythology", 0.6, 0.7],
    ["Pop Culture", 1.0, 0.9], ["Sports", 0.7, 0.7], ["Social Science", 0.6, 0.6], ["Philosophy", 0.3, 0.3], ["Theology", 0.4, 0.4], ["Current Events", 1.5, 1.4], ["Miscellaneous", 1.0, 1.5]];
  function rootOf(e) { return String((e && (e.category_path || e.category)) || "").split(" > ")[0] || "Miscellaneous"; }
  function dot(root) { return '<span class="pk-dot" style="--c:' + (ROOT_COLOR[root] || "#8b949e") + '"></span>'; }
  var _roots = null;
  async function roots() {
    if (_roots) return _roots;
    try { var t = ctx.host && ctx.host.getCategoryTree ? await ctx.host.getCategoryTree("tossups") : (await ctx.api.get("/api/category-tree?type=tossups")).tree; _roots = (t || []).map(function (n) { return { id: n.id, name: n.name, count: n.count }; }); }
    catch (e) { _roots = []; }
    return _roots;
  }
  var DIFF_NAME = { 0: "Unrated", 1: "Middle school", 2: "Easy high school", 3: "Regular high school", 4: "Hard high school", 5: "National high school", 6: "Easy college", 7: "Medium college", 8: "Regionals college", 9: "Nationals college", 10: "Open" };

  function tile(value, label, cls) { return '<div class="pk-tile' + (cls ? " " + cls : "") + '"><b class="num">' + value + "</b><span>" + esc(label) + "</span></div>"; }
  function segHtml(name, items, on) {
    return '<div class="seg pk-seg" role="group">' + items.map(function (it) {
      return '<button type="button" data-' + name + '="' + esc(it[0]) + '" aria-pressed="' + (String(on) === String(it[0])) + '">' + esc(it[1]) + "</button>";
    }).join("") + "</div>";
  }
  function emptyHtml(text) { return '<div class="db-empty pk-empty">' + esc(text) + "</div>"; }
  function playList(kind, ids, title) {
    if (!ids || !ids.length) return false;
    try { return !!(ctx.host && ctx.host.launchQuestions && ctx.host.launchQuestions(kind, ids, { title: title })); } catch (e) { return false; }
  }

  // a reader: shows `text` a character at a time at the practice reading speed. start(), pause(), go(), stop();
  // at() is how far it is; onEnd once it's all shown
  function Reader(el, text, opts) {
    opts = opts || {};
    var ms = opts.ms != null ? opts.ms : (Number(cfg().revealSpeed) || 25), idx = 0, raf = 0, last = 0, on = false;
    var paint = function () { el.innerHTML = '<span class="pk-read">' + esc(text.slice(0, idx)) + '</span><span class="pk-unread" aria-hidden="true">' + esc(text.slice(idx)) + "</span>"; };
    var step = function (t) {
      raf = 0; if (!on) return;
      if (!last) last = t;
      var n = ms > 0 ? Math.floor((t - last) / ms) : text.length;
      if (n > 0) { idx = Math.min(text.length, idx + n); last += n * ms; paint(); if (opts.onTick) opts.onTick(idx); }
      if (idx >= text.length) { on = false; if (opts.onEnd) opts.onEnd(); return; }
      raf = requestAnimationFrame(step);
    };
    paint();
    return {
      start: function () { if (on) return; on = true; last = 0; raf = requestAnimationFrame(step); },
      pause: function () { on = false; if (raf) cancelAnimationFrame(raf); raf = 0; },
      stop: function () { on = false; if (raf) cancelAnimationFrame(raf); raf = 0; },
      showAll: function () { this.stop(); idx = text.length; el.textContent = text; },
      at: function () { return idx; },
      running: function () { return on; },
    };
  }
  // a reader's position in the displayed text → the record's question_sanitized (what judging and stats count)
  function serverPos(q, display, pos) {
    try { if (ctx.host && ctx.host.mapDisplayPos) return ctx.host.mapDisplayPos(display, (q && q.question_sanitized) || "", pos); } catch (e) {}
    return pos;
  }

  // ── Difficulty Ladder: rounds of ten tossups at your level; seven right moves you up, three or fewer down ──
  // A round plays in practice (its own page). Each tossup that comes up from the round counts: right, or wrong
  // (a neg, a wrong answer, or one you let go by). A ladder for all categories, or one per category.
  var body = null, page = null;
  var st = Object.assign({ scope: "all", ladders: {}, round: null }, ctx.storage.get("ladder") || {});
  function save() { ctx.storage.set("ladder", st); }
  var LEVELS = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10], UP = 7, DOWN = 3, SIZE = 10;
  function ladder(scope) { var k = scope || st.scope; return st.ladders[k] = st.ladders[k] || { level: 2, rounds: [] }; }
  var cats = [], busy = false, lastQ = null;

  // a round's tossups as they come up in practice
  function inRound(id) { return st.round && st.round.ids.indexOf(id) >= 0; }
  function mark(id, right) {
    var r = st.round; if (!r || !inRound(id) || r.got[id] != null) return;
    r.got[id] = right ? 1 : 0; save();
    if (Object.keys(r.got).length >= r.ids.length) finishRound();
  }
  ctx.on("answer:result", function (d) { var q = ctx.getState().currentQuestion; if (q && d && d.result) mark(q.id, !!d.result.correct); });
  ctx.on("question:render", function (d) {
    // the round's last tossup went by with no answer: it counts as missed
    if (lastQ && inRound(lastQ) && st.round.got[lastQ] == null) mark(lastQ, false);
    lastQ = d && d.question && d.type === "tossup" ? d.question.id : null;
  });
  function finishRound() {
    var r = st.round; if (!r) return;
    var n = Object.keys(r.got).length, right = Object.keys(r.got).filter(function (k) { return r.got[k]; }).length;
    st.round = null;
    if (n < 5) { save(); return; }   // too little of it played to judge
    var L = ladder(r.scope), from = L.level;
    var score = right * SIZE / n;
    if (score >= UP) L.level = Math.min(10, L.level + 1); else if (score <= DOWN) L.level = Math.max(1, L.level - 1);
    L.rounds.push({ level: from, right: right, n: n, at: Date.now(), to: L.level });
    L.rounds = L.rounds.slice(-30);
    L.best = Math.max(L.best || 0, L.level);
    st.last = { scope: r.scope, from: from, to: L.level, right: right, n: n };
    save();
  }

  function scopeName(k) { if (k === "all") return "All categories"; var c = cats.find(function (x) { return x.id === k; }); return c ? c.name : "This category"; }
  function render() {
    if (!body) return;
    var L = ladder(), lv = L.level, last = st.last && st.last.scope === st.scope ? st.last : null;
    body.innerHTML = '<div class="pk-wrap dl">' +
      '<div class="pk-bar-top"><select id="dl-scope" class="dl-scope" aria-label="Ladder">' + [["all", "All categories"]].concat(cats.map(function (c) { return [c.id, c.name]; })).map(function (o) {
        var l = st.ladders[o[0]]; return '<option value="' + esc(o[0]) + '"' + (o[0] === st.scope ? " selected" : "") + ">" + esc(o[1]) + (l ? " · level " + l.level : "") + "</option>";
      }).join("") + "</select></div>" +
      (last ? '<div class="pk-card dl-last ' + (last.to > last.from ? "up" : last.to < last.from ? "down" : "") + '">' + (last.to > last.from ? ic("up", 16) + "Up to level " + last.to + ". You got " + last.right + " of " + last.n + "." : last.to < last.from ? ic("down", 16) + "Down to level " + last.to + ". You got " + last.right + " of " + last.n + "." : "Staying at level " + last.to + ". You got " + last.right + " of " + last.n + ". Seven gets you up.") + "</div>" : "") +
      (st.round ? '<div class="pk-card dl-open"><div class="pk-grow"><div class="pk-strong">A round is in play</div><div class="pk-muted pk-small">' + Object.keys(st.round.got).length + " of " + st.round.ids.length + " played at level " + st.round.level + " in " + esc(scopeName(st.round.scope)) + '</div></div><button type="button" class="btn" id="dl-end">End it now</button></div>' : "") +
      '<div class="dl-main"><div class="dl-ladder">' + LEVELS.slice().reverse().map(function (l) {
        return '<div class="dl-rung' + (l === lv ? " on" : l < lv ? " below" : "") + (L.best === l ? " best" : "") + '"><span class="num">' + l + '</span><span class="dl-rn">' + esc(DIFF_NAME[l]) + "</span>" + (l === lv ? '<span class="dl-you">You</span>' : L.best === l && L.best > lv ? '<span class="dl-tag">Best</span>' : "") + "</div>";
      }).join("") + "</div>" +
      '<div class="dl-side"><div class="pk-card"><div class="pk-strong">Level ' + lv + ", " + esc(DIFF_NAME[lv].toLowerCase()) + '</div><div class="pk-muted pk-small" style="margin:4px 0 14px">Ten tossups at this level' + (st.scope === "all" ? "" : " in " + esc(scopeName(st.scope))) + ". Get " + UP + " right to move up. " + DOWN + " or fewer moves you down.</div>" +
        '<button type="button" class="btn btn-primary" id="dl-go"' + (st.round || busy ? " disabled" : "") + ">" + ic("play", 14) + (busy ? "Finding tossups…" : "Play a round") + "</button></div>" +
        (L.rounds.length ? '<div class="pk-card"><h3>Your rounds</h3>' + L.rounds.slice(-8).reverse().map(function (r) {
          return '<div class="pk-row dl-round"><span class="num dl-rl">Level ' + r.level + '</span><span class="pk-grow pk-small pk-muted">' + new Date(r.at).toLocaleDateString(undefined, { month: "short", day: "numeric" }) + '</span><span class="num"><b>' + r.right + "</b>/" + r.n + '</span><span class="dl-arrow ' + (r.to > r.level ? "pk-good" : r.to < r.level ? "pk-bad" : "pk-muted") + '">' + (r.to > r.level ? ic("up", 14) : r.to < r.level ? ic("down", 14) : "–") + "</span></div>";
        }).join("") + "</div>" : "") + "</div></div></div>";
    body.querySelector("#dl-scope").onchange = function (e) { st.scope = e.target.value; save(); render(); };
    body.querySelector("#dl-go").onclick = play;
    var end = body.querySelector("#dl-end"); if (end) end.onclick = function () { finishRound(); render(); };
  }
  async function play() {
    if (busy || st.round) return;
    busy = true; render();
    var L = ladder(), f = practiceFilters();
    delete f.difficulties; delete f.categories; delete f.categoryIds;
    f.difficulties = [L.level];
    if (st.scope !== "all") f.categoryIds = [st.scope];
    var rows = await getTossups(SIZE, f, { powermarkOnly: "true" });
    if (rows.length < SIZE) rows = rows.concat((await getTossups(SIZE, f)).filter(function (q) { return !rows.some(function (x) { return x.id === q.id; }); })).slice(0, SIZE);
    busy = false;
    if (!rows.length) { render(); var b = body.querySelector("#dl-go"); if (b) b.lastChild.textContent = "No tossups at this level"; return; }
    st.round = { scope: st.scope, level: L.level, ids: rows.map(function (q) { return q.id; }), got: {}, at: Date.now() };
    st.last = null; save();
    playList("tossups", st.round.ids, "Ladder, level " + L.level);
  }

  page = ctx.registerPage({
    id: "difficulty-ladder", navLabel: "Difficulty Ladder", title: "Difficulty Ladder",
    onShow: async function (el) {
      body = el;
      // back from a round: what was played of it counts
      if (st.round && Object.keys(st.round.got).length >= 5 && Date.now() - st.round.at > 60000) {
        var s = ctx.getState(); if (!s.sessionActive) finishRound();
      }
      render();
      if (!cats.length) { cats = await roots(); render(); }
    },
  });

}
