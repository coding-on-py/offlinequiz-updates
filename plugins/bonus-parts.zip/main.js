/**
 * OfflineQuiz plugin: Bonus Parts
 *
 * Points per bonus from Stats' history, by category, with how often you get thirty and zero. From
 * the moment it's on it also keeps which parts you miss, and drills those parts until you get them.
 */
QB.registerPlugin({
  id: "bonus-parts",
  name: "Bonus Parts",
  version: "1.0.0",
  author: "OfflineQuiz",
  description: "Track your points per bonus by category and which parts you miss, then drill just those parts.",
  onEnable: __qbMain,
  onDisable: function (ctx) { if (ctx._cleanup) ctx._cleanup(); },
});
