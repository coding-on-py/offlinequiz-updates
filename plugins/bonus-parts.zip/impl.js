function __qbMain(ctx) {
  // ── the kit the 15.62 plugins share (text, icons, questions, judging, history) ──
  function esc(s) { return (s == null ? "" : String(s)).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
  var IC = {
    play: '<path d="M7 4l13 8-13 8z"/>',
    pause: '<path d="M8 5v14M16 5v14"/>',
    left: '<path d="M15 6l-6 6 6 6"/>',
    right: '<path d="M9 6l6 6-6 6"/>',
    next: '<path d="M6 5l9 7-9 7zM18 5v14"/>',
    refresh: '<path d="M20 11a8 8 0 10-2.3 5.7M20 4v7h-7"/>',
    x: '<path d="M6 6l12 12M18 6L6 18"/>',
    check: '<path d="M5 12l5 5 9-10"/>',
    mic: '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
    volume: '<path d="M4 9v6h4l5 4V5L8 9z"/><path d="M16 9a4 4 0 0 1 0 6M19 6a8 8 0 0 1 0 12"/>',
    copy: '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h3"/>',
    edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="M13.5 6.5l4 4"/>',
    bolt: '<path d="M13 3L5 14h6l-1 7 8-11h-6z"/>',
    flag: '<path d="M5 21V4M5 4h11l-2 4 2 4H5"/>',
    users: '<circle cx="9" cy="8" r="3"/><path d="M3 20a6 6 0 0 1 12 0M16 4a3 3 0 0 1 0 6M21 20a6 6 0 0 0-4-5.6"/>',
    target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
    down: '<path d="M6 9l6 6 6-6"/>',
    up: '<path d="M6 15l6-6 6 6"/>',
  };
  function ic(name, size) {
    var s = size || 16;
    return '<svg width="' + s + '" height="' + s + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (IC[name] || "") + "</svg>";
  }
  function loading(label) { return '<div class="pk-loading">' + (ctx.loadingBarHtml ? ctx.loadingBarHtml(label) : esc(label)) + "</div>"; }
  function norm(s) { return String(s || "").toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[^a-z0-9]+/g, " ").trim(); }
  function pct(a, n) { return n ? Math.round(100 * a / n) : 0; }
  function fmt(n) { return Number(n || 0).toLocaleString(); }
  function plural(n, one, many) { return fmt(n) + " " + (n === 1 ? one : (many || one + "s")); }
  function shuffle(a) { for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)), t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
  function inField(e) { var t = e && e.target; return !!t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT" || t.isContentEditable); }
  function dayKey(t) { var d = new Date(t || Date.now()); return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0"); }
  var DAY = 86400000;

  // the practice setup (Setup panel): its filters and reading settings
  function cfg() { try { return (ctx.host && ctx.host.getPracticeConfig && ctx.host.getPracticeConfig()) || {}; } catch (e) { return {}; } }
  // filters → query parameters, the ones the app sends for a random question
  function filtersQuery(f, extra) {
    f = f || {}; var p = [];
    var add = function (k, v) { p.push(k + "=" + encodeURIComponent(v)); };
    if (f.categories && f.categories.length) add("categories", f.categories.join(","));
    if (f.categoryIds && f.categoryIds.length) add("categoryIds", f.categoryIds.join(","));
    if (f.difficulties && f.difficulties.length) add("difficulties", f.difficulties.join(","));
    if (f.setNames && f.setNames.length) add("setNames", f.setNames.join(","));
    if (f.packetNumbers && f.packetNumbers.length) add("packetNumbers", f.packetNumbers.join(","));
    if (f.yearMin != null) add("yearMin", f.yearMin);
    if (f.yearMax != null) add("yearMax", f.yearMax);
    if (f.powermarkOnly) add("powermarkOnly", "true");
    if (f.canon && f.canon.length) add("canon", f.canon.join(","));
    add("cleanOnly", "1");
    Object.keys(extra || {}).forEach(function (k) { if (extra[k] != null && extra[k] !== false) add(k, extra[k]); });
    return p.join("&");
  }
  // the practice filters without a set (a drill draws from everything the player picked)
  function practiceFilters() { var f = Object.assign({}, cfg().filters || {}); delete f.setNames; delete f.packetNumbers; delete f.setIds; return f; }
  async function getTossups(n, f, extra) {
    try { var d = await ctx.api.get("/api/tossups/query?" + filtersQuery(f || practiceFilters(), Object.assign({ random: 1, limit: n }, extra || {}))); return (d && d.rows) || []; } catch (e) { return []; }
  }
  async function getBonuses(n, f, extra) {
    try { var d = await ctx.api.get("/api/bonuses/query?" + filtersQuery(f || practiceFilters(), Object.assign({ random: 1, limit: n }, extra || {}))); return (d && d.rows) || []; } catch (e) { return []; }
  }
  async function getTossup(id) { try { return (await ctx.api.get("/api/tossups/" + encodeURIComponent(id))).tossup || null; } catch (e) { return null; } }
  async function getBonus(id) { try { return (await ctx.api.get("/api/bonuses/" + encodeURIComponent(id))).bonus || null; } catch (e) { return null; } }
  async function searchTossups(query, limit, f) {
    try { var d = await ctx.api.get("/api/tossups/search?query=" + encodeURIComponent(query) + "&limit=" + (limit || 20) + (f ? "&" + filtersQuery(f) : "")); return { rows: (d && d.rows) || [], total: (d && d.total) || 0 }; } catch (e) { return { rows: [], total: 0 }; }
  }
  // tossups whose answer line names an answer
  async function tossupsOn(answer, limit) { return (await searchTossups('answer_sanitized : ("' + String(answer).replace(/"/g, "") + '")', limit || 20)).rows; }

  // a record's text as practice reads it (notes and pronunciation guides per the player's settings)
  function readText(q) {
    try { if (ctx.host && ctx.host.questionText) { var t = ctx.host.questionText(q, "question"); if (t != null) return String(t).replace(/\(\*\)/g, "").replace(/\s{2,}/g, " ").trim(); } } catch (e) {}
    return String((q && q.question_sanitized) || "").replace(/\(\*\)/g, "").trim();
  }
  function powerAt(q) { return String((q && q.question_sanitized) || "").indexOf("(*)"); }
  // sentences, without breaking at "St." or an initial ("J. R. R. Tolkien")
  var ABBR = /(?:\b(?:St|Ste|Mt|Mts|Dr|Mr|Mrs|Ms|Mme|Prof|Sr|Jr|Rev|Fr|Gen|Col|Capt|Lt|Sgt|Maj|Adm|Hon|Pres|Gov|Sen|Rep|vs|etc|cf|ca|al|Inc|Co|Corp|Ltd|Bros|approx|No|Nos|Op|op|no|Vol|vol|Ch|ch|Fig|fig|Ft|Pt|pt|Ave|[A-Za-z])\.["”’']?)$/;
  function sentences(text) {
    var parts = String(text || "").split(/(?<=[.?!]["”’)]*)\s+(?=["“(]?[A-Z0-9])/), out = [], cur = "";
    for (var i = 0; i < parts.length; i++) {
      cur = cur ? cur + " " + parts[i] : parts[i];
      if (i < parts.length - 1 && ABBR.test(cur.trim())) continue;
      out.push(cur.trim()); cur = "";
    }
    if (cur.trim()) out.push(cur.trim());
    return out.filter(Boolean);
  }
  // the answer line, with its bold and underlining (nothing else of the HTML)
  function answerHtml(q) {
    var h = String((q && q.answer) || "");
    if (!/<\/?(b|u|strong|em|i)\b/i.test(h)) return esc((q && q.answer_sanitized) || h);
    return h.replace(/<(\/?)(b|u|strong|em|i)\b[^>]*>/gi, "\u0001$1$2\u0002").replace(/<[^>]*>/g, "").replace(/&(?!(?:amp|lt|gt|quot|#\d+);)/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/\u0001(\/?)(\w+)\u0002/g, "<$1$2>");
  }
  function primary(q) {
    var a = "";
    try { if (ctx.host && ctx.host.extractPrimaryAnswer) a = ctx.host.extractPrimaryAnswer((q && q.answer) || "", (q && q.answer_sanitized) || ""); } catch (e) {}
    return a || String((q && q.answer_sanitized) || "").replace(/\s*[\[(].*$/, "").trim();
  }
  // judged right here, like practice (judge.js); { status: "accept" | "prompt" | "reject", prompt }
  async function judge(q, answer, opts) {
    opts = opts || {};
    try {
      if (ctx.host && ctx.host.judgeTossup) return (await ctx.host.judgeTossup(q, answer, { strictness: opts.strictness != null ? opts.strictness : (cfg().strictness || 10), buzzPosition: opts.buzzPosition, previous: opts.previous || null })) || { status: "reject" };
      return (await ctx.api.post("/api/evaluate-tossup", { questionId: q.id, answer: answer, strictness: cfg().strictness || 10, buzzPosition: opts.buzzPosition, previous: opts.previous || null })) || { status: "reject" };
    } catch (e) { return { status: "reject" }; }
  }
  async function judgePart(b, part, answer, opts) {
    opts = opts || {};
    try {
      if (ctx.host && ctx.host.judgeBonusPart) return (await ctx.host.judgeBonusPart(b, part, answer, { strictness: cfg().strictness || 10, previous: opts.previous || null })) || { status: "reject" };
      return (await ctx.api.post("/api/evaluate-bonus-part", { questionId: b.id, part: part, answer: answer, strictness: cfg().strictness || 10 })) || { status: "reject" };
    } catch (e) { return { status: "reject" }; }
  }
  async function judgeLine(line, sani, answer, opts) {
    opts = opts || {};
    try {
      if (ctx.host && ctx.host.judgeAnswerLine) return (await ctx.host.judgeAnswerLine(line, sani, answer, { strictness: cfg().strictness || 10, previous: opts.previous || null })) || { status: "reject" };
      return (await ctx.api.post("/api/evaluate-answer", { answerline: line, answer: answer, strictness: cfg().strictness || 10 })) || { status: "reject" };
    } catch (e) { return { status: "reject" }; }
  }
  function bonusParts(b) { try { return JSON.parse((b && (b.parts_sanitized || b.parts)) || "[]"); } catch (e) { return []; } }
  function bonusAnswers(b) { try { return JSON.parse((b && b.answers) || "[]"); } catch (e) { return []; } }
  function bonusAnswersSani(b) { try { return JSON.parse((b && b.answers_sanitized) || "[]"); } catch (e) { return []; } }

  // the player's answers (Stats' history), only the fields asked for
  async function history(fields) {
    try { return ((await ctx.api.get("/api/sessions/all-entries?" + (/\banswer\b/.test(fields || "") ? "answers=1&" : "") + "fields=" + encodeURIComponent(fields || ""))).entries) || []; } catch (e) { return []; }
  }
  // record a tossup answered on a plugin's page into the player's stats (the path Coach Mode uses)
  function record(q, r) {
    try {
      ctx.api.post("/api/check-tossup", { questionId: q.id, answer: r.answer || "", buzzPosition: r.buzzPosition || 0, sessionId: r.session, overriding: true,
        correct: !!r.correct, isPower: !!r.power, points: r.points || 0, celerity: r.celerity != null ? r.celerity : 1 }).catch(function () {});
    } catch (e) {}
  }

  var ROOT_COLOR = { "Literature": "#bc8cff", "Science": "#58a6ff", "Math": "#a5e05b", "Pop Culture": "#ff7b72", "Sports": "#ff6f91", "Fine Arts": "#f778ba", "History": "#e3b341", "Geography": "#56d364", "Mythology": "#ffa657", "Social Science": "#3dd6a3", "Philosophy": "#39c5cf", "Theology": "#8e9bff", "Current Events": "#c9d16b", "Miscellaneous": "#8b949e" };
  // NAQT's high school distribution, per 24 tossups / bonuses (naqt.com/hs/distribution.jsp)
  var NAQT = [["Literature", 3.9, 3.8], ["Science", 4.5, 4.3], ["Math", 1.0, 1.0], ["Fine Arts", 2.0, 2.0], ["History", 4.6, 4.5], ["Geography", 1.9, 1.9], ["Mythology", 0.6, 0.7],
    ["Pop Culture", 1.0, 0.9], ["Sports", 0.7, 0.7], ["Social Science", 0.6, 0.6], ["Philosophy", 0.3, 0.3], ["Theology", 0.4, 0.4], ["Current Events", 1.5, 1.4], ["Miscellaneous", 1.0, 1.5]];
  function rootOf(e) { return String((e && (e.category_path || e.category)) || "").split(" > ")[0] || "Miscellaneous"; }
  function dot(root) { return '<span class="pk-dot" style="--c:' + (ROOT_COLOR[root] || "#8b949e") + '"></span>'; }
  var _roots = null;
  async function roots() {
    if (_roots) return _roots;
    try { var t = ctx.host && ctx.host.getCategoryTree ? await ctx.host.getCategoryTree("tossups") : (await ctx.api.get("/api/category-tree?type=tossups")).tree; _roots = (t || []).map(function (n) { return { id: n.id, name: n.name, count: n.count }; }); }
    catch (e) { _roots = []; }
    return _roots;
  }
  var DIFF_NAME = { 0: "Unrated", 1: "Middle school", 2: "Easy high school", 3: "Regular high school", 4: "Hard high school", 5: "National high school", 6: "Easy college", 7: "Medium college", 8: "Regionals college", 9: "Nationals college", 10: "Open" };

  function tile(value, label, cls) { return '<div class="pk-tile' + (cls ? " " + cls : "") + '"><b class="num">' + value + "</b><span>" + esc(label) + "</span></div>"; }
  function segHtml(name, items, on) {
    return '<div class="seg pk-seg" role="group">' + items.map(function (it) {
      return '<button type="button" data-' + name + '="' + esc(it[0]) + '" aria-pressed="' + (String(on) === String(it[0])) + '">' + esc(it[1]) + "</button>";
    }).join("") + "</div>";
  }
  function emptyHtml(text) { return '<div class="db-empty pk-empty">' + esc(text) + "</div>"; }
  function playList(kind, ids, title) {
    if (!ids || !ids.length) return false;
    try { return !!(ctx.host && ctx.host.launchQuestions && ctx.host.launchQuestions(kind, ids, { title: title })); } catch (e) { return false; }
  }

  // a reader: shows `text` a character at a time at the practice reading speed. start(), pause(), go(), stop();
  // at() is how far it is; onEnd once it's all shown
  function Reader(el, text, opts) {
    opts = opts || {};
    var ms = opts.ms != null ? opts.ms : (Number(cfg().revealSpeed) || 25), idx = 0, raf = 0, last = 0, on = false;
    var paint = function () { el.innerHTML = '<span class="pk-read">' + esc(text.slice(0, idx)) + '</span><span class="pk-unread" aria-hidden="true">' + esc(text.slice(idx)) + "</span>"; };
    var step = function (t) {
      raf = 0; if (!on) return;
      if (!last) last = t;
      var n = ms > 0 ? Math.floor((t - last) / ms) : text.length;
      if (n > 0) { idx = Math.min(text.length, idx + n); last += n * ms; paint(); if (opts.onTick) opts.onTick(idx); }
      if (idx >= text.length) { on = false; if (opts.onEnd) opts.onEnd(); return; }
      raf = requestAnimationFrame(step);
    };
    paint();
    return {
      start: function () { if (on) return; on = true; last = 0; raf = requestAnimationFrame(step); },
      pause: function () { on = false; if (raf) cancelAnimationFrame(raf); raf = 0; },
      stop: function () { on = false; if (raf) cancelAnimationFrame(raf); raf = 0; },
      showAll: function () { this.stop(); idx = text.length; el.textContent = text; },
      at: function () { return idx; },
      running: function () { return on; },
    };
  }
  // a reader's position in the displayed text → the record's question_sanitized (what judging and stats count)
  function serverPos(q, display, pos) {
    try { if (ctx.host && ctx.host.mapDisplayPos) return ctx.host.mapDisplayPos(display, (q && q.question_sanitized) || "", pos); } catch (e) {}
    return pos;
  }

  // ── Bonus Parts: points per bonus by category, which parts you miss, and a drill on just those parts ──
  // Stats' history keeps how many parts of a bonus you got; which ones is kept here, from every bonus played while
  // the plugin is on (log: [{ id, root, parts: [1, 0, 1], at }]). A missed part stays on the drill list until you get it.
  var body = null, page = null, entries = null;
  var view = Object.assign({ weeks: 12 }, ctx.storage.get("view") || {});
  var log = ctx.storage.get("log") || [], missed = ctx.storage.get("missed") || [];
  function save() { ctx.storage.set("view", view); ctx.storage.set("log", log.slice(-3000)); ctx.storage.set("missed", missed.slice(-500)); }
  var PERIODS = [[4, "4 weeks"], [12, "12 weeks"], [0, "All time"]];
  var drill = null;

  // a bonus played in practice: which parts were right
  ctx.on("bonus:result", function (d) {
    try {
      var b = ctx.getState().currentQuestion, parts = (d && d.result && d.result.parts) || [];
      if (!b || !b.id || !parts.length) return;
      var got = parts.map(function (p) { return p && p.correct ? 1 : 0; });
      log.push({ id: b.id, root: rootOf(b), parts: got, at: Date.now() });
      got.forEach(function (g, i) {
        var k = b.id + ":" + i, at = missed.findIndex(function (m) { return m.k === k; });
        if (!g && at < 0) missed.push({ k: k, id: b.id, part: i, root: rootOf(b), at: Date.now() });
        if (g && at >= 0) missed.splice(at, 1);
      });
      save();
    } catch (e) {}
  });

  function render() {
    if (!body) return;
    if (drill) return renderDrill();
    if (!entries) { body.innerHTML = '<div class="pk-wrap bp">' + loading("Reading your bonuses…") + "</div>"; return; }
    var since = view.weeks ? Date.now() - view.weeks * 7 * DAY : 0;
    var list = entries.filter(function (e) { return e.timestamp >= since; });
    var pts = 0, dist = [0, 0, 0, 0], cats = {};
    list.forEach(function (e) {
      var got = Math.max(0, Math.min(3, Number(e.bonus_parts_correct) || Math.round((e.points || 0) / 10)));
      pts += e.points || got * 10; dist[got]++;
      var r = rootOf(e), c = cats[r] = cats[r] || { n: 0, pts: 0 }; c.n++; c.pts += e.points || got * 10;
    });
    var n = list.length, ppb = n ? pts / n : 0;
    var byPart = [0, 1, 2].map(function (i) { var h = 0, g = 0; log.forEach(function (l) { if (l.at >= since && l.parts.length > i) { h++; g += l.parts[i]; } }); return { h: h, g: g }; });
    var rows = Object.keys(cats).map(function (r) { return { r: r, n: cats[r].n, ppb: cats[r].pts / cats[r].n }; }).filter(function (x) { return x.n >= 3; }).sort(function (a, b) { return a.ppb - b.ppb; });
    body.innerHTML = '<div class="pk-wrap bp">' +
      '<div class="pk-bar-top">' + segHtml("weeks", PERIODS, view.weeks) + '<span class="spacer"></span>' +
        '<button type="button" class="btn' + (missed.length ? " btn-primary" : "") + '" id="bp-drill"' + (missed.length ? "" : " disabled") + ">" + ic("play", 14) + "Practice missed parts" + (missed.length ? " (" + missed.length + ")" : "") + "</button></div>" +
      (!n ? emptyHtml("No bonuses in this period yet.") :
      '<div class="pk-tiles">' + tile(ppb.toFixed(1), "Points per bonus", "pk-good") + tile(pct(dist[3], n) + "<small>%</small>", "Thirty", "pk-gold") + tile(pct(dist[0], n) + "<small>%</small>", "Zero", "pk-bad") + tile(fmt(n), "Bonuses") + "</div>" +
      '<div class="pk-card"><h3>How your bonuses go</h3><div class="bp-dist">' + [0, 1, 2, 3].map(function (k) {
          return '<span class="bp-seg bp-s' + k + '" style="flex-grow:' + Math.max(dist[k], 0.001) + '" title="' + dist[k] + " bonuses for " + k * 10 + '"></span>';
        }).join("") + '</div><div class="bp-key">' + [0, 1, 2, 3].map(function (k) { return '<span><i class="bp-s' + k + '"></i>' + k * 10 + " · " + pct(dist[k], n) + "%</span>"; }).join("") + "</div></div>" +
      '<div class="pk-card"><h3>By part</h3>' + (byPart[0].h ? byPart.map(function (p, i) {
          return '<div class="pk-row bp-part"><span class="bp-pl">Part ' + "ABC"[i] + '</span><span class="pk-grow"><span class="pk-meter"><span style="width:' + pct(p.g, p.h) + '%;--c:var(--green)"></span></span></span><span class="num bp-pn"><b>' + pct(p.g, p.h) + '%</b><small class="pk-muted"> of ' + p.h + "</small></span></div>";
        }).join("") + '<div class="pk-muted pk-small" style="margin-top:6px">From the bonuses you\'ve played since turning Bonus Parts on.</div>' : '<div class="pk-muted pk-small">Play some bonuses and this shows which parts you get. Bonus Parts keeps track from now on.</div>') + "</div>" +
      (rows.length ? '<div class="pk-sechead"><span class="eyebrow">Points per bonus by category, lowest first</span></div><div class="list pk-list">' + rows.map(function (x) {
          return '<div class="list-row">' + dot(x.r) + '<span class="bp-name">' + esc(x.r) + '</span><span class="pk-grow"><span class="pk-meter"><span style="width:' + (100 * x.ppb / 30) + "%;--c:" + (ROOT_COLOR[x.r] || "var(--accent)") + '"></span></span></span><span class="num bp-pn"><b>' + x.ppb.toFixed(1) + '</b><small class="pk-muted"> · ' + x.n + "</small></span></div>";
        }).join("") + "</div>" : "")) + "</div>";
    body.querySelectorAll("[data-weeks]").forEach(function (b) { b.onclick = function () { view.weeks = Number(b.dataset.weeks); save(); render(); }; });
    body.querySelector("#bp-drill").onclick = startDrill;
  }

  // ── the drill: one missed part at a time, with its lead-in ──
  async function startDrill() {
    if (!missed.length) return;
    drill = { items: shuffle(missed.slice()).slice(0, 30), i: 0, right: 0, cur: null };
    await loadItem();
  }
  async function loadItem() {
    if (!drill) return;
    if (drill.i >= drill.items.length) { var r = drill.right, n = drill.items.length; drill = null; render(); var top = body.querySelector(".pk-bar-top"); if (top) top.insertAdjacentHTML("afterend", '<div class="pk-card bp-done">You got <b>' + r + "</b> of " + n + " missed parts.</div>"); return; }
    renderDrill(true);
    var it = drill.items[drill.i], b = await getBonus(it.id);
    if (!drill) return;
    if (!b) { drill.i++; return loadItem(); }
    var parts = bonusParts(b);
    if (!parts[it.part]) { drill.i++; return loadItem(); }
    drill.cur = { b: b, it: it, phase: "answering", prompt: null, lead: (b.leadin_sanitized || "").replace(/\(\*\)/g, ""), text: parts[it.part] };
    renderDrill();
  }
  function renderDrill(wait) {
    var d = drill, c = d && d.cur;
    body.innerHTML = '<div class="pk-wrap bp"><div class="pk-bar-top"><span class="pk-chip">Part ' + (d.i + 1) + " of " + d.items.length + '</span><span class="pk-chip">' + d.right + ' right</span><span class="spacer"></span><button type="button" class="btn btn-ghost" id="bp-stop">Stop</button></div>' +
      '<div class="pk-card bp-card">' + (wait || !c ? loading("Getting the bonus…") :
        '<div class="pk-meta">' + dot(c.it.root) + esc(c.it.root) + " · Part " + "ABCDEFGHI"[c.it.part] + "</div>" +
        '<div class="pk-q bp-lead">' + esc(c.lead) + '</div><div class="pk-q">' + esc(c.text) + "</div>" +
        (c.phase === "done" ? '<div>' + c.verdict + '</div><div class="pk-answer"><span class="pk-muted">Answer </span>' + c.ans + '</div><div class="pk-actions"><button type="button" class="btn btn-primary" id="bp-next">Next<span class="pk-kbd">N</span></button></div>'
          : (c.prompt != null ? '<div class="pk-prompt">Prompt' + (c.promptAsk ? ": " + esc(c.promptAsk) : "") + "</div>" : "") +
            '<div class="pk-input"><input id="bp-ans" autocomplete="off" spellcheck="false" placeholder="Your answer" aria-label="Your answer"><button type="button" class="btn btn-primary" id="bp-go">Answer</button></div>')) + "</div></div>";
    body.querySelector("#bp-stop").onclick = function () { drill = null; render(); };
    var inp = body.querySelector("#bp-ans");
    if (inp) { inp.focus(); inp.addEventListener("keydown", function (e) { if (e.key === "Enter") { e.preventDefault(); answer(inp.value.trim()); } e.stopPropagation(); }); body.querySelector("#bp-go").onclick = function () { answer(inp.value.trim()); }; }
    var nx = body.querySelector("#bp-next"); if (nx) nx.onclick = function () { drill.i++; loadItem(); };
  }
  async function answer(a) {
    var c = drill && drill.cur; if (!c || c.phase !== "answering") return;
    c.phase = "judging";
    var r = a ? await judgePart(c.b, c.it.part, a, { previous: c.prompt }) : { status: "reject" };
    if (!drill || drill.cur !== c) return;
    if (r.status === "prompt" && c.prompt == null) { c.prompt = a; c.promptAsk = (r.prompt && r.prompt.ask) || ""; c.phase = "answering"; renderDrill(); return; }
    var right = r.status === "accept";
    if (right) { drill.right++; missed = missed.filter(function (m) { return m.k !== c.it.k; }); save(); }
    ctx.playSound(right ? "correct" : "incorrect");
    var raw = bonusAnswers(c.b)[c.it.part] || "", sani = bonusAnswersSani(c.b)[c.it.part] || "";
    c.ans = answerHtml({ answer: raw, answer_sanitized: sani });
    c.verdict = right ? '<span class="pk-verdict pk-ok">' + ic("check", 15) + "Right. It's off your list</span>" : '<span class="pk-verdict pk-no">' + ic("x", 15) + (a ? "Not “" + esc(a) + "”" : "Missed") + "</span>";
    c.phase = "done";
    renderDrill();
  }

  function active() { return page && page.screenEl && page.screenEl.classList.contains("active"); }
  function onKey(e) {
    if (!active() || inField(e) || e.metaKey || e.ctrlKey || e.altKey) return;
    if ((e.key === "n" || e.key === "N") && drill && drill.cur && drill.cur.phase === "done") { e.preventDefault(); drill.i++; loadItem(); }
  }
  document.addEventListener("keydown", onKey);
  ctx._cleanup = function () { document.removeEventListener("keydown", onKey); };
  page = ctx.registerPage({
    id: "bonus-parts", navLabel: "Bonus Parts", title: "Bonus Parts",
    onShow: function (el) {
      body = el; if (drill) { renderDrill(); return; }
      entries = null; render();
      history("type,points,bonus_parts_correct,category_path,category,timestamp").then(function (es) { entries = es.filter(function (e) { return e.type === "bonus"; }); render(); });
    },
  });

}
