function __qbMain(ctx) {
  // ── the kit the 15.62 plugins share (text, icons, questions, judging, history) ──
  function esc(s) { return (s == null ? "" : String(s)).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
  var IC = {
    play: '<path d="M7 4l13 8-13 8z"/>',
    pause: '<path d="M8 5v14M16 5v14"/>',
    left: '<path d="M15 6l-6 6 6 6"/>',
    right: '<path d="M9 6l6 6-6 6"/>',
    next: '<path d="M6 5l9 7-9 7zM18 5v14"/>',
    refresh: '<path d="M20 11a8 8 0 10-2.3 5.7M20 4v7h-7"/>',
    x: '<path d="M6 6l12 12M18 6L6 18"/>',
    check: '<path d="M5 12l5 5 9-10"/>',
    mic: '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
    volume: '<path d="M4 9v6h4l5 4V5L8 9z"/><path d="M16 9a4 4 0 0 1 0 6M19 6a8 8 0 0 1 0 12"/>',
    copy: '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h3"/>',
    edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="M13.5 6.5l4 4"/>',
    bolt: '<path d="M13 3L5 14h6l-1 7 8-11h-6z"/>',
    flag: '<path d="M5 21V4M5 4h11l-2 4 2 4H5"/>',
    users: '<circle cx="9" cy="8" r="3"/><path d="M3 20a6 6 0 0 1 12 0M16 4a3 3 0 0 1 0 6M21 20a6 6 0 0 0-4-5.6"/>',
    target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
    down: '<path d="M6 9l6 6 6-6"/>',
    up: '<path d="M6 15l6-6 6 6"/>',
  };
  function ic(name, size) {
    var s = size || 16;
    return '<svg width="' + s + '" height="' + s + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (IC[name] || "") + "</svg>";
  }
  function loading(label) { return '<div class="pk-loading">' + (ctx.loadingBarHtml ? ctx.loadingBarHtml(label) : esc(label)) + "</div>"; }
  function norm(s) { return String(s || "").toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[^a-z0-9]+/g, " ").trim(); }
  function pct(a, n) { return n ? Math.round(100 * a / n) : 0; }
  function fmt(n) { return Number(n || 0).toLocaleString(); }
  function plural(n, one, many) { return fmt(n) + " " + (n === 1 ? one : (many || one + "s")); }
  function shuffle(a) { for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)), t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
  function inField(e) { var t = e && e.target; return !!t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT" || t.isContentEditable); }
  function dayKey(t) { var d = new Date(t || Date.now()); return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0"); }
  var DAY = 86400000;

  // the practice setup (Setup panel): its filters and reading settings
  function cfg() { try { return (ctx.host && ctx.host.getPracticeConfig && ctx.host.getPracticeConfig()) || {}; } catch (e) { return {}; } }
  // filters → query parameters, the ones the app sends for a random question
  function filtersQuery(f, extra) {
    f = f || {}; var p = [];
    var add = function (k, v) { p.push(k + "=" + encodeURIComponent(v)); };
    if (f.categories && f.categories.length) add("categories", f.categories.join(","));
    if (f.categoryIds && f.categoryIds.length) add("categoryIds", f.categoryIds.join(","));
    if (f.difficulties && f.difficulties.length) add("difficulties", f.difficulties.join(","));
    if (f.setNames && f.setNames.length) add("setNames", f.setNames.join(","));
    if (f.packetNumbers && f.packetNumbers.length) add("packetNumbers", f.packetNumbers.join(","));
    if (f.yearMin != null) add("yearMin", f.yearMin);
    if (f.yearMax != null) add("yearMax", f.yearMax);
    if (f.powermarkOnly) add("powermarkOnly", "true");
    if (f.canon && f.canon.length) add("canon", f.canon.join(","));
    add("cleanOnly", "1");
    Object.keys(extra || {}).forEach(function (k) { if (extra[k] != null && extra[k] !== false) add(k, extra[k]); });
    return p.join("&");
  }
  // the practice filters without a set (a drill draws from everything the player picked)
  function practiceFilters() { var f = Object.assign({}, cfg().filters || {}); delete f.setNames; delete f.packetNumbers; delete f.setIds; return f; }
  async function getTossups(n, f, extra) {
    try { var d = await ctx.api.get("/api/tossups/query?" + filtersQuery(f || practiceFilters(), Object.assign({ random: 1, limit: n }, extra || {}))); return (d && d.rows) || []; } catch (e) { return []; }
  }
  async function getBonuses(n, f, extra) {
    try { var d = await ctx.api.get("/api/bonuses/query?" + filtersQuery(f || practiceFilters(), Object.assign({ random: 1, limit: n }, extra || {}))); return (d && d.rows) || []; } catch (e) { return []; }
  }
  async function getTossup(id) { try { return (await ctx.api.get("/api/tossups/" + encodeURIComponent(id))).tossup || null; } catch (e) { return null; } }
  async function getBonus(id) { try { return (await ctx.api.get("/api/bonuses/" + encodeURIComponent(id))).bonus || null; } catch (e) { return null; } }
  async function searchTossups(query, limit, f) {
    try { var d = await ctx.api.get("/api/tossups/search?query=" + encodeURIComponent(query) + "&limit=" + (limit || 20) + (f ? "&" + filtersQuery(f) : "")); return { rows: (d && d.rows) || [], total: (d && d.total) || 0 }; } catch (e) { return { rows: [], total: 0 }; }
  }
  // tossups whose answer line names an answer
  async function tossupsOn(answer, limit) { return (await searchTossups('answer_sanitized : ("' + String(answer).replace(/"/g, "") + '")', limit || 20)).rows; }

  // a record's text as practice reads it (notes and pronunciation guides per the player's settings)
  function readText(q) {
    try { if (ctx.host && ctx.host.questionText) { var t = ctx.host.questionText(q, "question"); if (t != null) return String(t).replace(/\(\*\)/g, "").replace(/\s{2,}/g, " ").trim(); } } catch (e) {}
    return String((q && q.question_sanitized) || "").replace(/\(\*\)/g, "").trim();
  }
  function powerAt(q) { return String((q && q.question_sanitized) || "").indexOf("(*)"); }
  // sentences, without breaking at "St." or an initial ("J. R. R. Tolkien")
  var ABBR = /(?:\b(?:St|Ste|Mt|Mts|Dr|Mr|Mrs|Ms|Mme|Prof|Sr|Jr|Rev|Fr|Gen|Col|Capt|Lt|Sgt|Maj|Adm|Hon|Pres|Gov|Sen|Rep|vs|etc|cf|ca|al|Inc|Co|Corp|Ltd|Bros|approx|No|Nos|Op|op|no|Vol|vol|Ch|ch|Fig|fig|Ft|Pt|pt|Ave|[A-Za-z])\.["”’']?)$/;
  function sentences(text) {
    var parts = String(text || "").split(/(?<=[.?!]["”’)]*)\s+(?=["“(]?[A-Z0-9])/), out = [], cur = "";
    for (var i = 0; i < parts.length; i++) {
      cur = cur ? cur + " " + parts[i] : parts[i];
      if (i < parts.length - 1 && ABBR.test(cur.trim())) continue;
      out.push(cur.trim()); cur = "";
    }
    if (cur.trim()) out.push(cur.trim());
    return out.filter(Boolean);
  }
  // the answer line, with its bold and underlining (nothing else of the HTML)
  function answerHtml(q) {
    var h = String((q && q.answer) || "");
    if (!/<\/?(b|u|strong|em|i)\b/i.test(h)) return esc((q && q.answer_sanitized) || h);
    return h.replace(/<(\/?)(b|u|strong|em|i)\b[^>]*>/gi, "\u0001$1$2\u0002").replace(/<[^>]*>/g, "").replace(/&(?!(?:amp|lt|gt|quot|#\d+);)/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/\u0001(\/?)(\w+)\u0002/g, "<$1$2>");
  }
  function primary(q) {
    var a = "";
    try { if (ctx.host && ctx.host.extractPrimaryAnswer) a = ctx.host.extractPrimaryAnswer((q && q.answer) || "", (q && q.answer_sanitized) || ""); } catch (e) {}
    return a || String((q && q.answer_sanitized) || "").replace(/\s*[\[(].*$/, "").trim();
  }
  // judged right here, like practice (judge.js); { status: "accept" | "prompt" | "reject", prompt }
  async function judge(q, answer, opts) {
    opts = opts || {};
    try {
      if (ctx.host && ctx.host.judgeTossup) return (await ctx.host.judgeTossup(q, answer, { strictness: opts.strictness != null ? opts.strictness : (cfg().strictness || 10), buzzPosition: opts.buzzPosition, previous: opts.previous || null })) || { status: "reject" };
      return (await ctx.api.post("/api/evaluate-tossup", { questionId: q.id, answer: answer, strictness: cfg().strictness || 10, buzzPosition: opts.buzzPosition, previous: opts.previous || null })) || { status: "reject" };
    } catch (e) { return { status: "reject" }; }
  }
  async function judgePart(b, part, answer, opts) {
    opts = opts || {};
    try {
      if (ctx.host && ctx.host.judgeBonusPart) return (await ctx.host.judgeBonusPart(b, part, answer, { strictness: cfg().strictness || 10, previous: opts.previous || null })) || { status: "reject" };
      return (await ctx.api.post("/api/evaluate-bonus-part", { questionId: b.id, part: part, answer: answer, strictness: cfg().strictness || 10 })) || { status: "reject" };
    } catch (e) { return { status: "reject" }; }
  }
  async function judgeLine(line, sani, answer, opts) {
    opts = opts || {};
    try {
      if (ctx.host && ctx.host.judgeAnswerLine) return (await ctx.host.judgeAnswerLine(line, sani, answer, { strictness: cfg().strictness || 10, previous: opts.previous || null })) || { status: "reject" };
      return (await ctx.api.post("/api/evaluate-answer", { answerline: line, answer: answer, strictness: cfg().strictness || 10 })) || { status: "reject" };
    } catch (e) { return { status: "reject" }; }
  }
  function bonusParts(b) { try { return JSON.parse((b && (b.parts_sanitized || b.parts)) || "[]"); } catch (e) { return []; } }
  function bonusAnswers(b) { try { return JSON.parse((b && b.answers) || "[]"); } catch (e) { return []; } }
  function bonusAnswersSani(b) { try { return JSON.parse((b && b.answers_sanitized) || "[]"); } catch (e) { return []; } }

  // the player's answers (Stats' history), only the fields asked for
  async function history(fields) {
    try { return ((await ctx.api.get("/api/sessions/all-entries?" + (/\banswer\b/.test(fields || "") ? "answers=1&" : "") + "fields=" + encodeURIComponent(fields || ""))).entries) || []; } catch (e) { return []; }
  }
  // record a tossup answered on a plugin's page into the player's stats (the path Coach Mode uses)
  function record(q, r) {
    try {
      ctx.api.post("/api/check-tossup", { questionId: q.id, answer: r.answer || "", buzzPosition: r.buzzPosition || 0, sessionId: r.session, overriding: true,
        correct: !!r.correct, isPower: !!r.power, points: r.points || 0, celerity: r.celerity != null ? r.celerity : 1 }).catch(function () {});
    } catch (e) {}
  }

  var ROOT_COLOR = { "Literature": "#bc8cff", "Science": "#58a6ff", "Math": "#a5e05b", "Pop Culture": "#ff7b72", "Sports": "#ff6f91", "Fine Arts": "#f778ba", "History": "#e3b341", "Geography": "#56d364", "Mythology": "#ffa657", "Social Science": "#3dd6a3", "Philosophy": "#39c5cf", "Theology": "#8e9bff", "Current Events": "#c9d16b", "Miscellaneous": "#8b949e" };
  // NAQT's high school distribution, per 24 tossups / bonuses (naqt.com/hs/distribution.jsp)
  var NAQT = [["Literature", 3.9, 3.8], ["Science", 4.5, 4.3], ["Math", 1.0, 1.0], ["Fine Arts", 2.0, 2.0], ["History", 4.6, 4.5], ["Geography", 1.9, 1.9], ["Mythology", 0.6, 0.7],
    ["Pop Culture", 1.0, 0.9], ["Sports", 0.7, 0.7], ["Social Science", 0.6, 0.6], ["Philosophy", 0.3, 0.3], ["Theology", 0.4, 0.4], ["Current Events", 1.5, 1.4], ["Miscellaneous", 1.0, 1.5]];
  function rootOf(e) { return String((e && (e.category_path || e.category)) || "").split(" > ")[0] || "Miscellaneous"; }
  function dot(root) { return '<span class="pk-dot" style="--c:' + (ROOT_COLOR[root] || "#8b949e") + '"></span>'; }
  var _roots = null;
  async function roots() {
    if (_roots) return _roots;
    try { var t = ctx.host && ctx.host.getCategoryTree ? await ctx.host.getCategoryTree("tossups") : (await ctx.api.get("/api/category-tree?type=tossups")).tree; _roots = (t || []).map(function (n) { return { id: n.id, name: n.name, count: n.count }; }); }
    catch (e) { _roots = []; }
    return _roots;
  }
  var DIFF_NAME = { 0: "Unrated", 1: "Middle school", 2: "Easy high school", 3: "Regular high school", 4: "Hard high school", 5: "National high school", 6: "Easy college", 7: "Medium college", 8: "Regionals college", 9: "Nationals college", 10: "Open" };

  function tile(value, label, cls) { return '<div class="pk-tile' + (cls ? " " + cls : "") + '"><b class="num">' + value + "</b><span>" + esc(label) + "</span></div>"; }
  function segHtml(name, items, on) {
    return '<div class="seg pk-seg" role="group">' + items.map(function (it) {
      return '<button type="button" data-' + name + '="' + esc(it[0]) + '" aria-pressed="' + (String(on) === String(it[0])) + '">' + esc(it[1]) + "</button>";
    }).join("") + "</div>";
  }
  function emptyHtml(text) { return '<div class="db-empty pk-empty">' + esc(text) + "</div>"; }
  function playList(kind, ids, title) {
    if (!ids || !ids.length) return false;
    try { return !!(ctx.host && ctx.host.launchQuestions && ctx.host.launchQuestions(kind, ids, { title: title })); } catch (e) { return false; }
  }

  // a reader: shows `text` a character at a time at the practice reading speed. start(), pause(), go(), stop();
  // at() is how far it is; onEnd once it's all shown
  function Reader(el, text, opts) {
    opts = opts || {};
    var ms = opts.ms != null ? opts.ms : (Number(cfg().revealSpeed) || 25), idx = 0, raf = 0, last = 0, on = false;
    var paint = function () { el.innerHTML = '<span class="pk-read">' + esc(text.slice(0, idx)) + '</span><span class="pk-unread" aria-hidden="true">' + esc(text.slice(idx)) + "</span>"; };
    var step = function (t) {
      raf = 0; if (!on) return;
      if (!last) last = t;
      var n = ms > 0 ? Math.floor((t - last) / ms) : text.length;
      if (n > 0) { idx = Math.min(text.length, idx + n); last += n * ms; paint(); if (opts.onTick) opts.onTick(idx); }
      if (idx >= text.length) { on = false; if (opts.onEnd) opts.onEnd(); return; }
      raf = requestAnimationFrame(step);
    };
    paint();
    return {
      start: function () { if (on) return; on = true; last = 0; raf = requestAnimationFrame(step); },
      pause: function () { on = false; if (raf) cancelAnimationFrame(raf); raf = 0; },
      stop: function () { on = false; if (raf) cancelAnimationFrame(raf); raf = 0; },
      showAll: function () { this.stop(); idx = text.length; el.textContent = text; },
      at: function () { return idx; },
      running: function () { return on; },
    };
  }
  // a reader's position in the displayed text → the record's question_sanitized (what judging and stats count)
  function serverPos(q, display, pos) {
    try { if (ctx.host && ctx.host.mapDisplayPos) return ctx.host.mapDisplayPos(display, (q && q.question_sanitized) || "", pos); } catch (e) {}
    return pos;
  }

  // ── Challenge: the same tossups for you and a friend, compared buzz by buzz ──
  // A challenge is a code: its tossups (ids packed small), who made it and how they did on each (points and how much
  // was read). Play the tossups, and you get a code back to send with your own results.
  var body = null, page = null, sess = "challenge-" + Date.now();
  var mine = ctx.storage.get("list") || [];            // [{ code, name, at, me: [..], them: [..], ids, mode: "made" | "took" }]
  function saveList() { ctx.storage.set("list", mine.slice(-40)); }
  var st = { view: "home", count: 10 }, game = null, reader = null;

  // ── codes ──
  function b64u(bytes) { var s = ""; bytes.forEach(function (b) { s += String.fromCharCode(b); }); return btoa(s).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, ""); }
  function unb64u(s) { s = String(s).replace(/-/g, "+").replace(/_/g, "/"); while (s.length % 4) s += "="; var b = atob(s), out = []; for (var i = 0; i < b.length; i++) out.push(b.charCodeAt(i)); return out; }
  // "QB-" + the ids packed (12 bytes each) + "." + the rest as JSON; ids that aren't 24 hex digits go in the JSON
  function encode(o) {
    var hex = o.ids.every(function (id) { return /^[0-9a-f]{24}$/.test(id); });
    var p = { v: 1, n: o.name || "", r: o.res.map(function (r) { return r ? r.pts + ":" + Math.round((r.at || 0) * 100) : "x"; }).join(",") }, packed = "";
    if (hex) { var bytes = []; o.ids.forEach(function (id) { for (var i = 0; i < 24; i += 2) bytes.push(parseInt(id.slice(i, i + 2), 16)); }); packed = b64u(bytes); } else p.i = o.ids;
    return "QB-" + packed + "." + b64u(Array.from(new TextEncoder().encode(JSON.stringify(p))));
  }
  function decode(code) {
    try {
      var m = /QB-([A-Za-z0-9_-]*)\.([A-Za-z0-9_-]+)/.exec(String(code).replace(/\s+/g, "")); if (!m) return null;
      var p = JSON.parse(new TextDecoder().decode(new Uint8Array(unb64u(m[2]))));
      var ids = p.i || [];
      if (m[1]) { var b = unb64u(m[1]); for (var i = 0; i + 12 <= b.length; i += 12) ids.push(b.slice(i, i + 12).map(function (x) { return x.toString(16).padStart(2, "0"); }).join("")); }
      var res = String(p.r || "").split(",").map(function (x) { if (!x || x === "x") return null; var a = x.split(":"); return { pts: Number(a[0]) || 0, at: (Number(a[1]) || 0) / 100 }; });
      return ids.length ? { name: p.n || "A friend", ids: ids.slice(0, 40), res: res } : null;
    } catch (e) { return null; }
  }
  function myName() { var s = ctx.getState() || {}; return (s.account && (s.account.displayName || s.account.handle)) || s.username || "Me"; }
  function total(res) { return (res || []).reduce(function (s, r) { return s + (r ? r.pts : 0); }, 0); }

  function render() {
    if (!body) return;
    if (st.view === "play") return renderPlay();
    if (st.view === "result") return renderResult();
    body.innerHTML = '<div class="pk-wrap ch">' +
      '<div class="ch-two"><div class="pk-card"><h3>Make a challenge</h3><div class="pk-muted pk-small" style="margin:-4px 0 12px">Play tossups from your Setup, then send the code to a friend. They play the same ones.</div>' +
        '<div class="pk-actions">' + segHtml("count", [[10, "10 tossups"], [20, "20 tossups"]], st.count) + '<button type="button" class="btn btn-primary" id="ch-make">' + ic("play", 14) + "Play</button></div></div>" +
      '<div class="pk-card"><h3>Take a challenge</h3><div class="pk-muted pk-small" style="margin:-4px 0 12px">Paste the code a friend sent you.</div>' +
        '<div class="pk-input"><input id="ch-code" placeholder="QB-…" autocomplete="off" spellcheck="false" aria-label="Challenge code"><button type="button" class="btn btn-primary" id="ch-take">Open</button></div><div class="pk-small pk-bad" id="ch-err"></div></div></div>' +
      (mine.length ? '<div class="pk-sechead"><span class="eyebrow">Your challenges</span></div><div class="list pk-list">' + mine.slice().reverse().map(function (c, i) {
        var me = total(c.me), them = c.them ? total(c.them) : null;
        return '<button type="button" class="list-row clickable ch-row" data-open="' + (mine.length - 1 - i) + '"><span class="pk-grow ch-what"><b>' + (c.mode === "made" ? "You made it" : "From " + esc(c.name)) + '</b><small class="pk-muted">' + plural(c.ids.length, "tossup") + " · " + new Date(c.at).toLocaleDateString(undefined, { month: "short", day: "numeric" }) + "</small></span>" +
          '<span class="num ch-score"><b>' + me + "</b>" + (them != null ? '<span class="pk-muted"> vs ' + them + "</span>" : "") + "</span>" + ic("right", 15) + "</button>";
      }).join("") + "</div>" : "") + "</div>";
    body.querySelectorAll("[data-count]").forEach(function (b) { b.onclick = function () { st.count = Number(b.dataset.count); render(); }; });
    body.querySelector("#ch-make").onclick = make;
    var inp = body.querySelector("#ch-code");
    inp.addEventListener("keydown", function (e) { e.stopPropagation(); if (e.key === "Enter") take(); });
    body.querySelector("#ch-take").onclick = take;
    body.querySelectorAll("[data-open]").forEach(function (b) { b.onclick = function () { st.view = "result"; st.open = +b.dataset.open; render(); }; });
  }
  async function make() {
    var b = body.querySelector("#ch-make"); if (b) { b.disabled = true; b.lastChild.textContent = "Finding tossups…"; }
    var rows = await getTossups(st.count, null, { powermarkOnly: "true" });
    if (!rows.length) rows = await getTossups(st.count);
    if (!rows.length) { if (b) { b.disabled = false; b.lastChild.textContent = "No tossups found"; } return; }
    start(rows, null);
  }
  async function take() {
    var c = decode(body.querySelector("#ch-code").value), err = body.querySelector("#ch-err");
    if (!c) { err.textContent = "That isn't a challenge code."; return; }
    // a code for a challenge you already played: show how it compares
    var same = mine.findIndex(function (m) { return m.ids.join() === c.ids.join(); });
    if (same >= 0 && mine[same].me) { if (!mine[same].them || c.name !== myName()) { mine[same].them = c.res; mine[same].themName = c.name; saveList(); } st.view = "result"; st.open = same; render(); return; }
    err.textContent = ""; var b = body.querySelector("#ch-take"); b.disabled = true; b.textContent = "Loading…";
    var rows = (await Promise.all(c.ids.map(getTossup))).filter(Boolean);
    b.disabled = false; b.textContent = "Open";
    if (!rows.length) { err.textContent = "Those tossups aren't in this question database."; return; }
    start(rows, c);
  }
  function start(rows, from) {
    game = { rows: rows, i: 0, res: [], from: from, cur: null };
    st.view = "play"; render(); nextQ();
  }

  // ── playing ──
  function renderPlay() {
    var g = game;
    body.innerHTML = '<div class="pk-wrap ch"><div class="pk-bar-top"><span class="pk-chip">Tossup ' + Math.min(g.rows.length, g.i + 1) + " of " + g.rows.length + '</span><span class="pk-chip">' + total(g.res) + " points</span>" + (g.from ? '<span class="pk-muted pk-small">Challenge from ' + esc(g.from.name) + "</span>" : "") + "</div>" +
      '<div class="pk-card ch-card"><div class="pk-meta" id="ch-meta"></div><div class="pk-q" id="ch-text"></div><div id="ch-under"></div></div><div class="pk-actions" id="ch-btns"></div></div>';
    paint();
  }
  function nextQ() {
    var g = game; if (!g) return;
    if (g.i >= g.rows.length) return finish();
    var q = g.rows[g.i], text = readText(q);
    g.cur = { q: q, text: text, phase: "reading", prompt: null };
    renderPlay();
    reader = Reader(body.querySelector("#ch-text"), text, { onEnd: function () { if (g.cur && g.cur.phase === "reading") { g.cur.phase = "window"; g.cur.until = Date.now() + 5000; paint(); win(); } } });
    reader.start();
  }
  function win() { var c = game && game.cur; if (!c || c.phase !== "window") return; if (Date.now() >= c.until) { done(null); return; } var s = body.querySelector("#ch-meta"); if (s) s.textContent = Math.ceil((c.until - Date.now()) / 1000) + "s to buzz"; setTimeout(win, 250); }
  function buzz() { var c = game && game.cur; if (!c || (c.phase !== "reading" && c.phase !== "window")) return; reader.pause(); c.phase = "answering"; c.at = reader.at(); ctx.playSound("buzz"); paint(); }
  async function submit(a) {
    var c = game && game.cur; if (!c || c.phase !== "answering") return;
    c.phase = "judging";
    var pos = serverPos(c.q, c.text, c.at), r = await judge(c.q, a, { buzzPosition: pos, previous: c.prompt });
    if (!game || game.cur !== c) return;
    if (r.status === "prompt" && c.prompt == null && a) { c.prompt = a; c.ask = (r.prompt && r.prompt.ask) || ""; c.phase = "answering"; paint(); return; }
    var right = r.status === "accept", p = powerAt(c.q), power = right && p >= 0 && pos <= p, pts = right ? (power ? 15 : 10) : c.at >= c.text.length ? 0 : -5;
    record(c.q, { answer: a, buzzPosition: pos, session: sess, correct: right, power: power, points: pts, celerity: c.text.length ? c.at / c.text.length : 1 });
    ctx.playSound(right ? (power ? "power" : "correct") : "incorrect");
    done({ pts: pts, at: c.text.length ? c.at / c.text.length : 1, ans: a });
  }
  function done(res) {
    var c = game.cur; if (reader) reader.showAll();
    game.res[game.i] = res ? { pts: res.pts, at: res.at } : null;
    c.phase = "done"; c.res = res; paint();
  }
  function paint() {
    var g = game, c = g && g.cur; if (!c) return;
    var meta = body.querySelector("#ch-meta"), under = body.querySelector("#ch-under"), btns = body.querySelector("#ch-btns");
    if (c.phase === "done") meta.innerHTML = dot(rootOf(c.q)) + esc(String(c.q.category_path || "").replace(/ > /g, " › "));
    else if (c.phase !== "window") meta.textContent = "";
    if (c.phase === "answering") {
      under.innerHTML = (c.prompt != null ? '<div class="pk-prompt">Prompt' + (c.ask ? ": " + esc(c.ask) : "") + "</div>" : "") + '<div class="pk-input"><input id="ch-ans" autocomplete="off" spellcheck="false" placeholder="Your answer" aria-label="Your answer"><button type="button" class="btn btn-primary" id="ch-send">Answer</button></div>';
      var inp = under.querySelector("#ch-ans"); inp.focus();
      inp.addEventListener("keydown", function (e) { if (e.key === "Enter") { e.preventDefault(); submit(inp.value.trim()); } e.stopPropagation(); });
      under.querySelector("#ch-send").onclick = function () { submit(inp.value.trim()); };
    } else if (c.phase === "done") {
      var r = c.res, them = g.from && g.from.res[g.i];
      under.innerHTML = '<div class="pk-row pk-wrapr">' + (r ? '<span class="pk-verdict ' + (r.pts >= 15 ? "pk-pw" : r.pts > 0 ? "pk-ok" : "pk-no") + '">' + (r.pts > 0 ? "+" : "") + r.pts + "</span>" : '<span class="pk-verdict pk-muted">No buzz</span>') +
        (g.from ? '<span class="pk-muted pk-small">' + esc(g.from.name) + " got " + (them ? (them.pts > 0 ? "+" : "") + them.pts + (them.pts ? " at " + Math.round(them.at * 100) + "%" : "") : "nothing") + "</span>" : "") + "</div>" +
        '<div class="pk-answer"><span class="pk-muted">Answer </span>' + answerHtml(c.q) + "</div>";
    } else if (c.phase !== "judging") under.innerHTML = "";
    btns.innerHTML = c.phase === "reading" || c.phase === "window" ? '<button type="button" class="btn btn-go" id="ch-buzz">Buzz<span class="pk-kbd">Space</span></button>'
      : c.phase === "done" ? '<button type="button" class="btn btn-primary" id="ch-next">' + (g.i + 1 >= g.rows.length ? "See how it went" : "Next") + '<span class="pk-kbd">N</span></button>' : "";
    var bz = btns.querySelector("#ch-buzz"); if (bz) bz.onclick = buzz;
    var nx = btns.querySelector("#ch-next"); if (nx) nx.onclick = function () { game.i++; nextQ(); };
  }
  function finish() {
    var g = game, ids = g.rows.map(function (q) { return q.id; }), name = myName();
    var entry = { mode: g.from ? "took" : "made", name: g.from ? g.from.name : name, at: Date.now(), ids: ids, me: g.res.slice(), them: g.from ? g.from.res : null, answers: g.rows.map(function (q) { return primary(q); }) };
    entry.code = encode({ ids: ids, name: name, res: g.res });
    mine.push(entry); saveList();
    game = null; st.view = "result"; st.open = mine.length - 1; render();
  }

  // ── a challenge's result: your code to send, and the comparison ──
  function renderResult() {
    var c = mine[st.open]; if (!c) { st.view = "home"; return render(); }
    var me = total(c.me), them = c.them ? total(c.them) : null, theirName = c.mode === "took" ? c.name : c.themName || "Your friend";
    body.innerHTML = '<div class="pk-wrap ch"><div class="pk-bar-top"><button type="button" class="btn btn-ghost" id="ch-home">' + ic("left", 15) + "Challenges</button></div>" +
      '<div class="pk-tiles">' + tile(fmt(me), "You", them != null && me >= them ? "pk-good" : "") + (them != null ? tile(fmt(them), theirName, them > me ? "pk-good" : "") : "") + "</div>" +
      (them != null ? '<div class="pk-card ch-verdict">' + (me > them ? "You won by " + (me - them) + "." : me < them ? esc(theirName) + " won by " + (them - me) + "." : "A tie.") + "</div>" : "") +
      '<div class="pk-card"><h3>' + (c.mode === "made" ? "Send this to a friend" : "Send this back to " + esc(c.name)) + '</h3><div class="pk-input"><input id="ch-mine" readonly value="' + esc(c.code) + '" aria-label="Your code"><button type="button" class="btn" id="ch-copy">' + ic("copy", 14) + "Copy</button></div>" +
        (c.mode === "made" && them == null ? '<div class="pk-muted pk-small" style="margin-top:8px">When they send their code back, paste it under Take a challenge to compare.</div>' : "") + "</div>" +
      '<div class="list pk-list">' + c.ids.map(function (id, i) {
        var a = c.me[i], b = c.them ? c.them[i] : undefined;
        var cell = function (r) { return r ? '<span class="ch-pts ' + (r.pts >= 15 ? "pk-gold" : r.pts > 0 ? "pk-good" : r.pts < 0 ? "pk-bad" : "pk-muted") + '">' + (r.pts > 0 ? "+" : "") + r.pts + (r.pts ? '<small class="pk-muted"> ' + Math.round(r.at * 100) + "%</small>" : "") + "</span>" : '<span class="ch-pts pk-muted">–</span>'; };
        return '<div class="list-row"><span class="num pk-muted ch-n">' + (i + 1) + '</span><span class="pk-grow">' + esc((c.answers && c.answers[i]) || "Tossup " + (i + 1)) + "</span>" + cell(a) + (c.them ? cell(b) : "") + "</div>";
      }).join("") + "</div></div>";
    body.querySelector("#ch-home").onclick = function () { st.view = "home"; render(); };
    body.querySelector("#ch-copy").onclick = function () { try { navigator.clipboard.writeText(c.code); var b = body.querySelector("#ch-copy"); b.lastChild.textContent = "Copied"; setTimeout(function () { if (b.isConnected) b.lastChild.textContent = "Copy"; }, 1500); } catch (e) { body.querySelector("#ch-mine").select(); } };
  }

  function active() { return page && page.screenEl && page.screenEl.classList.contains("active"); }
  function onKey(e) {
    if (!active() || inField(e) || e.metaKey || e.ctrlKey || e.altKey || st.view !== "play" || !game || !game.cur) return;
    if (e.key === " " && (game.cur.phase === "reading" || game.cur.phase === "window")) { e.preventDefault(); buzz(); }
    else if ((e.key === "n" || e.key === "N") && game.cur.phase === "done") { e.preventDefault(); game.i++; nextQ(); }
  }
  document.addEventListener("keydown", onKey);
  ctx._cleanup = function () { document.removeEventListener("keydown", onKey); if (reader) reader.stop(); };
  page = ctx.registerPage({
    id: "challenge", navLabel: "Challenge", title: "Challenge",
    onShow: function (el) { body = el; if (st.view === "play" && game && body.querySelector(".ch-card")) { if (game.cur && game.cur.phase === "reading" && reader) reader.start(); return; } render(); },
    onHide: function () { if (reader && game && game.cur && game.cur.phase === "reading") reader.pause(); },
  });

}
