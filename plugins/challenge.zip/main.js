/**
 * OfflineQuiz plugin: Challenge
 *
 * A challenge between friends, no room needed. Play ten or twenty tossups and get a short code. Your
 * friend pastes it, plays the same tossups, and you both see who got each one and how early.
 */
QB.registerPlugin({
  id: "challenge",
  name: "Challenge",
  version: "3.1.1",
  author: "OfflineQuiz",
  description: "Play a set of tossups, send a friend the code, and compare how you both did on each one.",
  onEnable: __qbMain,
  onDisable: function (ctx) { if (ctx._cleanup) ctx._cleanup(); },
});
