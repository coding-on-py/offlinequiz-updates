/**
 * OfflineQuiz plugin: Buzz Effects
 *
 * A little show when your answer is judged: confetti for a power and a 30 on a bonus, a glow for a ten,
 * a shake for a neg. It only changes how things look.
 */
QB.registerPlugin({
  id: "buzz-effects",
  name: "Buzz Effects",
  version: "1.2.0",
  author: "OfflineQuiz",
  description: "Confetti for powers, a glow for tens and a shake for negs.",
  settings: [
    {
      "key": "powers",
      "label": "Confetti for powers",
      "type": "toggle",
      "default": true,
      "location": "appearance"
    },
    {
      "key": "tens",
      "label": "Glow for tens",
      "type": "toggle",
      "default": true,
      "location": "appearance"
    },
    {
      "key": "negs",
      "label": "Shake for negs",
      "type": "toggle",
      "default": true,
      "location": "appearance"
    },
    {
      "key": "thirties",
      "label": "Confetti for a 30 on a bonus",
      "type": "toggle",
      "default": true,
      "location": "appearance"
    },
    {
      "key": "size",
      "label": "Size",
      "type": "select",
      "default": "normal",
      "location": "appearance",
      "options": [
        {
          "value": "subtle",
          "label": "Subtle"
        },
        {
          "value": "normal",
          "label": "Normal"
        },
        {
          "value": "big",
          "label": "Big"
        }
      ]
    }
  ],
  onEnable: __qbMain,
  onDisable: function (ctx) { if (ctx._cleanup) ctx._cleanup(); },
});
