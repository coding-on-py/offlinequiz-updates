function __qbMain(ctx) {
  // ── the kit the 15.62 plugins share (text, icons, questions, judging, history) ──
  function esc(s) { return (s == null ? "" : String(s)).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
  var IC = {
    play: '<path d="M7 4l13 8-13 8z"/>',
    pause: '<path d="M8 5v14M16 5v14"/>',
    left: '<path d="M15 6l-6 6 6 6"/>',
    right: '<path d="M9 6l6 6-6 6"/>',
    next: '<path d="M6 5l9 7-9 7zM18 5v14"/>',
    refresh: '<path d="M20 11a8 8 0 10-2.3 5.7M20 4v7h-7"/>',
    x: '<path d="M6 6l12 12M18 6L6 18"/>',
    check: '<path d="M5 12l5 5 9-10"/>',
    mic: '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
    volume: '<path d="M4 9v6h4l5 4V5L8 9z"/><path d="M16 9a4 4 0 0 1 0 6M19 6a8 8 0 0 1 0 12"/>',
    copy: '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h3"/>',
    edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="M13.5 6.5l4 4"/>',
    bolt: '<path d="M13 3L5 14h6l-1 7 8-11h-6z"/>',
    flag: '<path d="M5 21V4M5 4h11l-2 4 2 4H5"/>',
    users: '<circle cx="9" cy="8" r="3"/><path d="M3 20a6 6 0 0 1 12 0M16 4a3 3 0 0 1 0 6M21 20a6 6 0 0 0-4-5.6"/>',
    target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
    down: '<path d="M6 9l6 6 6-6"/>',
    up: '<path d="M6 15l6-6 6 6"/>',
    quote: '<path d="M7 7h4v4c0 3-1.5 5-4 6M15 7h4v4c0 3-1.5 5-4 6"/>',
    grid: '<rect x="3" y="3" width="8" height="10" rx="2"/><rect x="13" y="3" width="8" height="6" rx="2"/><rect x="13" y="11" width="8" height="10" rx="2"/><rect x="3" y="15" width="8" height="6" rx="2"/>',
    ear: '<path d="M7 9a5 5 0 0 1 10 0c0 3-3 4-3 7a3 3 0 0 1-6 0"/><path d="M10 9a2 2 0 0 1 4 0"/>',
  };
  function ic(name, size) {
    var s = size || 16;
    return '<svg width="' + s + '" height="' + s + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (IC[name] || "") + "</svg>";
  }
  function loading(label) { return '<div class="pk-loading">' + (ctx.loadingBarHtml ? ctx.loadingBarHtml(label) : esc(label)) + "</div>"; }
  function norm(s) { return String(s || "").toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[^a-z0-9]+/g, " ").trim(); }
  function pct(a, n) { return n ? Math.round(100 * a / n) : 0; }
  function fmt(n) { return Number(n || 0).toLocaleString(); }
  function plural(n, one, many) { return fmt(n) + " " + (n === 1 ? one : (many || one + "s")); }
  function shuffle(a) { for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)), t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
  function inField(e) { var t = e && e.target; return !!t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT" || t.isContentEditable); }
  function dayKey(t) { var d = new Date(t || Date.now()); return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0"); }
  var DAY = 86400000;

  // the practice setup (Setup panel): its filters and reading settings
  function cfg() { try { return (ctx.host && ctx.host.getPracticeConfig && ctx.host.getPracticeConfig()) || {}; } catch (e) { return {}; } }
  // filters → query parameters, the ones the app sends for a random question
  function filtersQuery(f, extra) {
    f = f || {}; var p = [];
    var add = function (k, v) { p.push(k + "=" + encodeURIComponent(v)); };
    if (f.categories && f.categories.length) add("categories", f.categories.join(","));
    if (f.categoryIds && f.categoryIds.length) add("categoryIds", f.categoryIds.join(","));
    if (f.difficulties && f.difficulties.length) add("difficulties", f.difficulties.join(","));
    if (f.setNames && f.setNames.length) add("setNames", f.setNames.join(","));
    if (f.packetNumbers && f.packetNumbers.length) add("packetNumbers", f.packetNumbers.join(","));
    if (f.yearMin != null) add("yearMin", f.yearMin);
    if (f.yearMax != null) add("yearMax", f.yearMax);
    if (f.powermarkOnly) add("powermarkOnly", "true");
    if (f.canon && f.canon.length) add("canon", f.canon.join(","));
    add("cleanOnly", "1");
    Object.keys(extra || {}).forEach(function (k) { if (extra[k] != null && extra[k] !== false) add(k, extra[k]); });
    return p.join("&");
  }
  // the practice filters without a set (a drill draws from everything the player picked)
  function practiceFilters() { var f = Object.assign({}, cfg().filters || {}); delete f.setNames; delete f.packetNumbers; delete f.setIds; return f; }
  async function getTossups(n, f, extra) {
    try { var d = await ctx.api.get("/api/tossups/query?" + filtersQuery(f || practiceFilters(), Object.assign({ random: 1, limit: n }, extra || {}))); return (d && d.rows) || []; } catch (e) { return []; }
  }
  async function getBonuses(n, f, extra) {
    try { var d = await ctx.api.get("/api/bonuses/query?" + filtersQuery(f || practiceFilters(), Object.assign({ random: 1, limit: n }, extra || {}))); return (d && d.rows) || []; } catch (e) { return []; }
  }
  async function getTossup(id) { try { return (await ctx.api.get("/api/tossups/" + encodeURIComponent(id))).tossup || null; } catch (e) { return null; } }
  async function getBonus(id) { try { return (await ctx.api.get("/api/bonuses/" + encodeURIComponent(id))).bonus || null; } catch (e) { return null; } }
  async function searchTossups(query, limit, f) {
    try { var d = await ctx.api.get("/api/tossups/search?query=" + encodeURIComponent(query) + "&limit=" + (limit || 20) + (f ? "&" + filtersQuery(f) : "")); return { rows: (d && d.rows) || [], total: (d && d.total) || 0 }; } catch (e) { return { rows: [], total: 0 }; }
  }
  // tossups whose answer line names an answer
  async function tossupsOn(answer, limit) { return (await searchTossups('answer_sanitized : ("' + String(answer).replace(/"/g, "") + '")', limit || 20)).rows; }

  // ── the voice plugins' files (15.69: Kokoro Voice, Voice Answers) ──
  // Worker code: a plugin's worker source starts with "(" + voiceFilesWorker + ")(cfg);". fetch() in that worker then
  // serves the model, voice and code files from IndexedDB once they've been fetched, so they load in a moment and work
  // offline. The first time, each comes from our server (onlinequiz.net/voice/, a copy of Hugging Face's and
  // jsDelivr's files by the same paths: server.js, scripts/publish-voice.mjs) or else its own host, in 4 MB ranges six at a time, each range kept as
  // it arrives: one long download over a slow line kept breaking off and starting again, so Kokoro never got ready.
  // cfg: { mirror: our copy's address (the website's own /voice/; the app's www.onlinequiz.net/voice/), db: the IndexedDB name (1.x/2.x kept whole files there by their address, and those are used), sizes: { url:
  // bytes } }. self.voiceFiles: plan(urls) totals what's still to fetch (progress goes to the page as { t: "progress",
  // loaded, total }), file(url), has(url) (kept already), blobUrl(url, type), importCode(url, fallback), route(fn) (fn(url)
  // → a Response promise for a file it makes itself, or null).
  // where our copy is: the website's own, else the live site's
  function voiceMirror() { return (window.QB_WEB && /^https?:/.test(location.origin) ? location.origin : "https://www.onlinequiz.net") + "/voice/"; }
  function voiceFilesWorker(cfg) {
    var MIRROR = cfg.mirror || "https://www.onlinequiz.net/voice/", HOSTS = [["https://huggingface.co/", "hf/"], ["https://cdn.jsdelivr.net/npm/", "npm/"]];
    var CHUNK = 4 << 20, LANES = 6, real = self.fetch.bind(self), sizes = cfg.sizes || {}, got = 0, want = 0, inflight = {};
    var dbp = null;
    function db() {
      return dbp || (dbp = new Promise(function (res, rej) { var r = indexedDB.open(cfg.db, 1); r.onupgradeneeded = function () { r.result.createObjectStore("files"); }; r.onsuccess = function () { res(r.result); }; r.onerror = function () { rej(r.error); }; }));
    }
    function get(k) { return db().then(function (d) { return new Promise(function (res) { try { var g = d.transaction("files").objectStore("files").get(k); g.onsuccess = function () { res(g.result); }; g.onerror = function () { res(undefined); }; } catch (e) { res(undefined); } }); }); }
    function put(k, v) { return db().then(function (d) { return new Promise(function (res) { try { var tx = d.transaction("files", "readwrite"); tx.objectStore("files").put(v, k); tx.oncomplete = function () { res(true); }; tx.onerror = tx.onabort = function () { res(false); }; } catch (e) { res(false); } }); }); }
    function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
    function mirrorOf(url) { for (var i = 0; i < HOSTS.length; i++) if (url.indexOf(HOSTS[i][0]) === 0) return MIRROR + HOSTS[i][1] + url.slice(HOSTS[i][0].length); return null; }
    function report() { if (want) postMessage({ t: "progress", loaded: Math.min(got, want), total: want }); }
    // kept: a small file whole, a big one as its ranges
    async function kept(url) {
      var whole = await get(url); if (whole) return whole;
      var meta = await get(url + "#meta"); if (!meta || !meta.done) return null;
      var all = new Uint8Array(meta.total), o = 0;
      for (var i = 0; i < meta.n; i++) { var p = await get(url + "#" + i); if (!p) return null; all.set(new Uint8Array(p), o); o += p.byteLength; }
      return all.buffer;
    }
    async function sizeAt(src) {
      var r = await real(src, { headers: { Range: "bytes=0-0" } });
      var m = /\/(\d+)\s*$/.exec(r.headers.get("Content-Range") || ""), n = m ? +m[1] : r.status === 200 ? +(r.headers.get("Content-Length") || 0) : 0;
      try { if (r.body) await r.body.cancel(); } catch (e) {}
      if (!n) throw new Error("HTTP " + r.status);
      return n;
    }
    async function pull(src, url, total) {
      // in one piece: a small file, and jsDelivr's (served compressed, so its ranges aren't the file's)
      if (total <= 2 * CHUNK || /^https:\/\/cdn\.jsdelivr\.net\//.test(src)) {
        var r = await real(src); if (!r.ok) throw new Error("HTTP " + r.status);
        var b = await r.arrayBuffer(); if (sizes[url] && b.byteLength !== sizes[url]) throw new Error("cut short");
        got += b.byteLength; report(); await put(url, b); return b;
      }
      var n = Math.ceil(total / CHUNK), parts = new Array(n), meta = await get(url + "#meta");
      if (meta && meta.total === total) { for (var i = 0; i < n; i++) { var p = await get(url + "#" + i); if (p && p.byteLength === Math.min(total, (i + 1) * CHUNK) - i * CHUNK) { parts[i] = p; got += p.byteLength; } } }
      else await put(url + "#meta", { total: total, n: n, done: false });
      report();
      var next = 0;
      async function lane() {
        for (;;) {
          var k = -1; while (next < n) { if (!parts[next]) { k = next++; break; } next++; }
          if (k < 0) return;
          var a = k * CHUNK, z = Math.min(total, a + CHUNK) - 1;
          for (var t = 0; ; t++) {
            try {
              var rr = await real(src, { headers: { Range: "bytes=" + a + "-" + z } });
              if (rr.status !== 206) throw new Error("HTTP " + rr.status);
              var buf = await rr.arrayBuffer(); if (buf.byteLength !== z - a + 1) throw new Error("cut short");
              await put(url + "#" + k, buf); parts[k] = buf; got += buf.byteLength; report(); break;
            } catch (e) { if (t >= 6) throw e; await sleep(700 * (t + 1)); }
          }
        }
      }
      var lanes = []; for (var j = 0; j < Math.min(LANES, n); j++) lanes.push(lane());
      await Promise.all(lanes);
      await put(url + "#meta", { total: total, n: n, done: true });
      var all = new Uint8Array(total), o = 0; for (var q = 0; q < n; q++) { all.set(new Uint8Array(parts[q]), o); o += parts[q].byteLength; }
      return all.buffer;
    }
    function file(url) {
      if (inflight[url]) return inflight[url];
      return (inflight[url] = (async function () {
        var k = await kept(url); if (k) return k;
        var srcs = [mirrorOf(url), url].filter(Boolean), last = null;
        for (var i = 0; i < srcs.length; i++) {
          try { var total = sizes[url] || (/^https:\/\/cdn\.jsdelivr\.net\//.test(srcs[i]) ? 1 : await sizeAt(srcs[i])); return await pull(srcs[i], url, total); }
          catch (e) { last = e; }
        }
        throw last || new Error("unreachable");
      })().finally(function () { delete inflight[url]; }));
    }
    // what loading still needs, so the progress is of the whole download
    async function plan(urls) {
      for (var i = 0; i < urls.length; i++) if (!(await has(urls[i]))) want += sizes[urls[i]] || 0;
      report();
    }
    async function has(url) {
      var n = await db().then(function (d) { return new Promise(function (res) { try { var c = d.transaction("files").objectStore("files").count(url); c.onsuccess = function () { res(c.result); }; c.onerror = function () { res(0); }; } catch (e) { res(0); } }); });
      if (n) return true;
      var meta = await get(url + "#meta"); return !!(meta && meta.done);
    }
    var routes = [];
    async function blobUrl(url, type) { return URL.createObjectURL(new Blob([await file(url)], { type: type || "application/octet-stream" })); }
    async function importCode(url, fallback) {
      try { return await import(await blobUrl(url, "text/javascript")); }
      catch (e) { if (fallback) return import(fallback); throw e; }
    }
    // a jsDelivr "+esm" module with the modules it imports ("/npm/…/+esm"), each kept, their imports pointed at the kept
    // copies (Voice Answers' transformers.js: it, onnxruntime-web and onnxruntime-common)
    var esm = {};
    function esmUrl(url) {
      return esm[url] || (esm[url] = (async function () {
        var text = new TextDecoder().decode(await file(url)), deps = {}, re = /(?:from|import)\s*\(?\s*"(\/npm\/[^"]+)"/g, m;
        while ((m = re.exec(text))) deps[m[1]] = 1;
        for (var d in deps) text = text.split('"' + d + '"').join('"' + await esmUrl("https://cdn.jsdelivr.net" + d) + '"');
        return URL.createObjectURL(new Blob([text], { type: "text/javascript" }));
      })());
    }
    async function importEsm(url) {
      try { return await import(await esmUrl(url)); }
      catch (e) { return import(url); }   // (online: as jsDelivr serves it)
    }
    // the libraries' own fetches (models, voices) come here; a browser cache they'd keep copies in is one that keeps nothing
    self.fetch = function (input, init) {
      var url = typeof input === "string" ? input : input && input.href ? input.href : input && input.url;
      for (var i = 0; url && i < routes.length; i++) { var made = routes[i](url); if (made) return made; }
      if (url && /^https:\/\/(huggingface\.co\/[^?#]+\/resolve\/|cdn\.jsdelivr\.net\/npm\/)/.test(url)) {
        return file(url).then(function (b) { return new Response(b, { status: 200, headers: { "content-length": String(b.byteLength) } }); });
      }
      return real(input, init);
    };
    var none = { match: async function () {}, put: async function () {}, delete: async function () { return false; }, keys: async function () { return []; } };
    try { Object.defineProperty(self, "caches", { configurable: true, value: { open: async function () { return none; }, has: async function () { return false; }, delete: async function () { return false; }, keys: async function () { return []; }, match: async function () {} } }); } catch (e) {}
    self.voiceFiles = { plan: plan, file: file, has: has, blobUrl: blobUrl, importCode: importCode, importEsm: importEsm, route: function (fn) { routes.push(fn); } };
  }

  // a record's text as practice reads it (notes and pronunciation guides per the player's settings)
  function readText(q) {
    try { if (ctx.host && ctx.host.questionText) { var t = ctx.host.questionText(q, "question"); if (t != null) return String(t).replace(/\(\*\)/g, "").replace(/\s{2,}/g, " ").trim(); } } catch (e) {}
    return String((q && q.question_sanitized) || "").replace(/\(\*\)/g, "").trim();
  }
  function powerAt(q) { return String((q && q.question_sanitized) || "").indexOf("(*)"); }
  // sentences, without breaking at "St." or an initial ("J. R. R. Tolkien")
  var ABBR = /(?:\b(?:St|Ste|Mt|Mts|Dr|Mr|Mrs|Ms|Mme|Prof|Sr|Jr|Rev|Fr|Gen|Col|Capt|Lt|Sgt|Maj|Adm|Hon|Pres|Gov|Sen|Rep|vs|etc|cf|ca|al|Inc|Co|Corp|Ltd|Bros|approx|No|Nos|Op|op|no|Vol|vol|Ch|ch|Fig|fig|Ft|Pt|pt|Ave|[A-Za-z])\.["”’']?)$/;
  function sentences(text) {
    var parts = String(text || "").split(/(?<=[.?!]["”’)]*)\s+(?=["“(]?[A-Z0-9])/), out = [], cur = "";
    for (var i = 0; i < parts.length; i++) {
      cur = cur ? cur + " " + parts[i] : parts[i];
      if (i < parts.length - 1 && ABBR.test(cur.trim())) continue;
      out.push(cur.trim()); cur = "";
    }
    if (cur.trim()) out.push(cur.trim());
    return out.filter(Boolean);
  }
  // where each sentence of a text ends (indexes into it)
  function sentenceEnds(text) {
    var at = 0, out = []; text = String(text || "");
    sentences(text).forEach(function (x) { var i = text.indexOf(x, at); if (i < 0) return; at = i + x.length; out.push(at); });
    return out;
  }
  // ── categories (15.63): the app's own picker, its picks kept under `key` ([] = every category) ──
  // mountCats(root, key, onChange) puts it in root's [data-cats] (made once, moved into each new render);
  // inCats(pk, e): a history entry or question in the picks; with no picks, all are
  var PICKERS = {};
  // opts.label: "" for just the picks, in a row that has its own label
  function catPicker(key, onChange, opts) {
    if (PICKERS[key]) return PICKERS[key];
    if (!ctx.host || !ctx.host.categoryPicker) return null;
    var o = { selected: ctx.storage.get(key) || [], onChange: function (ids) { ctx.storage.set(key, ids); if (onChange) onChange(ids); } };
    if (opts && opts.label != null) o.label = opts.label;
    var pk = ctx.host.categoryPicker(null, o);
    PICKERS[key] = pk;
    // the picks match nothing until the tree is in: draw again once it is
    if (pk.ready && (ctx.storage.get(key) || []).length) pk.ready.then(function () { if (onChange) onChange(pk.get()); });
    return pk;
  }
  function mountCats(root, key, onChange, opts) {
    var pk = catPicker(key, onChange, opts), host = root && root.querySelector("[data-cats]");
    if (pk && host) host.appendChild(pk.el);
    return pk;
  }
  function inCats(pk, e) {
    if (!pk || !pk.get().length) return true;
    return pk.matches(String((e && (e.category_path || e.path || e.category || e.root)) || ""));
  }
  // ── the app's reader on a page titled for the plugin (15.63: ctx.host.playPractice). Its Setup picks the categories ──
  function canRead() { return !!(ctx.host && ctx.host.playPractice); }
  function onReader() { return !!(ctx.host && ctx.host.onPracticePage && ctx.host.onPracticePage()); }
  // a plugin's start page: an icon, what it is, a Start button (data-pk="start"), a note under it
  function heroHtml(icon, title, text, start, note) {
    return '<div class="pk-hero"><span class="pk-hero-ico">' + ic(icon, 26) + "</span><h2>" + esc(title) + "</h2><p>" + esc(text) + "</p>" +
      '<div class="pk-actions pk-center"><button type="button" class="btn btn-primary" data-pk="start">' + ic("play", 14) + esc(start || "Start") + "</button></div>" +
      (note ? '<div class="pk-muted pk-small">' + note + "</div>" : "") + "</div>";
  }
  // the answer line, with its bold and underlining (nothing else of the HTML)
  function answerHtml(q) {
    var h = String((q && q.answer) || "");
    if (!/<\/?(b|u|strong|em|i)\b/i.test(h)) return esc((q && q.answer_sanitized) || h);
    return h.replace(/<(\/?)(b|u|strong|em|i)\b[^>]*>/gi, "\u0001$1$2\u0002").replace(/<[^>]*>/g, "").replace(/&(?!(?:amp|lt|gt|quot|#\d+);)/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/\u0001(\/?)(\w+)\u0002/g, "<$1$2>");
  }
  function primary(q) {
    var a = "";
    try { if (ctx.host && ctx.host.extractPrimaryAnswer) a = ctx.host.extractPrimaryAnswer((q && q.answer) || "", (q && q.answer_sanitized) || ""); } catch (e) {}
    return a || String((q && q.answer_sanitized) || "").replace(/\s*[\[(].*$/, "").trim();
  }
  // an answer as a person reads it in a list: the line up to its first bracket ("Mary, Queen of Scots"), where primary()
  // runs the bold parts together for matching ("Mary, Queen of Scots Mary Stuart")
  function answerName(q) { return String((q && q.answer_sanitized) || "").replace(/\s*[\[(].*$/, "").trim() || primary(q); }
  // judged right here, like practice (judge.js); { status: "accept" | "prompt" | "reject", prompt }
  async function judge(q, answer, opts) {
    opts = opts || {};
    try {
      if (ctx.host && ctx.host.judgeTossup) return (await ctx.host.judgeTossup(q, answer, { strictness: opts.strictness != null ? opts.strictness : (cfg().strictness || 10), buzzPosition: opts.buzzPosition, previous: opts.previous || null })) || { status: "reject" };
      return (await ctx.api.post("/api/evaluate-tossup", { questionId: q.id, answer: answer, strictness: cfg().strictness || 10, buzzPosition: opts.buzzPosition, previous: opts.previous || null })) || { status: "reject" };
    } catch (e) { return { status: "reject" }; }
  }
  async function judgePart(b, part, answer, opts) {
    opts = opts || {};
    try {
      if (ctx.host && ctx.host.judgeBonusPart) return (await ctx.host.judgeBonusPart(b, part, answer, { strictness: cfg().strictness || 10, previous: opts.previous || null })) || { status: "reject" };
      return (await ctx.api.post("/api/evaluate-bonus-part", { questionId: b.id, part: part, answer: answer, strictness: cfg().strictness || 10 })) || { status: "reject" };
    } catch (e) { return { status: "reject" }; }
  }
  async function judgeLine(line, sani, answer, opts) {
    opts = opts || {};
    try {
      if (ctx.host && ctx.host.judgeAnswerLine) return (await ctx.host.judgeAnswerLine(line, sani, answer, { strictness: cfg().strictness || 10, previous: opts.previous || null })) || { status: "reject" };
      return (await ctx.api.post("/api/evaluate-answer", { answerline: line, answer: answer, strictness: cfg().strictness || 10 })) || { status: "reject" };
    } catch (e) { return { status: "reject" }; }
  }
  function bonusParts(b) { try { return JSON.parse((b && (b.parts_sanitized || b.parts)) || "[]"); } catch (e) { return []; } }
  function bonusAnswers(b) { try { return JSON.parse((b && b.answers) || "[]"); } catch (e) { return []; } }
  function bonusAnswersSani(b) { try { return JSON.parse((b && b.answers_sanitized) || "[]"); } catch (e) { return []; } }

  // the player's answers (Stats' history), only the fields asked for
  async function history(fields) {
    try { return ((await ctx.api.get("/api/sessions/all-entries?" + (/\banswer\b/.test(fields || "") ? "answers=1&" : "") + "fields=" + encodeURIComponent(fields || ""))).entries) || []; } catch (e) { return []; }
  }
  // record a tossup answered on a plugin's page into the player's stats (the path Coach Mode uses)
  function record(q, r) {
    try {
      ctx.api.post("/api/check-tossup", { questionId: q.id, answer: r.answer || "", buzzPosition: r.buzzPosition || 0, sessionId: r.session, overriding: true,
        correct: !!r.correct, isPower: !!r.power, points: r.points || 0, celerity: r.celerity != null ? r.celerity : 1 }).catch(function () {});
    } catch (e) {}
  }

  var ROOT_COLOR = { "Literature": "#bc8cff", "Science": "#58a6ff", "Math": "#a5e05b", "Pop Culture": "#ff7b72", "Sports": "#ff6f91", "Fine Arts": "#f778ba", "History": "#e3b341", "Geography": "#56d364", "Mythology": "#ffa657", "Social Science": "#3dd6a3", "Philosophy": "#39c5cf", "Theology": "#8e9bff", "Current Events": "#c9d16b", "Miscellaneous": "#8b949e" };
  // NAQT's high school distribution, per 24 tossups / bonuses (naqt.com/hs/distribution.jsp)
  var NAQT = [["Literature", 3.9, 3.8], ["Science", 4.5, 4.3], ["Math", 1.0, 1.0], ["Fine Arts", 2.0, 2.0], ["History", 4.6, 4.5], ["Geography", 1.9, 1.9], ["Mythology", 0.6, 0.7],
    ["Pop Culture", 1.0, 0.9], ["Sports", 0.7, 0.7], ["Social Science", 0.6, 0.6], ["Philosophy", 0.3, 0.3], ["Theology", 0.4, 0.4], ["Current Events", 1.5, 1.4], ["Miscellaneous", 1.0, 1.5]];
  function rootOf(e) { return String((e && (e.category_path || e.category)) || "").split(" > ")[0] || "Miscellaneous"; }
  function dot(root) { return '<span class="pk-dot" style="--c:' + (ROOT_COLOR[root] || "#8b949e") + '"></span>'; }
  var _roots = null;
  async function roots() {
    if (_roots) return _roots;
    try { var t = ctx.host && ctx.host.getCategoryTree ? await ctx.host.getCategoryTree("tossups") : (await ctx.api.get("/api/category-tree?type=tossups")).tree; _roots = (t || []).map(function (n) { return { id: n.id, name: n.name, count: n.count }; }); }
    catch (e) { _roots = []; }
    return _roots;
  }
  var DIFF_NAME = { 0: "Unrated", 1: "Middle school", 2: "Easy high school", 3: "Regular high school", 4: "Hard high school", 5: "National high school", 6: "Easy college", 7: "Medium college", 8: "Regionals college", 9: "Nationals college", 10: "Open" };

  function tile(value, label, cls) { return '<div class="pk-tile' + (cls ? " " + cls : "") + '"><b class="num">' + value + "</b><span>" + esc(label) + "</span></div>"; }
  function segHtml(name, items, on) {
    return '<div class="seg pk-seg" role="group">' + items.map(function (it) {
      return '<button type="button" data-' + name + '="' + esc(it[0]) + '" aria-pressed="' + (String(on) === String(it[0])) + '">' + esc(it[1]) + "</button>";
    }).join("") + "</div>";
  }
  function emptyHtml(text) { return '<div class="db-empty pk-empty">' + esc(text) + "</div>"; }
  // square toggles 0 to 10, Setup's difficulty look (the app's .diff-toggles), `on` the ones picked; diffsIn reads them
  function diffHtml(name, on) {
    var h = '<div class="diff-toggles pk-diffs" role="group" aria-label="Difficulty">';
    for (var d = 0; d <= 10; d++) h += '<label title="' + esc(DIFF_NAME[d]) + '"><input type="checkbox" data-' + name + '="' + d + '"' + ((on || []).indexOf(d) >= 0 ? " checked" : "") + "><span>" + d + "</span></label>";
    return h + "</div>";
  }
  function diffsIn(root, name) { return [].slice.call(root.querySelectorAll("[data-" + name + "]")).filter(function (i) { return i.checked; }).map(function (i) { return Number(i.getAttribute("data-" + name)); }); }
  // a list of difficulties in a few words: [2, 3, 4, 5] → "2 to 5"
  function diffWords(ds) {
    ds = (ds || []).slice().sort(function (a, b) { return a - b; });
    if (!ds.length) return "any difficulty";
    var run = ds.every(function (d, i) { return !i || d === ds[i - 1] + 1; });
    return ds.length === 1 ? "difficulty " + ds[0] : run ? "difficulty " + ds[0] + " to " + ds[ds.length - 1] : "difficulty " + ds.join(", ");
  }
  function playList(kind, ids, title) {
    if (!ids || !ids.length) return false;
    try { return !!(ctx.host && ctx.host.launchQuestions && ctx.host.launchQuestions(kind, ids, { title: title })); } catch (e) { return false; }
  }

  // a reader: shows `text` a character at a time at the practice reading speed. start(), pause(), go(), stop();
  // at() is how far it is; onEnd once it's all shown
  function Reader(el, text, opts) {
    opts = opts || {};
    var ms = opts.ms != null ? opts.ms : (Number(cfg().revealSpeed) || 25), idx = 0, raf = 0, last = 0, on = false;
    var paint = function () { el.innerHTML = '<span class="pk-read">' + esc(text.slice(0, idx)) + '</span><span class="pk-unread" aria-hidden="true">' + esc(text.slice(idx)) + "</span>"; };
    var step = function (t) {
      raf = 0; if (!on) return;
      if (!last) last = t;
      var n = ms > 0 ? Math.floor((t - last) / ms) : text.length;
      if (n > 0) { idx = Math.min(text.length, idx + n); last += n * ms; paint(); if (opts.onTick) opts.onTick(idx); }
      if (idx >= text.length) { on = false; if (opts.onEnd) opts.onEnd(); return; }
      raf = requestAnimationFrame(step);
    };
    paint();
    return {
      start: function () { if (on) return; on = true; last = 0; raf = requestAnimationFrame(step); },
      pause: function () { on = false; if (raf) cancelAnimationFrame(raf); raf = 0; },
      stop: function () { on = false; if (raf) cancelAnimationFrame(raf); raf = 0; },
      showAll: function () { this.stop(); idx = text.length; el.textContent = text; },
      at: function () { return idx; },
      running: function () { return on; },
    };
  }
  // a reader's position in the displayed text → the record's question_sanitized (what judging and stats count)
  function serverPos(q, display, pos) {
    try { if (ctx.host && ctx.host.mapDisplayPos) return ctx.host.mapDisplayPos(display, (q && q.question_sanitized) || "", pos); } catch (e) {}
    return pos;
  }

  // ── Chatterbox Voice (15.73): the most natural voice for Read aloud, made on this computer's graphics chip ──
  // Chatterbox Turbo (Resemble AI, MIT; ResembleAI/chatterbox-turbo-ONNX) through transformers.js 4.3.2 in a module
  // worker, offered in the Voice panel (ctx.registerVoice) like Kokoro's. A small GPT-2 makes speech tokens from the text
  // and a decoder makes them sound, in a voice given by a few seconds of someone speaking. Those voices are worked out
  // ahead of time (plugins/kit/chatterbox-voice/voices/*.bin, from Kokoro reading a tossup, and the model's own voice), so
  // nobody downloads the 173 MB speech encoder: its place gets a one-node stand-in (STAND_IN) that's never run.
  // It's WebGPU only: on a processor it's several times slower than it speaks. What works there (tried on an M-series Mac):
  //   - the language model and the token embeddings at q4f16, the decoder at q4 (fp32 inside). The decoder's fp16 files
  //     (q4f16 and fp16) go silent a few seconds in, a number overflowing fp16, so its q4 is the one that sounds right
  //   - sampling (temperature 0.8, top-k 1000, top-p 0.95, repetition penalty 1.2, as Resemble's own code does). Picking
  //     the likeliest token every time got stuck saying one sound over and over in a third of longer sentences
  //   - about a third of the time it speaks (RTF 0.35), so a piece is made well before the one before it ends
  // Voice speed: the model has none, so the sound is stretched or squeezed (WSOLA: the same pitch, slices of the sound
  // overlapped at the point where they line up best).
  // Every file comes through voiceFilesWorker (kit.js), from our mirror first, kept in IndexedDB, offline after.
  var ID = "ResembleAI/chatterbox-turbo-ONNX", HF = "https://huggingface.co/" + ID + "/resolve/main/";
  var TF = "https://cdn.jsdelivr.net/npm/@huggingface/transformers@4.3.2/+esm";
  var ORT = "https://cdn.jsdelivr.net/npm/onnxruntime-web@1.31.0-dev.20260914-8d85527a0/dist/ort-wasm-simd-threaded.asyncify.";
  var MIRROR = voiceMirror(), OURS = MIRROR + "chatterbox/v1/";
  var MODEL = ["onnx/embed_tokens_q4f16.onnx", "onnx/language_model_q4f16.onnx", "onnx/conditional_decoder_q4.onnx"];
  var SIZES = {};
  SIZES[HF + "onnx/embed_tokens_q4f16.onnx"] = 2548; SIZES[HF + "onnx/embed_tokens_q4f16.onnx_data"] = 33648688;
  SIZES[HF + "onnx/language_model_q4f16.onnx"] = 276803; SIZES[HF + "onnx/language_model_q4f16.onnx_data"] = 183981430;
  SIZES[HF + "onnx/conditional_decoder_q4.onnx"] = 2179022; SIZES[HF + "onnx/conditional_decoder_q4.onnx_data"] = 246397384;
  SIZES[HF + "tokenizer.json"] = 3562272;
  SIZES[ORT + "wasm"] = 26861777; SIZES[ORT + "mjs"] = 53057;
  var VOICES = [["heart", "Heart, US"], ["michael", "Michael, US"], ["emma", "Emma, UK"], ["george", "George, UK"], ["bella", "Bella, US"], ["fenrir", "Fenrir, US"],
    ["original", "Original"]].map(function (v) { return { id: v[0], name: v[1] }; });
  VOICES.forEach(function (v) { SIZES[OURS + v.id + ".bin"] = v.id === "original" ? 740152 : 781624; });
  // (1.2) each voice reading the Voice panel's sample line, made ahead (plugins/kit/chatterbox-voice/previews, on our
  // mirror), so its play button plays at once, with nothing to load: they come down with its files and are kept like them
  var CLIPS = OURS + "previews/", CLIP_SIZES = {"bella":25422,"emma":25315,"fenrir":26820,"george":25670,"heart":25403,"michael":26785,"original":25208};
  VOICES.forEach(function (v) { if (CLIP_SIZES[v.id]) SIZES[CLIPS + v.id + ".webm"] = CLIP_SIZES[v.id]; });
  var STAND_IN = "CAhCAhAROmkKKAoMYXVkaW9fdmFsdWVzEg5hdWRpb19mZWF0dXJlcyIISWRlbnRpdHkSAWdaGwoMYXVkaW9fdmFsdWVzEgsKCQgBEgUKAxIBbmIdCg5hdWRpb19mZWF0dXJlcxILCgkIARIFCgMSAW4=";
  var NO_GPU = "Chatterbox needs a graphics chip the browser can use. The built-in voice reads instead.";
  var worker = null, ready = false, loading = null, wq = {}, wid = 0, listeners = [], dlFns = [];
  var WORKER = "(" + voiceFilesWorker.toString() + ")(" + JSON.stringify({ mirror: MIRROR, db: "qb-chatterbox", sizes: SIZES }) + ");\n" + [
    "const V = self.voiceFiles, ID = " + JSON.stringify(ID) + ", HF = " + JSON.stringify(HF) + ", TF = " + JSON.stringify(TF) + ", ORT = " + JSON.stringify(ORT) + ";",
    "const OURS = " + JSON.stringify(OURS) + ", MODEL = " + JSON.stringify(MODEL) + ", VOICES = " + JSON.stringify(VOICES.map(function (v) { return v.id; })) + ";",
    "const CLIPS = " + JSON.stringify(VOICES.filter(function (v) { return CLIP_SIZES[v.id]; }).map(function (v) { return CLIPS + v.id + ".webm"; })) + ";",
    "const STAND_IN = Uint8Array.from(atob(" + JSON.stringify(STAND_IN) + "), (c) => c.charCodeAt(0));",
    "let T = null, tok = null, model = null, fetching = null, gpu = null, queue = Promise.resolve(), epoch = 0, aheadN = 0;",
    "const voices = {};",
    "// a GPU the browser can use, with 16-bit numbers in its shaders (the q4f16 files need them)",
    "async function hasGpu() {",
    "  if (gpu != null) return gpu;",
    "  try { const a = navigator.gpu && (await navigator.gpu.requestAdapter()); gpu = !!(a && a.features.has(\"shader-f16\")); } catch (e) { gpu = false; }",
    "  return gpu;",
    "}",
    'const files = () => [TF, ORT + "mjs", ORT + "wasm", HF + "config.json", HF + "generation_config.json", HF + "tokenizer.json", HF + "tokenizer_config.json"]',
    '  .concat(...MODEL.map((f) => [HF + f, HF + f + "_data"]), VOICES.map((v) => OURS + v + ".bin"), CLIPS);',
    "function fetchAll() {",
    "  return fetching || (fetching = (async () => {",
    '    if (!(await hasGpu())) throw new Error("no gpu");',
    "    const f = files();",
    "    await V.plan(f);",
    "    await Promise.all(f.map((x) => V.file(x)));",
    "    await V.importEsm(TF);   // and the modules it imports",
    "  })().catch((e) => { fetching = null; throw e; }));",
    "}",
    "async function haveAll() { if (!(await hasGpu())) return true; for (const f of files()) if (!(await V.has(f))) return false; return true; }",
    "// the speech encoder that's never run",
    'V.route((url) => url.indexOf(HF + "onnx/speech_encoder") === 0 ? Promise.resolve(new Response(/_data$/.test(url) ? new Uint8Array(0) : STAND_IN)) : null);',
    "// a voice: the four tensors the speech encoder makes of someone speaking, kept in one file (\"QBCV\", the header's",
    "// length, a JSON header of each tensor's name, type, dims and place, then their bytes)",
    "async function voiceOf(id) {",
    "  if (voices[id]) return voices[id];",
    '  const b = await V.file(OURS + id + ".bin"), dv = new DataView(b);',
    '  if (dv.getUint32(0, false) !== 0x51424356) throw new Error("not a voice");',
    "  const hl = dv.getUint32(4, true), head = JSON.parse(new TextDecoder().decode(new Uint8Array(b, 8, hl))), base = Math.ceil((8 + hl) / 8) * 8, out = {};",
    '  for (const h of head) out[h.name] = new T.Tensor(h.type, h.type === "int64" ? new BigInt64Array(b.slice(base + h.off, base + h.off + h.bytes)) : new Float32Array(b.slice(base + h.off, base + h.off + h.bytes)), h.dims);',
    "  return (voices[id] = out);",
    "}",
    "async function load(voice) {",
    "  await fetchAll();",
    "  T = await V.importEsm(TF);",
    '  T.env.backends.onnx.wasm.wasmPaths = { mjs: await V.blobUrl(ORT + "mjs", "text/javascript"), wasm: await V.blobUrl(ORT + "wasm", "application/wasm") };',
    "  T.env.useBrowserCache = false;",
    "  tok = await T.AutoTokenizer.from_pretrained(ID);",
    "  model = await T.ChatterboxModel.from_pretrained(ID, {",
    '    device: { embed_tokens: "webgpu", speech_encoder: "wasm", language_model: "webgpu", conditional_decoder: "webgpu" },',
    '    dtype: { embed_tokens: "q4f16", speech_encoder: "q4f16", language_model: "q4f16", conditional_decoder: "q4" } });',
    "  await make(\"Ready.\", voice, 1);   // the first one is slow (the GPU's programs are built); better now",
    "}",
    "// the text as the model reads best: plain quotes and dashes, ending in a stop",
    "function clean(t) {",
    '  t = String(t).replace(/[“”]/g, \'"\').replace(/[‘’]/g, "\'").replace(/\\s*[—–]\\s*/g, ", ").replace(/…/g, "...").replace(/\\s+/g, " ").trim();',
    '  return /[.?!,;:"\')\\]]$/.test(t) ? t : t + ".";',
    "}",
    "// gone(): reading stopped, so it isn't wanted any more (it stops at the next token)",
    "async function make(text, voice, speed, gone) {",
    '  const spk = await voiceOf(VOICES.includes(voice) ? voice : "heart"), t = clean(text), inputs = tok(t), max = Math.ceil(t.length * 1.6) + 60;',
    "  class Stop extends T.StoppingCriteria { _call(ids) { const g = !!(gone && gone()); return ids.map(() => g); } }",
    "  let s = null;",
    "  // one that runs to the limit got stuck saying a sound over and over: made again",
    "  for (let k = 0; k < 2; k++) {",
    "    const w = await model.generate({ ...inputs, ...spk, max_new_tokens: max, repetition_penalty: 1.2, do_sample: true, temperature: 0.8, top_k: 1000, top_p: 0.95, stopping_criteria: [new Stop()] });",
    '    if (gone && gone()) throw new Error("cancelled");',
    "    s = new Float32Array(w.data);",
    "    if (s.length / 24000 < max / 25 - 0.1) break;",
    "  }",
    "  return stretch(tidy(s, t), speed);",
    "}",
    "// (1.1) Chatterbox stops for a breath now and then where the text has no comma (150 to 360 ms, in one sentence in",
    "// two): it sounded like a comma that wasn't there. A pause is kept where the text has one (a comma, a full stop, a",
    "// dash: placed by its share of the syllables, give or take a tenth), and any other is cut to 70 ms",
    "function tidy(x, text) {",
    "  const F = 240, n = Math.floor(x.length / F), e = new Float32Array(n); let pk = 0;",
    "  for (let f = 0; f < n; f++) { let a = 0; for (let k = f * F; k < (f + 1) * F; k++) a += x[k] * x[k]; e[f] = Math.sqrt(a / F); if (e[f] > pk) pk = e[f]; }",
    "  const thr = pk * 0.06; let a = 0, z = n - 1; while (a < n && e[a] < thr) a++; while (z > a && e[z] < thr) z--;",
    "  const runs = []; for (let f = a; f < z;) { if (e[f] >= thr) { f++; continue; } let g = f; while (g < z && e[g] < thr) g++; if (g - f >= 14) runs.push([f, g]); f = g; }",
    "  if (!runs.length) return x;",
    "  // the text's pauses as shares of its syllables (vowel groups), the last mark (its end) left out",
    "  const words = String(text).split(/\\s+/), syl = (w) => Math.max(1, (w.toLowerCase().match(/[aeiouy]+/g) || []).length), total = words.reduce((t, w) => t + syl(w), 0) || 1, marks = [];",
    '  let acc = 0; words.forEach((w, i) => { acc += syl(w); if (i < words.length - 1 && /[,;:.?!\\u2014)]["\u201d\u2019)]*$/.test(w)) marks.push(acc / total); });',
    "  let sil = 0; runs.forEach((r) => (sil += r[1] - r[0])); const voiced = Math.max(1, z - a - sil);",
    "  const cut = []; let before = 0, last = a;",
    "  for (const r of runs) { before += r[0] - last; last = r[1]; const at = before / voiced; if (!marks.some((m) => Math.abs(m - at) < 0.1)) cut.push([(r[0] + 3) * F, (r[1] - 4) * F]); }",
    "  if (!cut.length) return x;",
    "  let len = x.length; cut.forEach((c) => (len -= c[1] - c[0]));",
    "  const y = new Float32Array(len); let o = 0, from = 0;",
    "  for (const c of cut) { y.set(x.subarray(from, c[0]), o); o += c[0] - from; from = c[1]; }",
    "  y.set(x.subarray(from), o);",
    "  return y;",
    "}",
    "// WSOLA: slices of the sound, each a little further on (speed > 1) or back, overlapped where they line up best with",
    "// what came before, so the pitch stays",
    "function stretch(x, speed) {",
    "  if (!(speed > 0) || Math.abs(speed - 1) < 0.02 || x.length < 4000) return x;",
    "  const N = 720, H = 360, A = Math.round(H * speed), tol = 180, win = new Float32Array(N);",
    "  for (let i = 0; i < N; i++) win[i] = 0.5 - 0.5 * Math.cos((2 * Math.PI * i) / N);",
    "  const L = Math.ceil(x.length / speed) + N, y = new Float32Array(L), wt = new Float32Array(L);",
    "  let prev = 0;",
    "  for (let k = 0, at = 0, o = 0; at + N + tol < x.length && o + N < L; k++, at += A, o += H) {",
    "    let best = 0;",
    "    if (k) {",
    "      const ref = prev + H; let top = -Infinity;",
    "      for (let d = -tol; d <= tol; d += 2) {",
    "        const s = at + d; if (s < 0) continue;",
    "        let c = 0; for (let j = 0; j < N; j += 3) c += x[s + j] * x[ref + j];",
    "        if (c > top) { top = c; best = d; }",
    "      }",
    "    }",
    "    const st = Math.max(0, at + best);",
    "    for (let j = 0; j < N; j++) { y[o + j] += x[st + j] * win[j]; wt[o + j] += win[j]; }",
    "    prev = st;",
    "  }",
    "  let end = L; while (end > 0 && wt[end - 1] < 1e-3) end--;",
    "  for (let i = 0; i < end; i++) if (wt[i] > 1e-3) y[i] /= wt[i];",
    "  return y.subarray(0, end);",
    "}",
    "self.onmessage = (e) => {",
    "  const m = e.data;",
    "  // reading stopped: what was being made for it isn't wanted (what's made ahead, for the next question, is)",
    '  if (m.t === "cancel") { epoch++; return; }',
    "  // a sample line, not held up behind speech being made (1.2)",
    '  if (m.t === "clip") { V.file(m.url).then((b) => { b = b.slice(0); postMessage({ t: "clip", id: m.id, bytes: b }, [b]); }, (err) => postMessage({ t: "error", id: m.id, error: String((err && err.message) || err) })); return; }',
    '  const my = m.ahead ? -1 : epoch, gone = () => my >= 0 && my !== epoch, mine = m.ahead ? ++aheadN : 0;',
    "  // one at a time: two made together would each take twice as long",
    "  queue = queue.then(async () => {",
    "    try {",
    '      if (m.t === "synth" && gone()) throw new Error("cancelled");',
    "      // (1.2) made ahead for a question skipped since: two newer ones are waiting behind it, so it's dropped",
    '      if (m.t === "synth" && mine && aheadN - mine >= 2) throw new Error("cancelled");',
    '      if (m.t === "load") { if (!model) await load(m.voice || "heart"); postMessage({ t: "ready", id: m.id }); }',
    '      else if (m.t === "fetch") { await fetchAll(); postMessage({ t: "fetched", id: m.id }); }',
    '      else if (m.t === "have") postMessage({ t: "have", id: m.id, have: await haveAll() });',
    '      else if (m.t === "synth") { const s = new Float32Array(await make(m.text, m.voice, m.speed, gone)); postMessage({ t: "audio", id: m.id, samples: s, rate: 24000 }, [s.buffer]); }',
    '    } catch (err) { postMessage({ t: "error", id: m.id, error: String((err && err.message) || err) }); }',
    "  });",
    "};",
  ].join("\n");
  function call(msg) { return new Promise(function (res, rej) { var id = ++wid; msg.id = id; wq[id] = { res: res, rej: rej }; worker.postMessage(msg); }); }
  function ensureWorker() {
    if (worker) return;
    worker = new Worker(URL.createObjectURL(new Blob([WORKER], { type: "text/javascript" })), { type: "module" });
    worker.onmessage = function (e) {
      var m = e.data;
      if (m.t === "progress") { var f = m.total ? m.loaded / m.total : 0; listeners.concat(dlFns).forEach(function (fn) { try { fn(f); } catch (x) {} }); return; }
      var w = wq[m.id]; if (!w) return; delete wq[m.id];
      if (m.t === "error") { var err = new Error(m.error); if (m.error === "no gpu") err.userMessage = NO_GPU; w.rej(err); }
      else if (m.t === "audio") w.res({ samples: m.samples, rate: m.rate });
      else if (m.t === "have") w.res(!!m.have);
      else if (m.t === "clip") w.res(m.bytes || null);
      else w.res(true);
    };
  }
  function load(onProgress, o) {
    if (onProgress) listeners.push(onProgress);
    if (ready) return Promise.resolve();
    if (loading) return loading;
    try { ensureWorker(); } catch (e) { return Promise.reject(e); }
    loading = call({ t: "load", voice: (o && o.voice) || "heart" }).then(function () { ready = true; listeners = []; }, function (e) { loading = null; listeners = []; try { worker.terminate(); } catch (x) {} worker = null; throw e; });
    return loading;
  }
  // (1.2) a voice's sample line, ready to play (kept here once it's been asked for); null where there's none. It needs
  // no graphics chip, so it plays even where Chatterbox can't read
  var clips = {};
  function clip(id) {
    if (clips[id]) return Promise.resolve(clips[id]);
    if (!CLIP_SIZES[id]) return Promise.resolve(null);
    try { ensureWorker(); } catch (e) { return Promise.resolve(null); }
    return call({ t: "clip", url: CLIPS + id + ".webm" }).then(function (b) { if (b && b.byteLength) clips[id] = b; return clips[id] || null; }, function () { return null; });
  }
  ctx.registerVoice({
    id: "chatterbox", name: "Chatterbox",
    voices: VOICES,
    ready: function () { return ready; },
    load: load,
    synth: function (text, o) { return load().then(function () { return call({ t: "synth", text: text, voice: o.voice || "heart", speed: Math.max(0.7, Math.min(1.35, o.speed || 1)), ahead: !!o.ahead }); }); },
    // its first piece a clause (it takes a third of the time it speaks to make, and a piece cut mid-phrase ends like a
    // phrase), then each up to twice the last (app.js piecesFor)
    first: 120,
    cancel: function () { if (worker) worker.postMessage({ t: "cancel" }); },
    clip: clip,
  });
  // its files come down when it's got from the Store (its card showing how far), or a few seconds after it starts.
  // Without a GPU there's nothing to download
  function download(onProgress) {
    try { ensureWorker(); } catch (e) { return Promise.reject(e); }
    if (onProgress) dlFns.push(onProgress);
    var off = function () { dlFns = dlFns.filter(function (fn) { return fn !== onProgress; }); };
    return call({ t: "fetch" }).then(off, function (e) { off(); if (e.message === "no gpu") return; throw e; });
  }
  var fetchT = 0;
  if (ctx.registerDownload) ctx.registerDownload({ done: function () { if (ready) return true; try { ensureWorker(); } catch (e) { return true; } return call({ t: "have" }); }, start: download });
  else fetchT = setTimeout(function () { if (!ready && !loading) download().catch(function () {}); }, 3000);
  ctx._cleanup = function () {
    clearTimeout(fetchT); if (worker) { try { worker.terminate(); } catch (e) {} worker = null; } ready = false; loading = null; };

}
