/**
 * OfflineQuiz plugin: Chatterbox Voice
 *
 * Chatterbox Turbo, an open speech model by Resemble AI (MIT license), reads questions aloud in seven voices.
 * It runs on your computer's graphics chip, in the app and in Chrome or Edge, offline once it's downloaded.
 */
QB.registerPlugin({
  id: "chatterbox-voice",
  name: "Chatterbox Voice",
  version: "1.1.0",
  author: "OfflineQuiz",
  description: "The most natural voice for Read aloud, made on your computer's graphics chip. Works in the app and in Chrome or Edge, offline once it's downloaded.",
  onEnable: __qbMain,
  onDisable: function (ctx) { if (ctx._cleanup) ctx._cleanup(); },
});
