/**
 * OfflineQuiz plugin: Weekly Plan
 *
 * A weekly practice plan: a number of tossups for each category (NAQT's mix to start, or your own),
 * progress from Stats' history this week, the weeks before it, and one button to practice what's left.
 */
QB.registerPlugin({
  id: "weekly-plan",
  name: "Weekly Plan",
  version: "1.0.3",
  author: "OfflineQuiz",
  description: "Set how many tossups each category gets a week, track it, and practice what's left.",
  onEnable: __qbMain,
  onDisable: function (ctx) { if (ctx._cleanup) ctx._cleanup(); },
});
