function __qbMain(ctx) {
    // Every achievement carries its original mark in `icon` (百, 参, 千 …; plugin
    // achievements bring their own). Returning it puts the character back in
    // place of the app's line icon; the app draws one character large and four
    // as a 2×2 grid. An achievement whose icon is a picture (markup) keeps it.
    // styles.css draws the characters as small seals in the accent colour.
    ctx.registerAchievementIcons(function (ach) {
      if (!ach || ach.icon == null || ach.icon === "") return null;
      var s = String(ach.icon);
      return /^\s*</.test(s) ? null : s;
    });
  }
