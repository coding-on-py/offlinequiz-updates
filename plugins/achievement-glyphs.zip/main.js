QB.registerPlugin({
  id: "achievement-glyphs",
  name: "Achievement Glyphs",
  version: "1.1.0",
  author: "OfflineQuiz",
  description: "The original kanji marks for achievements (百, 千, 萬 …) in place of the line icons.",
  onEnable: __qbMain,
  onDisable: function () {},
});
