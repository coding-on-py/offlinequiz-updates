QB.registerPlugin({
  id: "achievement-glyphs",
  name: "Achievement Glyphs",
  version: "1.5.0",
  author: "OfflineQuiz",
  description: "The original kanji marks for achievements (百, 千, 萬 …) instead of line icons.",
  onEnable: __qbMain,
  onDisable: function () {},
});
