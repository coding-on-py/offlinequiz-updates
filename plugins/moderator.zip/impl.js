function __qbMain(ctx) {
  // ── the kit the 15.62 plugins share (text, icons, questions, judging, history) ──
  function esc(s) { return (s == null ? "" : String(s)).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
  var IC = {
    play: '<path d="M7 4l13 8-13 8z"/>',
    pause: '<path d="M8 5v14M16 5v14"/>',
    left: '<path d="M15 6l-6 6 6 6"/>',
    right: '<path d="M9 6l6 6-6 6"/>',
    next: '<path d="M6 5l9 7-9 7zM18 5v14"/>',
    refresh: '<path d="M20 11a8 8 0 10-2.3 5.7M20 4v7h-7"/>',
    x: '<path d="M6 6l12 12M18 6L6 18"/>',
    check: '<path d="M5 12l5 5 9-10"/>',
    mic: '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
    volume: '<path d="M4 9v6h4l5 4V5L8 9z"/><path d="M16 9a4 4 0 0 1 0 6M19 6a8 8 0 0 1 0 12"/>',
    copy: '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h3"/>',
    edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="M13.5 6.5l4 4"/>',
    bolt: '<path d="M13 3L5 14h6l-1 7 8-11h-6z"/>',
    flag: '<path d="M5 21V4M5 4h11l-2 4 2 4H5"/>',
    users: '<circle cx="9" cy="8" r="3"/><path d="M3 20a6 6 0 0 1 12 0M16 4a3 3 0 0 1 0 6M21 20a6 6 0 0 0-4-5.6"/>',
    target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
    down: '<path d="M6 9l6 6 6-6"/>',
    up: '<path d="M6 15l6-6 6 6"/>',
    quote: '<path d="M7 7h4v4c0 3-1.5 5-4 6M15 7h4v4c0 3-1.5 5-4 6"/>',
    ear: '<path d="M7 9a5 5 0 0 1 10 0c0 3-3 4-3 7a3 3 0 0 1-6 0"/><path d="M10 9a2 2 0 0 1 4 0"/>',
  };
  function ic(name, size) {
    var s = size || 16;
    return '<svg width="' + s + '" height="' + s + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (IC[name] || "") + "</svg>";
  }
  function loading(label) { return '<div class="pk-loading">' + (ctx.loadingBarHtml ? ctx.loadingBarHtml(label) : esc(label)) + "</div>"; }
  function norm(s) { return String(s || "").toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[^a-z0-9]+/g, " ").trim(); }
  function pct(a, n) { return n ? Math.round(100 * a / n) : 0; }
  function fmt(n) { return Number(n || 0).toLocaleString(); }
  function plural(n, one, many) { return fmt(n) + " " + (n === 1 ? one : (many || one + "s")); }
  function shuffle(a) { for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)), t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
  function inField(e) { var t = e && e.target; return !!t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT" || t.isContentEditable); }
  function dayKey(t) { var d = new Date(t || Date.now()); return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0"); }
  var DAY = 86400000;

  // the practice setup (Setup panel): its filters and reading settings
  function cfg() { try { return (ctx.host && ctx.host.getPracticeConfig && ctx.host.getPracticeConfig()) || {}; } catch (e) { return {}; } }
  // filters → query parameters, the ones the app sends for a random question
  function filtersQuery(f, extra) {
    f = f || {}; var p = [];
    var add = function (k, v) { p.push(k + "=" + encodeURIComponent(v)); };
    if (f.categories && f.categories.length) add("categories", f.categories.join(","));
    if (f.categoryIds && f.categoryIds.length) add("categoryIds", f.categoryIds.join(","));
    if (f.difficulties && f.difficulties.length) add("difficulties", f.difficulties.join(","));
    if (f.setNames && f.setNames.length) add("setNames", f.setNames.join(","));
    if (f.packetNumbers && f.packetNumbers.length) add("packetNumbers", f.packetNumbers.join(","));
    if (f.yearMin != null) add("yearMin", f.yearMin);
    if (f.yearMax != null) add("yearMax", f.yearMax);
    if (f.powermarkOnly) add("powermarkOnly", "true");
    if (f.canon && f.canon.length) add("canon", f.canon.join(","));
    add("cleanOnly", "1");
    Object.keys(extra || {}).forEach(function (k) { if (extra[k] != null && extra[k] !== false) add(k, extra[k]); });
    return p.join("&");
  }
  // the practice filters without a set (a drill draws from everything the player picked)
  function practiceFilters() { var f = Object.assign({}, cfg().filters || {}); delete f.setNames; delete f.packetNumbers; delete f.setIds; return f; }
  async function getTossups(n, f, extra) {
    try { var d = await ctx.api.get("/api/tossups/query?" + filtersQuery(f || practiceFilters(), Object.assign({ random: 1, limit: n }, extra || {}))); return (d && d.rows) || []; } catch (e) { return []; }
  }
  async function getBonuses(n, f, extra) {
    try { var d = await ctx.api.get("/api/bonuses/query?" + filtersQuery(f || practiceFilters(), Object.assign({ random: 1, limit: n }, extra || {}))); return (d && d.rows) || []; } catch (e) { return []; }
  }
  async function getTossup(id) { try { return (await ctx.api.get("/api/tossups/" + encodeURIComponent(id))).tossup || null; } catch (e) { return null; } }
  async function getBonus(id) { try { return (await ctx.api.get("/api/bonuses/" + encodeURIComponent(id))).bonus || null; } catch (e) { return null; } }
  async function searchTossups(query, limit, f) {
    try { var d = await ctx.api.get("/api/tossups/search?query=" + encodeURIComponent(query) + "&limit=" + (limit || 20) + (f ? "&" + filtersQuery(f) : "")); return { rows: (d && d.rows) || [], total: (d && d.total) || 0 }; } catch (e) { return { rows: [], total: 0 }; }
  }
  // tossups whose answer line names an answer
  async function tossupsOn(answer, limit) { return (await searchTossups('answer_sanitized : ("' + String(answer).replace(/"/g, "") + '")', limit || 20)).rows; }

  // a record's text as practice reads it (notes and pronunciation guides per the player's settings)
  function readText(q) {
    try { if (ctx.host && ctx.host.questionText) { var t = ctx.host.questionText(q, "question"); if (t != null) return String(t).replace(/\(\*\)/g, "").replace(/\s{2,}/g, " ").trim(); } } catch (e) {}
    return String((q && q.question_sanitized) || "").replace(/\(\*\)/g, "").trim();
  }
  function powerAt(q) { return String((q && q.question_sanitized) || "").indexOf("(*)"); }
  // sentences, without breaking at "St." or an initial ("J. R. R. Tolkien")
  var ABBR = /(?:\b(?:St|Ste|Mt|Mts|Dr|Mr|Mrs|Ms|Mme|Prof|Sr|Jr|Rev|Fr|Gen|Col|Capt|Lt|Sgt|Maj|Adm|Hon|Pres|Gov|Sen|Rep|vs|etc|cf|ca|al|Inc|Co|Corp|Ltd|Bros|approx|No|Nos|Op|op|no|Vol|vol|Ch|ch|Fig|fig|Ft|Pt|pt|Ave|[A-Za-z])\.["”’']?)$/;
  function sentences(text) {
    var parts = String(text || "").split(/(?<=[.?!]["”’)]*)\s+(?=["“(]?[A-Z0-9])/), out = [], cur = "";
    for (var i = 0; i < parts.length; i++) {
      cur = cur ? cur + " " + parts[i] : parts[i];
      if (i < parts.length - 1 && ABBR.test(cur.trim())) continue;
      out.push(cur.trim()); cur = "";
    }
    if (cur.trim()) out.push(cur.trim());
    return out.filter(Boolean);
  }
  // where each sentence of a text ends (indexes into it)
  function sentenceEnds(text) {
    var at = 0, out = []; text = String(text || "");
    sentences(text).forEach(function (x) { var i = text.indexOf(x, at); if (i < 0) return; at = i + x.length; out.push(at); });
    return out;
  }
  // ── categories (15.63): the app's own picker, its picks kept under `key` ([] = every category) ──
  // mountCats(root, key, onChange) puts it in root's [data-cats] (made once, moved into each new render);
  // inCats(pk, e): a history entry or question in the picks; with no picks, all are
  var PICKERS = {};
  function catPicker(key, onChange) {
    if (PICKERS[key]) return PICKERS[key];
    if (!ctx.host || !ctx.host.categoryPicker) return null;
    var pk = ctx.host.categoryPicker(null, { selected: ctx.storage.get(key) || [], onChange: function (ids) { ctx.storage.set(key, ids); if (onChange) onChange(ids); } });
    PICKERS[key] = pk;
    // the picks match nothing until the tree is in: draw again once it is
    if (pk.ready && (ctx.storage.get(key) || []).length) pk.ready.then(function () { if (onChange) onChange(pk.get()); });
    return pk;
  }
  function mountCats(root, key, onChange) {
    var pk = catPicker(key, onChange), host = root && root.querySelector("[data-cats]");
    if (pk && host) host.appendChild(pk.el);
    return pk;
  }
  function inCats(pk, e) {
    if (!pk || !pk.get().length) return true;
    return pk.matches(String((e && (e.category_path || e.path || e.category || e.root)) || ""));
  }
  // ── the app's reader on a page titled for the plugin (15.63: ctx.host.playPractice). Its Setup picks the categories ──
  function canRead() { return !!(ctx.host && ctx.host.playPractice); }
  function onReader() { return !!(ctx.host && ctx.host.onPracticePage && ctx.host.onPracticePage()); }
  // a plugin's start page: an icon, what it is, a Start button (data-pk="start"), a note under it
  function heroHtml(icon, title, text, start, note) {
    return '<div class="pk-hero"><span class="pk-hero-ico">' + ic(icon, 26) + "</span><h2>" + esc(title) + "</h2><p>" + esc(text) + "</p>" +
      '<div class="pk-actions pk-center"><button type="button" class="btn btn-primary" data-pk="start">' + ic("play", 14) + esc(start || "Start") + "</button></div>" +
      (note ? '<div class="pk-muted pk-small">' + note + "</div>" : "") + "</div>";
  }
  // the answer line, with its bold and underlining (nothing else of the HTML)
  function answerHtml(q) {
    var h = String((q && q.answer) || "");
    if (!/<\/?(b|u|strong|em|i)\b/i.test(h)) return esc((q && q.answer_sanitized) || h);
    return h.replace(/<(\/?)(b|u|strong|em|i)\b[^>]*>/gi, "\u0001$1$2\u0002").replace(/<[^>]*>/g, "").replace(/&(?!(?:amp|lt|gt|quot|#\d+);)/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/\u0001(\/?)(\w+)\u0002/g, "<$1$2>");
  }
  function primary(q) {
    var a = "";
    try { if (ctx.host && ctx.host.extractPrimaryAnswer) a = ctx.host.extractPrimaryAnswer((q && q.answer) || "", (q && q.answer_sanitized) || ""); } catch (e) {}
    return a || String((q && q.answer_sanitized) || "").replace(/\s*[\[(].*$/, "").trim();
  }
  // judged right here, like practice (judge.js); { status: "accept" | "prompt" | "reject", prompt }
  async function judge(q, answer, opts) {
    opts = opts || {};
    try {
      if (ctx.host && ctx.host.judgeTossup) return (await ctx.host.judgeTossup(q, answer, { strictness: opts.strictness != null ? opts.strictness : (cfg().strictness || 10), buzzPosition: opts.buzzPosition, previous: opts.previous || null })) || { status: "reject" };
      return (await ctx.api.post("/api/evaluate-tossup", { questionId: q.id, answer: answer, strictness: cfg().strictness || 10, buzzPosition: opts.buzzPosition, previous: opts.previous || null })) || { status: "reject" };
    } catch (e) { return { status: "reject" }; }
  }
  async function judgePart(b, part, answer, opts) {
    opts = opts || {};
    try {
      if (ctx.host && ctx.host.judgeBonusPart) return (await ctx.host.judgeBonusPart(b, part, answer, { strictness: cfg().strictness || 10, previous: opts.previous || null })) || { status: "reject" };
      return (await ctx.api.post("/api/evaluate-bonus-part", { questionId: b.id, part: part, answer: answer, strictness: cfg().strictness || 10 })) || { status: "reject" };
    } catch (e) { return { status: "reject" }; }
  }
  async function judgeLine(line, sani, answer, opts) {
    opts = opts || {};
    try {
      if (ctx.host && ctx.host.judgeAnswerLine) return (await ctx.host.judgeAnswerLine(line, sani, answer, { strictness: cfg().strictness || 10, previous: opts.previous || null })) || { status: "reject" };
      return (await ctx.api.post("/api/evaluate-answer", { answerline: line, answer: answer, strictness: cfg().strictness || 10 })) || { status: "reject" };
    } catch (e) { return { status: "reject" }; }
  }
  function bonusParts(b) { try { return JSON.parse((b && (b.parts_sanitized || b.parts)) || "[]"); } catch (e) { return []; } }
  function bonusAnswers(b) { try { return JSON.parse((b && b.answers) || "[]"); } catch (e) { return []; } }
  function bonusAnswersSani(b) { try { return JSON.parse((b && b.answers_sanitized) || "[]"); } catch (e) { return []; } }

  // the player's answers (Stats' history), only the fields asked for
  async function history(fields) {
    try { return ((await ctx.api.get("/api/sessions/all-entries?" + (/\banswer\b/.test(fields || "") ? "answers=1&" : "") + "fields=" + encodeURIComponent(fields || ""))).entries) || []; } catch (e) { return []; }
  }
  // record a tossup answered on a plugin's page into the player's stats (the path Coach Mode uses)
  function record(q, r) {
    try {
      ctx.api.post("/api/check-tossup", { questionId: q.id, answer: r.answer || "", buzzPosition: r.buzzPosition || 0, sessionId: r.session, overriding: true,
        correct: !!r.correct, isPower: !!r.power, points: r.points || 0, celerity: r.celerity != null ? r.celerity : 1 }).catch(function () {});
    } catch (e) {}
  }

  var ROOT_COLOR = { "Literature": "#bc8cff", "Science": "#58a6ff", "Math": "#a5e05b", "Pop Culture": "#ff7b72", "Sports": "#ff6f91", "Fine Arts": "#f778ba", "History": "#e3b341", "Geography": "#56d364", "Mythology": "#ffa657", "Social Science": "#3dd6a3", "Philosophy": "#39c5cf", "Theology": "#8e9bff", "Current Events": "#c9d16b", "Miscellaneous": "#8b949e" };
  // NAQT's high school distribution, per 24 tossups / bonuses (naqt.com/hs/distribution.jsp)
  var NAQT = [["Literature", 3.9, 3.8], ["Science", 4.5, 4.3], ["Math", 1.0, 1.0], ["Fine Arts", 2.0, 2.0], ["History", 4.6, 4.5], ["Geography", 1.9, 1.9], ["Mythology", 0.6, 0.7],
    ["Pop Culture", 1.0, 0.9], ["Sports", 0.7, 0.7], ["Social Science", 0.6, 0.6], ["Philosophy", 0.3, 0.3], ["Theology", 0.4, 0.4], ["Current Events", 1.5, 1.4], ["Miscellaneous", 1.0, 1.5]];
  function rootOf(e) { return String((e && (e.category_path || e.category)) || "").split(" > ")[0] || "Miscellaneous"; }
  function dot(root) { return '<span class="pk-dot" style="--c:' + (ROOT_COLOR[root] || "#8b949e") + '"></span>'; }
  var _roots = null;
  async function roots() {
    if (_roots) return _roots;
    try { var t = ctx.host && ctx.host.getCategoryTree ? await ctx.host.getCategoryTree("tossups") : (await ctx.api.get("/api/category-tree?type=tossups")).tree; _roots = (t || []).map(function (n) { return { id: n.id, name: n.name, count: n.count }; }); }
    catch (e) { _roots = []; }
    return _roots;
  }
  var DIFF_NAME = { 0: "Unrated", 1: "Middle school", 2: "Easy high school", 3: "Regular high school", 4: "Hard high school", 5: "National high school", 6: "Easy college", 7: "Medium college", 8: "Regionals college", 9: "Nationals college", 10: "Open" };

  function tile(value, label, cls) { return '<div class="pk-tile' + (cls ? " " + cls : "") + '"><b class="num">' + value + "</b><span>" + esc(label) + "</span></div>"; }
  function segHtml(name, items, on) {
    return '<div class="seg pk-seg" role="group">' + items.map(function (it) {
      return '<button type="button" data-' + name + '="' + esc(it[0]) + '" aria-pressed="' + (String(on) === String(it[0])) + '">' + esc(it[1]) + "</button>";
    }).join("") + "</div>";
  }
  function emptyHtml(text) { return '<div class="db-empty pk-empty">' + esc(text) + "</div>"; }
  function playList(kind, ids, title) {
    if (!ids || !ids.length) return false;
    try { return !!(ctx.host && ctx.host.launchQuestions && ctx.host.launchQuestions(kind, ids, { title: title })); } catch (e) { return false; }
  }

  // a reader: shows `text` a character at a time at the practice reading speed. start(), pause(), go(), stop();
  // at() is how far it is; onEnd once it's all shown
  function Reader(el, text, opts) {
    opts = opts || {};
    var ms = opts.ms != null ? opts.ms : (Number(cfg().revealSpeed) || 25), idx = 0, raf = 0, last = 0, on = false;
    var paint = function () { el.innerHTML = '<span class="pk-read">' + esc(text.slice(0, idx)) + '</span><span class="pk-unread" aria-hidden="true">' + esc(text.slice(idx)) + "</span>"; };
    var step = function (t) {
      raf = 0; if (!on) return;
      if (!last) last = t;
      var n = ms > 0 ? Math.floor((t - last) / ms) : text.length;
      if (n > 0) { idx = Math.min(text.length, idx + n); last += n * ms; paint(); if (opts.onTick) opts.onTick(idx); }
      if (idx >= text.length) { on = false; if (opts.onEnd) opts.onEnd(); return; }
      raf = requestAnimationFrame(step);
    };
    paint();
    return {
      start: function () { if (on) return; on = true; last = 0; raf = requestAnimationFrame(step); },
      pause: function () { on = false; if (raf) cancelAnimationFrame(raf); raf = 0; },
      stop: function () { on = false; if (raf) cancelAnimationFrame(raf); raf = 0; },
      showAll: function () { this.stop(); idx = text.length; el.textContent = text; },
      at: function () { return idx; },
      running: function () { return on; },
    };
  }
  // a reader's position in the displayed text → the record's question_sanitized (what judging and stats count)
  function serverPos(q, display, pos) {
    try { if (ctx.host && ctx.host.mapDisplayPos) return ctx.host.mapDisplayPos(display, (q && q.question_sanitized) || "", pos); } catch (e) {}
    return pos;
  }

  // ── Moderator: read a game to a room from one computer and keep the score ──
  // 2.0 (15.63): laid out like a diagnostic's IRL Reading. The whole game is one list of question cards (power mark,
  // pronunciation guides and the answer on each) with the score in a bar at the top. No timer and no buzz keys: the
  // room buzzes however it does, and a tap records what happened. A team that gets a tossup gets the bonus after it.
  var body = null;
  var cfgM = Object.assign({ teams: ["Team A", "Team B"], bonuses: true, source: "random", set: "", packet: 1, count: 20, cats: [] }, ctx.storage.get("cfg") || {});
  cfgM.teams = (cfgM.teams || []).map(function (t, k) { return typeof t === "string" ? t : (t && t.name) || "Team " + "ABCDEF"[k]; });
  if (cfgM.teams.length < 2) cfgM.teams = ["Team A", "Team B"];
  function saveCfg() { ctx.storage.set("cfg", cfgM); }
  var game = null, sets = null, picker = null;

  // a question's HTML with only its bold, underlining and italics; the power mark and pronunciation guides marked
  function safeHtml(h, plain) {
    h = String(h || "");
    var out = !/<\/?(b|u|strong|em|i)\b/i.test(h) ? esc(plain || h)
      : h.replace(/<(\/?)(b|u|strong|em|i)\b[^>]*>/gi, "\u0001$1$2\u0002").replace(/<[^>]*>/g, "").replace(/&(?!(?:amp|lt|gt|quot|#\d+);)/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/\u0001/g, "<").replace(/\u0002/g, ">");
    return out.replace(/\(\*\)/g, '<span class="irl-pm">(*)</span>').replace(/\((?:&quot;|“|")[^()]{1,60}(?:&quot;|”|")\)/g, function (m) { return '<span class="pg">' + m + "</span>"; });
  }
  function hasPower(q) { return String((q && q.question_sanitized) || "").indexOf("(*)") >= 0; }
  function chip(q) { var r = rootOf(q); return '<span class="md-cat">' + dot(r) + esc(r) + "</span>"; }
  function signed(n) { return n > 0 ? "+" + n : String(n); }
  function vals(b) { try { return JSON.parse(b.point_values || "[]"); } catch (e) { return []; } }

  // ── the game ──
  function scoreOf(k) {
    var s = 0;
    game.marks.forEach(function (m, i) {
      if (!m) return;
      Object.keys(m.negs || {}).forEach(function (t) { if (+t === k) s -= 5; });
      if (m.team === k) { s += m.pts; var b = game.bonusFor[i]; if (b && m.parts) bonusParts(b).forEach(function (p, j) { if (m.parts[j]) s += vals(b)[j] || 10; }); }
    });
    return s;
  }
  function current() { for (var i = 0; i < game.tu.length; i++) if (!game.marks[i] || !game.marks[i].done) return i; return -1; }
  function mark(i, team, pts) {
    var m = game.marks[i] = game.marks[i] || { negs: {} };
    if (pts < 0) {
      m.negs[team] = true;
      ctx.playSound("incorrect");
      if (cfgM.teams.every(function (_, k) { return m.negs[k]; })) m.done = true;
    } else {
      m.team = team; m.pts = pts; m.done = true; m.parts = [];
      ctx.playSound(pts >= 15 ? "power" : "correct");
    }
    render(true);
  }
  function dead(i) { var m = game.marks[i] = game.marks[i] || { negs: {} }; m.done = true; m.team = null; render(true); }
  function undo(i) { game.marks[i] = null; render(); }

  function tossupCard(q, i, cur) {
    var m = game.marks[i] || { negs: {} }, b = game.bonusFor[i];
    var status = m.done ? (m.team != null ? '<span class="irl-pts pos">' + esc(cfgM.teams[m.team]) + " " + signed(m.pts) + "</span>" : '<span class="irl-pts">Nobody got it</span>') : "";
    var negs = Object.keys(m.negs || {}).map(function (k) { return '<span class="md-neg">' + esc(cfgM.teams[+k]) + " −5</span>"; }).join("");
    var acts = m.done ? '<div class="irl-actions"><button type="button" class="btn btn-sm btn-ghost" data-md="undo" data-i="' + i + '">Undo</button></div>'
      : '<div class="md-score">' + cfgM.teams.map(function (t, k) {
          var out = m.negs && m.negs[k];
          return '<div class="md-trow' + (out ? " out" : "") + '"><span class="md-tname">' + esc(t) + "</span>" + (out ? '<span class="pk-muted pk-small">Negged</span>'
            : (hasPower(q) ? '<button type="button" class="btn btn-sm md-pw" data-md="pts" data-i="' + i + '" data-k="' + k + '" data-p="15">Power</button>' : "") +
              '<button type="button" class="btn btn-sm md-ok" data-md="pts" data-i="' + i + '" data-k="' + k + '" data-p="10">Right</button><button type="button" class="btn btn-sm md-no" data-md="pts" data-i="' + i + '" data-k="' + k + '" data-p="-5">Neg</button>') + "</div>";
        }).join("") + '<div class="irl-actions"><button type="button" class="btn btn-sm" data-md="dead" data-i="' + i + '">Nobody got it</button></div></div>';
    var html = '<section class="cl-card irl-q md-q' + (cur ? " current" : "") + '" id="md-t-' + i + '" aria-label="Tossup ' + (i + 1) + '"><div class="irl-qh"><span class="irl-num">Tossup ' + (i + 1) + "</span>" + chip(q) + negs + status + "</div>" +
      '<p class="irl-text">' + safeHtml(q.question, q.question_sanitized) + "</p>" +
      '<p class="irl-ans"><span class="cl-lbl">Answer</span>' + answerHtml(q) + "</p>" + acts + "</section>";
    if (cfgM.bonuses && b && m.done && m.team != null) html += bonusCard(b, i, m);
    return html;
  }
  function bonusCard(b, i, m) {
    var v = vals(b), got = bonusParts(b).reduce(function (s, p, j) { return s + (m.parts[j] ? (v[j] || 10) : 0); }, 0), raw = bonusAnswers(b), sani = bonusAnswersSani(b);
    return '<section class="cl-card irl-q md-q" id="md-b-' + i + '" aria-label="Bonus ' + (i + 1) + '"><div class="irl-qh"><span class="irl-num">Bonus ' + (i + 1) + "</span>" + chip(b) +
      '<span class="pk-muted pk-small">for ' + esc(cfgM.teams[m.team]) + '</span><span class="irl-pts' + (got ? " pos" : "") + '">' + signed(got) + "</span></div>" +
      '<p class="irl-lead">' + safeHtml(b.leadin, b.leadin_sanitized) + "</p>" +
      bonusParts(b).map(function (p, j) {
        var on = !!m.parts[j];
        return '<div class="irl-part"><span class="pn">' + (j + 1) + '</span><div><p>' + esc(p) + '</p><p class="bp-ans"><span class="cl-lbl">Answer</span>' + (raw[j] ? safeHtml(raw[j], sani[j]) : esc(sani[j] || "")) + "</p></div>" +
          '<button type="button" class="btn btn-sm md-got" data-md="part" data-i="' + i + '" data-j="' + j + '" aria-pressed="' + on + '">' + (on ? ic("check", 13) + "Got it" : "Got it") + "</button></div>";
      }).join("") + "</section>";
  }
  function renderGame(scrollToCurrent) {
    var cur = current(), total = game.tu.length;
    body.innerHTML = '<div class="pk-wrap md">' +
      '<div class="irl-bar md-bar"><button type="button" class="irl-now" data-md="jump"' + (cur < 0 ? " disabled" : "") + "><b>" + (cur < 0 ? "All read" : "Tossup " + (cur + 1) + " of " + total) + "</b><small>" + (cur < 0 ? "Ready to finish" : "Up next") + "</small></button>" +
        '<div class="md-scores">' + cfgM.teams.map(function (t, k) { return '<div class="irl-score"><b class="num">' + scoreOf(k) + "</b><small>" + esc(t) + "</small></div>"; }).join("") + "</div>" +
        '<button type="button" class="btn btn-primary" data-md="finish">Finish' + ic("right", 15) + "</button></div>" +
      '<div class="irl-list">' + game.tu.map(function (q, i) { return tossupCard(q, i, i === cur); }).join("") +
        '<div class="cl-card irl-q irl-end"><button type="button" class="btn btn-primary" data-md="finish">Finish the game</button></div></div></div>';
    if (scrollToCurrent && cur >= 0) { var el = body.querySelector("#md-t-" + cur); if (el) el.scrollIntoView({ behavior: "smooth", block: "start" }); }
  }
  function renderOver() {
    var rows = cfgM.teams.map(function (t, k) { return { name: t, pts: scoreOf(k), k: k }; }).sort(function (a, b) { return b.pts - a.pts; });
    var heard = game.marks.filter(function (m) { return m && m.done; }).length;
    body.innerHTML = '<div class="pk-wrap pk-narrow md">' +
      '<div class="pk-hero"><span class="pk-hero-ico">' + ic("flag", 26) + "</span><h2>" + (rows[0].pts === (rows[1] || {}).pts ? "A tie" : esc(rows[0].name) + " won") + "</h2><p>" + plural(heard, "tossup") + " read.</p>" +
        '<div class="md-final">' + rows.map(function (r) { return '<div class="md-frow"><span>' + esc(r.name) + '</span><b class="num">' + r.pts + "</b></div>"; }).join("") + "</div>" +
        '<div class="pk-actions pk-center"><button type="button" class="btn btn-primary" data-md="new">New game</button><button type="button" class="btn" data-md="back">Back to the game</button></div></div></div>';
  }

  // ── setting up ──
  function renderSetup() {
    var last = cfgM.last;
    body.innerHTML = '<div class="pk-wrap pk-narrow md">' +
      '<div class="pk-hero"><span class="pk-hero-ico">' + ic("users", 26) + "</span><h2>Read a game to a room</h2><p>The whole game on one page, with each answer under its question. Tap who got each tossup, and the score keeps itself.</p></div>" +
      '<div class="pk-card"><h3>Teams</h3><div class="md-teams">' + cfgM.teams.map(function (t, k) {
        return '<div class="md-tset"><input class="md-tin" data-k="' + k + '" value="' + esc(t) + '" maxlength="24" aria-label="Team name">' + (cfgM.teams.length > 2 ? '<button type="button" class="btn btn-ghost btn-sm" data-rm="' + k + '" aria-label="Remove ' + esc(t) + '">' + ic("x", 14) + "</button>" : "") + "</div>";
      }).join("") + "</div>" + (cfgM.teams.length < 6 ? '<button type="button" class="btn btn-sm md-add" data-md="add">' + ic("plus", 13) + "Add a team</button>" : "") + "</div>" +
      '<div class="pk-card"><h3>Questions</h3><div class="md-opts">' +
        '<div class="md-opt"><span>From</span>' + segHtml("src", [["random", "Categories"], ["packet", "A packet"]], cfgM.source) + "</div>" +
        (cfgM.source === "packet"
          ? '<div class="md-opt"><span>Set</span><select id="md-set" class="mode-input">' + (sets ? sets.map(function (s) { return "<option" + (s.name === cfgM.set ? " selected" : "") + ">" + esc(s.name) + "</option>"; }).join("") : "<option>Loading…</option>") + "</select></div>" +
            '<div class="md-opt"><span>Packet</span><input id="md-pk" class="mode-input md-num" type="number" min="1" max="40" value="' + cfgM.packet + '"></div>'
          : '<div class="md-opt"><span>Categories</span><span id="md-cats"></span></div><div class="md-opt"><span>Tossups</span>' + segHtml("count", [[10, "10"], [15, "15"], [20, "20"], [24, "24"]], cfgM.count) + "</div>") +
        '<label class="checkbox-row md-bon"><input type="checkbox" id="md-bonuses"' + (cfgM.bonuses ? " checked" : "") + "> Bonuses after a right tossup</label></div></div>" +
      '<div class="pk-actions pk-center"><button type="button" class="btn btn-primary" data-md="start">' + ic("play", 14) + 'Start the game</button></div><div class="pk-center pk-small pk-bad" id="md-err"></div>' +
      (last ? '<div class="pk-card"><h3>Last game</h3>' + last.teams.map(function (t) { return '<div class="md-frow"><span>' + esc(t.name) + '</span><b class="num">' + t.score + "</b></div>"; }).join("") + "</div>" : "") + "</div>";
    body.querySelectorAll(".md-tin").forEach(function (i) {
      i.addEventListener("input", function () { cfgM.teams[+i.dataset.k] = i.value.trim() || "Team " + "ABCDEF"[+i.dataset.k]; saveCfg(); });
      i.addEventListener("keydown", function (e) { e.stopPropagation(); });
    });
    body.querySelectorAll("[data-rm]").forEach(function (b) { b.onclick = function () { cfgM.teams.splice(+b.dataset.rm, 1); saveCfg(); render(); }; });
    body.querySelectorAll("[data-src]").forEach(function (b) { b.onclick = function () { cfgM.source = b.dataset.src; saveCfg(); render(); }; });
    body.querySelectorAll("[data-count]").forEach(function (b) { b.onclick = function () { cfgM.count = Number(b.dataset.count); saveCfg(); render(); }; });
    var st = body.querySelector("#md-set"); if (st) st.onchange = function () { cfgM.set = st.value; saveCfg(); };
    var pk = body.querySelector("#md-pk"); if (pk) { pk.onchange = function () { cfgM.packet = Math.max(1, parseInt(pk.value) || 1); saveCfg(); }; pk.addEventListener("keydown", function (e) { e.stopPropagation(); }); }
    body.querySelector("#md-bonuses").onchange = function (e) { cfgM.bonuses = e.target.checked; saveCfg(); };
    var host = body.querySelector("#md-cats");
    if (host && ctx.host && ctx.host.categoryPicker) {
      picker = ctx.host.categoryPicker(null, { selected: cfgM.cats || [], label: "", onChange: function (ids) { cfgM.cats = ids; saveCfg(); } });
      host.appendChild(picker.el);
    }
    if (cfgM.source === "packet" && !sets) loadSets();
  }
  async function loadSets() { try { sets = ((await ctx.api.get("/api/sets")).sets || []); if (!cfgM.set && sets[0]) cfgM.set = sets[0].name; } catch (e) { sets = []; } if (!game) render(); }
  async function start() {
    var btn = body.querySelector('[data-md="start"]'), err = body.querySelector("#md-err");
    if (btn) { btn.disabled = true; btn.lastChild.textContent = "Getting questions…"; }
    var tu = [], bo = [];
    if (cfgM.source === "packet") {
      try { var c = await ctx.api.get("/api/packet-content?setName=" + encodeURIComponent(cfgM.set) + "&packetNumber=" + cfgM.packet); tu = c.tossups || []; bo = c.bonuses || []; } catch (e) {}
    } else {
      var f = practiceFilters(); if (cfgM.cats && cfgM.cats.length) { f.categoryIds = cfgM.cats.slice(); delete f.categories; }
      tu = await getTossups(cfgM.count, f);
      if (cfgM.bonuses) bo = await getBonuses(cfgM.count, f);
    }
    if (!tu.length) { if (btn) { btn.disabled = false; btn.lastChild.textContent = "Start the game"; } if (err) err.textContent = "No questions found. Try other categories or another packet."; return; }
    game = { tu: tu, bonusFor: tu.map(function (_, i) { return bo[i] || null; }), marks: [], over: false };
    render();
    window.scrollTo(0, 0);
  }
  function finish() {
    if (!game) return;
    cfgM.last = { teams: cfgM.teams.map(function (t, k) { return { name: t, score: scoreOf(k) }; }), at: Date.now() };
    saveCfg();
    game.over = true; render(); window.scrollTo(0, 0);
  }

  function render(scrollToCurrent) {
    if (!body) return;
    if (!game) return renderSetup();
    if (game.over) return renderOver();
    renderGame(scrollToCurrent);
  }
  // one listener for every button on the page
  function onClick(e) {
    var b = e.target.closest && e.target.closest("[data-md]"); if (!b || !body || !body.contains(b)) return;
    var a = b.dataset.md, i = +b.dataset.i;
    if (a === "start") start();
    else if (a === "add") { cfgM.teams.push("Team " + "ABCDEF"[cfgM.teams.length]); saveCfg(); render(); }
    else if (a === "pts") mark(i, +b.dataset.k, +b.dataset.p);
    else if (a === "dead") dead(i);
    else if (a === "undo") undo(i);
    else if (a === "part") { var m = game.marks[i]; if (m) { m.parts[+b.dataset.j] = !m.parts[+b.dataset.j]; render(); } }
    else if (a === "jump") { var c = current(); var el = c >= 0 && body.querySelector("#md-t-" + c); if (el) el.scrollIntoView({ behavior: "smooth", block: "start" }); }
    else if (a === "finish") { if (current() >= 0 && ctx.host && ctx.host.confirm) ctx.host.confirm("Finish the game? Some tossups weren't read.", finish, { yes: "Finish" }); else finish(); }
    else if (a === "new") { game = null; render(); window.scrollTo(0, 0); }
    else if (a === "back") { game.over = false; render(); }
  }
  document.addEventListener("click", onClick);
  ctx._cleanup = function () { document.removeEventListener("click", onClick); };
  ctx.registerPage({
    id: "moderator", navLabel: "Moderator", title: "Moderator",
    onShow: function (el) { body = el; render(); },
  });

}
