function __qbMain(ctx) {
  // ── the kit the 15.62 plugins share (text, icons, questions, judging, history) ──
  function esc(s) { return (s == null ? "" : String(s)).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
  var IC = {
    play: '<path d="M7 4l13 8-13 8z"/>',
    pause: '<path d="M8 5v14M16 5v14"/>',
    left: '<path d="M15 6l-6 6 6 6"/>',
    right: '<path d="M9 6l6 6-6 6"/>',
    next: '<path d="M6 5l9 7-9 7zM18 5v14"/>',
    refresh: '<path d="M20 11a8 8 0 10-2.3 5.7M20 4v7h-7"/>',
    x: '<path d="M6 6l12 12M18 6L6 18"/>',
    check: '<path d="M5 12l5 5 9-10"/>',
    mic: '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
    volume: '<path d="M4 9v6h4l5 4V5L8 9z"/><path d="M16 9a4 4 0 0 1 0 6M19 6a8 8 0 0 1 0 12"/>',
    copy: '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h3"/>',
    edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="M13.5 6.5l4 4"/>',
    bolt: '<path d="M13 3L5 14h6l-1 7 8-11h-6z"/>',
    flag: '<path d="M5 21V4M5 4h11l-2 4 2 4H5"/>',
    users: '<circle cx="9" cy="8" r="3"/><path d="M3 20a6 6 0 0 1 12 0M16 4a3 3 0 0 1 0 6M21 20a6 6 0 0 0-4-5.6"/>',
    target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
    down: '<path d="M6 9l6 6 6-6"/>',
    up: '<path d="M6 15l6-6 6 6"/>',
  };
  function ic(name, size) {
    var s = size || 16;
    return '<svg width="' + s + '" height="' + s + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (IC[name] || "") + "</svg>";
  }
  function loading(label) { return '<div class="pk-loading">' + (ctx.loadingBarHtml ? ctx.loadingBarHtml(label) : esc(label)) + "</div>"; }
  function norm(s) { return String(s || "").toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[^a-z0-9]+/g, " ").trim(); }
  function pct(a, n) { return n ? Math.round(100 * a / n) : 0; }
  function fmt(n) { return Number(n || 0).toLocaleString(); }
  function plural(n, one, many) { return fmt(n) + " " + (n === 1 ? one : (many || one + "s")); }
  function shuffle(a) { for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)), t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
  function inField(e) { var t = e && e.target; return !!t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT" || t.isContentEditable); }
  function dayKey(t) { var d = new Date(t || Date.now()); return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0"); }
  var DAY = 86400000;

  // the practice setup (Setup panel): its filters and reading settings
  function cfg() { try { return (ctx.host && ctx.host.getPracticeConfig && ctx.host.getPracticeConfig()) || {}; } catch (e) { return {}; } }
  // filters → query parameters, the ones the app sends for a random question
  function filtersQuery(f, extra) {
    f = f || {}; var p = [];
    var add = function (k, v) { p.push(k + "=" + encodeURIComponent(v)); };
    if (f.categories && f.categories.length) add("categories", f.categories.join(","));
    if (f.categoryIds && f.categoryIds.length) add("categoryIds", f.categoryIds.join(","));
    if (f.difficulties && f.difficulties.length) add("difficulties", f.difficulties.join(","));
    if (f.setNames && f.setNames.length) add("setNames", f.setNames.join(","));
    if (f.packetNumbers && f.packetNumbers.length) add("packetNumbers", f.packetNumbers.join(","));
    if (f.yearMin != null) add("yearMin", f.yearMin);
    if (f.yearMax != null) add("yearMax", f.yearMax);
    if (f.powermarkOnly) add("powermarkOnly", "true");
    if (f.canon && f.canon.length) add("canon", f.canon.join(","));
    add("cleanOnly", "1");
    Object.keys(extra || {}).forEach(function (k) { if (extra[k] != null && extra[k] !== false) add(k, extra[k]); });
    return p.join("&");
  }
  // the practice filters without a set (a drill draws from everything the player picked)
  function practiceFilters() { var f = Object.assign({}, cfg().filters || {}); delete f.setNames; delete f.packetNumbers; delete f.setIds; return f; }
  async function getTossups(n, f, extra) {
    try { var d = await ctx.api.get("/api/tossups/query?" + filtersQuery(f || practiceFilters(), Object.assign({ random: 1, limit: n }, extra || {}))); return (d && d.rows) || []; } catch (e) { return []; }
  }
  async function getBonuses(n, f, extra) {
    try { var d = await ctx.api.get("/api/bonuses/query?" + filtersQuery(f || practiceFilters(), Object.assign({ random: 1, limit: n }, extra || {}))); return (d && d.rows) || []; } catch (e) { return []; }
  }
  async function getTossup(id) { try { return (await ctx.api.get("/api/tossups/" + encodeURIComponent(id))).tossup || null; } catch (e) { return null; } }
  async function getBonus(id) { try { return (await ctx.api.get("/api/bonuses/" + encodeURIComponent(id))).bonus || null; } catch (e) { return null; } }
  async function searchTossups(query, limit, f) {
    try { var d = await ctx.api.get("/api/tossups/search?query=" + encodeURIComponent(query) + "&limit=" + (limit || 20) + (f ? "&" + filtersQuery(f) : "")); return { rows: (d && d.rows) || [], total: (d && d.total) || 0 }; } catch (e) { return { rows: [], total: 0 }; }
  }
  // tossups whose answer line names an answer
  async function tossupsOn(answer, limit) { return (await searchTossups('answer_sanitized : ("' + String(answer).replace(/"/g, "") + '")', limit || 20)).rows; }

  // a record's text as practice reads it (notes and pronunciation guides per the player's settings)
  function readText(q) {
    try { if (ctx.host && ctx.host.questionText) { var t = ctx.host.questionText(q, "question"); if (t != null) return String(t).replace(/\(\*\)/g, "").replace(/\s{2,}/g, " ").trim(); } } catch (e) {}
    return String((q && q.question_sanitized) || "").replace(/\(\*\)/g, "").trim();
  }
  function powerAt(q) { return String((q && q.question_sanitized) || "").indexOf("(*)"); }
  // sentences, without breaking at "St." or an initial ("J. R. R. Tolkien")
  var ABBR = /(?:\b(?:St|Ste|Mt|Mts|Dr|Mr|Mrs|Ms|Mme|Prof|Sr|Jr|Rev|Fr|Gen|Col|Capt|Lt|Sgt|Maj|Adm|Hon|Pres|Gov|Sen|Rep|vs|etc|cf|ca|al|Inc|Co|Corp|Ltd|Bros|approx|No|Nos|Op|op|no|Vol|vol|Ch|ch|Fig|fig|Ft|Pt|pt|Ave|[A-Za-z])\.["”’']?)$/;
  function sentences(text) {
    var parts = String(text || "").split(/(?<=[.?!]["”’)]*)\s+(?=["“(]?[A-Z0-9])/), out = [], cur = "";
    for (var i = 0; i < parts.length; i++) {
      cur = cur ? cur + " " + parts[i] : parts[i];
      if (i < parts.length - 1 && ABBR.test(cur.trim())) continue;
      out.push(cur.trim()); cur = "";
    }
    if (cur.trim()) out.push(cur.trim());
    return out.filter(Boolean);
  }
  // the answer line, with its bold and underlining (nothing else of the HTML)
  function answerHtml(q) {
    var h = String((q && q.answer) || "");
    if (!/<\/?(b|u|strong|em|i)\b/i.test(h)) return esc((q && q.answer_sanitized) || h);
    return h.replace(/<(\/?)(b|u|strong|em|i)\b[^>]*>/gi, "\u0001$1$2\u0002").replace(/<[^>]*>/g, "").replace(/&(?!(?:amp|lt|gt|quot|#\d+);)/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/\u0001(\/?)(\w+)\u0002/g, "<$1$2>");
  }
  function primary(q) {
    var a = "";
    try { if (ctx.host && ctx.host.extractPrimaryAnswer) a = ctx.host.extractPrimaryAnswer((q && q.answer) || "", (q && q.answer_sanitized) || ""); } catch (e) {}
    return a || String((q && q.answer_sanitized) || "").replace(/\s*[\[(].*$/, "").trim();
  }
  // judged right here, like practice (judge.js); { status: "accept" | "prompt" | "reject", prompt }
  async function judge(q, answer, opts) {
    opts = opts || {};
    try {
      if (ctx.host && ctx.host.judgeTossup) return (await ctx.host.judgeTossup(q, answer, { strictness: opts.strictness != null ? opts.strictness : (cfg().strictness || 10), buzzPosition: opts.buzzPosition, previous: opts.previous || null })) || { status: "reject" };
      return (await ctx.api.post("/api/evaluate-tossup", { questionId: q.id, answer: answer, strictness: cfg().strictness || 10, buzzPosition: opts.buzzPosition, previous: opts.previous || null })) || { status: "reject" };
    } catch (e) { return { status: "reject" }; }
  }
  async function judgePart(b, part, answer, opts) {
    opts = opts || {};
    try {
      if (ctx.host && ctx.host.judgeBonusPart) return (await ctx.host.judgeBonusPart(b, part, answer, { strictness: cfg().strictness || 10, previous: opts.previous || null })) || { status: "reject" };
      return (await ctx.api.post("/api/evaluate-bonus-part", { questionId: b.id, part: part, answer: answer, strictness: cfg().strictness || 10 })) || { status: "reject" };
    } catch (e) { return { status: "reject" }; }
  }
  async function judgeLine(line, sani, answer, opts) {
    opts = opts || {};
    try {
      if (ctx.host && ctx.host.judgeAnswerLine) return (await ctx.host.judgeAnswerLine(line, sani, answer, { strictness: cfg().strictness || 10, previous: opts.previous || null })) || { status: "reject" };
      return (await ctx.api.post("/api/evaluate-answer", { answerline: line, answer: answer, strictness: cfg().strictness || 10 })) || { status: "reject" };
    } catch (e) { return { status: "reject" }; }
  }
  function bonusParts(b) { try { return JSON.parse((b && (b.parts_sanitized || b.parts)) || "[]"); } catch (e) { return []; } }
  function bonusAnswers(b) { try { return JSON.parse((b && b.answers) || "[]"); } catch (e) { return []; } }
  function bonusAnswersSani(b) { try { return JSON.parse((b && b.answers_sanitized) || "[]"); } catch (e) { return []; } }

  // the player's answers (Stats' history), only the fields asked for
  async function history(fields) {
    try { return ((await ctx.api.get("/api/sessions/all-entries?" + (/\banswer\b/.test(fields || "") ? "answers=1&" : "") + "fields=" + encodeURIComponent(fields || ""))).entries) || []; } catch (e) { return []; }
  }
  // record a tossup answered on a plugin's page into the player's stats (the path Coach Mode uses)
  function record(q, r) {
    try {
      ctx.api.post("/api/check-tossup", { questionId: q.id, answer: r.answer || "", buzzPosition: r.buzzPosition || 0, sessionId: r.session, overriding: true,
        correct: !!r.correct, isPower: !!r.power, points: r.points || 0, celerity: r.celerity != null ? r.celerity : 1 }).catch(function () {});
    } catch (e) {}
  }

  var ROOT_COLOR = { "Literature": "#bc8cff", "Science": "#58a6ff", "Math": "#a5e05b", "Pop Culture": "#ff7b72", "Sports": "#ff6f91", "Fine Arts": "#f778ba", "History": "#e3b341", "Geography": "#56d364", "Mythology": "#ffa657", "Social Science": "#3dd6a3", "Philosophy": "#39c5cf", "Theology": "#8e9bff", "Current Events": "#c9d16b", "Miscellaneous": "#8b949e" };
  // NAQT's high school distribution, per 24 tossups / bonuses (naqt.com/hs/distribution.jsp)
  var NAQT = [["Literature", 3.9, 3.8], ["Science", 4.5, 4.3], ["Math", 1.0, 1.0], ["Fine Arts", 2.0, 2.0], ["History", 4.6, 4.5], ["Geography", 1.9, 1.9], ["Mythology", 0.6, 0.7],
    ["Pop Culture", 1.0, 0.9], ["Sports", 0.7, 0.7], ["Social Science", 0.6, 0.6], ["Philosophy", 0.3, 0.3], ["Theology", 0.4, 0.4], ["Current Events", 1.5, 1.4], ["Miscellaneous", 1.0, 1.5]];
  function rootOf(e) { return String((e && (e.category_path || e.category)) || "").split(" > ")[0] || "Miscellaneous"; }
  function dot(root) { return '<span class="pk-dot" style="--c:' + (ROOT_COLOR[root] || "#8b949e") + '"></span>'; }
  var _roots = null;
  async function roots() {
    if (_roots) return _roots;
    try { var t = ctx.host && ctx.host.getCategoryTree ? await ctx.host.getCategoryTree("tossups") : (await ctx.api.get("/api/category-tree?type=tossups")).tree; _roots = (t || []).map(function (n) { return { id: n.id, name: n.name, count: n.count }; }); }
    catch (e) { _roots = []; }
    return _roots;
  }
  var DIFF_NAME = { 0: "Unrated", 1: "Middle school", 2: "Easy high school", 3: "Regular high school", 4: "Hard high school", 5: "National high school", 6: "Easy college", 7: "Medium college", 8: "Regionals college", 9: "Nationals college", 10: "Open" };

  function tile(value, label, cls) { return '<div class="pk-tile' + (cls ? " " + cls : "") + '"><b class="num">' + value + "</b><span>" + esc(label) + "</span></div>"; }
  function segHtml(name, items, on) {
    return '<div class="seg pk-seg" role="group">' + items.map(function (it) {
      return '<button type="button" data-' + name + '="' + esc(it[0]) + '" aria-pressed="' + (String(on) === String(it[0])) + '">' + esc(it[1]) + "</button>";
    }).join("") + "</div>";
  }
  function emptyHtml(text) { return '<div class="db-empty pk-empty">' + esc(text) + "</div>"; }
  function playList(kind, ids, title) {
    if (!ids || !ids.length) return false;
    try { return !!(ctx.host && ctx.host.launchQuestions && ctx.host.launchQuestions(kind, ids, { title: title })); } catch (e) { return false; }
  }

  // a reader: shows `text` a character at a time at the practice reading speed. start(), pause(), go(), stop();
  // at() is how far it is; onEnd once it's all shown
  function Reader(el, text, opts) {
    opts = opts || {};
    var ms = opts.ms != null ? opts.ms : (Number(cfg().revealSpeed) || 25), idx = 0, raf = 0, last = 0, on = false;
    var paint = function () { el.innerHTML = '<span class="pk-read">' + esc(text.slice(0, idx)) + '</span><span class="pk-unread" aria-hidden="true">' + esc(text.slice(idx)) + "</span>"; };
    var step = function (t) {
      raf = 0; if (!on) return;
      if (!last) last = t;
      var n = ms > 0 ? Math.floor((t - last) / ms) : text.length;
      if (n > 0) { idx = Math.min(text.length, idx + n); last += n * ms; paint(); if (opts.onTick) opts.onTick(idx); }
      if (idx >= text.length) { on = false; if (opts.onEnd) opts.onEnd(); return; }
      raf = requestAnimationFrame(step);
    };
    paint();
    return {
      start: function () { if (on) return; on = true; last = 0; raf = requestAnimationFrame(step); },
      pause: function () { on = false; if (raf) cancelAnimationFrame(raf); raf = 0; },
      stop: function () { on = false; if (raf) cancelAnimationFrame(raf); raf = 0; },
      showAll: function () { this.stop(); idx = text.length; el.textContent = text; },
      at: function () { return idx; },
      running: function () { return on; },
    };
  }
  // a reader's position in the displayed text → the record's question_sanitized (what judging and stats count)
  function serverPos(q, display, pos) {
    try { if (ctx.host && ctx.host.mapDisplayPos) return ctx.host.mapDisplayPos(display, (q && q.question_sanitized) || "", pos); } catch (e) {}
    return pos;
  }

  // ── Moderator: read questions to a room from one computer, with a buzz key per team and the scores ──
  // The moderator reads the question aloud from the screen (power mark, pronunciation guides and notes shown). A
  // team buzzes with its key; the first press locks the others out until the moderator scores it. A wrong answer
  // keeps that team out of the rest of the tossup. A team that gets a tossup gets the bonus that goes with it.
  var body = null, page = null;
  var cfgM = Object.assign({ teams: [{ name: "Team A", key: "a" }, { name: "Team B", key: "l" }], bonuses: true, source: "random", set: "", packet: 1, count: 20 }, ctx.storage.get("cfg") || {});
  function saveCfg() { ctx.storage.set("cfg", cfgM); }
  var game = null, sets = null, timerT = 0;
  var KEYS = ["a", "l", "z", "m"];

  // a question's HTML with only its bold, underlining and italics (the power part is bold, notes italic)
  function safeHtml(h, plain) {
    h = String(h || "");
    if (!/<\/?(b|u|strong|em|i)\b/i.test(h)) return esc(plain || h);
    return h.replace(/<(\/?)(b|u|strong|em|i)\b[^>]*>/gi, "\u0001$1$2\u0002").replace(/<[^>]*>/g, "").replace(/&(?!(?:amp|lt|gt|quot|#\d+);)/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/\u0001(\/?)(\w+)\u0002/g, "<$1$2>");
  }
  function markPower(html) { return html.replace(/\(\*\)/g, '<span class="md-pw">(*)</span>'); }

  function render() {
    if (!body) return;
    if (!game) return renderSetup();
    var t = game.tossups[game.i], b = game.bonus;
    var scores = cfgM.teams.map(function (tm, k) {
      return '<div class="md-team' + (game.buzz === k ? " buzzed" : "") + (game.out[k] ? " out" : "") + '"><span class="md-key">' + esc(tm.key.toUpperCase()) + '</span><span class="md-tn">' + esc(tm.name) + '</span><b class="num md-sc">' + game.score[k] + "</b></div>";
    }).join("");
    body.innerHTML = '<div class="pk-wrap md">' +
      '<div class="md-board">' + scores + "</div>" +
      '<div class="pk-bar-top"><span class="pk-chip">Tossup ' + (game.i + 1) + " of " + game.tossups.length + '</span><span class="spacer"></span><button type="button" class="btn btn-ghost" id="md-sheet" aria-expanded="' + !!game.sheet + '">' + (game.sheet ? "Hide the scoresheet" : "Scoresheet") + '</button><button type="button" class="btn btn-ghost" id="md-end">End the game</button></div>' +
      (game.sheet ? sheetHtml() : "") +
      (game.phase === "bonus" && b ? bonusHtml(b) :
      '<div class="pk-card md-card">' + (t ? '<div class="pk-meta">' + dot(rootOf(t)) + esc(String(t.category_path || "").replace(/ > /g, " › ")) + (t.set_name ? " · " + esc(t.set_name) : "") + "</div>" +
        '<div class="md-q">' + markPower(safeHtml(t.question, t.question_sanitized)) + "</div>" +
        '<div class="pk-answer md-ans"><span class="pk-muted">Answer </span>' + answerHtml(t) + "</div>" : loading("")) + "</div>" +
      '<div class="md-ctl">' + (game.buzz != null
        ? '<div class="md-who"><b>' + esc(cfgM.teams[game.buzz].name) + '</b> buzzed<span class="md-timer num" id="md-timer"></span></div><div class="pk-actions">' +
          '<button type="button" class="btn md-pw-btn" data-pts="15">Power +15</button><button type="button" class="btn btn-primary" data-pts="10">Right +10</button><button type="button" class="btn md-neg" data-pts="-5">Neg −5</button><button type="button" class="btn" data-pts="0">Wrong, no penalty</button></div>'
        : '<div class="md-who pk-muted">Read the question. Teams buzz with their keys.</div><div class="pk-actions"><button type="button" class="btn" id="md-dead">Dead, next tossup</button></div>') + "</div>") +
      "</div>";
    body.querySelector("#md-end").onclick = function () { if (ctx.host && ctx.host.confirm) ctx.host.confirm("End this game?", endGame, { yes: "End it" }); else endGame(); };
    body.querySelector("#md-sheet").onclick = sheet;
    body.querySelectorAll("[data-pts]").forEach(function (x) { x.onclick = function () { score(Number(x.dataset.pts)); }; });
    var d = body.querySelector("#md-dead"); if (d) d.onclick = function () { game.log.push({ i: game.i, team: null, pts: 0 }); nextTossup(); };
    body.querySelectorAll("[data-part]").forEach(function (x) { x.onclick = function () { var k = +x.dataset.part; game.parts[k] = !game.parts[k]; render(); }; });
    var bd = body.querySelector("#md-bdone"); if (bd) bd.onclick = bonusDone;
    tickTimer();
  }
  function bonusHtml(b) {
    var parts = bonusParts(b), raw = bonusAnswers(b), sani = bonusAnswersSani(b), vals = (function () { try { return JSON.parse(b.point_values || "[]"); } catch (e) { return []; } })();
    var got = parts.reduce(function (s, p, k) { return s + (game.parts[k] ? (vals[k] || 10) : 0); }, 0);
    return '<div class="pk-card md-card"><div class="pk-meta">Bonus for <b>' + esc(cfgM.teams[game.bonusTeam].name) + "</b> · " + dot(rootOf(b)) + esc(rootOf(b)) + "</div>" +
      '<div class="md-q">' + safeHtml(b.leadin, b.leadin_sanitized) + "</div>" +
      parts.map(function (p, k) {
        return '<div class="md-part"><div class="md-q md-pq"><b class="md-pv">[' + (vals[k] || 10) + "]</b> " + esc(p) + '</div><div class="pk-row"><div class="pk-answer pk-grow"><span class="pk-muted">Answer </span>' + answerHtml({ answer: raw[k], answer_sanitized: sani[k] }) + '</div><button type="button" class="btn btn-sm md-got' + (game.parts[k] ? " on" : "") + '" data-part="' + k + '">' + (game.parts[k] ? ic("check", 13) + "Got it" : "Got it?") + "</button></div></div>";
      }).join("") + '<div class="pk-actions"><span class="pk-strong">' + got + ' points</span><span style="flex:1"></span><button type="button" class="btn btn-primary" id="md-bdone">Done, next tossup</button></div></div>';
  }
  function tickTimer() {
    clearTimeout(timerT);
    var el = body && body.querySelector("#md-timer"); if (!el || game.buzz == null) return;
    var left = Math.max(0, Math.ceil((game.buzzAt + 5000 - Date.now()) / 1000));
    el.textContent = left ? left + "s" : "Time";
    el.classList.toggle("late", !left);
    if (left) timerT = setTimeout(tickTimer, 250);
  }
  function score(pts) {
    var k = game.buzz; if (k == null) return;
    game.score[k] += pts; game.log.push({ i: game.i, team: k, pts: pts });
    ctx.playSound(pts > 0 ? (pts >= 15 ? "power" : "correct") : "incorrect");
    game.buzz = null;
    if (pts > 0) {
      if (cfgM.bonuses && game.bonuses[game.i]) { game.phase = "bonus"; game.bonus = game.bonuses[game.i]; game.bonusTeam = k; game.parts = []; render(); return; }
      nextTossup(); return;
    }
    game.out[k] = true;
    if (cfgM.teams.every(function (_, j) { return game.out[j]; })) { nextTossup(); return; }
    render();
  }
  function bonusDone() {
    var b = game.bonus, vals = (function () { try { return JSON.parse(b.point_values || "[]"); } catch (e) { return []; } })();
    var got = bonusParts(b).reduce(function (s, p, k) { return s + (game.parts[k] ? (vals[k] || 10) : 0); }, 0);
    game.score[game.bonusTeam] += got; game.log[game.log.length - 1].bonus = got;
    nextTossup();
  }
  function nextTossup() {
    game.i++; game.out = {}; game.buzz = null; game.phase = "tossup"; game.bonus = null;
    if (game.i >= game.tossups.length) { endGame(); return; }
    render(); window.scrollTo(0, 0);
  }
  function endGame() {
    var g = game; game = null; clearTimeout(timerT);
    if (g) cfgM.last = { teams: cfgM.teams.map(function (t, k) { return { name: t.name, score: g.score[k] }; }), n: g.log.length, at: Date.now() };
    saveCfg(); render();
  }
  function sheetHtml() {
    var rows = game.log.map(function (l) { return "<tr><td class=\"num\">" + (l.i + 1) + "</td>" + cfgM.teams.map(function (_, k) { return "<td class=\"num\">" + (l.team === k ? (l.pts > 0 ? "+" : "") + l.pts + (l.bonus != null ? " and " + l.bonus : "") : "") + "</td>"; }).join("") + "</tr>"; }).join("");
    return '<div class="pk-card md-sheetc"><table class="md-table"><thead><tr><th>Tossup</th>' + cfgM.teams.map(function (t) { return "<th>" + esc(t.name) + "</th>"; }).join("") + "</tr></thead><tbody>" + (rows || '<tr><td colspan="9" class="pk-muted">Nothing scored yet</td></tr>') + "</tbody></table></div>";
  }
  function sheet() { game.sheet = !game.sheet; render(); }
  function renderSetup() {
    var last = cfgM.last;
    body.innerHTML = '<div class="pk-wrap md">' +
      '<div class="pk-card"><h3>Teams</h3><div class="md-teams">' + cfgM.teams.map(function (t, k) {
        return '<div class="md-tset"><span class="md-key">' + esc(t.key.toUpperCase()) + '</span><input class="md-tname" data-k="' + k + '" value="' + esc(t.name) + '" maxlength="24" aria-label="Team name">' + (cfgM.teams.length > 2 ? '<button type="button" class="btn btn-ghost btn-icon btn-sm" data-rm="' + k + '" aria-label="Remove team">' + ic("x", 14) + "</button>" : "") + "</div>";
      }).join("") + (cfgM.teams.length < 4 ? '<button type="button" class="btn btn-sm" id="md-add">' + ic("plus", 13) + "Add a team</button>" : "") + '</div><div class="pk-muted pk-small" style="margin-top:8px">Each team buzzes with its letter key.</div></div>' +
      '<div class="pk-card"><h3>Questions</h3><div class="pk-actions">' + segHtml("src", [["random", "From your Setup"], ["packet", "A packet"]], cfgM.source) + "</div>" +
        (cfgM.source === "packet" ? '<div class="md-pick"><label class="pk-field"><span>Set</span><select id="md-set">' + (sets ? sets.map(function (s) { return '<option' + (s.name === cfgM.set ? " selected" : "") + ">" + esc(s.name) + "</option>"; }).join("") : "<option>Loading…</option>") + '</select></label><label class="pk-field"><span>Packet</span><input id="md-pk" type="number" min="1" max="99" value="' + cfgM.packet + '"></label></div>'
          : '<div class="md-pick"><label class="pk-field"><span>Tossups</span><select id="md-count">' + [10, 15, 20, 24].map(function (n) { return '<option' + (n === cfgM.count ? " selected" : "") + ">" + n + "</option>"; }).join("") + "</select></label></div>") +
        '<label class="checkbox-row md-bon"><input type="checkbox" id="md-bonuses"' + (cfgM.bonuses ? " checked" : "") + "> Bonuses after a right tossup</label></div>" +
      '<div class="pk-actions"><button type="button" class="btn btn-primary" id="md-start">' + ic("play", 14) + "Start the game</button></div>" +
      (last ? '<div class="pk-card"><h3>Last game</h3>' + last.teams.map(function (t) { return '<div class="pk-row md-lrow"><span class="pk-grow">' + esc(t.name) + '</span><b class="num">' + t.score + "</b></div>"; }).join("") + "</div>" : "") + "</div>";
    body.querySelectorAll(".md-tname").forEach(function (i) { i.addEventListener("input", function () { cfgM.teams[+i.dataset.k].name = i.value.trim() || "Team " + "ABCD"[+i.dataset.k]; saveCfg(); }); i.addEventListener("keydown", function (e) { e.stopPropagation(); }); });
    body.querySelectorAll("[data-rm]").forEach(function (b) { b.onclick = function () { cfgM.teams.splice(+b.dataset.rm, 1); cfgM.teams.forEach(function (t, k) { t.key = KEYS[k]; }); saveCfg(); render(); }; });
    var add = body.querySelector("#md-add"); if (add) add.onclick = function () { var k = cfgM.teams.length; cfgM.teams.push({ name: "Team " + "ABCD"[k], key: KEYS[k] }); saveCfg(); render(); };
    body.querySelectorAll("[data-src]").forEach(function (b) { b.onclick = function () { cfgM.source = b.dataset.src; saveCfg(); render(); if (cfgM.source === "packet" && !sets) loadSets(); }; });
    var st = body.querySelector("#md-set"); if (st) st.onchange = function () { cfgM.set = st.value; saveCfg(); };
    var pk = body.querySelector("#md-pk"); if (pk) { pk.onchange = function () { cfgM.packet = Math.max(1, parseInt(pk.value) || 1); saveCfg(); }; pk.addEventListener("keydown", function (e) { e.stopPropagation(); }); }
    var ct = body.querySelector("#md-count"); if (ct) ct.onchange = function () { cfgM.count = Number(ct.value); saveCfg(); };
    body.querySelector("#md-bonuses").onchange = function (e) { cfgM.bonuses = e.target.checked; saveCfg(); };
    body.querySelector("#md-start").onclick = start;
    if (cfgM.source === "packet" && !sets) loadSets();
  }
  async function loadSets() { try { sets = ((await ctx.api.get("/api/sets")).sets || []); if (!cfgM.set && sets[0]) cfgM.set = sets[0].name; } catch (e) { sets = []; } if (!game) render(); }
  async function start() {
    var btn = body.querySelector("#md-start"); if (btn) { btn.disabled = true; btn.lastChild.textContent = "Getting questions…"; }
    var tu = [], bo = [];
    if (cfgM.source === "packet") {
      try { var c = await ctx.api.get("/api/packet-content?setName=" + encodeURIComponent(cfgM.set) + "&packetNumber=" + cfgM.packet); tu = c.tossups || []; bo = c.bonuses || []; } catch (e) {}
    } else {
      tu = await getTossups(cfgM.count);
      if (cfgM.bonuses) bo = await getBonuses(cfgM.count);
    }
    if (!tu.length) { if (btn) { btn.disabled = false; btn.lastChild.textContent = "No questions found"; } return; }
    game = { tossups: tu, bonuses: bo, i: 0, score: cfgM.teams.map(function () { return 0; }), out: {}, buzz: null, phase: "tossup", log: [] };
    render();
  }
  // a team's key: the first press holds the floor until the moderator scores it
  function onKey(e) {
    if (!game || game.phase !== "tossup" || !(page && page.screenEl && page.screenEl.classList.contains("active")) || inField(e) || e.metaKey || e.ctrlKey || e.altKey || e.repeat) return;
    var k = cfgM.teams.findIndex(function (t) { return t.key === String(e.key).toLowerCase(); });
    if (k < 0) return;
    e.preventDefault();
    if (game.buzz != null || game.out[k]) return;
    game.buzz = k; game.buzzAt = Date.now();
    ctx.playSound("buzz");
    render();
  }
  document.addEventListener("keydown", onKey);
  ctx._cleanup = function () { document.removeEventListener("keydown", onKey); clearTimeout(timerT); };
  page = ctx.registerPage({
    id: "moderator", navLabel: "Moderator", title: "Moderator",
    onShow: function (el) { body = el; render(); },
  });

}
