/**
 * OfflineQuiz plugin: Moderator
 *
 * For club practice in person. The moderator reads from the screen, with the power mark, the
 * pronunciation guides and the notes shown. Each team buzzes with its own key on the same keyboard,
 * the first press locks the others out, and the moderator scores it with one click.
 */
QB.registerPlugin({
  id: "moderator",
  name: "Moderator",
  version: "2.3.0",
  author: "OfflineQuiz",
  description: "Read a game to a room from one computer and keep the score, laid out like IRL Reading.",
  onEnable: __qbMain,
  onDisable: function (ctx) { if (ctx._cleanup) ctx._cleanup(); },
});
