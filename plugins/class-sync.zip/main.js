QB.registerPlugin({
  id: "class-sync",
  name: "Class Sync",
  version: "1.0.0",
  author: "OfflineQuiz",
  description: "Upload your stats, achievements and Fact Sheet searches to your class — only when you press the button.",
  onEnable: __qbMain,
});
