function __qbMain(ctx) {
  var body = null, page = null;

  var RELAY = "https://offlinequiz-mp-relay.warren2028045.workers.dev";
  function esc(s) { return (s == null ? "" : String(s)).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }

  // ── identity ────────────────────────────────────────────────────────────
  // A stable per-install id keeps two students with the same display name
  // apart, and lets the same person re-upload over their own record forever.
  function userId() {
    var id = ctx.storage.get("user-id");
    if (!id) {
      id = "u" + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
      ctx.storage.set("user-id", id);
    }
    return id;
  }
  function displayName() {
    var n = ctx.storage.get("display-name");
    if (n) return n;
    try { var st = ctx.getState && ctx.getState(); if (st && st.username) return st.username; } catch (e) {}
    return "";
  }
  // Everyone who installs this plugin reports to the same pool — there is no
  // class code to hand out and nothing to type. The dashboard plugin reads the
  // same pool.
  var POOL = "everyone";
  function lastUpload() { return ctx.storage.get("last-upload") || null; }

  // ── snapshot ────────────────────────────────────────────────────────────
  // One self-contained picture of this student's state. The server upserts it
  // by (class, user), so uploading twice is a no-op — which is exactly why a
  // failed upload can always be retried without any bookkeeping.
  async function buildSnapshot() {
    var snap = {
      userId: userId(),
      name: displayName() || "(unnamed)",
      builtAt: Date.now(),
      stats: {},
      achievements: [],
      starred: { tossups: 0, bonuses: 0 },
      searches: [],
      buzzes: [],
    };

    try {
      var sd = await ctx.api.get("/api/stats");
      var s = (sd && sd.stats) || {};
      snap.stats = {
        totalQuestions: s.totalQuestions || 0,
        totalPoints: s.totalPoints || 0,
        pointsPerQuestion: +(s.averagePointsPerQuestion || 0).toFixed(2),
        tossupAccuracy: +(((s.tossupAccuracy || 0) * 100)).toFixed(1),
        powers: s.tossupPowers || 0,
        negs: s.tossupNegs || 0,
        avgCelerity: +(((s.tossupAvgCelerity || 0) * 100)).toFixed(1),
        bonusesHeard: s.bonusesAttempted || 0,
        ppb: +(s.bonusConversion || 0).toFixed(2),
      };
    } catch (e) {}

    // getEarnedAchievements landed in app 11.2. On an older base the method is
    // simply absent, and silently reporting "0 achievements" would be a wrong
    // number rather than a missing one — so flag it and say so on the page.
    try {
      if (ctx.host && ctx.host.getEarnedAchievements) {
        var achs = await ctx.host.getEarnedAchievements();
        snap.achievements = (achs || []).filter(function (a) { return a.earned; }).map(function (a) { return a.id; });
        snap.achievementNames = {};
        (achs || []).forEach(function (a) { if (a.earned) snap.achievementNames[a.id] = a.name; });
      } else {
        snap.achievementsUnavailable = true;
      }
    } catch (e) {
      snap.achievementsUnavailable = true;
    }

    try {
      var t = await ctx.api.get("/api/starred?type=tossup");
      var b = await ctx.api.get("/api/starred?type=bonus");
      snap.starred = { tossups: ((t && t.starred) || []).length, bonuses: ((b && b.starred) || []).length };
    } catch (e) {}

    // Fact Sheet searches (absolute totals).
    var searched = [];
    try { if (window.QBFactSheet && window.QBFactSheet.searches) searched = window.QBFactSheet.searches(); } catch (e) {}
    snap.searches = searched.map(function (x) { return { term: x.term, count: x.count, last: x.last }; });

    // Only questions whose ANSWER the student looked up in Fact Sheet — the
    // rest of their practice history never leaves the machine. The base app
    // resolves every answer in one call (?answers=1) using the same
    // normalization applied to the search terms here, so this is a set
    // membership test rather than fuzzy substring matching, and it costs one
    // request no matter how long the student's history is.
    if (searched.length) {
      var norm = function (s) { return String(s || "").toLowerCase().replace(/[^a-z0-9]+/g, " ").trim(); };
      var want = {};
      searched.forEach(function (x) { var k = norm(x.term); if (k) want[k] = 1; });
      try {
        var d = await ctx.api.get("/api/sessions/all-entries?answers=1");
        var entries = (d && d.entries) || [];
        for (var i = entries.length - 1; i >= 0 && snap.buzzes.length < 400; i--) {
          var en = entries[i];
          if (!en.question_id || !en.answer) continue;
          var norms = en.answer_norms || [];
          var hit = false;
          for (var n = 0; n < norms.length; n++) { if (want[norms[n]]) { hit = true; break; } }
          if (!hit) continue;
          snap.buzzes.push({
            questionId: en.question_id,
            answer: en.answer,
            given: en.given_answer || "",
            buzzPosition: en.buzz_position != null ? en.buzz_position : null,
            celerity: en.celerity != null ? +Number(en.celerity).toFixed(3) : null,
            points: en.points != null ? en.points : null,
            category: en.category || "",
            type: en.type || "tossup",
            at: en.timestamp || null,
          });
        }
      } catch (e) {}
    }
    return snap;
  }

  // What changed since the last successful upload — used only to show a
  // friendly "nothing new" state. Never gates the upload itself: if the last
  // attempt failed, or the marker is stale/missing, uploading is still allowed
  // and the server just upserts the same record.
  function diffSummary(snap) {
    var prev = lastUpload();
    if (!prev || !prev.ok) return null;
    var newAch = (snap.achievements || []).filter(function (id) { return (prev.achievements || []).indexOf(id) < 0; });
    var prevSearch = prev.searchTotal || 0;
    var searchTotal = (snap.searches || []).reduce(function (a, x) { return a + (x.count || 0); }, 0);
    return {
      newAchievements: newAch.length,
      newSearches: Math.max(0, searchTotal - prevSearch),
      questionsDelta: (snap.stats.totalQuestions || 0) - (prev.totalQuestions || 0),
      nothingNew: newAch.length === 0 && searchTotal === prevSearch && (snap.stats.totalQuestions || 0) === (prev.totalQuestions || 0),
    };
  }

  async function upload(snap, statusEl, btn) {
    btn.disabled = true;
    statusEl.innerHTML = '<span class="text-muted">Uploading…</span>';
    try {
      var res = await fetch(RELAY + "/class/" + POOL + "/user/" + encodeURIComponent(snap.userId), {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(snap),
      });
      var out = null;
      try { out = await res.json(); } catch (e) {}
      if (!res.ok) throw new Error((out && out.error) || ("server said " + res.status));
      // Only record success AFTER a confirmed response. If anything above threw,
      // nothing is marked, so the next press re-sends — and the server upsert
      // makes that harmless.
      ctx.storage.set("last-upload", {
        ok: true,
        at: Date.now(),
        achievements: snap.achievements || [],
        searchTotal: (snap.searches || []).reduce(function (a, x) { return a + (x.count || 0); }, 0),
        totalQuestions: snap.stats.totalQuestions || 0,
      });
      statusEl.innerHTML = '<span class="cs-good">Uploaded. Your teacher can see it now.</span>';
      ctx.toast("Your data was uploaded");
      render();
    } catch (e) {
      var msg = String((e && e.message) || e);
      var offline = /Failed to fetch|NetworkError|load failed/i.test(msg);
      statusEl.innerHTML = '<span class="cs-bad">' + esc(offline ? "Couldn't reach the server — check your internet and try again." : "Upload failed: " + msg) + "</span>";
      btn.disabled = false;
    }
  }

  async function render() {
    if (!body) return;
    var last = lastUpload();
    body.innerHTML =
      '<div class="cs-wrap"><div class="cs-card">' +
        '<div class="cs-title">Class Sync is on</div>' +
        '<div class="cs-sub">Nothing is sent anywhere until you press Upload.</div>' +
        '<div class="cs-row"><label class="cs-lbl">Your name</label><input id="cs-name" class="mode-input" value="' + esc(displayName()) + '" placeholder="how you appear on your teacher’s list" autocomplete="off"></div>' +
        '<div class="cs-list" id="cs-summary"><div class="text-muted">Reading your data…</div></div>' +
        '<div class="cs-actions"><button class="btn btn-primary" id="cs-upload">Upload my data</button>' +
          '<span class="cs-status" id="cs-status">' + (last && last.ok ? '<span class="text-muted">Last upload: ' + new Date(last.at).toLocaleString() + "</span>" : "") + "</span></div>" +
      "</div></div>";

    body.querySelector("#cs-name").onchange = function (e) { ctx.storage.set("display-name", e.target.value.trim()); };

    var snap = await buildSnapshot();
    var sum = body.querySelector("#cs-summary");
    if (!sum) return;
    var d = diffSummary(snap);
    sum.innerHTML =
      '<div class="cs-what">This upload will include:</div>' +
      '<div class="cs-items">' +
        '<span class="cs-item"><b>' + snap.stats.totalQuestions + "</b> questions answered</span>" +
        (snap.achievementsUnavailable
          ? '<span class="cs-item cs-warn">achievements need app 11.2+ — update the app</span>'
          : '<span class="cs-item"><b>' + (snap.achievements || []).length + "</b> achievements</span>") +
        '<span class="cs-item"><b>' + (snap.starred.tossups + snap.starred.bonuses) + "</b> starred questions</span>" +
        '<span class="cs-item"><b>' + (snap.searches || []).length + "</b> answers searched in Fact Sheet</span>" +
        '<span class="cs-item"><b>' + (snap.buzzes || []).length + "</b> buzzes on those answers</span>" +
      "</div>" +
      (d && d.nothingNew ? '<div class="cs-note">Nothing new since your last upload — sending again is harmless.</div>'
        : d ? '<div class="cs-note">New since last upload: ' + d.newAchievements + " achievements, " + d.newSearches + " searches, " + Math.max(0, d.questionsDelta) + " questions.</div>"
        : "");

    var btn = body.querySelector("#cs-upload");
    btn.onclick = function () { upload(snap, body.querySelector("#cs-status"), btn); };
  }

  page = ctx.registerPage({
    id: "sync", navLabel: "Class Sync", title: "CLASS SYNC",
    onShow: function (el) { body = el; render(); },
  });
}
