function __qbMain(ctx) {
  // ── the kit the 15.62 plugins share (text, icons, questions, judging, history) ──
  function esc(s) { return (s == null ? "" : String(s)).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
  var IC = {
    play: '<path d="M7 4l13 8-13 8z"/>',
    pause: '<path d="M8 5v14M16 5v14"/>',
    left: '<path d="M15 6l-6 6 6 6"/>',
    right: '<path d="M9 6l6 6-6 6"/>',
    next: '<path d="M6 5l9 7-9 7zM18 5v14"/>',
    refresh: '<path d="M20 11a8 8 0 10-2.3 5.7M20 4v7h-7"/>',
    x: '<path d="M6 6l12 12M18 6L6 18"/>',
    check: '<path d="M5 12l5 5 9-10"/>',
    mic: '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
    volume: '<path d="M4 9v6h4l5 4V5L8 9z"/><path d="M16 9a4 4 0 0 1 0 6M19 6a8 8 0 0 1 0 12"/>',
    copy: '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h3"/>',
    edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="M13.5 6.5l4 4"/>',
    bolt: '<path d="M13 3L5 14h6l-1 7 8-11h-6z"/>',
    flag: '<path d="M5 21V4M5 4h11l-2 4 2 4H5"/>',
    users: '<circle cx="9" cy="8" r="3"/><path d="M3 20a6 6 0 0 1 12 0M16 4a3 3 0 0 1 0 6M21 20a6 6 0 0 0-4-5.6"/>',
    target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
    down: '<path d="M6 9l6 6 6-6"/>',
    up: '<path d="M6 15l6-6 6 6"/>',
  };
  function ic(name, size) {
    var s = size || 16;
    return '<svg width="' + s + '" height="' + s + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (IC[name] || "") + "</svg>";
  }
  function loading(label) { return '<div class="pk-loading">' + (ctx.loadingBarHtml ? ctx.loadingBarHtml(label) : esc(label)) + "</div>"; }
  function norm(s) { return String(s || "").toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[^a-z0-9]+/g, " ").trim(); }
  function pct(a, n) { return n ? Math.round(100 * a / n) : 0; }
  function fmt(n) { return Number(n || 0).toLocaleString(); }
  function plural(n, one, many) { return fmt(n) + " " + (n === 1 ? one : (many || one + "s")); }
  function shuffle(a) { for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)), t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
  function inField(e) { var t = e && e.target; return !!t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT" || t.isContentEditable); }
  function dayKey(t) { var d = new Date(t || Date.now()); return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0"); }
  var DAY = 86400000;

  // the practice setup (Setup panel): its filters and reading settings
  function cfg() { try { return (ctx.host && ctx.host.getPracticeConfig && ctx.host.getPracticeConfig()) || {}; } catch (e) { return {}; } }
  // filters → query parameters, the ones the app sends for a random question
  function filtersQuery(f, extra) {
    f = f || {}; var p = [];
    var add = function (k, v) { p.push(k + "=" + encodeURIComponent(v)); };
    if (f.categories && f.categories.length) add("categories", f.categories.join(","));
    if (f.categoryIds && f.categoryIds.length) add("categoryIds", f.categoryIds.join(","));
    if (f.difficulties && f.difficulties.length) add("difficulties", f.difficulties.join(","));
    if (f.setNames && f.setNames.length) add("setNames", f.setNames.join(","));
    if (f.packetNumbers && f.packetNumbers.length) add("packetNumbers", f.packetNumbers.join(","));
    if (f.yearMin != null) add("yearMin", f.yearMin);
    if (f.yearMax != null) add("yearMax", f.yearMax);
    if (f.powermarkOnly) add("powermarkOnly", "true");
    if (f.canon && f.canon.length) add("canon", f.canon.join(","));
    add("cleanOnly", "1");
    Object.keys(extra || {}).forEach(function (k) { if (extra[k] != null && extra[k] !== false) add(k, extra[k]); });
    return p.join("&");
  }
  // the practice filters without a set (a drill draws from everything the player picked)
  function practiceFilters() { var f = Object.assign({}, cfg().filters || {}); delete f.setNames; delete f.packetNumbers; delete f.setIds; return f; }
  async function getTossups(n, f, extra) {
    try { var d = await ctx.api.get("/api/tossups/query?" + filtersQuery(f || practiceFilters(), Object.assign({ random: 1, limit: n }, extra || {}))); return (d && d.rows) || []; } catch (e) { return []; }
  }
  async function getBonuses(n, f, extra) {
    try { var d = await ctx.api.get("/api/bonuses/query?" + filtersQuery(f || practiceFilters(), Object.assign({ random: 1, limit: n }, extra || {}))); return (d && d.rows) || []; } catch (e) { return []; }
  }
  async function getTossup(id) { try { return (await ctx.api.get("/api/tossups/" + encodeURIComponent(id))).tossup || null; } catch (e) { return null; } }
  async function getBonus(id) { try { return (await ctx.api.get("/api/bonuses/" + encodeURIComponent(id))).bonus || null; } catch (e) { return null; } }
  async function searchTossups(query, limit, f) {
    try { var d = await ctx.api.get("/api/tossups/search?query=" + encodeURIComponent(query) + "&limit=" + (limit || 20) + (f ? "&" + filtersQuery(f) : "")); return { rows: (d && d.rows) || [], total: (d && d.total) || 0 }; } catch (e) { return { rows: [], total: 0 }; }
  }
  // tossups whose answer line names an answer
  async function tossupsOn(answer, limit) { return (await searchTossups('answer_sanitized : ("' + String(answer).replace(/"/g, "") + '")', limit || 20)).rows; }

  // a record's text as practice reads it (notes and pronunciation guides per the player's settings)
  function readText(q) {
    try { if (ctx.host && ctx.host.questionText) { var t = ctx.host.questionText(q, "question"); if (t != null) return String(t).replace(/\(\*\)/g, "").replace(/\s{2,}/g, " ").trim(); } } catch (e) {}
    return String((q && q.question_sanitized) || "").replace(/\(\*\)/g, "").trim();
  }
  function powerAt(q) { return String((q && q.question_sanitized) || "").indexOf("(*)"); }
  // sentences, without breaking at "St." or an initial ("J. R. R. Tolkien")
  var ABBR = /(?:\b(?:St|Ste|Mt|Mts|Dr|Mr|Mrs|Ms|Mme|Prof|Sr|Jr|Rev|Fr|Gen|Col|Capt|Lt|Sgt|Maj|Adm|Hon|Pres|Gov|Sen|Rep|vs|etc|cf|ca|al|Inc|Co|Corp|Ltd|Bros|approx|No|Nos|Op|op|no|Vol|vol|Ch|ch|Fig|fig|Ft|Pt|pt|Ave|[A-Za-z])\.["”’']?)$/;
  function sentences(text) {
    var parts = String(text || "").split(/(?<=[.?!]["”’)]*)\s+(?=["“(]?[A-Z0-9])/), out = [], cur = "";
    for (var i = 0; i < parts.length; i++) {
      cur = cur ? cur + " " + parts[i] : parts[i];
      if (i < parts.length - 1 && ABBR.test(cur.trim())) continue;
      out.push(cur.trim()); cur = "";
    }
    if (cur.trim()) out.push(cur.trim());
    return out.filter(Boolean);
  }
  // the answer line, with its bold and underlining (nothing else of the HTML)
  function answerHtml(q) {
    var h = String((q && q.answer) || "");
    if (!/<\/?(b|u|strong|em|i)\b/i.test(h)) return esc((q && q.answer_sanitized) || h);
    return h.replace(/<(\/?)(b|u|strong|em|i)\b[^>]*>/gi, "\u0001$1$2\u0002").replace(/<[^>]*>/g, "").replace(/&(?!(?:amp|lt|gt|quot|#\d+);)/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/\u0001(\/?)(\w+)\u0002/g, "<$1$2>");
  }
  function primary(q) {
    var a = "";
    try { if (ctx.host && ctx.host.extractPrimaryAnswer) a = ctx.host.extractPrimaryAnswer((q && q.answer) || "", (q && q.answer_sanitized) || ""); } catch (e) {}
    return a || String((q && q.answer_sanitized) || "").replace(/\s*[\[(].*$/, "").trim();
  }
  // judged right here, like practice (judge.js); { status: "accept" | "prompt" | "reject", prompt }
  async function judge(q, answer, opts) {
    opts = opts || {};
    try {
      if (ctx.host && ctx.host.judgeTossup) return (await ctx.host.judgeTossup(q, answer, { strictness: opts.strictness != null ? opts.strictness : (cfg().strictness || 10), buzzPosition: opts.buzzPosition, previous: opts.previous || null })) || { status: "reject" };
      return (await ctx.api.post("/api/evaluate-tossup", { questionId: q.id, answer: answer, strictness: cfg().strictness || 10, buzzPosition: opts.buzzPosition, previous: opts.previous || null })) || { status: "reject" };
    } catch (e) { return { status: "reject" }; }
  }
  async function judgePart(b, part, answer, opts) {
    opts = opts || {};
    try {
      if (ctx.host && ctx.host.judgeBonusPart) return (await ctx.host.judgeBonusPart(b, part, answer, { strictness: cfg().strictness || 10, previous: opts.previous || null })) || { status: "reject" };
      return (await ctx.api.post("/api/evaluate-bonus-part", { questionId: b.id, part: part, answer: answer, strictness: cfg().strictness || 10 })) || { status: "reject" };
    } catch (e) { return { status: "reject" }; }
  }
  async function judgeLine(line, sani, answer, opts) {
    opts = opts || {};
    try {
      if (ctx.host && ctx.host.judgeAnswerLine) return (await ctx.host.judgeAnswerLine(line, sani, answer, { strictness: cfg().strictness || 10, previous: opts.previous || null })) || { status: "reject" };
      return (await ctx.api.post("/api/evaluate-answer", { answerline: line, answer: answer, strictness: cfg().strictness || 10 })) || { status: "reject" };
    } catch (e) { return { status: "reject" }; }
  }
  function bonusParts(b) { try { return JSON.parse((b && (b.parts_sanitized || b.parts)) || "[]"); } catch (e) { return []; } }
  function bonusAnswers(b) { try { return JSON.parse((b && b.answers) || "[]"); } catch (e) { return []; } }
  function bonusAnswersSani(b) { try { return JSON.parse((b && b.answers_sanitized) || "[]"); } catch (e) { return []; } }

  // the player's answers (Stats' history), only the fields asked for
  async function history(fields) {
    try { return ((await ctx.api.get("/api/sessions/all-entries?" + (/\banswer\b/.test(fields || "") ? "answers=1&" : "") + "fields=" + encodeURIComponent(fields || ""))).entries) || []; } catch (e) { return []; }
  }
  // record a tossup answered on a plugin's page into the player's stats (the path Coach Mode uses)
  function record(q, r) {
    try {
      ctx.api.post("/api/check-tossup", { questionId: q.id, answer: r.answer || "", buzzPosition: r.buzzPosition || 0, sessionId: r.session, overriding: true,
        correct: !!r.correct, isPower: !!r.power, points: r.points || 0, celerity: r.celerity != null ? r.celerity : 1 }).catch(function () {});
    } catch (e) {}
  }

  var ROOT_COLOR = { "Literature": "#bc8cff", "Science": "#58a6ff", "Math": "#a5e05b", "Pop Culture": "#ff7b72", "Sports": "#ff6f91", "Fine Arts": "#f778ba", "History": "#e3b341", "Geography": "#56d364", "Mythology": "#ffa657", "Social Science": "#3dd6a3", "Philosophy": "#39c5cf", "Theology": "#8e9bff", "Current Events": "#c9d16b", "Miscellaneous": "#8b949e" };
  // NAQT's high school distribution, per 24 tossups / bonuses (naqt.com/hs/distribution.jsp)
  var NAQT = [["Literature", 3.9, 3.8], ["Science", 4.5, 4.3], ["Math", 1.0, 1.0], ["Fine Arts", 2.0, 2.0], ["History", 4.6, 4.5], ["Geography", 1.9, 1.9], ["Mythology", 0.6, 0.7],
    ["Pop Culture", 1.0, 0.9], ["Sports", 0.7, 0.7], ["Social Science", 0.6, 0.6], ["Philosophy", 0.3, 0.3], ["Theology", 0.4, 0.4], ["Current Events", 1.5, 1.4], ["Miscellaneous", 1.0, 1.5]];
  function rootOf(e) { return String((e && (e.category_path || e.category)) || "").split(" > ")[0] || "Miscellaneous"; }
  function dot(root) { return '<span class="pk-dot" style="--c:' + (ROOT_COLOR[root] || "#8b949e") + '"></span>'; }
  var _roots = null;
  async function roots() {
    if (_roots) return _roots;
    try { var t = ctx.host && ctx.host.getCategoryTree ? await ctx.host.getCategoryTree("tossups") : (await ctx.api.get("/api/category-tree?type=tossups")).tree; _roots = (t || []).map(function (n) { return { id: n.id, name: n.name, count: n.count }; }); }
    catch (e) { _roots = []; }
    return _roots;
  }
  var DIFF_NAME = { 0: "Unrated", 1: "Middle school", 2: "Easy high school", 3: "Regular high school", 4: "Hard high school", 5: "National high school", 6: "Easy college", 7: "Medium college", 8: "Regionals college", 9: "Nationals college", 10: "Open" };

  function tile(value, label, cls) { return '<div class="pk-tile' + (cls ? " " + cls : "") + '"><b class="num">' + value + "</b><span>" + esc(label) + "</span></div>"; }
  function segHtml(name, items, on) {
    return '<div class="seg pk-seg" role="group">' + items.map(function (it) {
      return '<button type="button" data-' + name + '="' + esc(it[0]) + '" aria-pressed="' + (String(on) === String(it[0])) + '">' + esc(it[1]) + "</button>";
    }).join("") + "</div>";
  }
  function emptyHtml(text) { return '<div class="db-empty pk-empty">' + esc(text) + "</div>"; }
  function playList(kind, ids, title) {
    if (!ids || !ids.length) return false;
    try { return !!(ctx.host && ctx.host.launchQuestions && ctx.host.launchQuestions(kind, ids, { title: title })); } catch (e) { return false; }
  }

  // a reader: shows `text` a character at a time at the practice reading speed. start(), pause(), go(), stop();
  // at() is how far it is; onEnd once it's all shown
  function Reader(el, text, opts) {
    opts = opts || {};
    var ms = opts.ms != null ? opts.ms : (Number(cfg().revealSpeed) || 25), idx = 0, raf = 0, last = 0, on = false;
    var paint = function () { el.innerHTML = '<span class="pk-read">' + esc(text.slice(0, idx)) + '</span><span class="pk-unread" aria-hidden="true">' + esc(text.slice(idx)) + "</span>"; };
    var step = function (t) {
      raf = 0; if (!on) return;
      if (!last) last = t;
      var n = ms > 0 ? Math.floor((t - last) / ms) : text.length;
      if (n > 0) { idx = Math.min(text.length, idx + n); last += n * ms; paint(); if (opts.onTick) opts.onTick(idx); }
      if (idx >= text.length) { on = false; if (opts.onEnd) opts.onEnd(); return; }
      raf = requestAnimationFrame(step);
    };
    paint();
    return {
      start: function () { if (on) return; on = true; last = 0; raf = requestAnimationFrame(step); },
      pause: function () { on = false; if (raf) cancelAnimationFrame(raf); raf = 0; },
      stop: function () { on = false; if (raf) cancelAnimationFrame(raf); raf = 0; },
      showAll: function () { this.stop(); idx = text.length; el.textContent = text; },
      at: function () { return idx; },
      running: function () { return on; },
    };
  }
  // a reader's position in the displayed text → the record's question_sanitized (what judging and stats count)
  function serverPos(q, display, pos) {
    try { if (ctx.host && ctx.host.mapDisplayPos) return ctx.host.mapDisplayPos(display, (q && q.question_sanitized) || "", pos); } catch (e) {}
    return pos;
  }

  // ── Rival: an opponent that buzzes where a player a little better than you would ──
  // Its buzz point comes from your own: the median point of the question where you buzz right in that category
  // (Stats' history), minus an edge set by its level. Each tossup you win moves it up a level and each one it wins moves it
  // down two thirds of one, so it settles where you win about four in ten: always a little ahead. It's right more
  // often at higher levels, and a wrong buzz from it leaves the question to you.
  var body = null, page = null, sess = "rival-" + Date.now();
  var st = Object.assign({ level: 4, games: 0, wins: 0, best: 0 }, ctx.storage.get("rival") || {});
  function save() { ctx.storage.set("rival", st); }
  var you = null;            // { root: { med, n } , all: { med, n } } from history
  var queue = [], game = null, cur = null, reader = null, keyOff = null;
  var GAME_LEN = 20;

  async function learnYou() {
    var es = await history("type,correct,points,celerity,category_path,category,timestamp");
    var by = {}, all = [];
    es.slice(-3000).forEach(function (e) {
      if (e.type !== "tossup" || !e.correct || e.celerity == null || e.celerity <= 0 || e.celerity > 1) return;
      var r = rootOf(e); (by[r] = by[r] || []).push(e.celerity); all.push(e.celerity);
    });
    var med = function (a) { if (!a.length) return null; var s = a.slice().sort(function (x, y) { return x - y; }); return s[Math.floor(s.length / 2)]; };
    you = { all: { med: med(all) || 0.72, n: all.length } };
    Object.keys(by).forEach(function (r) { you[r] = { med: by[r].length >= 8 ? med(by[r]) : null, n: by[r].length }; });
  }
  function edge(L) { return -0.12 + 0.03 * L; }              // how much earlier than you it buzzes (fraction of the question)
  function accuracy(L) { return 0.7 + 0.025 * L; }
  function planRival(q, len) {
    var r = rootOf(q), mine = (you[r] && you[r].med) || you.all.med;
    var f = mine - edge(st.level) + (Math.random() - 0.5) * 0.16;
    f = Math.max(0.12, Math.min(0.97, f));
    return { at: Math.max(8, Math.round(len * f)), right: Math.random() < accuracy(st.level) };
  }

  async function fill() {
    if (queue.length >= 4) return;
    var rows = await getTossups(12, null, { powermarkOnly: "true" });
    if (!rows.length) rows = await getTossups(12);
    rows.forEach(function (q) { if (!queue.some(function (x) { return x.id === q.id; })) queue.push(q); });
  }

  function scoreLine() {
    if (!game) return "";
    return '<span class="rv-score"><span>You <b class="num">' + game.me + '</b></span><span class="pk-muted">·</span><span>Rival <b class="num">' + game.rival + "</b></span></span>" +
      '<span class="pk-chip">Tossup ' + Math.max(1, Math.min(GAME_LEN, game.n + (cur && cur.phase !== "done" ? 1 : 0))) + " of " + GAME_LEN + "</span>";
  }
  function levelHtml() {
    var dots = ""; for (var i = 1; i <= 10; i++) dots += '<i class="' + (i <= Math.round(st.level) ? "on" : "") + '"></i>';
    return '<span class="rv-level" title="The Rival\'s level moves with you">Rival level <b class="num">' + Math.round(st.level) + '</b><span class="rv-dots">' + dots + "</span></span>";
  }

  function render() {
    if (!body) return;
    if (!game) { renderHome(); return; }
    body.innerHTML = '<div class="pk-wrap rv">' +
      '<div class="pk-bar-top">' + levelHtml() + '<span class="spacer"></span>' + scoreLine() + "</div>" +
      '<div class="pk-card rv-card"><div class="pk-meta" id="rv-meta"></div><div class="pk-q" id="rv-text"></div>' +
      '<div class="rv-status" id="rv-status"></div><div id="rv-under"></div></div>' +
      '<div class="pk-actions" id="rv-btns"></div></div>';
    paintTurn();
  }
  function renderHome() {
    var games = st.games || 0;
    body.innerHTML = '<div class="pk-wrap rv">' +
      '<div class="pk-card rv-intro"><div class="pk-row" style="gap:14px"><span class="rv-face">' + ic("bolt", 22) + '</span><div class="pk-grow"><div class="pk-strong">Play a game against the Rival</div>' +
      '<div class="pk-muted pk-small">Twenty tossups from your Setup. It buzzes a little earlier than you usually do, and it gets better as you do.</div></div></div>' +
      '<div class="pk-actions" style="margin-top:14px"><button type="button" class="btn btn-primary" id="rv-start">' + ic("play", 14) + 'Start a game<span class="pk-kbd">S</span></button>' + levelHtml() + "</div></div>" +
      '<div class="pk-tiles">' + tile(fmt(games), "Games") + tile(fmt(st.wins || 0), "Wins", "pk-good") + tile(games ? pct(st.wins || 0, games) + "<small>%</small>" : "–", "Won") + tile(st.best ? fmt(st.best) : "–", "Best score", "pk-gold") + "</div>" +
      (st.lastGame ? '<div class="pk-card"><h3>Last game</h3><div class="pk-row"><span class="pk-grow">You ' + st.lastGame.me + " · Rival " + st.lastGame.rival + "</span>" +
        '<span class="' + (st.lastGame.me > st.lastGame.rival ? "pk-good" : "pk-bad") + ' pk-strong">' + (st.lastGame.me > st.lastGame.rival ? "Won" : st.lastGame.me === st.lastGame.rival ? "Tied" : "Lost") + "</span></div></div>" : "") +
      "</div>";
    body.querySelector("#rv-start").onclick = startGame;
  }
  async function startGame() {
    game = { n: 0, me: 0, rival: 0, log: [] };
    if (!you) await learnYou();
    render();
    nextQ();
  }

  async function nextQ() {
    if (!game) return;
    if (game.n >= GAME_LEN) { endGame(); return; }
    var status = body && body.querySelector("#rv-status"); if (status) status.innerHTML = ctx.loadingBarHtml ? ctx.loadingBarHtml("Finding a tossup…") : "";
    await fill();
    var q = queue.shift();
    fill();
    if (!q) { if (status) status.textContent = "No tossups match your Setup."; return; }
    var text = readText(q);
    cur = { q: q, text: text, phase: "reading", rival: planRival(q, text.length), rivalOut: false, meOut: false, prompt: null, buzzAt: 0 };
    render();
    var el = body.querySelector("#rv-text");
    reader = Reader(el, text, {
      onTick: function (i) { if (cur && cur.phase === "reading" && !cur.rivalOut && i >= cur.rival.at) rivalBuzz(); },
      onEnd: function () { if (cur && cur.phase === "reading") { cur.phase = "window"; cur.windowEnd = Date.now() + 5000; paintTurn(); windowTick(); } },
    });
    reader.start();
  }
  // the question's over and nobody (else) buzzed: a few seconds to buzz, then the Rival takes it if it knew it
  function windowTick() {
    if (!cur || cur.phase !== "window") return;
    var left = cur.windowEnd - Date.now();
    var s = body && body.querySelector("#rv-status");
    if (s) s.innerHTML = '<span class="pk-muted">' + Math.max(0, Math.ceil(left / 1000)) + "s to buzz</span>";
    if (left <= 0) { if (!cur.rivalOut && cur.rival.right) { rivalBuzz(); } else finish(null); return; }
    setTimeout(windowTick, 200);
  }
  function rivalBuzz() {
    if (!cur || (cur.phase !== "reading" && cur.phase !== "window")) return;
    if (reader) reader.pause();
    cur.phase = "rival";
    ctx.playSound("buzz");
    paintTurn();
    setTimeout(function () {
      if (!cur || cur.phase !== "rival") return;
      var power = powerAt(cur.q) >= 0 && serverPos(cur.q, cur.text, reader.at()) <= powerAt(cur.q);
      if (cur.rival.right) {
        var pts = power ? 15 : 10;
        game.rival += pts; cur.rivalGot = pts;
        finish("rival");
      } else {
        game.rival -= 5; cur.rivalOut = true; cur.rivalNeg = true;
        ctx.playSound("incorrect");
        if (cur.meOut) { finish(null); return; }
        cur.phase = reader.at() >= cur.text.length ? "window" : "reading";
        paintTurn();
        if (cur.phase === "reading") reader.start(); else { cur.windowEnd = Date.now() + 5000; windowTick(); }
      }
    }, 1100);
  }
  function buzz() {
    if (!cur || cur.meOut || (cur.phase !== "reading" && cur.phase !== "window")) return;
    if (reader) reader.pause();
    cur.phase = "answering"; cur.buzzAt = reader.at();
    ctx.playSound("buzz");
    paintTurn();
  }
  async function submit(ans) {
    if (!cur || cur.phase !== "answering") return;
    cur.phase = "judging";
    var pos = serverPos(cur.q, cur.text, cur.buzzAt);
    var r = await judge(cur.q, ans, { buzzPosition: pos, previous: cur.prompt });
    if (!cur) return;
    if (r.status === "prompt" && cur.prompt == null && ans) { cur.prompt = ans; cur.promptAsk = (r.prompt && r.prompt.ask) || ""; cur.phase = "answering"; paintTurn(); return; }
    var right = r.status === "accept", p = powerAt(cur.q), power = right && p >= 0 && pos <= p;
    var pts = right ? (power ? 15 : 10) : (cur.buzzAt >= cur.text.length ? 0 : -5);
    game.me += pts; cur.mine = { ans: ans, right: right, power: power, pts: pts };
    record(cur.q, { answer: ans, buzzPosition: pos, session: sess, correct: right, power: power, points: pts, celerity: cur.text.length ? cur.buzzAt / cur.text.length : 1 });
    ctx.playSound(right ? (power ? "power" : "correct") : "incorrect");
    if (right) { finish("me"); return; }
    cur.meOut = true; cur.prompt = null;
    if (cur.rivalOut) { finish(null); return; }
    // the Rival can still take it: reading goes on
    cur.phase = reader.at() >= cur.text.length ? "window" : "reading";
    paintTurn();
    if (cur.phase === "reading") reader.start(); else { cur.windowEnd = Date.now() + 2500; windowTick(); }
  }
  function finish(winner) {
    if (!cur) return;
    if (reader) reader.showAll();
    cur.phase = "done"; cur.winner = winner;
    // the level follows who won the tossup (a dead one leaves it alone)
    if (winner === "me") st.level = Math.min(10, st.level + 1);
    else if (winner === "rival") st.level = Math.max(1, st.level - 2 / 3);
    save();
    game.n++; game.log.push({ id: cur.q.id, winner: winner });
    paintTurn();
  }
  function endGame() {
    var won = game.me > game.rival;
    st.games = (st.games || 0) + 1; if (won) st.wins = (st.wins || 0) + 1;
    st.best = Math.max(st.best || 0, game.me);
    st.lastGame = { me: game.me, rival: game.rival, at: Date.now() };
    save();
    game = null; cur = null; reader = null;
    render();
  }

  function paintTurn() {
    if (!body || !cur) return;
    var meta = body.querySelector("#rv-meta"), s = body.querySelector("#rv-status"), under = body.querySelector("#rv-under"), btns = body.querySelector("#rv-btns");
    if (!s) return;
    var top = body.querySelector(".pk-bar-top"); if (top) top.innerHTML = levelHtml() + '<span class="spacer"></span>' + scoreLine();
    meta.innerHTML = cur.phase === "done" ? dot(rootOf(cur.q)) + esc(String(cur.q.category_path || cur.q.category || "").replace(/ > /g, " › ")) + (cur.q.difficulty != null ? " · Diff " + cur.q.difficulty : "") + (cur.q.set_name ? " · " + esc(cur.q.set_name) : "") : "";
    var said = [];
    if (cur.rivalNeg) said.push('<span class="pk-bad">The Rival negged (−5).</span>');
    if (cur.mine && !cur.mine.right) said.push('<span class="pk-bad">You negged with “' + esc(cur.mine.ans || "no answer") + '”.</span>');
    if (cur.phase === "rival") s.innerHTML = '<span class="rv-buzzed">' + ic("bolt", 14) + "The Rival buzzed</span>";
    else if (cur.phase === "answering" || cur.phase === "judging") s.innerHTML = said.join(" ");
    else if (cur.phase === "done") {
      var v = cur.winner === "me" ? '<span class="pk-verdict ' + (cur.mine.power ? "pk-pw" : "pk-ok") + '">' + ic("check", 15) + (cur.mine.power ? "You powered it" : "You got it") + " (+" + cur.mine.pts + ")</span>"
        : cur.winner === "rival" ? '<span class="pk-verdict pk-no">' + ic("bolt", 15) + "The Rival got it (+" + cur.rivalGot + ")</span>"
        : '<span class="pk-verdict pk-muted">Nobody got it</span>';
      s.innerHTML = v + (said.length ? " " + said.join(" ") : "");
    } else s.innerHTML = said.join(" ") || '<span class="pk-muted">' + (cur.phase === "window" ? "" : "Listening…") + "</span>";
    if (cur.phase === "answering") {
      under.innerHTML = (cur.prompt != null ? '<div class="pk-prompt">Prompt' + (cur.promptAsk ? ": " + esc(cur.promptAsk) : "") + "</div>" : "") +
        '<div class="pk-input"><input id="rv-ans" autocomplete="off" spellcheck="false" placeholder="Your answer" aria-label="Your answer"><button type="button" class="btn btn-primary" id="rv-send">Answer</button></div>';
      var inp = under.querySelector("#rv-ans");
      inp.focus();
      inp.addEventListener("keydown", function (e) { if (e.key === "Enter") { e.preventDefault(); submit(inp.value.trim()); } e.stopPropagation(); });
      under.querySelector("#rv-send").onclick = function () { submit(inp.value.trim()); };
    } else if (cur.phase === "done") {
      under.innerHTML = '<div class="pk-answer"><span class="pk-muted">Answer </span>' + answerHtml(cur.q) + "</div>";
    } else if (cur.phase !== "judging") under.innerHTML = "";
    var last = game && game.n >= GAME_LEN;
    btns.innerHTML = cur.phase === "reading" || cur.phase === "window" ? (cur.meOut ? "" : '<button type="button" class="btn btn-go" id="rv-buzz">Buzz<span class="pk-kbd">Space</span></button>') + '<button type="button" class="btn btn-ghost" id="rv-quit">End game</button>'
      : cur.phase === "done" ? '<button type="button" class="btn btn-primary" id="rv-next">' + (last ? "See the result" : "Next") + '<span class="pk-kbd">N</span></button><button type="button" class="btn btn-ghost" id="rv-quit">End game</button>' : "";
    var b = btns.querySelector("#rv-buzz"); if (b) b.onclick = buzz;
    var n = btns.querySelector("#rv-next"); if (n) n.onclick = nextQ;
    var qu = btns.querySelector("#rv-quit"); if (qu) qu.onclick = function () { if (reader) reader.stop(); if (game && game.n) endGame(); else { game = null; cur = null; render(); } };
  }

  function active() { return page && page.screenEl && page.screenEl.classList.contains("active"); }
  function onKey(e) {
    if (!active() || inField(e) || e.metaKey || e.ctrlKey || e.altKey) return;
    if (e.key === " " && cur && (cur.phase === "reading" || cur.phase === "window")) { e.preventDefault(); buzz(); }
    else if ((e.key === "n" || e.key === "N") && cur && cur.phase === "done") { e.preventDefault(); nextQ(); }
    else if ((e.key === "s" || e.key === "S") && !game) { e.preventDefault(); startGame(); }
  }
  document.addEventListener("keydown", onKey);
  ctx._cleanup = function () { document.removeEventListener("keydown", onKey); if (reader) reader.stop(); };

  page = ctx.registerPage({
    id: "rival", navLabel: "Rival", title: "Rival",
    onShow: function (el, info) {
      body = el;
      if (body.querySelector(".rv") && game) { if (cur && cur.phase === "reading" && reader) reader.start(); return; }   // back to a game in play
      you = null; learnYou(); render();
    },
    onHide: function () { if (reader && cur && cur.phase === "reading") reader.pause(); },
  });

}
