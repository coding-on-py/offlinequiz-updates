/**
 * OfflineQuiz plugin: Rival
 *
 * An opponent that learns from you. It buzzes a little before your usual buzz point in each
 * category, moves up a level when you beat it to a tossup and down when it beats you, so every
 * game is close and pushes you to buzz earlier.
 */
QB.registerPlugin({
  id: "rival",
  name: "Rival",
  version: "3.0.2",
  author: "OfflineQuiz",
  description: "Play tossups in a room against an opponent that buzzes a little earlier than you, types its answers, and gets better as you do.",
  onEnable: __qbMain,
  onDisable: function (ctx) { if (ctx._cleanup) ctx._cleanup(); },
});
