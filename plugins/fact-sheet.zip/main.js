/**
 * OfflineQuiz plugin: Fact Sheet
 *
 * A study sheet for any answer: the phrases its questions keep using, each with
 * a real sentence, how many questions use it, where in the question it comes,
 * and how often it points to that answer anywhere in the database.
 */
QB.registerPlugin({
  id: "fact-sheet",
  name: "Fact Sheet",
  version: "1.15.0",
  author: "OfflineQuiz",
  description: "A study sheet of the clues that keep coming up for an answer.",
  onEnable: __qbMain,
});
