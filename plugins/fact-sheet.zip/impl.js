function __qbMain(ctx) {
  // The Review-as-flashcards button follows Flashcards being turned on/off while
  // this tab stays on screen (Back revives the Database without re-rendering it).
  function hasFc() { try { return !(window.QB && QB.getActivePages) || (QB.getActivePages() || []).some(function (p) { return p.id === "flashcards::cards"; }); } catch (e) { return true; } }
  if (ctx.on) ctx.on("plugins:changed", function () {
    var b = document.getElementById("fs-review"); if (!b) return;
    var ok = hasFc(); b.disabled = !ok;
    if (ok) b.removeAttribute("title"); else b.title = "Needs Flashcards plugin";
  });
  var body = null, page = null;

  function esc(s) { return (s == null ? "" : String(s)).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
  function loadBar(label) { return (window.QB && QB.loadingBarHtml) ? QB.loadingBarHtml(label) : '<div class="text-muted">' + esc(label) + "</div>"; }
  function mainAnswer(sani) { return decodeEnt(sani).split(/[\[(<]/)[0].trim().replace(/[;:,.]+$/, ""); }

  var STOP = {};
  ("a an the of in on at to for from with within without by as is are was were be been being am do does did done not no nor so or and but if then than because while during after before until once when where which who whom whose what why how all any both each few more most other some such only own same here there over under again further about above below between into through against up down out off very can will just should now points point name names named ftp identify gives give given made make makes making one two first second third often called also another may might must many much works worked title titled known includes including include described describes describe used uses use using like unlike along later earlier begins ends opens work whose").split(/\s+/).forEach(function (w) { STOP[w] = 1; });
  // Referent/pronoun words poison a "fact" no matter where they appear —
  // "form of this technique" tells you nothing. Blocked at EVERY position.
  var PRON = {};
  ("this these that those it its his her hers their theirs they them he she him you your one ones man woman author composer poet character work entity thing figure title titular").split(/\s+/).forEach(function (w) { PRON[w] = 1; });

  function splitSentencesWithPos(text) {
    // sentences plus their fractional start position within the question
    var clean = (text || "").replace(/\(\*\)/g, "");
    var total = clean.length || 1;
    var out = [], re = /(?<=[.!?…]["”’']?)\s+(?=["“‘']?[A-Z0-9(])/g, last = 0, m;
    while ((m = re.exec(clean))) {
      out.push({ s: clean.slice(last, m.index).trim(), pos: last / total });
      last = m.index + m[0].length;
    }
    if (last < clean.length) out.push({ s: clean.slice(last).trim(), pos: last / total });
    return out.filter(function (e) { return e.s; });
  }
  function toks(s) {
    return (s.toLowerCase().match(/[\p{L}\p{N}'’-]+/gu) || []).map(function (w) { return w.replace(/['’]s$/, ""); });
  }
  function gramsOfSent(words, skip) {
    var out = [];
    for (var i = 0; i < words.length; i++) {
      for (var L = 2; L <= 5; L++) {
        if (i + L > words.length) break;
        var g = words.slice(i, i + L);
        if (STOP[g[0]] || STOP[g[L - 1]]) continue;
        var bad = false;
        for (var k = 0; k < L; k++) if (PRON[g[k]] || skip[g[k]] || /^\d+$/.test(g[k]) || g[k].length < 2) { bad = true; break; }
        if (bad) continue;
        out.push(g.join(" "));
      }
    }
    return out;
  }

  // ── search log ────────────────────────────────────────────────────────
  // Absolute per-answer totals (never increments), so anything that reads this
  // — the Class Sync plugin included — can be re-sent safely without a
  // duplicate delivery double-counting. Purely local unless you install a
  // plugin that uploads it.
  function searchLog() { return ctx.storage.get("fs-searches") || {}; }
  function logSearch(term) {
    var key = String(term).trim().toLowerCase();
    if (!key) return;
    var log = searchLog();
    var e = log[key] || { term: String(term).trim(), count: 0, first: Date.now(), last: 0 };
    e.count++;
    e.last = Date.now();
    log[key] = e;
    ctx.storage.set("fs-searches", log);
  }
  // Read-only accessor other plugins can use without knowing the storage key.
  window.QBFactSheet = {
    searches: function () {
      var log = searchLog();
      return Object.keys(log).map(function (k) {
        return { term: log[k].term || k, count: log[k].count || 0, first: log[k].first || 0, last: log[k].last || 0 };
      }).sort(function (a, b) { return b.count - a.count; });
    },
    starredFacts: function () { return starred(); },
  };
  ctx._unsub.push(function () { try { delete window.QBFactSheet; } catch (e) {} });

  // ── stars + review/folder integration ──
  function starred() { return ctx.storage.get("fs-stars") || []; }
  function starKey(it) { return (it.front || "") + "|" + (it.back || ""); }
  function isStarred(it) { var k = starKey(it); return starred().some(function (x) { return starKey(x) === k; }); }
  function toggleStar(it, el) {
    var lst = starred(), k = starKey(it), i = lst.findIndex(function (x) { return starKey(x) === k; });
    if (i >= 0) lst.splice(i, 1); else lst.push(it);
    ctx.storage.set("fs-stars", lst);
    if (ctx.playSound) ctx.playSound("star");
    if (el) { var on = i < 0; el.textContent = on ? "★" : "☆"; el.classList.toggle("on", on); }
  }
  function addToMenu(it, anchor) {
    var spec = { review: { kind: "fact", front: it.front, back: it.back, meta: "fact sheet" }, folder: { type: "facts", item: { front: it.front, back: it.back } } };
    if (ctx.host && ctx.host.openItemSaveMenu) ctx.host.openItemSaveMenu(spec, anchor);
    else if (window.QBFolders) window.QBFolders.pick("facts", spec.folder.item, anchor);
  }
  // Register a "Facts" folder type when the Folders plugin is around (now or later).
  var _foldersUnreg = null;
  function tryRegisterFolderType() {
    if (_foldersUnreg || !window.QBFolders || !window.QBFolders.registerType) return;
    _foldersUnreg = window.QBFolders.registerType({ key: "facts", label: "Facts", item: "fact", run: ["flashcards"] });
  }
  tryRegisterFolderType();
  ctx.on("plugins:changed", tryRegisterFolderType);
  ctx._unsub.push(function () { if (_foldersUnreg) { try { _foldersUnreg(); } catch (e) {} _foldersUnreg = null; } });

  // ── question text ─────────────────────────────────────────────────────
  // Words are counted from what a question SAYS to players: the host's
  // reading text (ctx.host.questionText) when the base has it, else the plain
  // copy. Moderator / reader notes and pronunciation guides are then removed
  // whatever the reading settings say: they are never clue words.
  var NOTE_LBL = /(?:note to (?:the )?(?:moderators?|readers?)\b|reader(?:'s)? note\b|moderator(?:'s)? note\b)/i;
  var NOTE_LBL_G = /(?:note to (?:the )?(?:moderators?|readers?)\b|reader(?:'s)? note\b|moderator(?:'s)? note\b)\s*(?:#\s*\d+\s*)?(?:,[^:]{0,40})?:\s*/gi;
  var NOTE_RUN = /^\s*[\[(<*]*\s*(?:note to (?:the )?(?:moderators?|readers?)\b|reader(?:'s)? note\b|moderator(?:'s)? note\b)/i;
  var ENT = { amp: "&", lt: "<", gt: ">", quot: '"', apos: "'", nbsp: "\u00a0" };
  function decodeEnt(s) {
    return String(s || "").replace(/&(#x[0-9a-f]+|#\d+|[a-z]+);/gi, function (m, e) {
      if (e[0] === "#") { try { return String.fromCodePoint(e[1] === "x" || e[1] === "X" ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10)); } catch (x) { return m; } }
      var v = ENT[e.toLowerCase()]; return v == null ? m : v;
    });
  }
  // A note is the italic run of the HTML field that STARTS with its label.
  function noteRuns(html) {
    if (!html || html.indexOf("<") < 0) return [];
    var runs = [], it = 0, last = 0, m, re = /<\/?([a-z]+)[^>]*>/gi;
    function push(t) { if (!t) return; var p = runs[runs.length - 1], ital = it > 0; if (p && p.italic === ital) p.text += t; else runs.push({ text: t, italic: ital }); }
    while ((m = re.exec(html))) {
      push(decodeEnt(html.slice(last, m.index)));
      var tag = m[1].toLowerCase();
      if (tag === "i" || tag === "em") it = Math.max(0, it + (m[0][1] === "/" ? -1 : 1));
      last = re.lastIndex;
    }
    push(decodeEnt(html.slice(last)));
    return runs.filter(function (r) { return r.italic && NOTE_RUN.test(r.text); }).map(function (r) { return r.text.trim(); });
  }
  // The plain copy folds accents, straightens quotes and spells out dashes.
  function foldPlain(s) {
    return String(s || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "")
      .replace(/[“”]/g, '"').replace(/[‘’]/g, "'").replace(/[–—]/g, "-").replace(/…/g, "...").replace(/\u00a0/g, " ");
  }
  function cutSpan(t, i, j) { return t.slice(0, i).replace(/\s+$/, "") + (i > 0 && j < t.length ? " " : "") + t.slice(j).replace(/^\s+/, ""); }
  function stripNotes(t, html) {
    if (!NOTE_LBL.test(t)) return t;
    noteRuns(html).forEach(function (note) {
      var cands = [foldPlain(note), note];
      for (var c = 0; c < cands.length; c++) { var i = t.indexOf(cands[c]); if (i >= 0) { t = cutSpan(t, i, i + cands[c].length); break; } }
    });
    if (!NOTE_LBL.test(t)) return t;
    t = t.replace(/\s*[\[(]\s*(?:notes?\s+to\s+(?:the\s+)?(?:moderators?|readers?)|(?:moderators?|readers?)(?:'s)?\s+notes?)\b[^\])]*[\])]/gi, " ");
    // An unformatted "Label: …" has no marked end: cut through its first
    // sentence, or to where the question visibly restarts (a lowercase word,
    // then a capitalised one, outside quotes).
    var m, guard = 0;
    NOTE_LBL_G.lastIndex = 0;
    while ((m = NOTE_LBL_G.exec(t)) && guard++ < 6) {
      var s = m.index, from = s + m[0].length, rest = t.slice(from, from + 300), b = -1;
      var w = rest.match(/^\S+\s+/), re = /[.!?]+["'”’)]*\s+|[a-z0-9"'”’)]\s+(?=[A-Z](?:[a-z'’]|\s))/g, mm;
      re.lastIndex = w ? w[0].length : 0;
      while ((mm = re.exec(rest))) {
        var stop = /^[.!?]/.test(mm[0]);
        if (!stop && ((rest.slice(0, mm.index + 1).match(/"/g) || []).length % 2)) continue;
        b = stop ? mm.index + mm[0].length : mm.index + 1; break;
      }
      while (s > 0 && /[\s*<\[(]/.test(t[s - 1])) s--;
      t = cutSpan(t, s, b >= 0 ? from + b : from);
      NOTE_LBL_G.lastIndex = s;
    }
    return t;
  }
  function stripGuides(t) {
    if (ctx.host && typeof ctx.host.stripPronunciations === "function") { try { t = ctx.host.stripPronunciations(t); } catch (e) {} }
    return String(t || "").replace(/\s*\(\s*["“][^"”()]*["”]\s*\)/g, "");
  }
  var _qtCache = typeof WeakMap === "function" ? new WeakMap() : null;
  function qText(q) {
    if (!q) return "";
    if (_qtCache && _qtCache.has(q)) return _qtCache.get(q);
    var t = null;
    if (ctx.host && typeof ctx.host.questionText === "function") { try { t = ctx.host.questionText(q, "question"); } catch (e) { t = null; } }
    if (typeof t !== "string") t = q.question_sanitized || "";
    t = stripGuides(stripNotes(decodeEnt(t), q.question)).replace(/\s{2,}/g, " ").trim();
    if (_qtCache) _qtCache.set(q, t);
    return t;
  }

  // ── category picker ──────────────────────────────────────────────────
  // Current base: the app's own selector (ctx.host.categoryPicker) — several
  // whole-subtree node ids, sent as categoryIds=a,b. Older base without it:
  // the cascade below (level 1 → 2 → 3 selects, then a 4th listing every
  // deeper node under the level-3 pick as an "A > B" relative path; the
  // DEEPEST pick is the filter, sent as categories=<id>).
  var _catPicker = null;
  function hasCatPicker() { return !!(ctx.host && typeof ctx.host.categoryPicker === "function"); }
  var CAT_ALL = ["All categories", "All subcategories", "All topics", "All subtopics"];
  var _catTree = null;   // { roots, byId } once loaded
  function loadCatTree() {
    var p = (ctx.host && typeof ctx.host.getCategoryTree === "function")
      ? Promise.resolve().then(function () { return ctx.host.getCategoryTree("tossups"); })
      : ctx.api.get("/api/category-tree?type=tossups").then(function (d) { return (d && d.tree) || []; });
    return p.then(function (roots) {
      var byId = Object.create(null);
      (function walk(list) { (list || []).forEach(function (n) { byId[n.id] = n; walk(n.children); }); })(roots);
      _catTree = { roots: roots || [], byId: byId };
      return _catTree;
    });
  }
  function fillCatSel(sel, level, items) {
    if (!sel) return;
    sel.innerHTML = '<option value="">' + CAT_ALL[level] + "</option>";
    items.forEach(function (it) { var o = document.createElement("option"); o.value = it.id; o.textContent = it.label; sel.appendChild(o); });
    sel.disabled = level > 0 && !items.length;
  }
  function wireCatCascade(sels) {
    function kids(sel) { var n = _catTree && sel && sel.value ? _catTree.byId[sel.value] : null; return n ? n.children || [] : []; }
    function named(list) { return list.map(function (n) { return { id: n.id, label: n.name }; }); }
    function deep() {
      var out = [];
      (function walk(list, prefix) {
        list.forEach(function (c) { var lab = prefix ? prefix + " > " + c.name : c.name; out.push({ id: c.id, label: lab }); walk(c.children || [], lab); });
      })(kids(sels[2]), "");
      return out;
    }
    for (var i = 1; i < sels.length; i++) fillCatSel(sels[i], i, []);
    sels[0].addEventListener("change", function () { fillCatSel(sels[1], 1, named(kids(sels[0]))); fillCatSel(sels[2], 2, []); fillCatSel(sels[3], 3, []); });
    sels[1].addEventListener("change", function () { fillCatSel(sels[2], 2, named(kids(sels[1]))); fillCatSel(sels[3], 3, []); });
    sels[2].addEventListener("change", function () { fillCatSel(sels[3], 3, deep()); });
    return loadCatTree().then(function (t) {
      if (!t.roots.length) throw new Error("no tree");
      fillCatSel(sels[0], 0, named(t.roots));
    }).catch(function () {
      // Older base without the tree: level-1 names (the server accepts them).
      return ctx.api.get("/api/categories?type=tossups").then(function (d) {
        fillCatSel(sels[0], 0, ((d && d.categories) || []).map(function (c) { return { id: c.category, label: c.category }; }));
      }).catch(function () {});
    });
  }
  function catPick(sels) {
    for (var i = sels.length - 1; i >= 0; i--) { var s = sels[i]; if (s && !s.disabled && s.value) return s.value; }
    return "";
  }
  function cascadeHtml() {
    return ["fs-cat", "fs-sub", "fs-alt", "fs-deep"].map(function (id, i) {
      return '<select id="' + id + '" class="mode-input" style="flex:1;min-width:130px"' + (i ? " disabled" : "") + '><option value="">' + CAT_ALL[i] + "</option></select>";
    }).join("");
  }
  function catSels() { return ["#fs-cat", "#fs-sub", "#fs-alt", "#fs-deep"].map(function (id) { return body.querySelector(id); }); }
  function catQs() {
    if (_catPicker) {
      var ids = [];
      try { ids = (_catPicker.get() || []).filter(Boolean); } catch (e) { ids = []; }
      return ids.length ? "&categoryIds=" + encodeURIComponent(ids.join(",")) : "";
    }
    var cat = catPick(catSels());
    return cat ? "&categories=" + encodeURIComponent(cat) : "";
  }
  function filterQs() {
    var diffs = [].slice.call(body.querySelectorAll(".fs-diff-cb:checked")).map(function (c) { return c.value; });
    var ya = parseInt(body.querySelector("#fs-ymin").value), yb = parseInt(body.querySelector("#fs-ymax").value);
    var ymin = Math.min(ya, yb), ymax = Math.max(ya, yb);
    return catQs() +
      (diffs.length ? "&difficulties=" + diffs.join(",") : "") +
      (ymin > 2000 ? "&yearMin=" + ymin : "") + (ymax < 2026 ? "&yearMax=" + ymax : "");
  }
  function posRange() {
    var a = parseInt(body.querySelector("#fs-plo").value), b = parseInt(body.querySelector("#fs-phi").value);
    return { lo: Math.min(a, b) / 100, hi: Math.max(a, b) / 100 };
  }
  function wireDual(loId, hiId, fillId, valId, fmt) {
    var lo = body.querySelector("#" + loId), hi = body.querySelector("#" + hiId), fill = body.querySelector("#" + fillId), val = body.querySelector("#" + valId);
    function sync() {
      var a = Math.min(parseInt(lo.value), parseInt(hi.value)), b = Math.max(parseInt(lo.value), parseInt(hi.value));
      var min = parseInt(lo.min), max = parseInt(lo.max);
      if (fill) { fill.style.left = ((a - min) / (max - min)) * 100 + "%"; fill.style.right = ((max - b) / (max - min)) * 100 + "%"; }
      if (val) val.textContent = fmt(a, b);
    }
    lo.addEventListener("input", sync); hi.addEventListener("input", sync); sync();
  }

  // P(answer | fact): of all questions containing the phrase (same
  // category/difficulty/year filters), how many are answered by the term?
  // Computed lazily per rendered card, cached.
  var _probCache = Object.create(null), _probGen = 0;
  function factProb(gram, targetTokens, filters, cb) {
    var key = gram + "|" + targetTokens.join(" ") + "|" + filters;
    if (_probCache[key]) { cb(_probCache[key]); return; }
    var quoted = gram.split(" ").map(function (t) { return '"' + t + '"'; }).join(" ");
    ctx.api.get("/api/tossups/search?query=" + encodeURIComponent("question_sanitized : (" + quoted + ")") + "&limit=400" + filters).then(function (d) {
      var rs = (d && d.rows) || [];
      var total = 0, hit = 0;
      var seq = gram.split(" ");
      rs.forEach(function (q) {
        var ws = toks(qText(q).replace(/\(\*\)/g, " "));
        var found = false;
        for (var i = 0; i + seq.length <= ws.length; i++) {
          var ok = true;
          for (var j = 0; j < seq.length; j++) if (ws[i + j] !== seq[j]) { ok = false; break; }
          if (ok) { found = true; break; }
        }
        if (!found) return;
        total++;
        var al = (q.answer_sanitized || "").toLowerCase();
        var match = true;
        for (var k = 0; k < targetTokens.length; k++) if (al.indexOf(targetTokens[k]) < 0) { match = false; break; }
        if (match) hit++;
      });
      var r = { p: total ? hit / total : 0, hit: hit, total: total };
      _probCache[key] = r;
      cb(r);
    }).catch(function () { cb(null); });
  }
  function minProb() { var s = body && body.querySelector("#fs-minp"); return s ? (parseInt(s.value, 10) || 0) / 100 : 0; }
  function applyProbThreshold(out) {
    var thr = minProb();
    var hidden = 0, resolved = 0;
    out.querySelectorAll(".fs-card").forEach(function (card) {
      var cell = card.querySelector(".fs-prob");
      var has = cell && cell.dataset.p != null;
      if (has) resolved++;
      var hide = thr > 0 && has && parseFloat(cell.dataset.p) < thr;
      card.style.display = hide ? "none" : "";
      if (hide) hidden++;
    });
    var note = out.querySelector(".fs-thr-note");
    if (thr > 0 && hidden) {
      if (!note) { note = document.createElement("div"); note.className = "fs-meta fs-thr-note"; var meta = out.querySelector(".fs-meta"); if (meta) meta.after(note); else out.prepend(note); }
      note.textContent = hidden + " fact" + (hidden === 1 ? "" : "s") + " below the → answer threshold hidden";
    } else if (note) note.remove();
  }
  function fillFactProbs(out, targetTokens, filters) {
    var gen = ++_probGen;
    var cells = [].slice.call(out.querySelectorAll(".fs-prob[data-g]"));
    var idx = 0, workers = 0;
    function next() {
      if (gen !== _probGen) return;
      while (workers < 4 && idx < cells.length) {
        (function (cell) {
          workers++;
          factProb(cell.dataset.g, targetTokens, filters, function (r) {
            workers--;
            if (gen === _probGen && cell.isConnected) {
              cell.textContent = r && r.total ? "→ answer " + Math.round(100 * r.p) + "% (" + r.hit + "/" + r.total + ")" : "→ answer –";
              cell.dataset.p = r && r.total ? r.p : 0;
              if (r && r.total && r.p >= 0.8) cell.classList.add("fs-prob-hi");
              applyProbThreshold(out);
            }
            next();
          });
        })(cells[idx++]);
      }
    }
    next();
  }

  var _gen = 0;
  // opts.rerun: a filter changed under shown results — refresh them without
  // counting another search in the log. (As a click handler it gets an Event.)
  async function compile(opts) {
    var rerun = !!(opts && opts.rerun === true);
    var gen = ++_gen;
    var term = (body.querySelector("#fs-input").value || "").trim();
    var out = body.querySelector("#fs-results");
    var topN = parseInt(body.querySelector("#fs-top").value) || 15;
    if (!term) { out.innerHTML = '<div class="text-muted">Type an answer first.</div>'; return; }
    if (!rerun) logSearch(term);
    out.innerHTML = loadBar("Reading every “" + esc(term) + "” question…");

    var tokens = toks(term);
    if (!tokens.length) { out.innerHTML = '<div class="text-muted">Nothing searchable in that.</div>'; return; }
    var quoted = tokens.map(function (t) { return '"' + t + '"'; }).join(" ");
    var rows = [];
    try { rows = (await ctx.api.get("/api/tossups/search?query=" + encodeURIComponent("answer_sanitized : (" + quoted + ")") + "&limit=500" + filterQs())).rows || []; }
    catch (e) { if (gen === _gen) out.innerHTML = '<div class="text-muted">Search failed: ' + esc(e.message || e) + "</div>"; return; }
    if (gen !== _gen) return;
    var qs = rows.filter(function (q) {
      var al = mainAnswer(q.answer_sanitized).toLowerCase();
      for (var i = 0; i < tokens.length; i++) if (al.indexOf(tokens[i]) < 0) return false;
      return true;
    });
    if (!qs.length) { out.innerHTML = '<div class="text-muted">No questions for “' + esc(term) + '”.</div>'; return; }

    var pr = posRange();
    var pwEl = body.querySelector("#fs-power");
    var powerOnly = !!(pwEl && pwEl.checked);
    var skip = {};
    tokens.forEach(function (t) { skip[t] = 1; });
    var facts = Object.create(null); // gram -> {docs, posSum, posN, best, bestLen}
    var skippedUnmarked = 0;
    qs.forEach(function (q) {
      var seen = {};
      var raw = qText(q);
      var powerFrac = -1;
      if (powerOnly) {
        // "Before power": only sentences starting before the (*) count;
        // unmarked questions are excluded entirely.
        var pi = raw.indexOf("(*)");
        if (pi < 0) { skippedUnmarked++; return; }
        var cleanLen = raw.replace(/\(\*\)/g, "").length || 1;
        powerFrac = raw.slice(0, pi).replace(/\(\*\)/g, "").length / cleanLen;
      }
      splitSentencesWithPos(raw).forEach(function (se) {
        if (powerOnly) { if (se.pos > powerFrac) return; }
        else if (se.pos < pr.lo || se.pos > pr.hi) return; // position filter
        var ws = toks(se.s);
        gramsOfSent(ws, skip).forEach(function (g) {
          var f = facts[g];
          if (!f) f = facts[g] = { docs: 0, posSum: 0, posN: 0, best: "", bestLen: 1e9 };
          f.posSum += se.pos; f.posN++;
          if (!seen[g]) { seen[g] = 1; f.docs++; }
          var sl = se.s.length;
          if (sl >= 40 && sl < f.bestLen) { f.best = se.s; f.bestLen = sl; }
          else if (!f.best) { f.best = se.s; f.bestLen = sl; }
        });
      });
    });
    var list = Object.keys(facts).map(function (g) { return { g: g, docs: facts[g].docs, avgPos: facts[g].posN ? facts[g].posSum / facts[g].posN : 0, best: facts[g].best, len: g.split(" ").length }; })
      .filter(function (e) { return e.docs >= 2; })
      .sort(function (a, b) { return b.docs - a.docs || b.len - a.len; });
    var head = list.slice(0, Math.max(topN * 6, 240)), drop = {};
    head.forEach(function (e) {
      head.forEach(function (o) {
        if (o === e || o.len <= e.len) return;
        if (o.g.indexOf(e.g) >= 0 && o.docs >= 0.8 * e.docs) drop[e.g] = 1;
      });
    });
    var kept = head.filter(function (e) { return !drop[e.g]; }).slice(0, topN);
    if (gen !== _gen) return;
    if (!kept.length) { out.innerHTML = '<div class="text-muted">No recurring facts.</div>'; return; }

    out.innerHTML =
      kept.map(function (e, i) {
        var hi = e.best;
        try { hi = esc(e.best).replace(new RegExp("(" + e.g.split(" ").map(function (w) { return w.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"); }).join("[\\s,;'’-]+") + ")", "i"), "<mark>$1</mark>"); } catch (err) { hi = esc(e.best); }
        var st = isStarred({ front: e.g, back: term });
        return '<div class="fs-card" data-g="' + esc(e.g) + '">' +
          '<div class="fs-card-head"><span class="fs-rank">' + (i + 1) + '</span><strong class="fs-gram">' + esc(e.g) + "</strong>" +
          '<span class="fs-avgpos" title="Average position of this fact within the question — earlier = harder clue">avg at ' + Math.round(100 * e.avgPos) + "%</span>" +
          '<span class="fs-prob" data-g="' + esc(e.g) + '" title="Of ALL questions containing this phrase (same filters), how many are answered by this term">…</span>' +
          '<span class="fs-badge">' + Math.round(100 * e.docs / qs.length) + "% · " + e.docs + "/" + qs.length + " questions</span>" +
          '<span class="fs-act fs-star' + (st ? " on" : "") + '" title="Star this fact (saved under Database → Facts)">' + (st ? "★" : "☆") + "</span>" +
          '<span class="fs-act fs-foldx" title="Add to review / folder">+</span></div>' +
          (e.best ? '<div class="fs-example">' + hi + "</div>" : "") +
          "</div>";
      }).join("");

    fillFactProbs(out, tokens, filterQs());
    out.querySelectorAll(".fs-card").forEach(function (card) {
      var g = card.dataset.g;
      var it = { front: g, back: term };
      var st = card.querySelector(".fs-star");
      if (st) st.onclick = function (ev) { ev.stopPropagation(); toggleStar(it, st); };
      var fx = card.querySelector(".fs-foldx");
      if (fx) fx.onclick = function (ev) { ev.stopPropagation(); addToMenu(it, fx); };
      card.oncontextmenu = function (ev) {
        if (!window.QB || !QB.contextMenu) return;
        ev.preventDefault();
        var items = [];
        if (ctx.host && ctx.host.searchDatabase) items.push({ label: "Find questions containing this fact", onClick: function () { ctx.host.searchDatabase({ query: g, field: "question", exact: true, qtype: "tossup" }); } });
        items.push({ label: "Copy fact", onClick: function () { try { navigator.clipboard.writeText(g + " → " + term); QB.toast("Copied"); } catch (e2) {} } });
        items.push({ sep: true });
        items.push({ label: isStarred(it) ? "Unstar fact" : "Star fact", onClick: function () { toggleStar(it, st); } });
        items.push({ label: "Add to review / folder…", onClick: function () { addToMenu(it, card); } });
        QB.contextMenu(ev.clientX, ev.clientY, items, { title: g + " → " + term });
      };
      card.onclick = function () {
        if (ctx.host && ctx.host.searchDatabase) ctx.host.searchDatabase({ query: g, field: "question", exact: true, qtype: "tossup" });
      };
    });
  }

  async function render() {
    var diffBoxes = "";
    for (var d = 0; d <= 10; d++) diffBoxes += '<label class="fs-diff"><input type="checkbox" class="fs-diff-cb" value="' + d + '">' + d + "</label>";
    var usePicker = hasCatPicker();
    var catRow = usePicker
      ? '<div class="fs-row"><button type="button" id="fs-cat-btn" class="btn cat-launch"></button></div>'
      : '<div class="fs-row">' + cascadeHtml() + "</div>";
    body.innerHTML =
      '<div class="fs-wrap">' +
        '<div class="fs-card-panel">' +
          '<div class="fs-row">' +
            '<input type="text" id="fs-input" class="mode-input" placeholder="Answer to study…" autocomplete="off" autocorrect="off" spellcheck="false" style="flex:1;min-width:200px">' +
            '<select id="fs-top" class="mode-input" style="width:110px"><option value="10">Top 10</option><option value="15" selected>Top 15</option><option value="25">Top 25</option><option value="40">Top 40</option></select>' +
            '<select id="fs-minp" class="mode-input" style="width:150px" title="Only show facts whose → answer probability is at least this"><option value="0">Any → answer %</option><option value="50">→ answer ≥ 50%</option><option value="60">→ answer ≥ 60%</option><option value="70">→ answer ≥ 70%</option><option value="80">→ answer ≥ 80%</option><option value="90">→ answer ≥ 90%</option></select>' +
            '<button class="btn btn-primary" id="fs-go">Compile facts</button>' +
          "</div>" +
          catRow +
          '<div class="fs-row"><span class="fs-label">Difficulty</span>' + diffBoxes + "</div>" +
          '<div class="fs-row"><span class="fs-label">Years</span>' +
            '<div class="dual-range fs-dual"><div class="dual-range-track"><div class="dual-range-fill" id="fs-yfill"></div></div>' +
              '<input type="range" id="fs-ymin" min="2000" max="2026" value="2000"><input type="range" id="fs-ymax" min="2000" max="2026" value="2026"></div>' +
            '<span class="fs-label" id="fs-yval" style="min-width:84px;text-align:right"></span>' +
          "</div>" +
          '<div class="fs-row"><span class="fs-label">Position</span>' +
            '<div class="dual-range fs-dual"><div class="dual-range-track"><div class="dual-range-fill" id="fs-pfill"></div></div>' +
              '<input type="range" id="fs-plo" min="0" max="100" step="5" value="0"><input type="range" id="fs-phi" min="0" max="100" step="5" value="100"></div>' +
            '<span class="fs-label" id="fs-pval" style="min-width:84px;text-align:right"></span>' +
            '<label class="fs-diff" style="margin-left:8px" title="Only sentences BEFORE the (*) powermark count; questions without a powermark are skipped. Disables the position range."><input type="checkbox" id="fs-power"> Before power only</label>' +
          "</div>" +
        "</div>" +
        '<div id="fs-results"></div>' +
      "</div>";
    body.querySelector("#fs-go").onclick = compile;
    body.querySelector("#fs-input").addEventListener("keydown", function (e) { if (e.key === "Enter") compile(); });
    body.querySelector("#fs-minp").addEventListener("change", function () { var out = body.querySelector("#fs-results"); if (out) applyProbThreshold(out); });
    _catPicker = null;
    if (usePicker) {
      try {
        _catPicker = ctx.host.categoryPicker(body.querySelector("#fs-cat-btn"), {
          type: "tossups",
          selected: [],
          onChange: function () {
            // Shown results follow the new picks; otherwise they apply on the next compile.
            var inp = body && body.querySelector("#fs-input"), out = body && body.querySelector("#fs-results");
            if (inp && (inp.value || "").trim() && out && out.childNodes.length) compile({ rerun: true });
          },
        });
      } catch (e) { _catPicker = null; }
    }
    if (!_catPicker) {
      // Older base (or the picker failed): the cascade.
      if (usePicker) {
        var row = body.querySelector("#fs-cat-btn"); row = row && row.parentNode;
        if (row) row.innerHTML = cascadeHtml();
      }
      wireCatCascade(catSels());
    }
    wireDual("fs-ymin", "fs-ymax", "fs-yfill", "fs-yval", function (a, b) { return a + " – " + b; });
    wireDual("fs-plo", "fs-phi", "fs-pfill", "fs-pval", function (a, b) { return a + "% – " + b + "%"; });
    var pw = body.querySelector("#fs-power");
    if (pw) pw.onchange = function () {
      ["fs-plo", "fs-phi"].forEach(function (id) { var el = body.querySelector("#" + id); if (el) el.disabled = pw.checked; });
      var fill = body.querySelector("#fs-pfill"); if (fill && fill.closest(".dual-range")) fill.closest(".dual-range").style.opacity = pw.checked ? "0.35" : "";
      var pv = body.querySelector("#fs-pval");
      if (pv) { if (pw.checked) pv.textContent = "before (*)"; else { var a = Math.min(parseInt(body.querySelector("#fs-plo").value), parseInt(body.querySelector("#fs-phi").value)), b = Math.max(parseInt(body.querySelector("#fs-plo").value), parseInt(body.querySelector("#fs-phi").value)); pv.textContent = a + "% – " + b + "%"; } }
    };
  }

  // ── Database tab: saved facts ──
  ctx.registerStarredProvider({
    id: "fact-sheet", title: "Facts",
    render: function (container) {
      var list = starred();
      if (!list.length) { container.innerHTML = '<div class="text-muted" style="padding:16px">No saved facts yet.</div>'; return; }
      var fcOk = true;
      try { if (window.QB && window.QB.getActivePages) fcOk = (window.QB.getActivePages() || []).some(function (p) { return p.id === "flashcards::cards"; }); } catch (e) {}
      var bar = '<div class="db-toolbar"><button class="btn btn-sm btn-primary" id="fs-review"' + (fcOk ? "" : ' disabled title="Needs Flashcards plugin"') + '>▶ Review as flashcards</button>' +
        '<span class="text-muted" style="font-size:11px">' + list.length + " saved</span></div>";
      container.innerHTML = bar + '<table class="stats-table"><thead><tr><th></th><th>Fact</th><th>Answer</th></tr></thead><tbody>' +
        list.map(function (it, i) {
          return '<tr><td style="white-space:nowrap"><span class="fs-act fs-star on" data-i="' + i + '" title="Unstar">★</span><span class="fs-act fs-foldx" data-i="' + i + '" title="Add to review / folder">+</span></td><td>' + esc(it.front) + "</td><td><strong>" + esc(it.back) + "</strong></td></tr>";
        }).join("") + "</tbody></table>";
      container.querySelectorAll(".fs-star").forEach(function (s) {
        s.addEventListener("click", function () { var it = list[parseInt(s.dataset.i)]; if (it) toggleStar(it, s); });
      });
      container.querySelectorAll(".fs-foldx").forEach(function (s) {
        s.addEventListener("click", function (ev) { ev.stopPropagation(); var it = list[parseInt(s.dataset.i)]; if (it) addToMenu(it, s); });
      });
      var rv = container.querySelector("#fs-review");
      if (rv) rv.onclick = function () {
        var cards = starred().map(function (it) { return { front: it.front, back: it.back, meta: "fact" }; });
        if (!cards.length) { ctx.toast("Nothing saved", "error"); return; }
        try { localStorage.setItem("qb-flashcards-cards", JSON.stringify({ cards: cards, ts: Date.now() })); } catch (e) {}
        if (!(window.QB && window.QB.showPage && window.QB.showPage("flashcards::cards"))) { try { localStorage.removeItem("qb-flashcards-cards"); } catch (e) {} ctx.toast("Enable the Flashcards plugin first", "error"); }
      };
    },
  });

  page = ctx.registerPage({
    id: "facts", navLabel: "Fact Sheet", title: "FACT SHEET",
    onShow: function (el) {
      body = el;
      if (!body.querySelector("#fs-input")) render();
      try {
        var h = JSON.parse(localStorage.getItem("qb-facts-handoff") || "null");
        if (h && h.term) {
          localStorage.removeItem("qb-facts-handoff");
          var tries = 0;
          (function apply() {
            var inp = body.querySelector("#fs-input");
            if (!inp) { if (tries++ < 20) setTimeout(apply, 60); return; }
            inp.value = h.term;
            compile();
          })();
        }
      } catch (e) {}
    },
  });
}
