// ── Shared kit ─────────────────────────────────────────────────────────────
// The same helpers ship in Keyword Frequency, Buzzwords and Fact Sheet (each
// plugin runs in its own scope): question text without notes, the filter row
// (the app's category picker, difficulty toggles, Years and Clues popovers),
// star / save buttons, a pager and the Database "saved" tab.
function __qbKit(ctx) {
  var K = {};
  function esc(s) { return (s == null ? "" : String(s)).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
  K.esc = esc;
  var ICONS = {
    search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>',
    down: '<path d="M6 9l6 6 6-6"/>',
    left: '<path d="M15 6l-6 6 6 6"/>',
    right: '<path d="M9 6l6 6-6 6"/>',
  };
  K.ic = function (n, s) {
    s = s || 16;
    return '<svg width="' + s + '" height="' + s + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (ICONS[n] || "") + "</svg>";
  };
  K.loadBar = function (label) { return (window.QB && QB.loadingBarHtml) ? QB.loadingBarHtml(label) : '<div class="db-empty">' + esc(label) + "</div>"; };
  K.loadBarDet = function (label, frac) {
    var pct = Math.max(0, Math.min(100, Math.round((frac || 0) * 100)));
    return '<div class="qb-loading"><div class="qb-loadbar det"><div class="qb-loadbar-fill" style="width:' + pct + '%"></div></div><span>' + esc(label) + "</span></div>";
  };
  K.empty = function (text) { return '<div class="db-empty">' + esc(text) + "</div>"; };
  K.num = function (n) { return Number(n || 0).toLocaleString(); };
  K.pct = function (x) { return Math.round(100 * (x || 0)) + "%"; };

  // ── question text ──────────────────────────────────────────────────────
  // Words come from what a question SAYS to players: the host's reading text
  // (ctx.host.questionText) when the base has it, else the plain copy.
  // Moderator / reader notes and pronunciation guides are removed whatever the
  // reading settings say: they are never clue words.
  var NOTE_LBL = /(?:note to (?:the )?(?:moderators?|readers?)\b|reader(?:'s)? note\b|moderator(?:'s)? note\b)/i;
  var NOTE_LBL_G = /(?:note to (?:the )?(?:moderators?|readers?)\b|reader(?:'s)? note\b|moderator(?:'s)? note\b)\s*(?:#\s*\d+\s*)?(?:,[^:]{0,40})?:\s*/gi;
  var NOTE_RUN = /^\s*[\[(<*]*\s*(?:note to (?:the )?(?:moderators?|readers?)\b|reader(?:'s)? note\b|moderator(?:'s)? note\b)/i;
  var ENT = { amp: "&", lt: "<", gt: ">", quot: '"', apos: "'", nbsp: " " };
  function decodeEnt(s) {
    return String(s || "").replace(/&(#x[0-9a-f]+|#\d+|[a-z]+);/gi, function (m, e) {
      if (e[0] === "#") { try { return String.fromCodePoint(e[1] === "x" || e[1] === "X" ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10)); } catch (x) { return m; } }
      var v = ENT[e.toLowerCase()]; return v == null ? m : v;
    });
  }
  K.decodeEnt = decodeEnt;
  // A note is the italic run of the HTML field that STARTS with its label.
  function noteRuns(html) {
    if (!html || html.indexOf("<") < 0) return [];
    var runs = [], it = 0, last = 0, m, re = /<\/?([a-z]+)[^>]*>/gi;
    function push(t) { if (!t) return; var p = runs[runs.length - 1], ital = it > 0; if (p && p.italic === ital) p.text += t; else runs.push({ text: t, italic: ital }); }
    while ((m = re.exec(html))) {
      push(decodeEnt(html.slice(last, m.index)));
      var tag = m[1].toLowerCase();
      if (tag === "i" || tag === "em") it = Math.max(0, it + (m[0][1] === "/" ? -1 : 1));
      last = re.lastIndex;
    }
    push(decodeEnt(html.slice(last)));
    return runs.filter(function (r) { return r.italic && NOTE_RUN.test(r.text); }).map(function (r) { return r.text.trim(); });
  }
  // The plain copy folds accents, straightens quotes and spells out dashes.
  function foldPlain(s) {
    return String(s || "").normalize("NFD").replace(/[̀-ͯ]/g, "")
      .replace(/[“”]/g, '"').replace(/[‘’]/g, "'").replace(/[–—]/g, "-").replace(/…/g, "...").replace(/ /g, " ");
  }
  function cutSpan(t, i, j) { return t.slice(0, i).replace(/\s+$/, "") + (i > 0 && j < t.length ? " " : "") + t.slice(j).replace(/^\s+/, ""); }
  function stripNotes(t, html) {
    if (!NOTE_LBL.test(t)) return t;
    noteRuns(html).forEach(function (note) {
      var cands = [foldPlain(note), note];
      for (var c = 0; c < cands.length; c++) { var i = t.indexOf(cands[c]); if (i >= 0) { t = cutSpan(t, i, i + cands[c].length); break; } }
    });
    if (!NOTE_LBL.test(t)) return t;
    t = t.replace(/\s*[\[(]\s*(?:notes?\s+to\s+(?:the\s+)?(?:moderators?|readers?)|(?:moderators?|readers?)(?:'s)?\s+notes?)\b[^\])]*[\])]/gi, " ");
    // An unformatted "Label: …" has no marked end: cut through its first
    // sentence, or to where the question visibly restarts (a lowercase word,
    // then a capitalised one, outside quotes).
    var m, guard = 0;
    NOTE_LBL_G.lastIndex = 0;
    while ((m = NOTE_LBL_G.exec(t)) && guard++ < 6) {
      var s = m.index, from = s + m[0].length, rest = t.slice(from, from + 300), b = -1;
      var w = rest.match(/^\S+\s+/), re = /[.!?]+["'”’)]*\s+|[a-z0-9"'”’)]\s+(?=[A-Z](?:[a-z'’]|\s))/g, mm;
      re.lastIndex = w ? w[0].length : 0;
      while ((mm = re.exec(rest))) {
        var stop = /^[.!?]/.test(mm[0]);
        if (!stop && ((rest.slice(0, mm.index + 1).match(/"/g) || []).length % 2)) continue;
        b = stop ? mm.index + mm[0].length : mm.index + 1; break;
      }
      while (s > 0 && /[\s*<\[(]/.test(t[s - 1])) s--;
      t = cutSpan(t, s, b >= 0 ? from + b : from);
      NOTE_LBL_G.lastIndex = s;
    }
    return t;
  }
  function stripGuides(t) {
    if (ctx.host && typeof ctx.host.stripPronunciations === "function") { try { t = ctx.host.stripPronunciations(t); } catch (e) {} }
    return String(t || "").replace(/\s*\(\s*["“][^"”()]*["”]\s*\)/g, "");
  }
  var _qtCache = typeof WeakMap === "function" ? new WeakMap() : null;
  K.qText = function (q) {
    if (!q) return "";
    if (_qtCache && _qtCache.has(q)) return _qtCache.get(q);
    var t = null;
    if (ctx.host && typeof ctx.host.questionText === "function") { try { t = ctx.host.questionText(q, "question"); } catch (e) { t = null; } }
    if (typeof t !== "string") t = q.question_sanitized || "";
    t = stripGuides(stripNotes(decodeEnt(t), q.question)).replace(/\s{2,}/g, " ").trim();
    if (_qtCache) _qtCache.set(q, t);
    return t;
  };
  // The answer line's main answer: what comes before any [accept …] / (…).
  K.mainAnswer = function (sani) { return decodeEnt(sani).split(/[\[(<]/)[0].trim().replace(/[;:,.]+$/, ""); };
  // Lowercase word tokens; internal apostrophes kept, a possessive 's dropped.
  K.tokens = function (text) {
    return (String(text || "").toLowerCase().match(/[\p{L}\p{N}'’]+/gu) || []).map(function (w) { return w.replace(/['’]s$/, ""); }).filter(Boolean);
  };
  // FTS: every token quoted (they are ANDed).
  K.ftsAll = function (col, toks) { return col + " : (" + toks.map(function (t) { return '"' + t.replace(/"/g, "") + '"'; }).join(" ") + ")"; };
  // The words of a question inside the chosen clue range (percent of the
  // question, or only what comes before the power mark).
  K.sliceWords = function (q, v) {
    var text = K.qText(q);
    if (v.power) {
      var pi = text.indexOf("(*)");
      return pi < 0 ? [] : K.tokens(text.slice(0, pi));
    }
    var words = K.tokens(text.replace(/\(\*\)/g, " "));
    var n = words.length; if (!n) return [];
    if (v.lo <= 0 && v.hi >= 100) return words;
    var a = Math.round((v.lo / 100) * n), b = Math.round((v.hi / 100) * n);
    return words.slice(a, Math.max(a + 1, b));
  };
  // Is seq a contiguous run inside arr?
  K.hasSeq = function (arr, seq) {
    if (!seq.length || seq.length > arr.length) return false;
    if (seq.length === 1) return arr.indexOf(seq[0]) >= 0;
    for (var i = 0; i + seq.length <= arr.length; i++) {
      var ok = true;
      for (var j = 0; j < seq.length; j++) if (arr[i + j] !== seq[j]) { ok = false; break; }
      if (ok) return true;
    }
    return false;
  };
  // Spelling / transliteration variants (Baldr / Balder / Baldur): one edit.
  K.lev1 = function (a, b) {
    if (a === b) return true;
    var la = a.length, lb = b.length;
    if (Math.abs(la - lb) > 1 || Math.min(la, lb) < 4) return false;
    var i = 0, j = 0, edits = 0;
    while (i < la && j < lb) {
      if (a[i] === b[j]) { i++; j++; continue; }
      if (++edits > 1) return false;
      if (la === lb) { i++; j++; } else if (la > lb) { i++; } else { j++; }
    }
    return edits + (la - i) + (lb - j) <= 1;
  };

  // ── saved view (filters survive leaving the page) ──────────────────────
  K.load = function (defaults) {
    var v = null;
    try { v = ctx.storage.get("view"); } catch (e) { v = null; }
    var out = {};
    for (var k in defaults) out[k] = defaults[k];
    if (v && typeof v === "object") for (var k2 in defaults) if (v[k2] !== undefined && v[k2] !== null) out[k2] = v[k2];
    if (!Array.isArray(out.cats)) out.cats = [];
    if (!Array.isArray(out.diffs)) out.diffs = [];
    out.lo = Math.max(0, Math.min(100, parseInt(out.lo, 10) || 0));
    out.hi = Math.max(0, Math.min(100, parseInt(out.hi, 10))); if (isNaN(out.hi)) out.hi = 100;
    if (out.lo > out.hi) { var t = out.lo; out.lo = out.hi; out.hi = t; }
    return out;
  };
  K.save = function (v) { try { ctx.storage.set("view", v); } catch (e) {} };

  // ── filter row ─────────────────────────────────────────────────────────
  var DIFF_NAMES = ["Unrated", "Middle school", "Easy high school", "Regular high school", "Hard high school", "National high school", "Easy college", "Medium college", "Regionals college", "Nationals college", "Open"];
  var Y0 = 2000, Y1 = 2026;
  K.yearsLabel = function (v) { return (!v.y0 && !v.y1) ? "Any" : (v.y0 || Y0) + "–" + (v.y1 || Y1); };
  K.cluesLabel = function (v) { return v.power ? "Before power" : (v.lo <= 0 && v.hi >= 100) ? "All" : v.lo + "–" + v.hi + "%"; };
  K.filterQs = function (v, catH) {
    var ids = [];
    if (catH) { try { ids = (catH.get() || []).filter(Boolean); } catch (e) { ids = []; } }
    else ids = (v.cats || []).filter(Boolean);
    return (ids.length ? "&categoryIds=" + encodeURIComponent(ids.join(",")) : "") +
      ((v.diffs || []).length ? "&difficulties=" + v.diffs.join(",") : "") +
      (v.y0 ? "&yearMin=" + v.y0 : "") + (v.y1 ? "&yearMax=" + v.y1 : "");
  };
  K.filterRowHtml = function (v, extra) {
    var diffs = "";
    for (var d = 0; d <= 10; d++) diffs += '<label title="' + esc(DIFF_NAMES[d]) + '"><input type="checkbox" value="' + d + '"' + ((v.diffs || []).indexOf(d) >= 0 ? " checked" : "") + "><span>" + d + "</span></label>";
    return '<div class="qrow fsq-filters">' +
      '<span class="fsq-cat-slot"></span>' +
      '<div class="diff-toggles fsq-diffs" role="group" aria-label="Difficulty"><span class="dt-lbl">Difficulty</span>' + diffs + "</div>" +
      '<div class="pop-wrap fsq-popw"><button type="button" class="btn fsq-pop-btn" data-pop="years" aria-expanded="false" aria-haspopup="dialog">Years <span class="accent-val num fsq-years-val">' + esc(K.yearsLabel(v)) + "</span>" + K.ic("down", 14) + "</button>" +
        '<div class="pop left years-pop fsq-pop" data-pop-for="years" role="dialog" aria-label="Years" hidden><form class="fsq-years-form">' +
          '<div class="yrow"><label class="ifield"><span>From</span><input class="fsq-y0" inputmode="numeric" autocomplete="off" value="' + (v.y0 || Y0) + '" aria-label="From year"></label>' +
          '<label class="ifield"><span>To</span><input class="fsq-y1" inputmode="numeric" autocomplete="off" value="' + (v.y1 || Y1) + '" aria-label="To year"></label></div>' +
          '<div class="yrow"><button type="button" class="btn btn-sm fsq-y-any" style="flex:1">Any year</button><button type="submit" class="btn btn-sm btn-primary" style="flex:1">Apply</button></div>' +
        "</form></div></div>" +
      '<div class="pop-wrap fsq-popw"><button type="button" class="btn fsq-pop-btn" data-pop="clues" aria-expanded="false" aria-haspopup="dialog">Clues <span class="accent-val fsq-clues-val">' + esc(K.cluesLabel(v)) + "</span>" + K.ic("down", 14) + "</button>" +
        '<div class="pop left fsq-pop fsq-clue-pop" data-pop-for="clues" role="dialog" aria-label="Clues" hidden>' +
          '<div class="fsq-clue-head"><span>Part of the question</span><b class="num fsq-range-val"></b></div>' +
          '<div class="dual-range fsq-dual"><div class="dual-range-track"><div class="dual-range-fill fsq-fill"></div></div>' +
            '<input type="range" class="fsq-lo" min="0" max="100" step="5" value="' + v.lo + '" aria-label="From">' +
            '<input type="range" class="fsq-hi" min="0" max="100" step="5" value="' + v.hi + '" aria-label="To"></div>' +
          '<label class="checkbox-row fsq-power-row"><input type="checkbox" class="fsq-power"' + (v.power ? " checked" : "") + "><span>Before power only</span></label>" +
        "</div></div>" +
      (extra || "") +
    "</div>";
  };

  // Popovers: the button toggles; a click elsewhere or Esc closes (the app
  // does both for every .pop — this keeps older bases working too).
  function closePops(except) {
    document.querySelectorAll(".fsq-pop:not([hidden])").forEach(function (p) {
      if (except && p === except) return;
      p.hidden = true;
      var b = p.parentNode && p.parentNode.querySelector(".fsq-pop-btn"); if (b) b.setAttribute("aria-expanded", "false");
    });
  }
  K.closePops = closePops;
  function onDocDown(e) { if (!e.target.closest || !e.target.closest(".fsq-pop, .fsq-pop-btn")) closePops(); }
  document.addEventListener("mousedown", onDocDown, true);
  ctx._unsub.push(function () { document.removeEventListener("mousedown", onDocDown, true); });
  function openPop(btn, pop) {
    var open = pop.hidden;
    closePops(open ? pop : null);
    pop.hidden = !open;
    btn.setAttribute("aria-expanded", String(open));
    if (!open) return;
    // keep it on screen (a button near the right edge on a phone)
    pop.style.left = ""; pop.style.right = "";
    // the right edge of what's visible: the viewport, or a scrolling parent
    // (its scrollbar takes width from the viewport)
    var edge = document.documentElement.clientWidth || window.innerWidth;
    for (var a = pop.parentElement; a && a !== document.body; a = a.parentElement) {
      var ox = getComputedStyle(a).overflowX;
      if (ox === "auto" || ox === "scroll" || ox === "hidden" || ox === "clip") { edge = Math.min(edge, a.getBoundingClientRect().left + a.clientWidth); break; }
    }
    var r = pop.getBoundingClientRect();
    if (r.right > edge - 8) pop.style.left = Math.min(0, edge - 8 - r.right) + "px";
    var f = pop.querySelector("input"); if (f && pop.dataset.popFor === "years") setTimeout(function () { try { f.focus(); f.select(); } catch (e) {} }, 30);
  }

  // Wires the row. onChange(kind) runs after any filter changes (v is saved).
  // Returns { cat } — the category picker handle (null on a base without one).
  K.wireFilterRow = function (root, v, onChange) {
    var row = root.querySelector(".fsq-filters");
    var fire = function (kind) { K.save(v); try { onChange(kind); } catch (e) { console.error(e); } };
    var cat = null, slot = row.querySelector(".fsq-cat-slot");
    if (ctx.host && typeof ctx.host.categoryPicker === "function") {
      try {
        cat = ctx.host.categoryPicker(null, { type: "tossups", selected: (v.cats || []).slice(), label: "Categories",
          onChange: function (ids) { v.cats = (ids || []).slice(); fire("cats"); } });
        if (cat && cat.el) slot.replaceWith(cat.el); else cat = null;
      } catch (e) { cat = null; }
    }
    if (!cat && slot) slot.remove();
    row.querySelectorAll(".fsq-diffs input").forEach(function (cb) {
      cb.addEventListener("change", function () {
        v.diffs = [].slice.call(row.querySelectorAll(".fsq-diffs input:checked")).map(function (c) { return parseInt(c.value, 10); });
        fire("diffs");
      });
    });
    row.querySelectorAll(".fsq-pop-btn").forEach(function (b) {
      b.addEventListener("click", function (e) { e.preventDefault(); openPop(b, b.parentNode.querySelector(".fsq-pop")); });
    });
    row.querySelectorAll(".fsq-pop").forEach(function (p) {
      p.addEventListener("keydown", function (e) {
        if (e.key === "Escape" && !p.hidden) { e.preventDefault(); e.stopPropagation(); closePops(); var b = p.parentNode.querySelector(".fsq-pop-btn"); if (b) b.focus(); }
      });
    });
    // Years
    var yv = row.querySelector(".fsq-years-val"), f = row.querySelector(".fsq-years-form");
    function setYears(a, b) {
      a = parseInt(a, 10); b = parseInt(b, 10);
      if (isNaN(a) || a < 1900 || a > 2100) a = Y0;
      if (isNaN(b) || b < 1900 || b > 2100) b = Y1;
      if (a > b) { var t = a; a = b; b = t; }
      var y0 = a > Y0 ? a : null, y1 = b < Y1 ? b : null;
      var changed = y0 !== (v.y0 || null) || y1 !== (v.y1 || null);
      v.y0 = y0; v.y1 = y1;
      yv.textContent = K.yearsLabel(v);
      f.querySelector(".fsq-y0").value = v.y0 || Y0; f.querySelector(".fsq-y1").value = v.y1 || Y1;
      closePops();
      if (changed) fire("years");
    }
    f.addEventListener("submit", function (e) { e.preventDefault(); setYears(f.querySelector(".fsq-y0").value, f.querySelector(".fsq-y1").value); });
    f.querySelector(".fsq-y-any").addEventListener("click", function () { setYears(Y0, Y1); });
    // Clues: a percent range of the question, or before the power mark
    var lo = row.querySelector(".fsq-lo"), hi = row.querySelector(".fsq-hi"), fill = row.querySelector(".fsq-fill");
    var rv = row.querySelector(".fsq-range-val"), cv = row.querySelector(".fsq-clues-val"), pw = row.querySelector(".fsq-power");
    function paintRange() {
      var a = parseInt(lo.value, 10), b = parseInt(hi.value, 10), mn = Math.min(a, b), mx = Math.max(a, b);
      v.lo = mn; v.hi = mx;
      fill.style.left = mn + "%"; fill.style.right = (100 - mx) + "%";
      rv.textContent = mn + "–" + mx + "%";
      lo.disabled = hi.disabled = !!v.power;
      row.querySelector(".fsq-dual").classList.toggle("off", !!v.power);
      cv.textContent = K.cluesLabel(v);
    }
    var rangeAt = null;
    lo.addEventListener("input", paintRange); hi.addEventListener("input", paintRange);
    var rangeDone = function () { var s = v.lo + "-" + v.hi; if (s !== rangeAt) { rangeAt = s; fire("clues"); } };
    lo.addEventListener("change", rangeDone); hi.addEventListener("change", rangeDone);
    pw.addEventListener("change", function () { v.power = pw.checked; paintRange(); fire("clues"); });
    paintRange(); rangeAt = v.lo + "-" + v.hi;
    return { cat: cat };
  };

  // ── star / save ────────────────────────────────────────────────────────
  K.canSave = function () { return !!((ctx.host && ctx.host.openItemSaveMenu) || window.QBFolders); };
  K.starBtn = function (on, attrs) {
    return '<button type="button" class="star-btn fsq-star' + (on ? " on" : "") + '" aria-label="' + (on ? "Unstar" : "Star") + '" aria-pressed="' + !!on + '"' + (attrs || "") + ">" + (on ? "★" : "☆") + "</button>";
  };
  K.setStar = function (btn, on) {
    if (!btn) return;
    btn.classList.toggle("on", !!on); btn.textContent = on ? "★" : "☆";
    btn.setAttribute("aria-pressed", String(!!on)); btn.setAttribute("aria-label", on ? "Unstar" : "Star");
  };
  K.saveBtn = function (attrs) { return K.canSave() ? '<button type="button" class="star-btn save-plus fsq-save" aria-label="Save to review or a folder"' + (attrs || "") + ">+</button>" : ""; };
  K.openSave = function (spec, anchor) {
    if (ctx.host && ctx.host.openItemSaveMenu) ctx.host.openItemSaveMenu(spec, anchor);
    else if (window.QBFolders) window.QBFolders.pick(spec.folder.type, spec.folder.item, anchor);
  };

  // ── pager ──────────────────────────────────────────────────────────────
  K.pagerHtml = function (page, pages) {
    if (pages <= 1) return "";
    return '<nav class="fsq-pager" aria-label="Pages">' +
      '<button type="button" class="btn btn-icon" data-pg="' + (page - 1) + '" aria-label="Previous page"' + (page <= 0 ? " disabled" : "") + ">" + K.ic("left", 16) + "</button>" +
      '<span class="fsq-pagenum">Page <b class="num">' + (page + 1) + '</b> of <span class="num">' + pages + "</span></span>" +
      '<button type="button" class="btn btn-icon" data-pg="' + (page + 1) + '" aria-label="Next page"' + (page >= pages - 1 ? " disabled" : "") + ">" + K.ic("right", 16) + "</button></nav>";
  };
  K.wirePager = function (root, go) {
    root.querySelectorAll(".fsq-pager [data-pg]").forEach(function (b) {
      b.addEventListener("click", function () { if (!b.disabled) go(parseInt(b.dataset.pg, 10), !!b.closest(".fsq-foot")); });
    });
  };

  // ── other plugins / pages ─────────────────────────────────────────────
  K.pageActive = function (id) {
    try { return !!(window.QB && QB.getActivePages && (QB.getActivePages() || []).some(function (p) { return p.id === id || p.id.indexOf(id + "::") === 0; })); } catch (e) { return false; }
  };
  K.hasFlashcards = function () { return K.pageActive("flashcards::cards"); };
  K.reviewAsFlashcards = function (cards) {
    if (!cards.length) return false;
    try { localStorage.setItem("qb-flashcards-cards", JSON.stringify({ cards: cards, ts: Date.now() })); } catch (e) {}
    var ok = !!(window.QB && QB.showPage && QB.showPage("flashcards::cards"));
    if (!ok) { try { localStorage.removeItem("qb-flashcards-cards"); } catch (e) {} }
    return ok;
  };
  K.searchDb = function (opts) { if (ctx.host && ctx.host.searchDatabase) ctx.host.searchDatabase(opts); };

  // ── Database → <plugin> tab: the saved pairs ───────────────────────────
  // o: { title, empty, key, list(), save(list), front(it), back(it), card(it), saveSpec(it) }
  K.savedTab = function (o) {
    var host = null;
    function paint() {
      if (!host || !host.isConnected) return;
      var list = o.list();
      if (!list.length) { host.innerHTML = K.empty(o.empty); return; }
      var fc = K.hasFlashcards();
      host.innerHTML =
        '<div class="db-toolbar fsq-saved-bar"><span class="fsq-saved-n">' + K.num(list.length) + " saved</span><span class=\"spacer\"></span>" +
          (fc ? '<button type="button" class="btn btn-sm btn-primary fsq-review">Review as flashcards</button>' : "") + "</div>" +
        '<div class="list fsq-saved">' + list.map(function (it, i) {
          return '<div class="list-row fsq-saved-row" data-i="' + i + '"><span class="fsq-front">' + esc(o.front(it)) + '</span><span class="fsq-arrow" aria-hidden="true">→</span><span class="fsq-back">' + esc(o.back(it)) + "</span>" +
            '<span class="fsq-acts">' + K.saveBtn(' data-i="' + i + '"') + K.starBtn(true, ' data-i="' + i + '"') + "</span></div>";
        }).join("") + "</div>";
      host.querySelectorAll(".fsq-star").forEach(function (s) {
        s.addEventListener("click", function () {
          // Unstarring greys the row out (star it again to keep it); it leaves on the next visit.
          var it = list[parseInt(s.dataset.i, 10)]; if (!it) return;
          var cur = o.list(), k = o.key(it), idx = cur.findIndex(function (x) { return o.key(x) === k; });
          var on = idx < 0;
          if (on) cur.push(it); else cur.splice(idx, 1);
          o.save(cur);
          K.setStar(s, on);
          var row = s.closest(".fsq-saved-row"); if (row) row.classList.toggle("off", !on);
          if (ctx.playSound) ctx.playSound("star");
        });
      });
      host.querySelectorAll(".fsq-save").forEach(function (b) {
        b.addEventListener("click", function () { var it = list[parseInt(b.dataset.i, 10)]; if (it) K.openSave(o.saveSpec(it), b); });
      });
      var rv = host.querySelector(".fsq-review");
      if (rv) rv.addEventListener("click", function () { K.reviewAsFlashcards(o.list().map(o.card)); });
    }
    ctx.on("plugins:changed", function () { paint(); });
    ctx.registerStarredProvider({ id: o.id, title: o.title, render: function (container) { host = container; paint(); } });
  };
  return K;
}

// ── Fact Sheet ─────────────────────────────────────────────────────────────
// Type an answer: every question about it is read and the phrases that keep
// coming back are listed as facts, each with a real sentence from a question,
// how many questions use it, where in the question it usually comes, and how
// often the phrase points to this answer anywhere in the database.
function __qbMain(ctx) {
  var K = __qbKit(ctx), esc = K.esc;
  var STOP = {};
  ("a an the of in on at to for from with within without by as is are was were be been being am do does did done not no nor so or and but if then than because while during after before until once when where which who whom whose what why how all any both each few more most other some such only own same here there over under again further about above below between into through against up down out off very can will just should now points point name names named ftp identify gives give given made make makes making one two first second third often called also another may might must many much works worked title titled known includes including include described describes describe used uses use using like unlike along later earlier begins ends opens work whose").split(/\s+/).forEach(function (w) { STOP[w] = 1; });
  // Referent words make a "fact" say nothing ("form of this technique") —
  // blocked at every position.
  var PRON = {};
  ("this these that those it its his her hers their theirs they them he she him you your one ones man woman author composer poet character work entity thing figure title titular").split(/\s+/).forEach(function (w) { PRON[w] = 1; });

  // Versions before 1.13 kept a search log; nothing reads it any more.
  try { localStorage.removeItem("qb-pl-fact-sheet-fs-searches"); } catch (e) {}

  var v = K.load({ cats: [], diffs: [], y0: null, y1: null, lo: 0, hi: 100, power: false, sort: "common", minp: 0 });
  if (v.sort !== "early") v.sort = "common";
  if ([0, 50, 80].indexOf(+v.minp) < 0) v.minp = 0;
  var body = null, catH = null, cur = null, lastTerm = "", gen = 0, shown = 15, STEP = 15, MAXF = 60;
  function el(sel) { return body && body.querySelector(sel); }
  function fold(s) { return String(s || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase(); }
  function answerHas(q, toks) {
    var m = fold(K.mainAnswer(q.answer_sanitized));
    for (var i = 0; i < toks.length; i++) if (m.indexOf(fold(toks[i])) < 0) return false;
    return true;
  }

  // ── stars + review / folders ──
  function stars() { return ctx.storage.get("fs-stars") || []; }
  function starKey(it) { return String(it.front || "").toLowerCase() + "|" + String(it.back || "").toLowerCase(); }
  function isStarred(front, back) { var k = starKey({ front: front, back: back }); return stars().some(function (x) { return starKey(x) === k; }); }
  function toggleStar(front, back, btn) {
    var lst = stars(), k = starKey({ front: front, back: back }), i = lst.findIndex(function (x) { return starKey(x) === k; });
    if (i >= 0) lst.splice(i, 1); else lst.push({ front: front, back: back });
    ctx.storage.set("fs-stars", lst);
    K.setStar(btn, i < 0);
    if (ctx.playSound) ctx.playSound("star");
  }
  function saveSpec(front, back) { return { review: { kind: "fact", front: front, back: back, meta: "fact sheet" }, folder: { type: "facts", item: { front: front, back: back } } }; }
  // A "Facts" folder type while the Folders plugin is on (now or later).
  var foldersUnreg = null;
  function tryRegisterFolderType() {
    if (foldersUnreg || !window.QBFolders || !window.QBFolders.registerType) return;
    foldersUnreg = window.QBFolders.registerType({ key: "facts", label: "Facts", item: "fact", run: ["flashcards"] });
  }
  tryRegisterFolderType();
  ctx.on("plugins:changed", tryRegisterFolderType);
  ctx._unsub.push(function () { if (foldersUnreg) { try { foldersUnreg(); } catch (e) {} foldersUnreg = null; } });

  // ── reading the questions ──
  // Sentences with the fraction of the question where each one starts.
  function sentences(text) {
    var clean = (text || "").replace(/\(\*\)/g, ""), total = clean.length || 1;
    var out = [], re = /(?<=[.!?…]["”’']?)\s+(?=["“‘']?[A-Z0-9(])/g, last = 0, m;
    while ((m = re.exec(clean))) { out.push({ s: clean.slice(last, m.index).trim(), pos: last / total }); last = m.index + m[0].length; }
    if (last < clean.length) out.push({ s: clean.slice(last).trim(), pos: last / total });
    return out.filter(function (e) { return e.s; });
  }
  // Phrases of 2–5 words that don't start or end on a stop word.
  function gramsOf(words, skip) {
    var out = [];
    for (var i = 0; i < words.length; i++) {
      for (var L = 2; L <= 5; L++) {
        if (i + L > words.length) break;
        var g = words.slice(i, i + L);
        if (STOP[g[0]] || STOP[g[L - 1]]) continue;
        var bad = false;
        for (var k = 0; k < L; k++) if (PRON[g[k]] || skip[g[k]] || /^\d+$/.test(g[k]) || g[k].length < 2) { bad = true; break; }
        if (!bad) out.push(g.join(" "));
      }
    }
    return out;
  }
  function collapse(items) {
    var idx = Object.create(null), drop = Object.create(null);
    items.forEach(function (it) { idx[it.g] = it; });
    items.forEach(function (it) {
      var t = it.g.split(" "); if (t.length < 3) return;
      for (var L = 2; L < t.length; L++) for (var s = 0; s + L <= t.length; s++) {
        var sub = t.slice(s, s + L).join(" "), si = idx[sub];
        if (si && it.docs >= 0.8 * si.docs) drop[sub] = 1;
      }
    });
    return items.filter(function (it) { return !drop[it.g]; });
  }
  // How the answer is usually written, when one spelling covers most of its
  // questions ("plath" → "Sylvia Plath"); else what was typed.
  function answerName(rows, term) {
    var c = Object.create(null), best = "", bn = 0;
    rows.forEach(function (q) { var m = K.mainAnswer(q.answer_sanitized); if (!m) return; c[m] = (c[m] || 0) + 1; if (c[m] > bn) { bn = c[m]; best = m; } });
    return best && bn * 2 >= rows.length ? best : term;
  }

  ctx.registerPage({
    id: "facts", navLabel: "Fact Sheet", title: "Fact Sheet",
    onShow: function (elx) {
      body = elx;
      if (!el("#fs-input")) render();
      // Handoff from the app's right-click ("Fact sheet for it") and the other study plugins.
      try {
        var h = JSON.parse(localStorage.getItem("qb-facts-handoff") || "null");
        if (h && h.term) { localStorage.removeItem("qb-facts-handoff"); compile(h.term); }
      } catch (e) {}
    },
  });

  function render() {
    body.innerHTML =
      '<div class="fsq fs">' +
        '<form class="cfield fsq-search" id="fs-form" autocomplete="off">' + K.ic("search", 18) +
          '<input type="search" enterkeyhint="go" id="fs-input" class="cinput" placeholder="Type an answer" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" aria-label="Answer">' +
          '<button type="submit" class="btn btn-primary" id="fs-go">Make sheet</button>' +
        "</form>" +
        K.filterRowHtml(v) +
        '<div id="fs-results">' + K.empty("No fact sheet yet") + "</div>" +
      "</div>";
    catH = K.wireFilterRow(body, v, function () { if (lastTerm) compile(lastTerm, { keep: true }); }).cat;
    var form = el("#fs-form"), inp = el("#fs-input");
    form.addEventListener("submit", function (e) { e.preventDefault(); compile(inp.value); });
    form.addEventListener("mousedown", function (e) { if (e.target === form) { e.preventDefault(); inp.focus(); } });
  }

  function compile(term, opts) {
    opts = opts || {};
    if (!body || !el("#fs-input")) return;
    term = String(term || "").trim();
    el("#fs-input").value = term;
    var out = el("#fs-results");
    lastTerm = term;
    if (!term) { cur = null; out.innerHTML = K.empty("No fact sheet yet"); return; }
    var my = ++gen;
    var toks = K.tokens(term);
    if (!toks.length) { cur = null; out.innerHTML = K.empty("No questions found"); return; }
    out.innerHTML = K.loadBar("Reading every “" + term + "” question…");
    var filters = K.filterQs(v, catH);
    ctx.api.get("/api/tossups/search?query=" + encodeURIComponent(K.ftsAll("answer_sanitized", toks)) + "&limit=500" + filters).then(function (d) {
      if (my !== gen) return;
      var qs = ((d && d.rows) || []).filter(function (q) { return answerHas(q, toks); });
      if (!qs.length) { cur = null; out.innerHTML = K.empty("No questions found"); return; }
      var facts = Object.create(null);
      qs.forEach(function (q) {
        var skip = Object.create(null);
        toks.forEach(function (t) { skip[t] = 1; });
        K.tokens(q.answer_sanitized).forEach(function (w) { skip[w] = 1; });
        var raw = K.qText(q), powerAt = -1;
        if (v.power) {
          // before the power mark only; unmarked questions don't count
          var pi = raw.indexOf("(*)"); if (pi < 0) return;
          powerAt = raw.slice(0, pi).replace(/\(\*\)/g, "").length / (raw.replace(/\(\*\)/g, "").length || 1);
        }
        var seen = Object.create(null);
        sentences(raw).forEach(function (se) {
          if (v.power) { if (se.pos >= powerAt) return; }
          else if (se.pos < v.lo / 100 - 1e-9 || se.pos > v.hi / 100 + 1e-9) return;
          gramsOf(K.tokens(se.s), skip).forEach(function (g) {
            var f = facts[g] || (facts[g] = { g: g, docs: 0, posSum: 0, posN: 0, best: "", bestLen: 1e9 });
            f.posSum += se.pos; f.posN++;
            if (!seen[g]) { seen[g] = 1; f.docs++; }
            var sl = se.s.length;
            // the example: the shortest sentence of a readable length
            if ((sl >= 40 && sl < f.bestLen) || !f.best) { f.best = se.s; f.bestLen = sl >= 40 ? sl : 1e9; }
          });
        });
      });
      var list = Object.keys(facts).map(function (g) { var f = facts[g]; f.len = g.split(" ").length; f.avg = f.posN ? f.posSum / f.posN : 0; return f; })
        .filter(function (f) { return f.docs >= 2; })
        .sort(function (a, b) { return b.docs - a.docs || b.len - a.len; });
      list = collapse(list.slice(0, 300)).slice(0, MAXF);
      if (!list.length) { cur = null; out.innerHTML = K.empty("No facts in that part of the questions"); return; }
      cur = { term: term, toks: toks, name: answerName(qs, term), n: qs.length, facts: list, filters: filters, clue: v.power ? "P" : v.lo + "-" + v.hi };
      if (!opts.keep) shown = STEP;
      paint();
    }).catch(function () { if (my === gen) { cur = null; out.innerHTML = K.empty("Search failed"); } });
  }

  // How often the phrase points to this answer: of every question using it
  // (same filters), the share this answer is the answer to. Cached.
  var probCache = Object.create(null);
  function factProb(f, c, cb) {
    var key = f.g + "|" + c.toks.join(" ") + "|" + c.filters;
    if (probCache[key]) return cb(probCache[key]);
    var seq = f.g.split(" ");
    ctx.api.get("/api/tossups/search?query=" + encodeURIComponent(K.ftsAll("question_sanitized", seq)) + "&limit=400" + c.filters).then(function (d) {
      var total = 0, hit = 0;
      ((d && d.rows) || []).forEach(function (q) {
        if (!K.hasSeq(K.tokens(K.qText(q).replace(/\(\*\)/g, " ")), seq)) return;
        total++;
        if (answerHas(q, c.toks)) hit++;
      });
      var r = { p: total ? hit / total : 0, hit: hit, total: total };
      probCache[key] = r; cb(r);
    }).catch(function () { cb(null); });
  }
  // Fetch the share for every fact in `list` (4 at a time); each(f) after one lands.
  function fillProbs(list, c, each, done) {
    var idx = 0, busy = 0, left = list.length, my = gen;
    if (!left) { if (done) done(); return; }
    function next() {
      while (busy < 4 && idx < list.length) {
        (function (f) {
          busy++;
          factProb(f, c, function (r) {
            busy--; left--;
            f.prob = r && r.total ? r : { p: 0, hit: 0, total: 0 };
            if (my === gen && cur === c) { if (each) each(f); if (!left && done) done(); next(); }
          });
        })(list[idx++]);
      }
    }
    next();
  }
  function posLabel(avg) { return avg < 0.34 ? "Early clue" : avg < 0.67 ? "Middle clue" : "Late clue"; }
  function probHtml(f) {
    if (!f.prob) return '<span class="fs-share">Points to it …</span>';
    if (!f.prob.total) return '<span class="fs-share">Points to it –</span>';
    return '<span class="fs-share' + (f.prob.p >= 0.8 ? " hi" : "") + '">Points to it ' + K.pct(f.prob.p) + "</span>";
  }
  // The fact as the sentence writes it ("Lady Lazarus"), found in the sentence.
  function factRe(g) {
    try {
      var parts = g.split(" ").map(function (w) { return w.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "(?:['’]s)?"; });
      return new RegExp(parts.join("[^\\p{L}\\p{N}]+"), "iu");
    } catch (e) { return null; }
  }
  function display(f) {
    var re = f.best && factRe(f.g), m = re && re.exec(f.best);
    return m ? m[0].replace(/["“”]/g, "").replace(/\s+/g, " ") : f.g;
  }
  function highlight(sentence, g) {
    var re = factRe(g), m = re && re.exec(sentence);
    if (!m) return esc(sentence);
    return esc(sentence.slice(0, m.index)) + "<mark>" + esc(m[0]) + "</mark>" + esc(sentence.slice(m.index + m[0].length));
  }
  function visibleFacts(c) {
    var list = c.facts.slice();
    if (v.sort === "early") list.sort(function (a, b) { return a.avg - b.avg || b.docs - a.docs; });
    if (v.minp > 0) list = list.filter(function (f) { return f.prob && f.prob.total && f.prob.p >= v.minp / 100 - 1e-9; });
    return list;
  }

  function paint() {
    var out = el("#fs-results"), c = cur; if (!out || !c) return;
    // a share threshold needs every share first
    if (v.minp > 0 && c.facts.some(function (f) { return !f.prob; })) {
      var have = c.facts.filter(function (f) { return f.prob; }).length;
      out.innerHTML = K.loadBarDet("Checking facts…", have / c.facts.length);
      fillProbs(c.facts.filter(function (f) { return !f.prob; }), c, function () {
        var bar = out.querySelector(".qb-loadbar-fill"); var n = c.facts.filter(function (f) { return f.prob; }).length;
        if (bar) bar.style.width = Math.round(100 * n / c.facts.length) + "%";
      }, function () { if (cur === c) paint(); });
      return;
    }
    var list = visibleFacts(c), slice = list.slice(0, shown);
    var head = '<div class="rhead"><span class="total num">' + K.num(c.n) + (c.n === 1 ? " question" : " questions") + '</span><span class="fsq-sub">about ' + esc(c.name) + "</span>" +
      '<span class="spacer"></span>' +
      '<div class="seg" id="fs-sort" role="group" aria-label="Order"><button type="button" data-sort="common" aria-pressed="' + (v.sort === "common") + '">Most common</button><button type="button" data-sort="early" aria-pressed="' + (v.sort === "early") + '">Earliest</button></div>' +
      '<select id="fs-minp" class="mode-input" aria-label="Points to it">' + [[0, "Points to it: any"], [50, "Points to it 50%+"], [80, "Points to it 80%+"]].map(function (o) { return '<option value="' + o[0] + '"' + (+v.minp === o[0] ? " selected" : "") + ">" + o[1] + "</option>"; }).join("") + "</select>" +
      "</div>";
    out.innerHTML = head + (slice.length ?
      '<div class="list fs-list">' + slice.map(function (f, i) {
        return '<div class="list-row fs-row" data-g="' + esc(f.g) + '"><span class="lr-rank num">' + (i + 1) + "</span>" +
          '<div class="fs-main"><span class="fs-gram fsq-link" data-g="' + esc(f.g) + '">' + esc(display(f)) + "</span>" +
            (f.best ? '<div class="fs-example">' + highlight(f.best, f.g) + "</div>" : "") +
            '<div class="fs-meta"><span>' + f.docs + " of " + c.n + " questions</span><span>" + posLabel(f.avg) + "</span>" + probHtml(f) + "</div>" +
          "</div>" +
          '<span class="fsq-acts">' + K.saveBtn() + K.starBtn(isStarred(display(f), c.name)) + "</span></div>";
      }).join("") + "</div>" : K.empty("No facts match")) +
      (list.length > shown ? '<div class="fsq-foot"><button type="button" class="btn" id="fs-more">Show more</button></div>' : "");
    var byG = Object.create(null); c.facts.forEach(function (f) { byG[f.g] = f; });
    var sortSeg = out.querySelector("#fs-sort");
    sortSeg.addEventListener("click", function (e) {
      var b = e.target.closest("[data-sort]"); if (!b || b.dataset.sort === v.sort) return;
      v.sort = b.dataset.sort; K.save(v); paint();
    });
    out.querySelector("#fs-minp").addEventListener("change", function (e) { v.minp = parseInt(e.target.value, 10) || 0; K.save(v); paint(); });
    var more = out.querySelector("#fs-more"); if (more) more.addEventListener("click", function () { shown += STEP; paint(); });
    out.querySelectorAll(".fs-row").forEach(function (row) {
      var f = byG[row.dataset.g]; if (!f) return;
      var st = row.querySelector(".fsq-star"), sv = row.querySelector(".fsq-save");
      row.querySelector(".fs-gram").addEventListener("click", function () { K.searchDb({ query: f.g, field: "question", exact: true, qtype: "tossup" }); });
      st.addEventListener("click", function (ev) { ev.stopPropagation(); toggleStar(display(f), c.name, st); });
      if (sv) sv.addEventListener("click", function (ev) { ev.stopPropagation(); K.openSave(saveSpec(display(f), c.name), sv); });
      row.addEventListener("contextmenu", function (ev) {
        if (!window.QB || !QB.contextMenu) return;
        ev.preventDefault();
        var items = [{ label: "Find questions with this fact", onClick: function () { K.searchDb({ query: f.g, field: "question", exact: true, qtype: "tossup" }); } }];
        if (K.pageActive("keyword-freq::kwfreq")) items.push({ label: "Answers for “" + f.g + "”", onClick: function () { try { localStorage.setItem("qb-kf-handoff", JSON.stringify({ mode: "words", term: f.g })); } catch (x) {} QB.showPage("keyword-freq::kwfreq"); } });
        items.push({ label: "Copy fact", onClick: function () { try { navigator.clipboard.writeText(display(f) + " → " + c.name); } catch (x) {} } });
        items.push({ sep: true });
        items.push({ label: st.classList.contains("on") ? "Unstar" : "Star", onClick: function () { st.click(); } });
        if (sv) items.push({ label: "Save to review or a folder…", onClick: function () { K.openSave(saveSpec(display(f), c.name), sv); } });
        QB.contextMenu(ev.clientX, ev.clientY, items, { title: display(f) + " → " + c.name });
      });
    });
    // shares for the facts on screen, filled in as they land
    fillProbs(slice.filter(function (f) { return !f.prob; }), c, function (f) {
      var row = out.querySelector('.fs-row[data-g="' + (window.CSS && CSS.escape ? CSS.escape(f.g) : f.g) + '"]');
      var cell = row && row.querySelector(".fs-share"); if (cell) cell.outerHTML = probHtml(f);
    });
  }

  // ── Database → Facts: saved facts ──
  K.savedTab({
    id: "fact-sheet", title: "Facts", empty: "No saved facts yet",
    list: stars, save: function (l) { ctx.storage.set("fs-stars", l); }, key: starKey,
    front: function (it) { return it.front; }, back: function (it) { return it.back; },
    card: function (it) { return { front: it.front, back: it.back, meta: "fact" }; },
    saveSpec: function (it) { return saveSpec(it.front, it.back); },
  });
}
