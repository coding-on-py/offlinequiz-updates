function __qbMain(ctx) {
  var body = null, page = null;

  function esc(s) { return (s == null ? "" : String(s)).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
  function loadBar(label) { return (window.QB && QB.loadingBarHtml) ? QB.loadingBarHtml(label) : '<div class="text-muted">' + esc(label) + "</div>"; }
  function mainAnswer(sani) { return (sani || "").split(/[\[(]/)[0].trim().replace(/[;:,.]+$/, ""); }

  var STOP = {};
  ("a an the of in on at to for from with within without by as is are was were be been being am do does did done not no nor so or and but if then than because while during after before until once when where which who whom whose what why how all any both each few more most other some such only own same here there over under again further about above below between into through against up down out off very can will just should now points point name names named ftp identify gives give given made make makes making one two first second third often called also another may might must many much works worked title titled known includes including include described describes describe used uses use using like unlike along later earlier begins ends opens work whose").split(/\s+/).forEach(function (w) { STOP[w] = 1; });
  // Referent/pronoun words poison a "fact" no matter where they appear —
  // "form of this technique" tells you nothing. Blocked at EVERY position.
  var PRON = {};
  ("this these that those it its his her hers their theirs they them he she him you your one ones man woman author composer poet character work entity thing figure title titular").split(/\s+/).forEach(function (w) { PRON[w] = 1; });

  function splitSentencesWithPos(text) {
    // sentences plus their fractional start position within the question
    var clean = (text || "").replace(/\(\*\)/g, "");
    var total = clean.length || 1;
    var out = [], re = /(?<=[.!?…]["”’']?)\s+(?=["“‘']?[A-Z0-9(])/g, last = 0, m;
    while ((m = re.exec(clean))) {
      out.push({ s: clean.slice(last, m.index).trim(), pos: last / total });
      last = m.index + m[0].length;
    }
    if (last < clean.length) out.push({ s: clean.slice(last).trim(), pos: last / total });
    return out.filter(function (e) { return e.s; });
  }
  function toks(s) {
    return (s.toLowerCase().match(/[\p{L}\p{N}'’-]+/gu) || []).map(function (w) { return w.replace(/['’]s$/, ""); });
  }
  function gramsOfSent(words, skip) {
    var out = [];
    for (var i = 0; i < words.length; i++) {
      for (var L = 2; L <= 5; L++) {
        if (i + L > words.length) break;
        var g = words.slice(i, i + L);
        if (STOP[g[0]] || STOP[g[L - 1]]) continue;
        var bad = false;
        for (var k = 0; k < L; k++) if (PRON[g[k]] || skip[g[k]] || /^\d+$/.test(g[k]) || g[k].length < 2) { bad = true; break; }
        if (bad) continue;
        out.push(g.join(" "));
      }
    }
    return out;
  }

  // ── stars + review/folder integration ──
  function starred() { return ctx.storage.get("fs-stars") || []; }
  function starKey(it) { return (it.front || "") + "|" + (it.back || ""); }
  function isStarred(it) { var k = starKey(it); return starred().some(function (x) { return starKey(x) === k; }); }
  function toggleStar(it, el) {
    var lst = starred(), k = starKey(it), i = lst.findIndex(function (x) { return starKey(x) === k; });
    if (i >= 0) lst.splice(i, 1); else lst.push(it);
    ctx.storage.set("fs-stars", lst);
    if (ctx.playSound) ctx.playSound("star");
    if (el) { var on = i < 0; el.textContent = on ? "★" : "☆"; el.classList.toggle("on", on); }
  }
  function addToMenu(it, anchor) {
    var spec = { review: { kind: "fact", front: it.front, back: it.back, meta: "fact sheet" }, folder: { type: "facts", item: { front: it.front, back: it.back } } };
    if (ctx.host && ctx.host.openItemSaveMenu) ctx.host.openItemSaveMenu(spec, anchor);
    else if (window.QBFolders) window.QBFolders.pick("facts", spec.folder.item, anchor);
  }
  // Register a "Facts" folder type when the Folders plugin is around (now or later).
  var _foldersUnreg = null;
  function tryRegisterFolderType() {
    if (_foldersUnreg || !window.QBFolders || !window.QBFolders.registerType) return;
    _foldersUnreg = window.QBFolders.registerType({ key: "facts", label: "Facts", item: "fact", run: ["flashcards"] });
  }
  tryRegisterFolderType();
  ctx.on("plugins:changed", tryRegisterFolderType);
  ctx._unsub.push(function () { if (_foldersUnreg) { try { _foldersUnreg(); } catch (e) {} _foldersUnreg = null; } });

  // ── cascading category filters (same taxonomy the rest of the app uses) ──
  var ALT_SUBCATS = {
    "Other Science": ["Astronomy", "Computer Science", "Earth Science", "Engineering", "Math", "Misc Science"],
    "Other Literature": ["Drama", "Long Fiction", "Poetry", "Short Fiction", "Misc Literature"],
    "Other Fine Arts": ["Architecture", "Dance", "Film", "Jazz", "Musicals", "Opera", "Photography", "Misc Arts"],
    "Social Science": ["Anthropology", "Economics", "Linguistics", "Psychology", "Sociology", "Other Social Science"],
  };
  function fillSel(sel, arr, blank) {
    sel.innerHTML = '<option value="">' + blank + "</option>";
    arr.forEach(function (v) { var o = document.createElement("option"); o.value = v; o.textContent = v; sel.appendChild(o); });
  }
  async function onCatChange() {
    var cat = body.querySelector("#fs-cat").value, sub = body.querySelector("#fs-sub"), alt = body.querySelector("#fs-alt");
    fillSel(sub, [], "All subcategories"); fillSel(alt, [], "All alt subcats");
    if (!cat) return;
    if (cat === "Social Science") { fillSel(sub, ALT_SUBCATS["Social Science"], "All subcategories"); return; }
    try {
      var d = await ctx.api.get("/api/subcategories?type=tossups&category=" + encodeURIComponent(cat));
      if (body.querySelector("#fs-cat").value !== cat) return;
      fillSel(sub, ((d && d.subcategories) || []).map(function (s) { return s.subcategory; }).filter(Boolean), "All subcategories");
    } catch (e) {}
  }
  async function onSubChange() {
    var cat = body.querySelector("#fs-cat").value, sub = body.querySelector("#fs-sub").value, alt = body.querySelector("#fs-alt");
    fillSel(alt, [], "All alt subcats");
    if (!cat || !sub || cat === "Social Science") return;
    try {
      var d = await ctx.api.get("/api/alternate-subcategories?type=tossups&category=" + encodeURIComponent(cat) + "&subcategory=" + encodeURIComponent(sub));
      if (body.querySelector("#fs-sub").value !== sub) return;
      var alts = (d && d.alternateSubcategories) || [];
      if (!alts.length && /^Other /.test(sub) && ALT_SUBCATS[sub]) alts = ALT_SUBCATS[sub];
      fillSel(alt, alts, "All alt subcats");
    } catch (e) {}
  }
  function filterQs() {
    var cat = body.querySelector("#fs-cat").value, sub = body.querySelector("#fs-sub").value, alt = body.querySelector("#fs-alt").value;
    if (cat === "Social Science" && sub) { alt = sub; sub = ""; }
    var diffs = [].slice.call(body.querySelectorAll(".fs-diff-cb:checked")).map(function (c) { return c.value; });
    var ya = parseInt(body.querySelector("#fs-ymin").value), yb = parseInt(body.querySelector("#fs-ymax").value);
    var ymin = Math.min(ya, yb), ymax = Math.max(ya, yb);
    return (cat ? "&categories=" + encodeURIComponent(cat) : "") +
      (sub ? "&subcategories=" + encodeURIComponent(sub) : "") +
      (alt ? "&alternateSubcategories=" + encodeURIComponent(alt) : "") +
      (diffs.length ? "&difficulties=" + diffs.join(",") : "") +
      (ymin > 2000 ? "&yearMin=" + ymin : "") + (ymax < 2026 ? "&yearMax=" + ymax : "");
  }
  function posRange() {
    var a = parseInt(body.querySelector("#fs-plo").value), b = parseInt(body.querySelector("#fs-phi").value);
    return { lo: Math.min(a, b) / 100, hi: Math.max(a, b) / 100 };
  }
  function wireDual(loId, hiId, fillId, valId, fmt) {
    var lo = body.querySelector("#" + loId), hi = body.querySelector("#" + hiId), fill = body.querySelector("#" + fillId), val = body.querySelector("#" + valId);
    function sync() {
      var a = Math.min(parseInt(lo.value), parseInt(hi.value)), b = Math.max(parseInt(lo.value), parseInt(hi.value));
      var min = parseInt(lo.min), max = parseInt(lo.max);
      if (fill) { fill.style.left = ((a - min) / (max - min)) * 100 + "%"; fill.style.right = ((max - b) / (max - min)) * 100 + "%"; }
      if (val) val.textContent = fmt(a, b);
    }
    lo.addEventListener("input", sync); hi.addEventListener("input", sync); sync();
  }

  // P(answer | fact): of all questions containing the phrase (same
  // category/difficulty/year filters), how many are answered by the term?
  // Computed lazily per rendered card, cached.
  var _probCache = Object.create(null), _probGen = 0;
  function factProb(gram, targetTokens, filters, cb) {
    var key = gram + "|" + targetTokens.join(" ") + "|" + filters;
    if (_probCache[key]) { cb(_probCache[key]); return; }
    var quoted = gram.split(" ").map(function (t) { return '"' + t + '"'; }).join(" ");
    ctx.api.get("/api/tossups/search?query=" + encodeURIComponent("question_sanitized : (" + quoted + ")") + "&limit=400" + filters).then(function (d) {
      var rs = (d && d.rows) || [];
      var total = 0, hit = 0;
      var seq = gram.split(" ");
      rs.forEach(function (q) {
        var ws = toks((q.question_sanitized || "").replace(/\(\*\)/g, " "));
        var found = false;
        for (var i = 0; i + seq.length <= ws.length; i++) {
          var ok = true;
          for (var j = 0; j < seq.length; j++) if (ws[i + j] !== seq[j]) { ok = false; break; }
          if (ok) { found = true; break; }
        }
        if (!found) return;
        total++;
        var al = (q.answer_sanitized || "").toLowerCase();
        var match = true;
        for (var k = 0; k < targetTokens.length; k++) if (al.indexOf(targetTokens[k]) < 0) { match = false; break; }
        if (match) hit++;
      });
      var r = { p: total ? hit / total : 0, hit: hit, total: total };
      _probCache[key] = r;
      cb(r);
    }).catch(function () { cb(null); });
  }
  function fillFactProbs(out, targetTokens, filters) {
    var gen = ++_probGen;
    var cells = [].slice.call(out.querySelectorAll(".fs-prob[data-g]"));
    var idx = 0, workers = 0;
    function next() {
      if (gen !== _probGen) return;
      while (workers < 4 && idx < cells.length) {
        (function (cell) {
          workers++;
          factProb(cell.dataset.g, targetTokens, filters, function (r) {
            workers--;
            if (gen === _probGen && cell.isConnected) {
              cell.textContent = r && r.total ? "→ answer " + Math.round(100 * r.p) + "% (" + r.hit + "/" + r.total + ")" : "→ answer –";
              if (r && r.total && r.p >= 0.8) cell.classList.add("fs-prob-hi");
            }
            next();
          });
        })(cells[idx++]);
      }
    }
    next();
  }

  var _gen = 0;
  async function compile() {
    var gen = ++_gen;
    var term = (body.querySelector("#fs-input").value || "").trim();
    var out = body.querySelector("#fs-results");
    var topN = parseInt(body.querySelector("#fs-top").value) || 15;
    if (!term) { out.innerHTML = '<div class="text-muted">Type an answer first.</div>'; return; }
    out.innerHTML = loadBar("Reading every “" + esc(term) + "” question…");

    var tokens = toks(term);
    if (!tokens.length) { out.innerHTML = '<div class="text-muted">Nothing searchable in that.</div>'; return; }
    var quoted = tokens.map(function (t) { return '"' + t + '"'; }).join(" ");
    var rows = [];
    try { rows = (await ctx.api.get("/api/tossups/search?query=" + encodeURIComponent("answer_sanitized : (" + quoted + ")") + "&limit=500" + filterQs())).rows || []; }
    catch (e) { if (gen === _gen) out.innerHTML = '<div class="text-muted">Search failed: ' + esc(e.message || e) + "</div>"; return; }
    if (gen !== _gen) return;
    var qs = rows.filter(function (q) {
      var al = mainAnswer(q.answer_sanitized).toLowerCase();
      for (var i = 0; i < tokens.length; i++) if (al.indexOf(tokens[i]) < 0) return false;
      return true;
    });
    if (!qs.length) { out.innerHTML = '<div class="text-muted">No questions have “' + esc(term) + '” as their answer with these filters.</div>'; return; }

    var pr = posRange();
    var skip = {};
    tokens.forEach(function (t) { skip[t] = 1; });
    var facts = Object.create(null); // gram -> {docs, posSum, posN, best, bestLen}
    qs.forEach(function (q) {
      var seen = {};
      splitSentencesWithPos(q.question_sanitized || "").forEach(function (se) {
        if (se.pos < pr.lo || se.pos > pr.hi) return; // position filter
        var ws = toks(se.s);
        gramsOfSent(ws, skip).forEach(function (g) {
          var f = facts[g];
          if (!f) f = facts[g] = { docs: 0, posSum: 0, posN: 0, best: "", bestLen: 1e9 };
          f.posSum += se.pos; f.posN++;
          if (!seen[g]) { seen[g] = 1; f.docs++; }
          var sl = se.s.length;
          if (sl >= 40 && sl < f.bestLen) { f.best = se.s; f.bestLen = sl; }
          else if (!f.best) { f.best = se.s; f.bestLen = sl; }
        });
      });
    });
    var list = Object.keys(facts).map(function (g) { return { g: g, docs: facts[g].docs, avgPos: facts[g].posN ? facts[g].posSum / facts[g].posN : 0, best: facts[g].best, len: g.split(" ").length }; })
      .filter(function (e) { return e.docs >= 2; })
      .sort(function (a, b) { return b.docs - a.docs || b.len - a.len; });
    var head = list.slice(0, Math.max(topN * 6, 240)), drop = {};
    head.forEach(function (e) {
      head.forEach(function (o) {
        if (o === e || o.len <= e.len) return;
        if (o.g.indexOf(e.g) >= 0 && o.docs >= 0.8 * e.docs) drop[e.g] = 1;
      });
    });
    var kept = head.filter(function (e) { return !drop[e.g]; }).slice(0, topN);
    if (gen !== _gen) return;
    if (!kept.length) { out.innerHTML = '<div class="text-muted">Nothing recurs across these ' + qs.length + " questions in that position range.</div>"; return; }

    var prLabel = (pr.lo > 0 || pr.hi < 1) ? " · " + Math.round(pr.lo * 100) + "–" + Math.round(pr.hi * 100) + "% of the question" : "";
    out.innerHTML =
      '<div class="fs-meta">' + kept.length + " recurring facts · from " + qs.length + " question" + (qs.length === 1 ? "" : "s") + " answered by “" + esc(term) + "”" + prLabel + "</div>" +
      kept.map(function (e, i) {
        var hi = e.best;
        try { hi = esc(e.best).replace(new RegExp("(" + e.g.split(" ").map(function (w) { return w.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"); }).join("[\\s,;'’-]+") + ")", "i"), "<mark>$1</mark>"); } catch (err) { hi = esc(e.best); }
        var st = isStarred({ front: e.g, back: term });
        return '<div class="fs-card" data-g="' + esc(e.g) + '">' +
          '<div class="fs-card-head"><span class="fs-rank">' + (i + 1) + '</span><strong class="fs-gram">' + esc(e.g) + "</strong>" +
          '<span class="fs-avgpos" title="Average position of this fact within the question — earlier = harder clue">avg at ' + Math.round(100 * e.avgPos) + "%</span>" +
          '<span class="fs-prob" data-g="' + esc(e.g) + '" title="Of ALL questions containing this phrase (same filters), how many are answered by this term">…</span>' +
          '<span class="fs-badge">' + Math.round(100 * e.docs / qs.length) + "% · " + e.docs + "/" + qs.length + " questions</span>" +
          '<span class="fs-star' + (st ? " on" : "") + '" title="Star this fact">' + (st ? "★" : "☆") + "</span>" +
          '<span class="fs-foldx" title="Add to review / folder">+</span></div>' +
          (e.best ? '<div class="fs-example">' + hi + "</div>" : "") +
          "</div>";
      }).join("");

    fillFactProbs(out, tokens, filterQs());
    out.querySelectorAll(".fs-card").forEach(function (card) {
      var g = card.dataset.g;
      var it = { front: g, back: term };
      var st = card.querySelector(".fs-star");
      if (st) st.onclick = function (ev) { ev.stopPropagation(); toggleStar(it, st); };
      var fx = card.querySelector(".fs-foldx");
      if (fx) fx.onclick = function (ev) { ev.stopPropagation(); addToMenu(it, fx); };
      card.oncontextmenu = function (ev) {
        if (!window.QB || !QB.contextMenu) return;
        ev.preventDefault();
        var items = [];
        if (ctx.host && ctx.host.searchDatabase) items.push({ label: "Find questions containing this fact", onClick: function () { ctx.host.searchDatabase({ query: g, field: "question", exact: true, qtype: "tossup" }); } });
        items.push({ label: "Copy fact", onClick: function () { try { navigator.clipboard.writeText(g + " → " + term); QB.toast("Copied"); } catch (e2) {} } });
        items.push({ sep: true });
        items.push({ label: isStarred(it) ? "Unstar fact" : "Star fact", onClick: function () { toggleStar(it, st); } });
        items.push({ label: "Add to review / folder…", onClick: function () { addToMenu(it, card); } });
        QB.contextMenu(ev.clientX, ev.clientY, items, { title: g + " → " + term });
      };
      card.onclick = function () {
        if (ctx.host && ctx.host.searchDatabase) ctx.host.searchDatabase({ query: g, field: "question", exact: true, qtype: "tossup" });
      };
    });
  }

  async function render() {
    var diffBoxes = "";
    for (var d = 0; d <= 10; d++) diffBoxes += '<label class="fs-diff"><input type="checkbox" class="fs-diff-cb" value="' + d + '">' + d + "</label>";
    body.innerHTML =
      '<div class="fs-wrap">' +
        '<div class="fs-card-panel">' +
          '<div class="fs-row">' +
            '<input type="text" id="fs-input" class="mode-input" placeholder="Answer to study — e.g. Odysseus, entropy, Brahms…" autocomplete="off" autocorrect="off" spellcheck="false" style="flex:1;min-width:200px">' +
            '<select id="fs-top" class="mode-input" style="width:110px"><option value="10">Top 10</option><option value="15" selected>Top 15</option><option value="25">Top 25</option><option value="40">Top 40</option></select>' +
            '<button class="btn btn-primary" id="fs-go">Compile facts</button>' +
          "</div>" +
          '<div class="fs-row">' +
            '<select id="fs-cat" class="mode-input" style="flex:1;min-width:130px"><option value="">All categories</option></select>' +
            '<select id="fs-sub" class="mode-input" style="flex:1;min-width:130px"><option value="">All subcategories</option></select>' +
            '<select id="fs-alt" class="mode-input" style="flex:1;min-width:130px"><option value="">All alt subcats</option></select>' +
          "</div>" +
          '<div class="fs-row"><span class="fs-label">Difficulty</span>' + diffBoxes + "</div>" +
          '<div class="fs-row"><span class="fs-label">Years</span>' +
            '<div class="dual-range fs-dual"><div class="dual-range-track"><div class="dual-range-fill" id="fs-yfill"></div></div>' +
              '<input type="range" id="fs-ymin" min="2000" max="2026" value="2000"><input type="range" id="fs-ymax" min="2000" max="2026" value="2026"></div>' +
            '<span class="fs-label" id="fs-yval" style="min-width:84px;text-align:right"></span>' +
          "</div>" +
          '<div class="fs-row"><span class="fs-label">Position</span>' +
            '<div class="dual-range fs-dual"><div class="dual-range-track"><div class="dual-range-fill" id="fs-pfill"></div></div>' +
              '<input type="range" id="fs-plo" min="0" max="100" step="5" value="0"><input type="range" id="fs-phi" min="0" max="100" step="5" value="100"></div>' +
            '<span class="fs-label" id="fs-pval" style="min-width:84px;text-align:right"></span>' +
          "</div>" +
        "</div>" +
        '<div id="fs-results"><div class="text-muted">Type an answer and press Compile.</div></div>' +
      "</div>";
    body.querySelector("#fs-go").onclick = compile;
    body.querySelector("#fs-input").addEventListener("keydown", function (e) { if (e.key === "Enter") compile(); });
    body.querySelector("#fs-cat").addEventListener("change", onCatChange);
    body.querySelector("#fs-sub").addEventListener("change", onSubChange);
    wireDual("fs-ymin", "fs-ymax", "fs-yfill", "fs-yval", function (a, b) { return a + " – " + b; });
    wireDual("fs-plo", "fs-phi", "fs-pfill", "fs-pval", function (a, b) { return a + "% – " + b + "%"; });
    try {
      var d = await ctx.api.get("/api/categories?type=tossups");
      var sel = body.querySelector("#fs-cat");
      ((d && d.categories) || []).forEach(function (c) { var o = document.createElement("option"); o.value = c.category; o.textContent = c.category; sel.appendChild(o); });
    } catch (e) {}
  }

  // ── Database tab: saved facts ──
  ctx.registerStarredProvider({
    id: "fact-sheet", title: "Facts",
    render: function (container) {
      var list = starred();
      if (!list.length) { container.innerHTML = '<div class="text-muted" style="padding:16px">No saved facts yet — ★ a fact in Fact Sheet.</div>'; return; }
      var bar = '<div class="db-toolbar"><button class="btn btn-sm btn-primary" id="fs-review">▶ Review as flashcards</button>' +
        '<span class="text-muted" style="font-size:11px">' + list.length + " saved</span></div>";
      container.innerHTML = bar + '<table class="stats-table"><thead><tr><th></th><th>Fact</th><th>Answer</th></tr></thead><tbody>' +
        list.map(function (it, i) {
          return '<tr><td><span class="fs-star on" data-i="' + i + '" title="Unstar">★</span></td><td>' + esc(it.front) + "</td><td><strong>" + esc(it.back) + "</strong></td></tr>";
        }).join("") + "</tbody></table>";
      container.querySelectorAll(".fs-star").forEach(function (s) {
        s.addEventListener("click", function () { var it = list[parseInt(s.dataset.i)]; if (it) toggleStar(it, s); });
      });
      var rv = container.querySelector("#fs-review");
      if (rv) rv.onclick = function () {
        var cards = starred().map(function (it) { return { front: it.front, back: it.back, meta: "fact" }; });
        if (!cards.length) { ctx.toast("Nothing saved", "error"); return; }
        try { localStorage.setItem("qb-flashcards-cards", JSON.stringify({ cards: cards, ts: Date.now() })); } catch (e) {}
        if (!(window.QB && window.QB.showPage && window.QB.showPage("flashcards::cards"))) ctx.toast("Enable the Flashcards plugin first", "error");
      };
    },
  });

  page = ctx.registerPage({
    id: "facts", navLabel: "Fact Sheet", title: "FACT SHEET",
    onShow: function (el) {
      body = el;
      if (!body.querySelector("#fs-input")) render();
      try {
        var h = JSON.parse(localStorage.getItem("qb-facts-handoff") || "null");
        if (h && h.term) {
          localStorage.removeItem("qb-facts-handoff");
          var tries = 0;
          (function apply() {
            var inp = body.querySelector("#fs-input");
            if (!inp) { if (tries++ < 20) setTimeout(apply, 60); return; }
            inp.value = h.term;
            compile();
          })();
        }
      } catch (e) {}
    },
  });
}
