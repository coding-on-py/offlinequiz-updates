function __qbMain(ctx) {
  var body = null, page = null;

  function esc(s) { return (s == null ? "" : String(s)).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
  function loadBar(label) { return (window.QB && QB.loadingBarHtml) ? QB.loadingBarHtml(label) : '<div class="text-muted">' + esc(label) + "</div>"; }
  function mainAnswer(sani) { return (sani || "").split(/[\[(]/)[0].trim().replace(/[;:,.]+$/, ""); }

  var STOP = {};
  ("a an the this that these those it its his her hers he she they them their we us our you your i me my of in on at to for from with within without by as is are was were be been being am do does did done not no nor so or and but if then than because while during after before until once when where which who whom whose what why how all any both each few more most other some such only own same here there over under again further about above below between into through against up down out off very can will just should now points point name names named ftp identify gives give given made make makes making one two first second third often called also another may might must many much works worked title titled known includes including include described describes describe used uses use using like unlike along later earlier begins ends opens whose work").split(/\s+/).forEach(function (w) { STOP[w] = 1; });

  // ── fact mining ────────────────────────────────────────────
  // Sentences from every question answered by X are mined for recurring
  // 2–5-word phrases (skipping stopwords at the edges and the answer's own
  // words). Each surviving phrase becomes a "fact" shown with its best
  // (shortest) real example sentence and how many questions mention it.
  function splitSentences(text) {
    return (text || "").replace(/\(\*\)/g, "")
      .split(/(?<=[.!?…]["”’']?)\s+(?=["“‘']?[A-Z0-9(])/)
      .map(function (c) { return c.trim(); })
      .filter(Boolean);
  }
  function toks(s) {
    return (s.toLowerCase().match(/[\p{L}\p{N}'’-]+/gu) || []).map(function (w) { return w.replace(/['’]s$/, ""); });
  }
  function gramsOfSent(words, skip) {
    var out = [];
    for (var i = 0; i < words.length; i++) {
      for (var L = 2; L <= 5; L++) {
        if (i + L > words.length) break;
        var g = words.slice(i, i + L);
        if (STOP[g[0]] || STOP[g[L - 1]]) continue;
        var bad = false;
        for (var k = 0; k < L; k++) if (skip[g[k]] || /^\d+$/.test(g[k]) || g[k].length < 2) { bad = true; break; }
        if (bad) continue;
        out.push(g.join(" "));
      }
    }
    return out;
  }

  var _gen = 0;
  async function compile() {
    var gen = ++_gen;
    var term = (body.querySelector("#fs-input").value || "").trim();
    var out = body.querySelector("#fs-results");
    var topN = parseInt(body.querySelector("#fs-top").value) || 15;
    var cat = body.querySelector("#fs-cat").value;
    if (!term) { out.innerHTML = '<div class="text-muted">Type an answer first — e.g. Odysseus, entropy, Brahms.</div>'; return; }
    out.innerHTML = loadBar("Reading every “" + esc(term) + "” question…");

    var tokens = toks(term);
    if (!tokens.length) { out.innerHTML = '<div class="text-muted">Nothing searchable in that.</div>'; return; }
    var quoted = tokens.map(function (t) { return '"' + t + '"'; }).join(" ");
    var url = "/api/tossups/search?query=" + encodeURIComponent("answer_sanitized : (" + quoted + ")") + "&limit=500" +
      (cat ? "&categories=" + encodeURIComponent(cat) : "");
    var rows = [];
    try { rows = (await ctx.api.get(url)).rows || []; } catch (e) { if (gen === _gen) out.innerHTML = '<div class="text-muted">Search failed: ' + esc(e.message || e) + "</div>"; return; }
    if (gen !== _gen) return;
    // keep only questions whose PRIMARY answer really is the term
    var qs = rows.filter(function (q) {
      var al = mainAnswer(q.answer_sanitized).toLowerCase();
      for (var i = 0; i < tokens.length; i++) if (al.indexOf(tokens[i]) < 0) return false;
      return true;
    });
    if (!qs.length) { out.innerHTML = '<div class="text-muted">No questions have “' + esc(term) + '” as their answer' + (cat ? " in " + esc(cat) : "") + ". Check the spelling, or try the broader match below.</div>"; return; }

    var skip = {};
    tokens.forEach(function (t) { skip[t] = 1; });
    var facts = Object.create(null); // gram -> {docs, total, best (shortest example), bestLen}
    qs.forEach(function (q) {
      var seen = {};
      splitSentences(q.question_sanitized || "").forEach(function (sent) {
        var ws = toks(sent);
        gramsOfSent(ws, skip).forEach(function (g) {
          var f = facts[g];
          if (!f) f = facts[g] = { docs: 0, total: 0, best: "", bestLen: 1e9 };
          f.total++;
          if (!seen[g]) { seen[g] = 1; f.docs++; }
          var sl = sent.length;
          if (sl >= 40 && sl < f.bestLen) { f.best = sent; f.bestLen = sl; }
          else if (!f.best && sl < f.bestLen) { f.best = sent; f.bestLen = sl; }
        });
      });
    });
    // Longest-phrase-wins: drop grams contained in a longer gram with ≥80% of
    // its coverage, so "blinded polyphemus" survives and "polyphemus" alone
    // doesn't crowd it out unless it's genuinely more widespread.
    var list = Object.keys(facts).map(function (g) { return { g: g, docs: facts[g].docs, total: facts[g].total, best: facts[g].best, len: g.split(" ").length }; })
      .filter(function (e) { return e.docs >= 2; })
      .sort(function (a, b) { return b.docs - a.docs || b.len - a.len; });
    var head = list.slice(0, Math.max(topN * 6, 240));
    var kept = [], drop = {};
    head.forEach(function (e) {
      if (drop[e.g]) return;
      head.forEach(function (o) {
        if (o === e || o.len <= e.len) return;
        if (o.g.indexOf(e.g) >= 0 && o.docs >= 0.8 * e.docs) { drop[e.g] = 1; }
      });
    });
    head.forEach(function (e) { if (!drop[e.g]) kept.push(e); });
    kept = kept.slice(0, topN);
    if (gen !== _gen) return;
    if (!kept.length) { out.innerHTML = '<div class="text-muted">Nothing recurs across these ' + qs.length + " questions — not enough material for a fact sheet.</div>"; return; }

    out.innerHTML =
      '<div class="fs-meta">' + kept.length + " recurring facts · from " + qs.length + " question" + (qs.length === 1 ? "" : "s") + " answered by “" + esc(term) + "”" + (cat ? " · " + esc(cat) : "") + " · sorted by how often they come up</div>" +
      kept.map(function (e, i) {
        var hi = e.best;
        try { hi = esc(e.best).replace(new RegExp("(" + e.g.split(" ").map(function (w) { return w.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"); }).join("[\\s,;'’-]+") + ")", "i"), "<mark>$1</mark>"); } catch (err) { hi = esc(e.best); }
        return '<div class="fs-card" data-g="' + esc(e.g) + '">' +
          '<div class="fs-card-head"><span class="fs-rank">' + (i + 1) + '</span><strong class="fs-gram">' + esc(e.g) + "</strong>" +
          '<span class="fs-badge" title="Share of this answer\'s questions that mention it">' + Math.round(100 * e.docs / qs.length) + "% · " + e.docs + "/" + qs.length + " questions</span></div>" +
          (e.best ? '<div class="fs-example">' + hi + "</div>" : "") +
          "</div>";
      }).join("");

    out.querySelectorAll(".fs-card").forEach(function (card) {
      card.oncontextmenu = function (ev) {
        if (!window.QB || !QB.contextMenu) return;
        ev.preventDefault();
        var g = card.dataset.g;
        var items = [];
        if (ctx.host && ctx.host.searchDatabase) items.push({ label: "Find questions containing this fact", onClick: function () { ctx.host.searchDatabase({ query: g, field: "question", exact: true, qtype: "tossup" }); } });
        items.push({ label: "Copy fact", onClick: function () { try { navigator.clipboard.writeText(g + " → " + term); QB.toast("Copied"); } catch (e2) {} } });
        if (ctx.host && ctx.host.itemReviewAdd) { items.push({ sep: true }); items.push({ label: "Save to review", onClick: function () { ctx.host.itemReviewAdd({ kind: "fact", front: g, back: term, meta: "fact sheet" }); } }); }
        QB.contextMenu(ev.clientX, ev.clientY, items, { title: g + " → " + term });
      };
      card.onclick = function () {
        if (ctx.host && ctx.host.searchDatabase) ctx.host.searchDatabase({ query: card.dataset.g, field: "question", exact: true, qtype: "tossup" });
      };
    });
  }

  async function render() {
    body.innerHTML =
      '<div class="fs-wrap">' +
        '<div class="fs-card-panel">' +
          '<div class="fs-row">' +
            '<input type="text" id="fs-input" class="mode-input" placeholder="Answer to study — e.g. Odysseus, entropy, Brahms…" autocomplete="off" autocorrect="off" spellcheck="false" style="flex:1;min-width:200px">' +
            '<select id="fs-cat" class="mode-input" style="width:170px"><option value="">All categories</option></select>' +
            '<select id="fs-top" class="mode-input" style="width:110px"><option value="10">Top 10</option><option value="15" selected>Top 15</option><option value="25">Top 25</option><option value="40">Top 40</option></select>' +
            '<button class="btn btn-primary" id="fs-go">Compile facts</button>' +
          "</div>" +
          '<div class="fs-hint text-muted">The most common clues, stories, and associations for an answer — what you should know when it comes up. Click a fact to see its questions; right-click for more.</div>' +
        "</div>" +
        '<div id="fs-results"><div class="text-muted">Type an answer and press Compile.</div></div>' +
      "</div>";
    body.querySelector("#fs-go").onclick = compile;
    body.querySelector("#fs-input").addEventListener("keydown", function (e) { if (e.key === "Enter") compile(); });
    try {
      var d = await ctx.api.get("/api/categories?type=tossups");
      var sel = body.querySelector("#fs-cat");
      ((d && d.categories) || []).forEach(function (c) { var o = document.createElement("option"); o.value = c.category; o.textContent = c.category; sel.appendChild(o); });
    } catch (e) {}
  }

  page = ctx.registerPage({
    id: "facts", navLabel: "Fact Sheet", title: "FACT SHEET",
    onShow: function (el) {
      body = el;
      if (!body.querySelector("#fs-input")) render();
      try {
        var h = JSON.parse(localStorage.getItem("qb-facts-handoff") || "null");
        if (h && h.term) {
          localStorage.removeItem("qb-facts-handoff");
          var tries = 0;
          (function apply() {
            var inp = body.querySelector("#fs-input");
            if (!inp) { if (tries++ < 20) setTimeout(apply, 60); return; }
            inp.value = h.term;
            compile();
          })();
        }
      } catch (e) {}
    },
  });
}
