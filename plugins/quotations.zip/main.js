/**
 * OfflineQuiz plugin: Quotations
 *
 * Lines quoted in tossups, alone. Each comes with what the tossup asks for ("name this author"),
 * and after you answer, the whole question with the quote marked.
 */
QB.registerPlugin({
  id: "quotations",
  name: "Quotations",
  version: "2.0.0",
  author: "OfflineQuiz",
  description: "Identify works and authors from the passages questions quote, a drill for literature clues.",
  onEnable: __qbMain,
  onDisable: function (ctx) { if (ctx._cleanup) ctx._cleanup(); },
});
