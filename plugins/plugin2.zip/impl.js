function __qbMain(ctx) {
  var body = null, page = null;

  var RELAY = "https://offlinequiz-mp-relay.warren2028045.workers.dev";
  function esc(s) { return (s == null ? "" : String(s)).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }

  // ── identity ────────────────────────────────────────────────────────────
  // PER-PROFILE identity and upload bookkeeping: two students sharing one
  // computer under different profiles must be two records on the dashboard,
  // and the change fingerprint must never compare one profile's upload
  // against another profile's numbers (machine-wide storage did exactly that
  // — the two profiles overwrote each other's record every launch). The old
  // machine-wide id is adopted by the FIRST profile to use v1.6 (one-time
  // claim, name + last-upload migrated with it) so an existing record keeps
  // its history; other profiles generate fresh ids.
  //
  // ctx.profileStorage is ASYNC (API-backed) — calling it like ctx.storage
  // hands back Promises, which once turned userId() into "[object Promise]"
  // and silently 400'd every upload. A write-through cache fronts it: every
  // key is loaded once (pready), reads are then synchronous, writes update
  // the cache and fire the async persist. EVERY entry point awaits pready.
  var _pcache = {}, _hasProfile = !!ctx.profileStorage;
  // Loaded values are VALIDATED: v1.6/1.7 builds briefly wrote Promises that
  // serialized as {} (or worse) into these keys — junk must read as "absent"
  // so identity regenerates and the machine-id migration can still claim.
  function isPlainObj(v) { return !!v && typeof v === "object" && !Array.isArray(v); }
  var PVALID = {
    "user-id": function (v) { return typeof v === "string" && /^[A-Za-z0-9_-]{1,64}$/.test(v); },
    "display-name": function (v) { return typeof v === "string"; },
    "last-upload": function (v) { return isPlainObj(v) && typeof v.at === "number"; },
    "ach-dates": isPlainObj, "search-base": isPlainObj, "search-daily": isPlainObj,
  };
  var PKEYS = Object.keys(PVALID);
  var pready = !_hasProfile ? Promise.resolve() : Promise.all(PKEYS.map(function (k) {
    return Promise.resolve(ctx.profileStorage.get(k))
      .then(function (v) { _pcache[k] = (v != null && PVALID[k](v)) ? v : null; })
      .catch(function () { _pcache[k] = null; });
  }));
  var pstore = _hasProfile ? {
    get: function (k) { return _pcache[k] == null ? null : _pcache[k]; },
    set: function (k, v) { _pcache[k] = v; try { ctx.profileStorage.set(k, v); } catch (e) {} },
  } : ctx.storage;
  function userId() {
    var id = pstore.get("user-id");
    if (!id && ctx.profileStorage) {
      var legacy = ctx.storage.get("user-id");
      if (legacy && !ctx.storage.get("user-id-claimed")) {
        ctx.storage.set("user-id-claimed", true);
        id = legacy;
        var ln = ctx.storage.get("display-name"); if (ln && !pstore.get("display-name")) pstore.set("display-name", ln);
        var lu = ctx.storage.get("last-upload"); if (lu && !pstore.get("last-upload")) pstore.set("last-upload", lu);
      }
    }
    if (!id) id = "u" + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
    pstore.set("user-id", id);
    return id;
  }
  pready.then(function () { userId(); });   // one-time migration, after the cache loads
  function displayName() {
    var n = pstore.get("display-name");
    if (n) return n;
    try { var st = ctx.getState && ctx.getState(); if (st && st.username) return st.username; } catch (e) {}
    return "";
  }
  // Everyone who installs this plugin reports to the same pool — there is no
  // class code to hand out and nothing to type. The dashboard plugin reads the
  // same pool.
  var POOL = "everyone";
  function lastUpload() { return pstore.get("last-upload") || null; }
  function dayKeyOf(dt) { return dt.getFullYear() + "-" + String(dt.getMonth() + 1).padStart(2, "0") + "-" + String(dt.getDate()).padStart(2, "0"); }

  // ── snapshot ────────────────────────────────────────────────────────────
  // One self-contained picture of this student's state. The server upserts it
  // by (class, user), so uploading twice is a no-op — which is exactly why a
  // failed upload can always be retried without any bookkeeping.
  async function buildSnapshot() {
    await pready;
    var snap = {
      userId: userId(),
      name: displayName() || "(unnamed)",
      builtAt: Date.now(),
      stats: {},
      achievements: [],
      starred: { tossups: 0, bonuses: 0 },
      searches: [],
      buzzes: [],
    };

    try {
      var sd = await ctx.api.get("/api/stats");
      var s = (sd && sd.stats) || {};
      snap.stats = {
        totalQuestions: s.totalQuestions || 0,
        totalPoints: s.totalPoints || 0,
        pointsPerQuestion: +(s.averagePointsPerQuestion || 0).toFixed(2),
        tossupAccuracy: +(((s.tossupAccuracy || 0) * 100)).toFixed(1),
        powers: s.tossupPowers || 0,
        negs: s.tossupNegs || 0,
        avgCelerity: +(((s.tossupAvgCelerity || 0) * 100)).toFixed(1),
        bonusesHeard: s.bonusesAttempted || 0,
        ppb: +(s.bonusConversion || 0).toFixed(2),
      };
    } catch (e) {}

    // getEarnedAchievements landed in app 11.2. On an older base the method is
    // simply absent, and silently reporting "0 achievements" would be a wrong
    // number rather than a missing one — so flag it and say so on the page.
    try {
      if (ctx.host && ctx.host.getEarnedAchievements) {
        var achs = await ctx.host.getEarnedAchievements();
        snap.achievements = (achs || []).filter(function (a) { return a.earned; }).map(function (a) { return a.id; });
        snap.achievementNames = {};
        (achs || []).forEach(function (a) { if (a.earned) snap.achievementNames[a.id] = a.name; });
      } else {
        snap.achievementsUnavailable = true;
      }
    } catch (e) {
      snap.achievementsUnavailable = true;
    }

    // Earned-at dates for the dashboard's time ranges. The base app computes
    // achievements from stats and stores NO earn timestamp, so class-sync
    // stamps each id the first time IT sees it earned (accurate to the upload
    // cadence: launch + session end). Ids already earned when this feature
    // first runs get 0 = "before tracking": they count all-time but never in
    // today/week/month — a wrong old date is worse than none.
    if (!snap.achievementsUnavailable) {
      try {
        var seenAch = pstore.get("ach-dates") || null;
        var firstAchRun = !seenAch;
        seenAch = seenAch || {};
        (snap.achievements || []).forEach(function (id) {
          if (!(id in seenAch)) seenAch[id] = firstAchRun ? 0 : Date.now();
        });
        pstore.set("ach-dates", seenAch);
        snap.achievementDates = {};
        (snap.achievements || []).forEach(function (id) { snap.achievementDates[id] = seenAch[id] || 0; });
      } catch (e) {}
    }

    try {
      var t = await ctx.api.get("/api/starred?type=tossup");
      var b = await ctx.api.get("/api/starred?type=bonus");
      snap.starred = { tossups: ((t && t.starred) || []).length, bonuses: ((b && b.starred) || []).length };
    } catch (e) {}

    // Per-day practice buckets — what lets the dashboard show "today / last
    // week / last month" views. Keyed by the student's LOCAL calendar date.
    // q/pts/pow/neg/cor are tossups; bq/bpts are bonuses (count + total pts).
    try {
      var de = await ctx.api.get("/api/sessions/all-entries");
      var ents = (de && de.entries) || [];
      var daily = {};
      for (var di = 0; di < ents.length; di++) {
        var en2 = ents[di];
        if (!en2 || !en2.timestamp) continue;
        var dt = new Date(en2.timestamp);
        if (isNaN(dt.getTime())) continue;
        var dk = dt.getFullYear() + "-" + String(dt.getMonth() + 1).padStart(2, "0") + "-" + String(dt.getDate()).padStart(2, "0");
        var db2 = daily[dk] || (daily[dk] = { q: 0, pts: 0, pow: 0, neg: 0, cor: 0, bq: 0, bpts: 0 });
        var pts2 = en2.points || 0;
        if (en2.type === "bonus") { db2.bq++; db2.bpts += pts2; }
        else {
          db2.q++; db2.pts += pts2;
          if (pts2 >= 15) db2.pow++;
          if (pts2 < 0) db2.neg++;
          if (en2.correct) db2.cor++;
        }
      }
      snap.daily = daily;
    } catch (e) {}

    // Fact Sheet searches (absolute totals).
    var searched = [];
    try { if (window.QBFactSheet && window.QBFactSheet.searches) searched = window.QBFactSheet.searches(); } catch (e) {}
    snap.searches = searched.map(function (x) { return { term: x.term, count: x.count, last: x.last }; });

    // Per-day search buckets. Fact Sheet keeps only per-term totals + a "last
    // searched" time, so class-sync tracks DELTAS: any growth since the stored
    // baseline is attributed to the day of that term's last search (uploads
    // run at launch + session end, so deltas are effectively same-day). The
    // first run just records the baseline — pre-existing searches stay
    // all-time only rather than dumping into "today".
    try {
      var sBase = pstore.get("search-base") || null;
      var sFirstRun = !sBase;
      sBase = sBase || {};
      var sDaily = pstore.get("search-daily") || {};
      var todayKey = dayKeyOf(new Date());
      searched.forEach(function (x) {
        var d = (x.count || 0) - (sBase[x.term] || 0);
        if (d > 0 && !sFirstRun) {
          var dk3 = x.last ? dayKeyOf(new Date(x.last)) : todayKey;
          if (!/^\d{4}-\d{2}-\d{2}$/.test(dk3)) dk3 = todayKey;   // bogus `last` timestamp
          sDaily[dk3] = (sDaily[dk3] || 0) + d;
        }
        sBase[x.term] = x.count || 0;
      });
      pstore.set("search-base", sBase);
      pstore.set("search-daily", sDaily);
      snap.searchDaily = sDaily;
    } catch (e) {}

    // Only questions whose ANSWER the student looked up in Fact Sheet — the
    // rest of their practice history never leaves the machine. The base app
    // resolves every answer in one call (?answers=1) using the same
    // normalization applied to the search terms here, so this is a set
    // membership test rather than fuzzy substring matching, and it costs one
    // request no matter how long the student's history is.
    if (searched.length) {
      var norm = function (s) { return String(s || "").toLowerCase().replace(/[^a-z0-9]+/g, " ").trim(); };
      var want = {};
      searched.forEach(function (x) { var k = norm(x.term); if (k) want[k] = 1; });
      try {
        var d = await ctx.api.get("/api/sessions/all-entries?answers=1");
        var entries = (d && d.entries) || [];
        for (var i = entries.length - 1; i >= 0 && snap.buzzes.length < 400; i--) {
          var en = entries[i];
          if (!en.question_id || !en.answer) continue;
          var norms = en.answer_norms || [];
          var hit = false;
          for (var n = 0; n < norms.length; n++) { if (want[norms[n]]) { hit = true; break; } }
          if (!hit) continue;
          snap.buzzes.push({
            questionId: en.question_id,
            answer: en.answer,
            given: en.given_answer || "",
            buzzPosition: en.buzz_position != null ? en.buzz_position : null,
            celerity: en.celerity != null ? +Number(en.celerity).toFixed(3) : null,
            points: en.points != null ? en.points : null,
            category: en.category || "",
            type: en.type || "tossup",
            at: en.timestamp || null,
          });
        }
      } catch (e) {}
    }
    return snap;
  }

  // ── change detection ─────────────────────────────────────────────────────
  // A cheap fingerprint of everything the snapshot reports, gathered WITHOUT the
  // expensive part (resolving every session entry's answer to match it against
  // Fact Sheet searches). Auto-uploads compare this first and skip entirely when
  // nothing has moved, so an idle app never does the heavy work — or the POST.
  async function changeSignature() {
    await pready;
    // n: renaming yourself must trigger a re-upload even when no question was
    // played — the confirmed failure was a student stuck as "(unnamed)".
    var sig = { q: 0, p: 0, s: 0, st: 0, b: 0, n: displayName() || "(unnamed)" };
    try {
      var sd = await ctx.api.get("/api/stats");
      var s = (sd && sd.stats) || {};
      sig.q = s.totalQuestions || 0;
      sig.p = s.totalPoints || 0;
      // Bonuses too: a bonus-only session scoring 0 points changes the daily
      // buckets without moving q or p, and must still trigger an upload.
      sig.b = s.bonusesAttempted || 0;
    } catch (e) {
      return null;   // can't tell — treat as "unknown" and let the upload proceed
    }
    try {
      var t = await ctx.api.get("/api/starred?type=tossup");
      var b = await ctx.api.get("/api/starred?type=bonus");
      sig.st = ((t && t.starred) || []).length + ((b && b.starred) || []).length;
    } catch (e) {}
    try {
      if (window.QBFactSheet && window.QBFactSheet.searches) {
        sig.s = window.QBFactSheet.searches().reduce(function (a, x) { return a + (x.count || 0); }, 0);
      }
    } catch (e) {}
    return sig;
  }
  function sigEqual(a, b) {
    return !!a && !!b && a.q === b.q && a.p === b.p && a.s === b.s && a.st === b.st && (a.b || 0) === (b.b || 0) && (a.n || "") === (b.n || "");
  }
  function snapshotSignature(snap) {
    return {
      q: snap.stats.totalQuestions || 0,
      p: snap.stats.totalPoints || 0,
      s: (snap.searches || []).reduce(function (a, x) { return a + (x.count || 0); }, 0),
      st: (snap.starred.tossups || 0) + (snap.starred.bonuses || 0),
      b: snap.stats.bonusesHeard || 0,
      n: snap.name || "(unnamed)",
    };
  }

  // ── transport ────────────────────────────────────────────────────────────
  // Headless: no DOM. Auto-uploads run whether or not the page is open, so the
  // network call and the success bookkeeping live here and the UI wraps it.
  async function sendSnapshot(snap) {
    var res = await fetch(RELAY + "/class/" + POOL + "/user/" + encodeURIComponent(snap.userId), {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(snap),
    });
    var out = null;
    try { out = await res.json(); } catch (e) {}
    if (!res.ok) throw new Error((out && out.error) || ("server said " + res.status));
    // A relay without the class endpoints answers EVERY path with a 200
    // plain-text banner, so res.ok alone would report a success that stored
    // nothing. Require the endpoint's own acknowledgement.
    if (!out || out.ok !== true) throw new Error("NOT_DEPLOYED");
    // Only recorded AFTER a confirmed response. If anything above threw nothing
    // is marked, so the next attempt re-sends — which the server upsert makes
    // harmless.
    pstore.set("last-upload", {
      ok: true,
      at: Date.now(),
      achievements: snap.achievements || [],
      searchTotal: (snap.searches || []).reduce(function (a, x) { return a + (x.count || 0); }, 0),
      totalQuestions: snap.stats.totalQuestions || 0,
      sig: snapshotSignature(snap),
    });
    return out;
  }

  function uploadErrorText(msg) {
    return /NOT_DEPLOYED|not configured/i.test(msg)
      ? "Nothing was uploaded — the class server isn’t set up yet. Ask whoever runs it to deploy the relay’s class storage."
      : /Failed to fetch|NetworkError|load failed/i.test(msg)
      ? "Couldn’t reach the server — check your internet and try again."
      : "Upload failed: " + msg;
  }

  async function upload(snap, statusEl, btn) {
    btn.disabled = true;
    statusEl.innerHTML = '<span class="text-muted">Uploading…</span>';
    try {
      await sendSnapshot(snap);
      // Re-render first so the "Last upload" line refreshes, then write the
      // result onto the NEW status node — otherwise the rebuild wipes it.
      render();
      var after = body && body.querySelector("#cs-status");
      if (after) {
        after.innerHTML = '<span class="cs-good">Uploaded</span>' +
          // Only ever shown on an app too old to report achievements, so the
          // page stays bare in the normal case without silently sending a zero.
          (snap.achievementsUnavailable ? ' <span class="cs-warn">· achievements need app 11.2+</span>' : "");
      }
      ctx.toast("Your data was uploaded");
    } catch (e) {
      statusEl.innerHTML = '<span class="cs-bad">' + esc(uploadErrorText(String((e && e.message) || e))) + "</span>";
      btn.disabled = false;
    }
  }

  // ── automatic uploads ────────────────────────────────────────────────────
  // Fires on app launch, on enabling the plugin, and at the end of a practice
  // session. Silent by design: a failure just leaves the marker untouched so the
  // next trigger retries, which the idempotent upsert makes free.
  var _autoBusy = false;
  function autoEnabled() { return ctx.storage.get("auto-upload") !== false; }

  async function autoUpload(reason) {
    if (!autoEnabled() || _autoBusy) return false;
    _autoBusy = true;
    try {
      var prev = lastUpload();
      var sig = await changeSignature();
      // A previous SUCCESS with an identical fingerprint means there is nothing
      // to send. Anything else — never uploaded, last one failed, no fingerprint
      // stored, or the probe itself failed — falls through and uploads.
      if (prev && prev.ok && prev.sig && sigEqual(sig, prev.sig)) return false;
      var snap = await buildSnapshot();
      if (!snap) return false;
      await sendSnapshot(snap);
      // Refresh the "Last upload" line if the student happens to be looking.
      if (body && body.querySelector("#cs-upload")) render();
      return true;
    } catch (e) {
      // Deliberately quiet: an offline app would otherwise nag on every launch.
      return false;
    } finally {
      _autoBusy = false;
    }
  }

  function render() {
    if (!body) return;
    var last = lastUpload();
    body.innerHTML =
      '<div class="cs-wrap"><div class="cs-card">' +
        '<div class="cs-title">Class Sync is on</div>' +
        '<div class="cs-row"><span class="cs-lbl">Your name<span class="qb-info" data-tip="How you appear on your teacher’s list">i</span></span><input id="cs-name" class="mode-input" value="' + esc(displayName()) + '" autocomplete="off"></div>' +
        '<div class="cs-actions"><button class="btn btn-primary" id="cs-upload">Upload my data</button>' +
          '<span class="cs-status" id="cs-status">' + (last && last.ok ? '<span class="text-muted">Last upload: ' + new Date(last.at).toLocaleString() + "</span>" : "") + "</span></div>" +
        '<label class="cs-auto"><input type="checkbox" id="cs-auto"' + (autoEnabled() ? " checked" : "") + "> Upload automatically</label>" +
      "</div></div>";

    body.querySelector("#cs-name").onchange = function (e) { pstore.set("display-name", e.target.value.trim()); };
    body.querySelector("#cs-auto").onchange = function (e) {
      ctx.storage.set("auto-upload", !!e.target.checked);
      if (e.target.checked) autoUpload("toggled-on");
    };

    var btn = body.querySelector("#cs-upload");
    // The snapshot is gathered on press rather than on page load: there is no
    // preview to keep current, and it means the upload always sends the very
    // latest numbers.
    btn.onclick = async function () {
      var statusEl = body.querySelector("#cs-status");
      btn.disabled = true;
      statusEl.innerHTML = '<span class="text-muted">Reading your data\u2026</span>';
      var snap = null;
      try { snap = await buildSnapshot(); } catch (e) {}
      if (!snap) {
        statusEl.innerHTML = '<span class="cs-bad">Couldn\u2019t read your data \u2014 try again.</span>';
        btn.disabled = false;
        return;
      }
      await upload(snap, statusEl, btn);
    };
  }

  page = ctx.registerPage({
    id: "sync", navLabel: "Class Sync", title: "CLASS SYNC",
    // render only after the profile cache loads — name and "last upload"
    // would otherwise paint from an empty cache.
    onShow: function (el) { body = el; pready.then(function () { if (body === el) render(); }); },
  });

  // Trigger 1 + 2: app launch and enabling the plugin are the same hook —
  // onEnable runs at boot for an already-enabled plugin, and again if the
  // student turns it on. Deferred so a slow first upload never delays startup.
  var _bootTimer = setTimeout(function () { autoUpload("launch"); }, 4000);
  if (ctx._unsub) ctx._unsub.push(function () { clearTimeout(_bootTimer); });

  // Trigger 3: the end of a practice session, when the numbers have actually
  // moved. Small delay so the final question's row is written first.
  // Guarded: on an older base without ctx.on, the plugin still loads and the
  // launch trigger plus the manual button keep working.
  if (ctx.on) {
    ctx.on("session:end", function () {
      setTimeout(function () { autoUpload("session-end"); }, 1500);
    });
  }
}
