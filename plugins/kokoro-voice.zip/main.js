/**
 * OfflineQuiz plugin: Kokoro Voice
 *
 * Kokoro, a small open speech model, reads questions aloud in five natural voices. It runs on your computer,
 * so it works in the app and in any browser, offline once it's downloaded.
 */
QB.registerPlugin({
  id: "kokoro-voice",
  name: "Kokoro Voice",
  version: "2.3.0",
  author: "OfflineQuiz",
  description: "A natural voice for Read aloud, made on your computer. Works in the app and every browser, offline once it's downloaded.",
  onEnable: __qbMain,
  onDisable: function (ctx) { if (ctx._cleanup) ctx._cleanup(); },
});
