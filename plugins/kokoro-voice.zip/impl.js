function __qbMain(ctx) {
  // ── the kit the 15.62 plugins share (text, icons, questions, judging, history) ──
  function esc(s) { return (s == null ? "" : String(s)).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
  var IC = {
    play: '<path d="M7 4l13 8-13 8z"/>',
    pause: '<path d="M8 5v14M16 5v14"/>',
    left: '<path d="M15 6l-6 6 6 6"/>',
    right: '<path d="M9 6l6 6-6 6"/>',
    next: '<path d="M6 5l9 7-9 7zM18 5v14"/>',
    refresh: '<path d="M20 11a8 8 0 10-2.3 5.7M20 4v7h-7"/>',
    x: '<path d="M6 6l12 12M18 6L6 18"/>',
    check: '<path d="M5 12l5 5 9-10"/>',
    mic: '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
    volume: '<path d="M4 9v6h4l5 4V5L8 9z"/><path d="M16 9a4 4 0 0 1 0 6M19 6a8 8 0 0 1 0 12"/>',
    copy: '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h3"/>',
    edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="M13.5 6.5l4 4"/>',
    bolt: '<path d="M13 3L5 14h6l-1 7 8-11h-6z"/>',
    flag: '<path d="M5 21V4M5 4h11l-2 4 2 4H5"/>',
    users: '<circle cx="9" cy="8" r="3"/><path d="M3 20a6 6 0 0 1 12 0M16 4a3 3 0 0 1 0 6M21 20a6 6 0 0 0-4-5.6"/>',
    target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
    down: '<path d="M6 9l6 6 6-6"/>',
    up: '<path d="M6 15l6-6 6 6"/>',
    quote: '<path d="M7 7h4v4c0 3-1.5 5-4 6M15 7h4v4c0 3-1.5 5-4 6"/>',
    grid: '<rect x="3" y="3" width="8" height="10" rx="2"/><rect x="13" y="3" width="8" height="6" rx="2"/><rect x="13" y="11" width="8" height="10" rx="2"/><rect x="3" y="15" width="8" height="6" rx="2"/>',
    ear: '<path d="M7 9a5 5 0 0 1 10 0c0 3-3 4-3 7a3 3 0 0 1-6 0"/><path d="M10 9a2 2 0 0 1 4 0"/>',
  };
  function ic(name, size) {
    var s = size || 16;
    return '<svg width="' + s + '" height="' + s + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (IC[name] || "") + "</svg>";
  }
  function loading(label) { return '<div class="pk-loading">' + (ctx.loadingBarHtml ? ctx.loadingBarHtml(label) : esc(label)) + "</div>"; }
  function norm(s) { return String(s || "").toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[^a-z0-9]+/g, " ").trim(); }
  function pct(a, n) { return n ? Math.round(100 * a / n) : 0; }
  function fmt(n) { return Number(n || 0).toLocaleString(); }
  function plural(n, one, many) { return fmt(n) + " " + (n === 1 ? one : (many || one + "s")); }
  function shuffle(a) { for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)), t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
  function inField(e) { var t = e && e.target; return !!t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT" || t.isContentEditable); }
  function dayKey(t) { var d = new Date(t || Date.now()); return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0"); }
  var DAY = 86400000;

  // the practice setup (Setup panel): its filters and reading settings
  function cfg() { try { return (ctx.host && ctx.host.getPracticeConfig && ctx.host.getPracticeConfig()) || {}; } catch (e) { return {}; } }
  // filters → query parameters, the ones the app sends for a random question
  function filtersQuery(f, extra) {
    f = f || {}; var p = [];
    var add = function (k, v) { p.push(k + "=" + encodeURIComponent(v)); };
    if (f.categories && f.categories.length) add("categories", f.categories.join(","));
    if (f.categoryIds && f.categoryIds.length) add("categoryIds", f.categoryIds.join(","));
    if (f.difficulties && f.difficulties.length) add("difficulties", f.difficulties.join(","));
    if (f.setNames && f.setNames.length) add("setNames", f.setNames.join(","));
    if (f.packetNumbers && f.packetNumbers.length) add("packetNumbers", f.packetNumbers.join(","));
    if (f.yearMin != null) add("yearMin", f.yearMin);
    if (f.yearMax != null) add("yearMax", f.yearMax);
    if (f.powermarkOnly) add("powermarkOnly", "true");
    if (f.canon && f.canon.length) add("canon", f.canon.join(","));
    add("cleanOnly", "1");
    Object.keys(extra || {}).forEach(function (k) { if (extra[k] != null && extra[k] !== false) add(k, extra[k]); });
    return p.join("&");
  }
  // the practice filters without a set (a drill draws from everything the player picked)
  function practiceFilters() { var f = Object.assign({}, cfg().filters || {}); delete f.setNames; delete f.packetNumbers; delete f.setIds; return f; }
  async function getTossups(n, f, extra) {
    try { var d = await ctx.api.get("/api/tossups/query?" + filtersQuery(f || practiceFilters(), Object.assign({ random: 1, limit: n }, extra || {}))); return (d && d.rows) || []; } catch (e) { return []; }
  }
  async function getBonuses(n, f, extra) {
    try { var d = await ctx.api.get("/api/bonuses/query?" + filtersQuery(f || practiceFilters(), Object.assign({ random: 1, limit: n }, extra || {}))); return (d && d.rows) || []; } catch (e) { return []; }
  }
  async function getTossup(id) { try { return (await ctx.api.get("/api/tossups/" + encodeURIComponent(id))).tossup || null; } catch (e) { return null; } }
  async function getBonus(id) { try { return (await ctx.api.get("/api/bonuses/" + encodeURIComponent(id))).bonus || null; } catch (e) { return null; } }
  async function searchTossups(query, limit, f) {
    try { var d = await ctx.api.get("/api/tossups/search?query=" + encodeURIComponent(query) + "&limit=" + (limit || 20) + (f ? "&" + filtersQuery(f) : "")); return { rows: (d && d.rows) || [], total: (d && d.total) || 0 }; } catch (e) { return { rows: [], total: 0 }; }
  }
  // tossups whose answer line names an answer
  async function tossupsOn(answer, limit) { return (await searchTossups('answer_sanitized : ("' + String(answer).replace(/"/g, "") + '")', limit || 20)).rows; }

  // ── the voice plugins' files (15.69: Kokoro Voice, Voice Answers) ──
  // Worker code: a plugin's worker source starts with "(" + voiceFilesWorker + ")(cfg);". fetch() in that worker then
  // serves the model, voice and code files from IndexedDB once they've been fetched, so they load in a moment and work
  // offline. The first time, each comes from our server (onlinequiz.net/voice/, a copy of Hugging Face's and
  // jsDelivr's files by the same paths: server.js, scripts/publish-voice.mjs) or else its own host, in 4 MB ranges six at a time, each range kept as
  // it arrives: one long download over a slow line kept breaking off and starting again, so Kokoro never got ready.
  // cfg: { mirror: our copy's address (the website's own /voice/; the app's www.onlinequiz.net/voice/), db: the IndexedDB name (1.x/2.x kept whole files there by their address, and those are used), sizes: { url:
  // bytes } }. self.voiceFiles: plan(urls) totals what's still to fetch (progress goes to the page as { t: "progress",
  // loaded, total }), file(url), has(url) (kept already), blobUrl(url, type), importCode(url, fallback), route(fn) (fn(url)
  // → a Response promise for a file it makes itself, or null).
  // where our copy is: the website's own, else the live site's
  function voiceMirror() { return (window.QB_WEB && /^https?:/.test(location.origin) ? location.origin : "https://www.onlinequiz.net") + "/voice/"; }
  function voiceFilesWorker(cfg) {
    var MIRROR = cfg.mirror || "https://www.onlinequiz.net/voice/", HOSTS = [["https://huggingface.co/", "hf/"], ["https://cdn.jsdelivr.net/npm/", "npm/"]];
    var CHUNK = 4 << 20, LANES = 6, real = self.fetch.bind(self), sizes = cfg.sizes || {}, got = 0, want = 0, inflight = {};
    var dbp = null;
    function db() {
      return dbp || (dbp = new Promise(function (res, rej) { var r = indexedDB.open(cfg.db, 1); r.onupgradeneeded = function () { r.result.createObjectStore("files"); }; r.onsuccess = function () { res(r.result); }; r.onerror = function () { rej(r.error); }; }));
    }
    function get(k) { return db().then(function (d) { return new Promise(function (res) { try { var g = d.transaction("files").objectStore("files").get(k); g.onsuccess = function () { res(g.result); }; g.onerror = function () { res(undefined); }; } catch (e) { res(undefined); } }); }); }
    function put(k, v) { return db().then(function (d) { return new Promise(function (res) { try { var tx = d.transaction("files", "readwrite"); tx.objectStore("files").put(v, k); tx.oncomplete = function () { res(true); }; tx.onerror = tx.onabort = function () { res(false); }; } catch (e) { res(false); } }); }); }
    function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
    function mirrorOf(url) { for (var i = 0; i < HOSTS.length; i++) if (url.indexOf(HOSTS[i][0]) === 0) return MIRROR + HOSTS[i][1] + url.slice(HOSTS[i][0].length); return null; }
    function report() { if (want) postMessage({ t: "progress", loaded: Math.min(got, want), total: want }); }
    // kept: a small file whole, a big one as its ranges
    async function kept(url) {
      var whole = await get(url); if (whole) return whole;
      var meta = await get(url + "#meta"); if (!meta || !meta.done) return null;
      var all = new Uint8Array(meta.total), o = 0;
      for (var i = 0; i < meta.n; i++) { var p = await get(url + "#" + i); if (!p) return null; all.set(new Uint8Array(p), o); o += p.byteLength; }
      return all.buffer;
    }
    async function sizeAt(src) {
      var r = await real(src, { headers: { Range: "bytes=0-0" } });
      var m = /\/(\d+)\s*$/.exec(r.headers.get("Content-Range") || ""), n = m ? +m[1] : r.status === 200 ? +(r.headers.get("Content-Length") || 0) : 0;
      try { if (r.body) await r.body.cancel(); } catch (e) {}
      if (!n) throw new Error("HTTP " + r.status);
      return n;
    }
    async function pull(src, url, total) {
      // in one piece: a small file, and jsDelivr's (served compressed, so its ranges aren't the file's)
      if (total <= 2 * CHUNK || /^https:\/\/cdn\.jsdelivr\.net\//.test(src)) {
        var r = await real(src); if (!r.ok) throw new Error("HTTP " + r.status);
        var b = await r.arrayBuffer(); if (sizes[url] && b.byteLength !== sizes[url]) throw new Error("cut short");
        got += b.byteLength; report(); await put(url, b); return b;
      }
      var n = Math.ceil(total / CHUNK), parts = new Array(n), meta = await get(url + "#meta");
      if (meta && meta.total === total) { for (var i = 0; i < n; i++) { var p = await get(url + "#" + i); if (p && p.byteLength === Math.min(total, (i + 1) * CHUNK) - i * CHUNK) { parts[i] = p; got += p.byteLength; } } }
      else await put(url + "#meta", { total: total, n: n, done: false });
      report();
      var next = 0;
      async function lane() {
        for (;;) {
          var k = -1; while (next < n) { if (!parts[next]) { k = next++; break; } next++; }
          if (k < 0) return;
          var a = k * CHUNK, z = Math.min(total, a + CHUNK) - 1;
          for (var t = 0; ; t++) {
            try {
              var rr = await real(src, { headers: { Range: "bytes=" + a + "-" + z } });
              if (rr.status !== 206) throw new Error("HTTP " + rr.status);
              var buf = await rr.arrayBuffer(); if (buf.byteLength !== z - a + 1) throw new Error("cut short");
              await put(url + "#" + k, buf); parts[k] = buf; got += buf.byteLength; report(); break;
            } catch (e) { if (t >= 6) throw e; await sleep(700 * (t + 1)); }
          }
        }
      }
      var lanes = []; for (var j = 0; j < Math.min(LANES, n); j++) lanes.push(lane());
      await Promise.all(lanes);
      await put(url + "#meta", { total: total, n: n, done: true });
      var all = new Uint8Array(total), o = 0; for (var q = 0; q < n; q++) { all.set(new Uint8Array(parts[q]), o); o += parts[q].byteLength; }
      return all.buffer;
    }
    function file(url) {
      if (inflight[url]) return inflight[url];
      return (inflight[url] = (async function () {
        var k = await kept(url); if (k) return k;
        var srcs = [mirrorOf(url), url].filter(Boolean), last = null;
        for (var i = 0; i < srcs.length; i++) {
          try { var total = sizes[url] || (/^https:\/\/cdn\.jsdelivr\.net\//.test(srcs[i]) ? 1 : await sizeAt(srcs[i])); return await pull(srcs[i], url, total); }
          catch (e) { last = e; }
        }
        throw last || new Error("unreachable");
      })().finally(function () { delete inflight[url]; }));
    }
    // what loading still needs, so the progress is of the whole download
    async function plan(urls) {
      for (var i = 0; i < urls.length; i++) if (!(await has(urls[i]))) want += sizes[urls[i]] || 0;
      report();
    }
    async function has(url) {
      var n = await db().then(function (d) { return new Promise(function (res) { try { var c = d.transaction("files").objectStore("files").count(url); c.onsuccess = function () { res(c.result); }; c.onerror = function () { res(0); }; } catch (e) { res(0); } }); });
      if (n) return true;
      var meta = await get(url + "#meta"); return !!(meta && meta.done);
    }
    var routes = [];
    async function blobUrl(url, type) { return URL.createObjectURL(new Blob([await file(url)], { type: type || "application/octet-stream" })); }
    async function importCode(url, fallback) {
      try { return await import(await blobUrl(url, "text/javascript")); }
      catch (e) { if (fallback) return import(fallback); throw e; }
    }
    // a jsDelivr "+esm" module with the modules it imports ("/npm/…/+esm"), each kept, their imports pointed at the kept
    // copies (Voice Answers' transformers.js: it, onnxruntime-web and onnxruntime-common)
    var esm = {};
    function esmUrl(url) {
      return esm[url] || (esm[url] = (async function () {
        var text = new TextDecoder().decode(await file(url)), deps = {}, re = /(?:from|import)\s*\(?\s*"(\/npm\/[^"]+)"/g, m;
        while ((m = re.exec(text))) deps[m[1]] = 1;
        for (var d in deps) text = text.split('"' + d + '"').join('"' + await esmUrl("https://cdn.jsdelivr.net" + d) + '"');
        return URL.createObjectURL(new Blob([text], { type: "text/javascript" }));
      })());
    }
    async function importEsm(url) {
      try { return await import(await esmUrl(url)); }
      catch (e) { return import(url); }   // (online: as jsDelivr serves it)
    }
    // the libraries' own fetches (models, voices) come here; a browser cache they'd keep copies in is one that keeps nothing
    self.fetch = function (input, init) {
      var url = typeof input === "string" ? input : input && input.href ? input.href : input && input.url;
      for (var i = 0; url && i < routes.length; i++) { var made = routes[i](url); if (made) return made; }
      if (url && /^https:\/\/(huggingface\.co\/[^?#]+\/resolve\/|cdn\.jsdelivr\.net\/npm\/)/.test(url)) {
        return file(url).then(function (b) { return new Response(b, { status: 200, headers: { "content-length": String(b.byteLength) } }); });
      }
      return real(input, init);
    };
    var none = { match: async function () {}, put: async function () {}, delete: async function () { return false; }, keys: async function () { return []; } };
    try { Object.defineProperty(self, "caches", { configurable: true, value: { open: async function () { return none; }, has: async function () { return false; }, delete: async function () { return false; }, keys: async function () { return []; }, match: async function () {} } }); } catch (e) {}
    self.voiceFiles = { plan: plan, file: file, has: has, blobUrl: blobUrl, importCode: importCode, importEsm: importEsm, route: function (fn) { routes.push(fn); } };
  }

  // a record's text as practice reads it (notes and pronunciation guides per the player's settings)
  function readText(q) {
    try { if (ctx.host && ctx.host.questionText) { var t = ctx.host.questionText(q, "question"); if (t != null) return String(t).replace(/\(\*\)/g, "").replace(/\s{2,}/g, " ").trim(); } } catch (e) {}
    return String((q && q.question_sanitized) || "").replace(/\(\*\)/g, "").trim();
  }
  function powerAt(q) { return String((q && q.question_sanitized) || "").indexOf("(*)"); }
  // sentences, without breaking at "St." or an initial ("J. R. R. Tolkien")
  var ABBR = /(?:\b(?:St|Ste|Mt|Mts|Dr|Mr|Mrs|Ms|Mme|Prof|Sr|Jr|Rev|Fr|Gen|Col|Capt|Lt|Sgt|Maj|Adm|Hon|Pres|Gov|Sen|Rep|vs|etc|cf|ca|al|Inc|Co|Corp|Ltd|Bros|approx|No|Nos|Op|op|no|Vol|vol|Ch|ch|Fig|fig|Ft|Pt|pt|Ave|[A-Za-z])\.["”’']?)$/;
  function sentences(text) {
    var parts = String(text || "").split(/(?<=[.?!]["”’)]*)\s+(?=["“(]?[A-Z0-9])/), out = [], cur = "";
    for (var i = 0; i < parts.length; i++) {
      cur = cur ? cur + " " + parts[i] : parts[i];
      if (i < parts.length - 1 && ABBR.test(cur.trim())) continue;
      out.push(cur.trim()); cur = "";
    }
    if (cur.trim()) out.push(cur.trim());
    return out.filter(Boolean);
  }
  // where each sentence of a text ends (indexes into it)
  function sentenceEnds(text) {
    var at = 0, out = []; text = String(text || "");
    sentences(text).forEach(function (x) { var i = text.indexOf(x, at); if (i < 0) return; at = i + x.length; out.push(at); });
    return out;
  }
  // ── categories (15.63): the app's own picker, its picks kept under `key` ([] = every category) ──
  // mountCats(root, key, onChange) puts it in root's [data-cats] (made once, moved into each new render);
  // inCats(pk, e): a history entry or question in the picks; with no picks, all are
  var PICKERS = {};
  // opts.label: "" for just the picks, in a row that has its own label
  function catPicker(key, onChange, opts) {
    if (PICKERS[key]) return PICKERS[key];
    if (!ctx.host || !ctx.host.categoryPicker) return null;
    var o = { selected: ctx.storage.get(key) || [], onChange: function (ids) { ctx.storage.set(key, ids); if (onChange) onChange(ids); } };
    if (opts && opts.label != null) o.label = opts.label;
    var pk = ctx.host.categoryPicker(null, o);
    PICKERS[key] = pk;
    // the picks match nothing until the tree is in: draw again once it is
    if (pk.ready && (ctx.storage.get(key) || []).length) pk.ready.then(function () { if (onChange) onChange(pk.get()); });
    return pk;
  }
  function mountCats(root, key, onChange, opts) {
    var pk = catPicker(key, onChange, opts), host = root && root.querySelector("[data-cats]");
    if (pk && host) host.appendChild(pk.el);
    return pk;
  }
  function inCats(pk, e) {
    if (!pk || !pk.get().length) return true;
    return pk.matches(String((e && (e.category_path || e.path || e.category || e.root)) || ""));
  }
  // ── the app's reader on a page titled for the plugin (15.63: ctx.host.playPractice). Its Setup picks the categories ──
  function canRead() { return !!(ctx.host && ctx.host.playPractice); }
  function onReader() { return !!(ctx.host && ctx.host.onPracticePage && ctx.host.onPracticePage()); }
  // a plugin's start page: an icon, what it is, a Start button (data-pk="start"), a note under it
  function heroHtml(icon, title, text, start, note) {
    return '<div class="pk-hero"><span class="pk-hero-ico">' + ic(icon, 26) + "</span><h2>" + esc(title) + "</h2><p>" + esc(text) + "</p>" +
      '<div class="pk-actions pk-center"><button type="button" class="btn btn-primary" data-pk="start">' + ic("play", 14) + esc(start || "Start") + "</button></div>" +
      (note ? '<div class="pk-muted pk-small">' + note + "</div>" : "") + "</div>";
  }
  // the answer line, with its bold and underlining (nothing else of the HTML)
  function answerHtml(q) {
    var h = String((q && q.answer) || "");
    if (!/<\/?(b|u|strong|em|i)\b/i.test(h)) return esc((q && q.answer_sanitized) || h);
    return h.replace(/<(\/?)(b|u|strong|em|i)\b[^>]*>/gi, "\u0001$1$2\u0002").replace(/<[^>]*>/g, "").replace(/&(?!(?:amp|lt|gt|quot|#\d+);)/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/\u0001(\/?)(\w+)\u0002/g, "<$1$2>");
  }
  function primary(q) {
    var a = "";
    try { if (ctx.host && ctx.host.extractPrimaryAnswer) a = ctx.host.extractPrimaryAnswer((q && q.answer) || "", (q && q.answer_sanitized) || ""); } catch (e) {}
    return a || String((q && q.answer_sanitized) || "").replace(/\s*[\[(].*$/, "").trim();
  }
  // an answer as a person reads it in a list: the line up to its first bracket ("Mary, Queen of Scots"), where primary()
  // runs the bold parts together for matching ("Mary, Queen of Scots Mary Stuart")
  function answerName(q) { return String((q && q.answer_sanitized) || "").replace(/\s*[\[(].*$/, "").trim() || primary(q); }
  // judged right here, like practice (judge.js); { status: "accept" | "prompt" | "reject", prompt }
  async function judge(q, answer, opts) {
    opts = opts || {};
    try {
      if (ctx.host && ctx.host.judgeTossup) return (await ctx.host.judgeTossup(q, answer, { strictness: opts.strictness != null ? opts.strictness : (cfg().strictness || 10), buzzPosition: opts.buzzPosition, previous: opts.previous || null })) || { status: "reject" };
      return (await ctx.api.post("/api/evaluate-tossup", { questionId: q.id, answer: answer, strictness: cfg().strictness || 10, buzzPosition: opts.buzzPosition, previous: opts.previous || null })) || { status: "reject" };
    } catch (e) { return { status: "reject" }; }
  }
  async function judgePart(b, part, answer, opts) {
    opts = opts || {};
    try {
      if (ctx.host && ctx.host.judgeBonusPart) return (await ctx.host.judgeBonusPart(b, part, answer, { strictness: cfg().strictness || 10, previous: opts.previous || null })) || { status: "reject" };
      return (await ctx.api.post("/api/evaluate-bonus-part", { questionId: b.id, part: part, answer: answer, strictness: cfg().strictness || 10 })) || { status: "reject" };
    } catch (e) { return { status: "reject" }; }
  }
  async function judgeLine(line, sani, answer, opts) {
    opts = opts || {};
    try {
      if (ctx.host && ctx.host.judgeAnswerLine) return (await ctx.host.judgeAnswerLine(line, sani, answer, { strictness: cfg().strictness || 10, previous: opts.previous || null })) || { status: "reject" };
      return (await ctx.api.post("/api/evaluate-answer", { answerline: line, answer: answer, strictness: cfg().strictness || 10 })) || { status: "reject" };
    } catch (e) { return { status: "reject" }; }
  }
  function bonusParts(b) { try { return JSON.parse((b && (b.parts_sanitized || b.parts)) || "[]"); } catch (e) { return []; } }
  function bonusAnswers(b) { try { return JSON.parse((b && b.answers) || "[]"); } catch (e) { return []; } }
  function bonusAnswersSani(b) { try { return JSON.parse((b && b.answers_sanitized) || "[]"); } catch (e) { return []; } }

  // the player's answers (Stats' history), only the fields asked for
  async function history(fields) {
    try { return ((await ctx.api.get("/api/sessions/all-entries?" + (/\banswer\b/.test(fields || "") ? "answers=1&" : "") + "fields=" + encodeURIComponent(fields || ""))).entries) || []; } catch (e) { return []; }
  }
  // record a tossup answered on a plugin's page into the player's stats (the path Coach Mode uses)
  function record(q, r) {
    try {
      ctx.api.post("/api/check-tossup", { questionId: q.id, answer: r.answer || "", buzzPosition: r.buzzPosition || 0, sessionId: r.session, overriding: true,
        correct: !!r.correct, isPower: !!r.power, points: r.points || 0, celerity: r.celerity != null ? r.celerity : 1 }).catch(function () {});
    } catch (e) {}
  }

  var ROOT_COLOR = { "Literature": "#bc8cff", "Science": "#58a6ff", "Math": "#a5e05b", "Pop Culture": "#ff7b72", "Sports": "#ff6f91", "Fine Arts": "#f778ba", "History": "#e3b341", "Geography": "#56d364", "Mythology": "#ffa657", "Social Science": "#3dd6a3", "Philosophy": "#39c5cf", "Theology": "#8e9bff", "Current Events": "#c9d16b", "Miscellaneous": "#8b949e" };
  // NAQT's high school distribution, per 24 tossups / bonuses (naqt.com/hs/distribution.jsp)
  var NAQT = [["Literature", 3.9, 3.8], ["Science", 4.5, 4.3], ["Math", 1.0, 1.0], ["Fine Arts", 2.0, 2.0], ["History", 4.6, 4.5], ["Geography", 1.9, 1.9], ["Mythology", 0.6, 0.7],
    ["Pop Culture", 1.0, 0.9], ["Sports", 0.7, 0.7], ["Social Science", 0.6, 0.6], ["Philosophy", 0.3, 0.3], ["Theology", 0.4, 0.4], ["Current Events", 1.5, 1.4], ["Miscellaneous", 1.0, 1.5]];
  function rootOf(e) { return String((e && (e.category_path || e.category)) || "").split(" > ")[0] || "Miscellaneous"; }
  function dot(root) { return '<span class="pk-dot" style="--c:' + (ROOT_COLOR[root] || "#8b949e") + '"></span>'; }
  var _roots = null;
  async function roots() {
    if (_roots) return _roots;
    try { var t = ctx.host && ctx.host.getCategoryTree ? await ctx.host.getCategoryTree("tossups") : (await ctx.api.get("/api/category-tree?type=tossups")).tree; _roots = (t || []).map(function (n) { return { id: n.id, name: n.name, count: n.count }; }); }
    catch (e) { _roots = []; }
    return _roots;
  }
  var DIFF_NAME = { 0: "Unrated", 1: "Middle school", 2: "Easy high school", 3: "Regular high school", 4: "Hard high school", 5: "National high school", 6: "Easy college", 7: "Medium college", 8: "Regionals college", 9: "Nationals college", 10: "Open" };

  function tile(value, label, cls) { return '<div class="pk-tile' + (cls ? " " + cls : "") + '"><b class="num">' + value + "</b><span>" + esc(label) + "</span></div>"; }
  function segHtml(name, items, on) {
    return '<div class="seg pk-seg" role="group">' + items.map(function (it) {
      return '<button type="button" data-' + name + '="' + esc(it[0]) + '" aria-pressed="' + (String(on) === String(it[0])) + '">' + esc(it[1]) + "</button>";
    }).join("") + "</div>";
  }
  function emptyHtml(text) { return '<div class="db-empty pk-empty">' + esc(text) + "</div>"; }
  // square toggles 0 to 10, Setup's difficulty look (the app's .diff-toggles), `on` the ones picked; diffsIn reads them
  function diffHtml(name, on) {
    var h = '<div class="diff-toggles pk-diffs" role="group" aria-label="Difficulty">';
    for (var d = 0; d <= 10; d++) h += '<label title="' + esc(DIFF_NAME[d]) + '"><input type="checkbox" data-' + name + '="' + d + '"' + ((on || []).indexOf(d) >= 0 ? " checked" : "") + "><span>" + d + "</span></label>";
    return h + "</div>";
  }
  function diffsIn(root, name) { return [].slice.call(root.querySelectorAll("[data-" + name + "]")).filter(function (i) { return i.checked; }).map(function (i) { return Number(i.getAttribute("data-" + name)); }); }
  // a list of difficulties in a few words: [2, 3, 4, 5] → "2 to 5"
  function diffWords(ds) {
    ds = (ds || []).slice().sort(function (a, b) { return a - b; });
    if (!ds.length) return "any difficulty";
    var run = ds.every(function (d, i) { return !i || d === ds[i - 1] + 1; });
    return ds.length === 1 ? "difficulty " + ds[0] : run ? "difficulty " + ds[0] + " to " + ds[ds.length - 1] : "difficulty " + ds.join(", ");
  }
  function playList(kind, ids, title) {
    if (!ids || !ids.length) return false;
    try { return !!(ctx.host && ctx.host.launchQuestions && ctx.host.launchQuestions(kind, ids, { title: title })); } catch (e) { return false; }
  }

  // a reader: shows `text` a character at a time at the practice reading speed. start(), pause(), go(), stop();
  // at() is how far it is; onEnd once it's all shown
  function Reader(el, text, opts) {
    opts = opts || {};
    var ms = opts.ms != null ? opts.ms : (Number(cfg().revealSpeed) || 25), idx = 0, raf = 0, last = 0, on = false;
    var paint = function () { el.innerHTML = '<span class="pk-read">' + esc(text.slice(0, idx)) + '</span><span class="pk-unread" aria-hidden="true">' + esc(text.slice(idx)) + "</span>"; };
    var step = function (t) {
      raf = 0; if (!on) return;
      if (!last) last = t;
      var n = ms > 0 ? Math.floor((t - last) / ms) : text.length;
      if (n > 0) { idx = Math.min(text.length, idx + n); last += n * ms; paint(); if (opts.onTick) opts.onTick(idx); }
      if (idx >= text.length) { on = false; if (opts.onEnd) opts.onEnd(); return; }
      raf = requestAnimationFrame(step);
    };
    paint();
    return {
      start: function () { if (on) return; on = true; last = 0; raf = requestAnimationFrame(step); },
      pause: function () { on = false; if (raf) cancelAnimationFrame(raf); raf = 0; },
      stop: function () { on = false; if (raf) cancelAnimationFrame(raf); raf = 0; },
      showAll: function () { this.stop(); idx = text.length; el.textContent = text; },
      at: function () { return idx; },
      running: function () { return on; },
    };
  }
  // a reader's position in the displayed text → the record's question_sanitized (what judging and stats count)
  function serverPos(q, display, pos) {
    try { if (ctx.host && ctx.host.mapDisplayPos) return ctx.host.mapDisplayPos(display, (q && q.question_sanitized) || "", pos); } catch (e) {}
    return pos;
  }

  // ── Kokoro Voice: a natural voice for Read aloud, made on this computer ──
  // Kokoro-82M (kokoro-js 1.2.1, Apache-2.0) in a module worker; it's offered as voices in the Voice popover
  // (ctx.registerVoice) and the app plays what it makes (app.js Speech: a sentence or two at a time, the next made while
  // one plays). With a GPU it runs on WebGPU, far faster than it speaks; without one, on the processor, slower.
  // 2.0 (15.69): every file it needs (the model, the voices, kokoro-js and the ONNX runtime) comes through
  // voiceFilesWorker (kit.js): from our download mirror in ranges that are kept as they arrive, then from IndexedDB, so it
  // starts in a moment and works offline. 1.x took its code from jsDelivr at every start (so it needed the internet) and
  // its model in one long download that kept breaking off on a slow line, so it never got ready and the browser's voice
  // read instead. Now reading waits for it, the loading shown where "Reading" goes (app.js Speech).
  // 2.1 (15.70): its files download as soon as the plugin is on (fetchAll), not when it's first picked, so it's ready
  // whenever it's chosen; the app makes the next question's opening while the answer shows (app.js Speech.warm).
  // 2.2 (15.71): getting it from the Store downloads them there, the card showing how far (ctx.registerDownload).
  // ── (2.4) Kokoro's own timing, so the text follows it word for word ──
  // Its model works out how many frames (600 samples each) every sound of the text lasts before it makes them. That
  // count ("/encoder/Cast_output_0", the rounded durations) is inside both model files people already have: the graph is
  // given it as a second output here (addOutput, a few bytes appended to the file's GraphProto as it's loaded), so
  // nothing new downloads. The sounds' words are then matched to the text's words (wordMarks).
  var DUR = "/encoder/Cast_output_0";
  // an ONNX model with one more graph output: ModelProto.graph (7) gets an output (12) { name, type: tensor int64 }
  function addOutput(buf, name) {
    var b = new Uint8Array(buf), i = 0, gKey = -1, gAt = 0, gLen = 0;
    function vint(at) { var v = 0, s = 1, c; do { c = b[at++]; v += (c & 127) * s; s *= 128; } while (c & 128); return [v, at]; }
    while (i < b.length) {
      var k0 = i, r = vint(i), key = r[0], f = Math.floor(key / 8), w = key % 8; i = r[1];
      if (w === 0) i = vint(i)[1]; else if (w === 1) i += 8; else if (w === 5) i += 4;
      else if (w === 2) { r = vint(i); if (f === 7) { gKey = k0; gAt = r[1]; gLen = r[0]; } i = r[1] + r[0]; }
      else return buf;
    }
    if (gKey < 0) return buf;
    function enc(v) { var o = []; while (v > 127) { o.push((v % 128) | 128); v = Math.floor(v / 128); } o.push(v); return o; }
    function ld(field, bytes) { return enc(field * 8 + 2).concat(enc(bytes.length), Array.from(bytes)); }
    var extra = ld(12, ld(1, Array.from(new TextEncoder().encode(name))).concat(ld(2, ld(1, [8, 7]))));
    var head = enc(58).concat(enc(gLen + extra.length));
    var out = new Uint8Array(gKey + head.length + gLen + extra.length + (b.length - gAt - gLen)), o = gKey;
    out.set(b.subarray(0, gKey), 0); out.set(head, o); o += head.length; out.set(b.subarray(gAt, gAt + gLen), o); o += gLen;
    out.set(extra, o); o += extra.length; out.set(b.subarray(gAt + gLen), o);
    return out.buffer;
  }
  // where each word of text is said: [start s, its first character, end s, after its last, …] (Float32Array).
  // toks: the model's input, a sound a token (a pad at each end), dur: frames for each. The sounds split into words at
  // spaces; the text's words and the sounds' words are matched in order (a number is a few spoken words, "St." one),
  // by their length in vowels and where the punctuation falls, the closest fit over the whole piece
  function wordMarks(text, toks, dur) {
    var FR = 600 / 24000, t = 0, pw = [], cur = null, V = /[aeiouyɑɐɒæɔəɘɚɛɜɝɞɪʊʌɯɤʏøœɨʉᵻAIOWYQEUæ]/;
    for (var i = 0; i < toks.length; i++) {
      var d = (Number(dur[i]) || 0) * FR, c = toks[i];
      if (i > 0 && i < toks.length - 1) {
        if (c === " ") { if (cur) { pw.push(cur); cur = null; } }
        else {
          if (!cur) cur = { s: -1, e: -1, v: 0, p: "", last: "" };
          // a punctuation mark's frames are the pause after the word: not the word's
          if (/[,.;:!?—…"“”'‘’()\[\]«»-]/.test(c)) { if (/[,.;:!?—…]/.test(c)) cur.p = c; }
          else { if (cur.s < 0) cur.s = t; cur.e = t + d; if (V.test(c) && !V.test(cur.last)) cur.v++; cur.last = c; }
        }
      }
      t += d;
    }
    if (cur) pw.push(cur);
    // a word of punctuation alone ("—") gives its mark to the word before it
    pw = pw.filter(function (w, k) { if (w.s >= 0) return true; if (k && pw[k - 1].s >= 0 && w.p) pw[k - 1].p = w.p; return false; });
    var tw = [], re = /\S+/g, m;
    while ((m = re.exec(text))) {
      var w = m[0], wl = w.toLowerCase(), v = /\d/.test(w) ? 1 + 1.3 * w.replace(/\D/g, "").length : Math.max(1, (wl.match(/[aeiouy]+/g) || []).length - (/[^aeiouy]e$/.test(wl) && wl.length > 3 ? 1 : 0));
      var pm = /([,.;:!?—…])["”’)\]]*$/.exec(w);
      tw.push({ a: m.index, b: m.index + w.length, v: v, p: pm ? pm[1] : "" });   // ("St." keeps its stop: the phonemizer says "saint." with one)
    }
    var n = tw.length, M = pw.length; if (!n || !M) return null;
    // D[i][j]: the best cost of matching tw[0..i) to pw[0..j); each step a group: one or two text words to one to four sound words
    var INF = 1e9, D = [], B = [];
    for (i = 0; i <= n; i++) { D.push(new Float64Array(M + 1).fill(INF)); B.push(new Int16Array(M + 1)); }
    D[0][0] = 0;
    for (i = 1; i <= n; i++) for (var j = 1; j <= M; j++) {
      for (var di = 1; di <= 2 && di <= i; di++) for (var dj = 1; dj <= 4 && dj <= j; dj++) {
        if (di > 1 && dj > 1) continue;
        var prev = D[i - di][j - dj]; if (prev >= INF) continue;
        var a = 0, bb = 0; for (var x = i - di; x < i; x++) a += tw[x].v; for (var y = j - dj; y < j; y++) bb += pw[y].v;
        var cost = Math.abs(Math.log((a + 0.6) / (bb + 0.6))) + (!tw[i - 1].p === !pw[j - 1].p ? 0 : 0.6) + 0.4 * (di - 1 + dj - 1);
        if (prev + cost < D[i][j]) { D[i][j] = prev + cost; B[i][j] = di * 8 + dj; }
      }
    }
    if (D[n][M] >= INF) return null;
    var groups = []; i = n; j = M;
    while (i > 0 && j > 0) { var bk = B[i][j], gi = bk >> 3, gj = bk & 7; groups.push([i - gi, i, j - gj, j]); i -= gi; j -= gj; }
    groups.reverse();
    var out = [];
    groups.forEach(function (g) {
      var s0 = pw[g[2]].s, e0 = pw[g[3] - 1].e, tot = 0; for (var x = g[0]; x < g[1]; x++) tot += tw[x].v;
      var at = s0;
      for (x = g[0]; x < g[1]; x++) { var len = (e0 - s0) * (tw[x].v / tot); out.push(at, tw[x].a, at + len, tw[x].b); at += len; }
    });
    return new Float32Array(out);
  }
  // a word's frames include the hush before a pause (Kokoro lengthens the last sound of a word before a comma): each
  // word's start and end moved in to where its sound is (10 ms steps, quiet below 6% of the loudest)
  function tighten(mk, s, sr) {
    if (!mk) return mk;
    var F = Math.round(sr / 100), n = Math.floor(s.length / F), e = new Float32Array(n), pk = 0, f, k;
    for (f = 0; f < n; f++) { var a = 0; for (k = f * F; k < (f + 1) * F; k++) a += s[k] * s[k]; e[f] = Math.sqrt(a / F); if (e[f] > pk) pk = e[f]; }
    var thr = pk * 0.06;
    for (var w = 0; w < mk.length; w += 4) {
      var f0 = Math.max(0, Math.floor(mk[w] * 100)), f1 = Math.min(n - 1, Math.ceil(mk[w + 2] * 100) - 1);
      var a0 = f0, a1 = f1; while (a0 < f1 && e[a0] < thr) a0++; while (a1 > a0 && e[a1] < thr) a1--;
      if (a1 > a0) { mk[w] = Math.max(mk[w], a0 / 100); mk[w + 2] = Math.min(mk[w + 2], (a1 + 2) / 100); }
    }
    return mk;
  }
  var HF = "https://huggingface.co/onnx-community/Kokoro-82M-v1.0-ONNX/resolve/main/";
  var BUNDLE = "https://cdn.jsdelivr.net/npm/kokoro-js@1.2.1/dist/kokoro.web.js";
  var ORT = "https://cdn.jsdelivr.net/npm/@huggingface/transformers@3.5.1/dist/ort-wasm-simd-threaded.jsep.";   // the runtime kokoro.web.js was built with
  // fp32 on WebGPU (a tenth of the time it speaks). Its smaller files don't work there: fp16, q8f16 and uint8f16 give
  // NaNs (silence) and q4f16 garbled speech (1.0). q8 on the processor is right, but slower than it speaks (1.7 times).
  // So the GPU gets fp32 from a pack a quarter of its 326 MB (scripts/voice-pack.py: its weights as 8-bit numbers with a
  // scale per row), made back into fp32 here (expand) and handed to the model as its external data file. The whole file
  // is still used where 1.x downloaded it, and when the pack can't be had.
  var GPU = { dtype: "fp32", file: "onnx/model.onnx" }, CPU = { dtype: "q8", file: "onnx/model_quantized.onnx" }, MAX_SPEED = 1.35;
  var MIRROR = voiceMirror(), PACK = MIRROR + "kokoro/v1/";
  var SIZES = {};
  SIZES[HF + GPU.file] = 325532232; SIZES[HF + CPU.file] = 92361116; SIZES[BUNDLE] = 2135146; SIZES[ORT + "wasm"] = 21596019; SIZES[ORT + "mjs"] = 44484;
  SIZES[PACK + "model.onnx"] = 1419532; SIZES[PACK + "model.q8.bin"] = 81496732;
  // every American and British voice of Kokoro v1.0 (2.3), the clearest first. The first five come down with the plugin,
  // the rest the first time one is heard or picked (half a megabyte each), then they work offline too
  var VOICES = [["af_heart", "Heart, US"], ["af_bella", "Bella, US"], ["am_michael", "Michael, US"], ["bf_emma", "Emma, UK"], ["bm_george", "George, UK"],
    ["af_nicole", "Nicole, US"], ["af_aoede", "Aoede, US"], ["af_kore", "Kore, US"], ["af_sarah", "Sarah, US"], ["af_alloy", "Alloy, US"], ["af_nova", "Nova, US"],
    ["af_sky", "Sky, US"], ["af_jessica", "Jessica, US"], ["af_river", "River, US"], ["am_fenrir", "Fenrir, US"], ["am_puck", "Puck, US"], ["am_echo", "Echo, US"],
    ["am_eric", "Eric, US"], ["am_liam", "Liam, US"], ["am_onyx", "Onyx, US"], ["am_adam", "Adam, US"], ["am_santa", "Santa, US"], ["bf_isabella", "Isabella, UK"],
    ["bf_alice", "Alice, UK"], ["bf_lily", "Lily, UK"], ["bm_fable", "Fable, UK"], ["bm_lewis", "Lewis, UK"], ["bm_daniel", "Daniel, UK"]].map(function (v) { return { id: v[0], name: v[1] }; });
  var CORE = VOICES.slice(0, 5);
  var worker = null, ready = false, loading = null, wq = {}, wid = 0, listeners = [], dlFns = [];
  var pace = 0, made = 0, onGpu = true, threads = false;   // (2.4) how fast it makes speech here: made-time over its length
  var WORKER = "(" + voiceFilesWorker.toString() + ")(" + JSON.stringify({ mirror: MIRROR, db: "qb-kokoro", sizes: SIZES }) + ");\n" +
    addOutput.toString() + "\n" + wordMarks.toString() + "\n" + tighten.toString() + "\nconst DUR = " + JSON.stringify(DUR) + ";\n" + [
    "const V = self.voiceFiles, HF = " + JSON.stringify(HF) + ", BUNDLE = " + JSON.stringify(BUNDLE) + ", ORT = " + JSON.stringify(ORT) + ";",
    "const GPU = " + JSON.stringify(GPU) + ", CPU = " + JSON.stringify(CPU) + ", PACK = " + JSON.stringify(PACK) + ";",
    "let tts = null, packed = false, gpu = false, fetching = null, last = null;",
    "const VOICES = " + JSON.stringify(CORE.map(function (v) { return v.id; })) + ";",
    "// every file it needs, downloaded and kept (2.1: as soon as the plugin is on, before it's picked); a load waits on the same",
    "async function filesFor() {",
    "  try { gpu = !!(navigator.gpu && await navigator.gpu.requestAdapter()); } catch (e) {}",
    "  packed = gpu && !(await V.has(HF + GPU.file));",
    '  return [BUNDLE, ORT + "mjs", ORT + "wasm", HF + "config.json", HF + "tokenizer.json", HF + "tokenizer_config.json"].concat(VOICES.map((v) => HF + "voices/" + v + ".bin"), !gpu ? [HF + CPU.file] : packed ? [PACK + "model.onnx", PACK + "model.q8.bin"] : [HF + GPU.file]);',
    "}",
    "function fetchAll() {",
    "  return fetching || (fetching = (async () => {",
    "    const files = await filesFor();",
    "    await V.plan(files);",
    "    await Promise.all(files.map((f) => V.file(f)));",
    "  })().catch((e) => { fetching = null; throw e; }));",
    "}",
    "async function haveAll() { for (const f of await filesFor()) if (!(await V.has(f))) return false; return true; }",
    "// the pack: 8-bit weights and a scale per row, back to fp32 (scripts/voice-pack.py writes it)",
    "function expand(qb) {",
    "  const dv = new DataView(qb); if (dv.getUint32(0, false) !== 0x51425138) throw new Error(\"not a pack\");",
    "  const hl = dv.getUint32(8, true), head = JSON.parse(new TextDecoder().decode(new Uint8Array(qb, 12, hl))), base = 12 + hl;",
    "  const out = new ArrayBuffer(head.total), o8 = new Uint8Array(out);",
    "  for (const t of head.tensors) {",
    '    if (t.enc === "f32") { o8.set(new Uint8Array(qb, base + t.at, t.len), t.off); continue; }',
    "    const sc = new Float32Array(qb, base + t.at, t.rows), q = new Int8Array(qb, base + t.at + t.rows * 4, t.rows * t.cols), f = new Float32Array(out, t.off, t.rows * t.cols);",
    "    for (let r = 0, i = 0; r < t.rows; r++) { const k = sc[r] / 127; for (let c = 0; c < t.cols; c++, i++) f[i] = q[i] * k; }",
    "  }",
    "  return out;",
    "}",
    "// while packed: the model's config says its weights are in model.onnx_data, and those two files are made from the pack",
    "// the model, whichever file it comes from, with its durations as an output (2.4)",
    "V.route((url) => {",
    "  if (url === HF + CPU.file || (!packed && url === HF + GPU.file)) return V.file(url).then((b) => new Response(addOutput(b, DUR)));",
    "  if (!packed) return null;",
    '  if (url === HF + "config.json") return V.file(url).then((b) => { const j = JSON.parse(new TextDecoder().decode(b)); j["transformers.js_config"] = Object.assign({}, j["transformers.js_config"], { use_external_data_format: { "model.onnx": 1 } }); return new Response(JSON.stringify(j)); });',
    '  if (url === HF + GPU.file) return V.file(PACK + "model.onnx").then((b) => new Response(addOutput(b, DUR)));',
    '  if (url === HF + GPU.file + "_data") return V.file(PACK + "model.q8.bin").then((b) => { const o = expand(b); return new Response(o, { headers: { "content-length": String(o.byteLength) } }); });',
    "  return null;",
    "});",
    "async function load(voice) {",
    "  await fetchAll();",
    "  const K = await V.importCode(BUNDLE, BUNDLE);",
    '  K.env.wasmPaths = { mjs: await V.blobUrl(ORT + "mjs", "text/javascript"), wasm: await V.blobUrl(ORT + "wasm", "application/wasm") };',
    '  const make = (m, g) => K.KokoroTTS.from_pretrained("onnx-community/Kokoro-82M-v1.0-ONNX", { dtype: m.dtype, device: g ? "webgpu" : "wasm" });',
    "  if (!gpu) tts = await make(CPU, false);",
    "  else {",
    "    try { tts = await make(GPU, true); }",
    "    catch (e) {",
    "      // no pack to be had: the whole file; and a GPU that can't run it at all: the processor",
    "      if (packed) { packed = false; try { await V.plan([HF + GPU.file]); tts = await make(GPU, true); } catch (e2) { tts = null; } }",
    "      if (!tts) { await V.plan([HF + CPU.file]); tts = await make(CPU, false); }",
    "    }",
    "  }",
    "  // the files of 1.0's model (q4f16) aren't used any more: their 155 MB go",
    '  try { const r = indexedDB.open("qb-kokoro", 1); r.onsuccess = () => { const st = r.result.transaction("files", "readwrite").objectStore("files"); const k = st.getAllKeys(); k.onsuccess = () => (k.result || []).forEach((x) => { if (/q4f16/.test(String(x))) st.delete(x); }); }; } catch (e) {}',
    "  // each run's input and its durations, kept for wordMarks",
    "  const run = tts.model._call.bind(tts.model);",
    "  tts.model._call = async (x) => { const o = await run(x); last = { ids: Array.from(x.input_ids.data, Number), dur: o[DUR] ? Array.from(o[DUR].data, Number) : null }; return o; };",
    '  await tts.generate("Ready.", { voice });   // the first one is slow; better now',
    "}",
    "// one at a time, so each piece's durations are its own (2.4)",
    "let queue = Promise.resolve();",
    "self.onmessage = (e) => { const m = e.data; queue = queue.then(() => handle(m)); };",
    "async function handle(m) {",
    "  try {",
    '    if (m.t === "load") { await load(m.voice || "af_heart"); postMessage({ t: "ready", id: m.id }); }',
    '    else if (m.t === "fetch") { await fetchAll(); postMessage({ t: "fetched", id: m.id }); }',
    '    else if (m.t === "have") postMessage({ t: "have", id: m.id, have: await haveAll() });',
    '    else if (m.t === "synth") {',
    "      // a GPU has given a piece of NaNs now and then: made again, and anything still broken is silence",
    "      const t0 = performance.now();",
    "      let a = await tts.generate(m.text, { voice: m.voice, speed: m.speed });",
    "      if (a.audio.some(Number.isNaN)) a = await tts.generate(m.text, { voice: m.voice, speed: m.speed });",
    "      const s = a.audio; for (let i = 0; i < s.length; i++) if (Number.isNaN(s[i])) s[i] = 0;",
    "      let marks = null;",
    "      try { if (last && last.dur && last.dur.length === last.ids.length) marks = tighten(wordMarks(m.text, tts.tokenizer.model.convert_ids_to_tokens(last.ids), last.dur), s, a.sampling_rate); } catch (x) {}",
    '      const dbg = m.debug && last ? { toks: tts.tokenizer.model.convert_ids_to_tokens(last.ids), dur: last.dur } : null;',
    '      const rtf = (performance.now() - t0) / 1000 / Math.max(0.5, s.length / a.sampling_rate);   // how long it took to make, over how long it lasts',
    '      postMessage({ t: "audio", id: m.id, samples: s, rate: a.sampling_rate, marks, dbg, rtf, gpu, threads: !!self.crossOriginIsolated }, marks ? [s.buffer, marks.buffer] : [s.buffer]);',
    "    }",
    '  } catch (err) { postMessage({ t: "error", id: m.id, error: String((err && err.message) || err) }); }',
    "}",
  ].join("\n");
  function call(msg) { return new Promise(function (res, rej) { var id = ++wid; msg.id = id; wq[id] = { res: res, rej: rej }; worker.postMessage(msg); }); }
  function ensureWorker() {
    if (worker) return;
    worker = new Worker(URL.createObjectURL(new Blob([WORKER], { type: "text/javascript" })), { type: "module" });
    worker.onmessage = function (e) {
      var m = e.data;
      if (m.t === "progress") { var f = m.total ? m.loaded / m.total : 0; listeners.concat(dlFns).forEach(function (fn) { try { fn(f); } catch (x) {} }); return; }
      var w = wq[m.id]; if (!w) return; delete wq[m.id];
      if (m.t === "error") w.rej(new Error(m.error));
      else if (m.t === "audio") { if (m.rtf > 0) { pace = pace ? pace * 0.6 + m.rtf * 0.4 : m.rtf; made++; onGpu = !!m.gpu; threads = !!m.threads; } w.res({ samples: m.samples, rate: m.rate, marks: m.marks || null, dbg: m.dbg || null }); }
      else if (m.t === "have") w.res(!!m.have);
      else w.res(true);
    };
  }
  // o.voice: the voice picked in the app (it's warmed up with that one)
  function load(onProgress, o) {
    if (onProgress) listeners.push(onProgress);
    if (ready) return Promise.resolve();
    if (loading) return loading;
    try { ensureWorker(); } catch (e) { return Promise.reject(e); }
    loading = call({ t: "load", voice: (o && o.voice) || "af_heart" }).then(function () { ready = true; listeners = []; }, function (e) { loading = null; listeners = []; try { worker.terminate(); } catch (x) {} worker = null; throw e; });
    return loading;
  }
  // (2.4) when it makes speech slower than it speaks (no graphics chip the browser can use), the Voice panel says why
  // it pauses: the app shows note()
  function note() {
    if (made < 2 || pace < 1.05) return "";
    return "Kokoro speaks faster than this computer can make it, so it pauses between sentences." + (onGpu ? "" : " A graphics chip the browser can use makes it quick.");
  }
  ctx.registerVoice({
    id: "kokoro", name: "Kokoro",
    voices: VOICES,
    ready: function () { return ready; },
    load: load,
    synth: function (text, o) { return load().then(function () { return call({ t: "synth", text: text, voice: o.voice || "af_heart", speed: Math.min(MAX_SPEED, o.speed || 1), debug: !!o.debug }); }); },
    note: note,
  });
  // (2.1) its files come down as soon as it's got, so picking it later never waits for the download; the model itself
  // is made when it's picked (the app gets the picked voice ready at launch). Getting it from the Store downloads them
  // there, its card showing how far (ctx.registerDownload, 15.71); an older app: in the background, 3 s after it starts
  function download(onProgress) {
    try { ensureWorker(); } catch (e) { return Promise.reject(e); }
    if (onProgress) dlFns.push(onProgress);
    var off = function () { dlFns = dlFns.filter(function (fn) { return fn !== onProgress; }); };
    return call({ t: "fetch" }).then(off, function (e) { off(); throw e; });
  }
  var fetchT = 0;
  if (ctx.registerDownload) ctx.registerDownload({ done: function () { if (ready) return true; try { ensureWorker(); } catch (e) { return true; } return call({ t: "have" }); }, start: download });
  else fetchT = setTimeout(function () { if (!ready && !loading) download().catch(function () {}); }, 3000);
  ctx._cleanup = function () {
    clearTimeout(fetchT); if (worker) { try { worker.terminate(); } catch (e) {} worker = null; } ready = false; loading = null; };

}
