QB.registerPlugin({
  id: "folders",
  name: "Question Folders",
  version: "2.10.0",
  author: "OfflineQuiz",
  description: "Save questions into your own named folders and play any folder as a practice session.",
  onEnable: __qbMain,
});
