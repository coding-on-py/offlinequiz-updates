QB.registerPlugin({
  id: "folders",
  name: "Question Folders",
  version: "2.13.0",
  author: "OfflineQuiz",
  description: "Save questions into your own folders and play any folder as practice.",
  onEnable: __qbMain,
});
