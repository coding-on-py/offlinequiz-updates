QB.registerPlugin({
  id: "folders",
  name: "Question Folders",
  version: "2.7.0",
  author: "OfflineQuiz",
  description: "Organize tossups, bonuses, flashcards, coach modes, buzz words and keywords into folders. Six type folders on the home page; create subfolders inside each and double-click to open. Right-click a subfolder to run it.",
  onEnable: __qbMain,
});
