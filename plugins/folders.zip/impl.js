function __qbMain(ctx) {
    function esc(s) { return (s == null ? "" : String(s)).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
    function ansHtml(raw, fallback) {
      var src = (raw && String(raw).trim()) ? String(raw) : String(fallback || "");
      var html = esc(src).replace(/&lt;(\/?)(b|u|i|em|strong)&gt;/gi, "<$1$2>");
      var d = document.createElement("div"); d.innerHTML = html; return d.innerHTML;
    }

    var TYPES = [
      { key: "tossups", label: "Tossups", item: "tossup", run: ["tossups", "flashcards", "coach"], core: true },
      { key: "bonuses", label: "Bonuses", item: "bonus", run: ["bonuses"], core: true },
      { key: "flashcards", label: "Flashcards", item: "flashcard", run: ["flashcards"], pluginId: "flashcards" },
      { key: "coachmodes", label: "Coach Modes", item: "coach", run: ["coach"], pluginId: "coach-mode" },
      { key: "buzzwords", label: "Buzz Words", item: "buzzword", run: ["flashcards"], pluginId: "buzz-words" },
      { key: "keywords", label: "Keywords", item: "keyword", run: ["flashcards"], pluginId: "keyword-freq" },
    ];
    function pluginEnabled(t) {
      if (t.core) return true;
      if (t.dynamic) return !!t.live;
      try { return !!(window.QB && window.QB.isPluginEnabled && window.QB.isPluginEnabled(t.pluginId)); } catch (e) { return true; }
    }
    var TYPE_BY_KEY = {}; TYPES.forEach(function (t) { TYPE_BY_KEY[t.key] = t; });
    var FOLDER_SVG = '<svg viewBox="0 0 24 24" width="34" height="34" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></svg>';

    function blank() { return { tossups: {}, bonuses: {}, flashcards: {}, coachmodes: {}, buzzwords: {}, keywords: {} }; }
    function data() {
      var d = ctx.storage.get("folders2");
      if (!d) { d = migrate(); ctx.storage.set("folders2", d); }
      TYPES.forEach(function (t) { if (!d[t.key]) d[t.key] = {}; });
      return d;
    }
    function save(d) { ctx.storage.set("folders2", d); }
    function migrate() {
      var d = blank();
      var old = ctx.storage.get("folders");
      if (old && typeof old === "object") {
        Object.keys(old).forEach(function (name) {
          (old[name] || []).forEach(function (e) {
            if (!e || !e.q) return;
            var bucket = e.type === "bonus" ? "bonuses" : "tossups";
            (d[bucket][name] = d[bucket][name] || []).push({ type: e.type || "tossup", q: e.q });
          });
        });
      }
      return d;
    }

    function addItem(typeKey, sub, item) {
      var d = data();
      var bucket = d[typeKey] || (d[typeKey] = {});
      var list = bucket[sub] = bucket[sub] || [];
      var key = itemKey(item);
      if (list.some(function (e) { return itemKey(e) === key; })) { ctx.toast("Already in “" + sub + "”"); return; }
      list.push(item); save(d); ctx.toast("Added to “" + sub + "”");
    }
    function itemKey(it) {
      if (!it) return "";
      if (it.q) return (it.type || "") + ":" + it.q.id;
      if (it.card) return "card:" + (it.card.front || "") + "|" + (it.card.back || "");
      if (it.kw != null) return "bw:" + it.kw + "|" + it.answer;
      if (it.front != null) return "kw:" + it.front + "|" + it.back;
      return JSON.stringify(it);
    }

    window.QBFolders = {
      add: function (typeKey, sub, item) { if (TYPE_BY_KEY[typeKey] && sub && item) addItem(typeKey, sub, item); },
      subfolders: function (typeKey) { var b = data()[typeKey] || {}; return Object.keys(b).sort(); },
      pick: function (typeKey, item, anchor) { pickSubfolder(typeKey, item, anchor); },
      // Other plugins register their own folder type — no Folders update needed.
      // spec: { key, label, item (noun for one entry), run (optional: ["flashcards"])
      //        renderItem (optional: function(item) -> html for the list row) }
      // Returns an unregister function; the type's saved DATA survives
      // unregistration and shows dimmed until the plugin returns.
      registerType: function (spec) {
        if (!spec || !spec.key || TYPE_BY_KEY[spec.key]) return function () {};
        var t = {
          key: String(spec.key), label: spec.label || spec.key, item: spec.item || "item",
          run: Array.isArray(spec.run) ? spec.run : [], dynamic: true, live: true,
          renderItem: typeof spec.renderItem === "function" ? spec.renderItem : null,
        };
        TYPES.push(t); TYPE_BY_KEY[t.key] = t;
        rerender();
        return function () { t.live = false; rerender(); };
      },
    };

    function overlay(title, bodyHtml) {
      var ov = document.createElement("div");
      ov.className = "fo-overlay";
      ov.innerHTML = '<div class="fo-dialog"><div class="filter-label">' + esc(title) + "</div>" + bodyHtml + "</div>";
      document.body.appendChild(ov);
      ov.addEventListener("click", function (e) { if (e.target === ov) ov.remove(); });
      return ov;
    }
    function namePrompt(title, initial, onName) {
      var ov = overlay(title,
        '<input type="text" id="fo-name" class="mode-input" value="' + esc(initial || "") + '" placeholder="Folder name…" autocomplete="off" spellcheck="false">' +
        '<div class="fo-row"><button class="btn btn-primary" id="fo-ok">Save</button><button class="btn btn-ghost" id="fo-x">Cancel</button></div>');
      var inp = ov.querySelector("#fo-name"); inp.focus(); inp.select();
      function ok() { var n = inp.value.trim(); if (!n) { inp.focus(); return; } if (onName(n) === false) { inp.classList.add("input-error"); inp.title = "Name already used"; inp.focus(); inp.select(); return; } ov.remove(); }
      inp.addEventListener("input", function () { inp.classList.remove("input-error"); inp.removeAttribute("title"); });
      ov.querySelector("#fo-ok").onclick = ok;
      ov.querySelector("#fo-x").onclick = function () { ov.remove(); };
      inp.addEventListener("keydown", function (e) { if (e.key === "Enter") { e.preventDefault(); ok(); } if (e.key === "Escape") { e.stopPropagation(); ov.remove(); } });
    }

    function pickSubfolder(typeKey, item, anchor, rectOverride) {
      var subs = QBFolders.subfolders(typeKey);
      closePop();
      var pop = document.createElement("div");
      pop.className = "fo-pop";
      pop.innerHTML =
        subs.map(function (s) { return '<div class="fo-pop-item" data-sub="' + esc(s) + '">' + FOLDER_SVG + "<span>" + esc(s) + "</span></div>"; }).join("") +
        '<div class="fo-pop-item fo-pop-new" data-new="1">+ New subfolder…</div>';
      document.body.appendChild(pop);
      var r = rectOverride || (anchor && anchor.getBoundingClientRect ? anchor.getBoundingClientRect() : null);
      if (!r || (!r.left && !r.top && !r.bottom)) r = { left: Math.max(8, (window.innerWidth - 240) / 2), bottom: window.innerHeight / 3 };
      pop.style.left = Math.max(8, Math.min(r.left, window.innerWidth - 240)) + "px";
      var popTop = (r.bottom != null ? r.bottom : (r.top || 0)) + 4;
      pop.style.top = Math.max(8, Math.min(popTop, window.innerHeight - pop.offsetHeight - 8)) + "px";
      pop.querySelectorAll("[data-sub]").forEach(function (el) { el.onclick = function () { closePop(); addItem(typeKey, el.dataset.sub, item); }; });
      pop.querySelector("[data-new]").onclick = function () { closePop(); namePrompt("New subfolder in " + TYPE_BY_KEY[typeKey].label, "", function (n) { addItem(typeKey, n, item); }); };
      setTimeout(function () { document.addEventListener("mousedown", closePopOnce, true); }, 0);
    }
    function closePop() { var p = document.querySelector(".fo-pop"); if (p) p.remove(); document.removeEventListener("mousedown", closePopOnce, true); }
    function closePopOnce(e) { if (!e.target.closest(".fo-pop")) closePop(); }

    ctx.registerSaveAction(function (q, type) {
      var typeKey = type === "bonus" ? "bonuses" : "tossups";
      return [{ label: "Add to folder…", onClick: function (opts) { pickSubfolder(typeKey, { type: type, q: q }, document.getElementById("save-menu"), opts && opts.anchorRect); } }];
    });

    var _nav = [];
    var _container = null;

    ctx.registerStarredProvider({
      id: "folders", title: "Folders",
      render: function (container) { _container = container; rerender(); },
    });
    ctx.onBack(function () {
      if (_nav.length && _container && document.body.contains(_container) && _container.offsetParent !== null) {
        _nav.pop(); rerender(); return true;
      }
      return false;
    });

    function rerender() {
      if (!_container) return;
      var d = data();
      if (_nav.length === 0) renderHome(_container, d);
      else if (_nav.length === 1) renderType(_container, d, _nav[0]);
      else renderSub(_container, d, _nav[0], _nav[1]);
    }

    function tile(inner, attrs) { return '<div class="fo-tile"' + (attrs || "") + ">" + inner + "</div>"; }

    // Click model: first click SELECTS a folder tile; clicking the selected
    // tile opens it (double-click still opens directly). Clicking the grid
    // background clears the selection.
    function wireSelectOpen(el, open) {
      el.onclick = function (e) {
        if (e.target.closest(".fo-x")) return;
        if (el.classList.contains("fo-selected")) { open(); return; }
        var grid = el.closest(".fo-grid") || el.parentElement;
        if (grid) grid.querySelectorAll(".fo-selected").forEach(function (x) { x.classList.remove("fo-selected"); });
        el.classList.add("fo-selected");
      };
      el.ondblclick = function (e) { if (!e.target.closest(".fo-x")) open(); };
      el.onkeydown = function (e) { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); open(); } };
    }
    function wireGridDeselect(c) {
      var grid = c.querySelector(".fo-grid");
      if (grid) grid.addEventListener("click", function (e) {
        if (e.target === grid) grid.querySelectorAll(".fo-selected").forEach(function (x) { x.classList.remove("fo-selected"); });
      });
    }
    function renderHome(c, d) {
      var tiles = TYPES.map(function (t) {
        var n = Object.keys(d[t.key] || {}).length;
        var en = pluginEnabled(t);
        if (!en && n === 0) return "";
        var dim = !en && n > 0;
        return '<div class="fo-tile' + (dim ? " fo-tile-dim" : "") + '" data-type="' + t.key + '"' + (dim ? ' data-dim="1"' : "") + ' tabindex="0">' + FOLDER_SVG +
          '<div class="fo-tile-name">' + esc(t.label) + (dim ? ' <span class="fo-dim-tag">(disabled)</span>' : "") + "</div>" +
          '<div class="fo-tile-sub">' + n + " folder" + (n === 1 ? "" : "s") + "</div></div>";
      }).filter(Boolean).join("");
      c.innerHTML = '<div class="fo-grid">' + tiles + "</div>";
      c.querySelectorAll("[data-type]").forEach(function (el) {
        if (el.dataset.dim) {
          var warn = function () { ctx.toast("Enable the " + TYPE_BY_KEY[el.dataset.type].label + " plugin to open these folders", "error"); };
          el.onclick = warn;
          el.ondblclick = warn;
          el.onkeydown = function (e) { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); warn(); } };
          return;
        }
        wireSelectOpen(el, function () { _nav = [el.dataset.type]; rerender(); });
      });
      wireGridDeselect(c);
    }
    function renderType(c, d, typeKey) {
      var t = TYPE_BY_KEY[typeKey], bucket = d[typeKey] || {};
      var subs = Object.keys(bucket).sort();
      c.innerHTML =
        '<div class="fo-head"><button class="btn btn-sm btn-ghost" id="fo-back">‹ Back</button>' +
          '<span class="fo-crumb">' + esc(t.label) + "</span>" +
          '<button class="btn btn-sm" id="fo-newsub">+ New subfolder</button></div>' +
        '<div class="fo-grid">' + (subs.length ? subs.map(function (s) {
          return '<div class="fo-tile" data-sub="' + esc(s) + '" tabindex="0">' + FOLDER_SVG +
            '<div class="fo-tile-name">' + esc(s) + "</div>" +
            '<div class="fo-tile-sub">' + bucket[s].length + " item" + (bucket[s].length === 1 ? "" : "s") + "</div>" +
            '<button class="fo-x" data-del="' + esc(s) + '" title="Delete">×</button></div>';
        }).join("") : '<div class="text-muted" style="padding:16px">No subfolders yet.</div>') + "</div>";
      c.querySelector("#fo-back").onclick = function () { _nav.pop(); rerender(); };
      c.querySelector("#fo-newsub").onclick = function () { namePrompt("New subfolder in " + t.label, "", function (n) { var dd = data(); if (!Object.prototype.hasOwnProperty.call(dd[typeKey], n)) dd[typeKey][n] = []; save(dd); rerender(); }); };
      c.querySelectorAll("[data-sub]").forEach(function (el) {
        wireSelectOpen(el, function () { _nav = [typeKey, el.dataset.sub]; rerender(); });
        el.oncontextmenu = function (e) { e.preventDefault(); runMenu(typeKey, el.dataset.sub, e); };
      });
      wireGridDeselect(c);
      c.querySelectorAll("[data-del]").forEach(function (el) {
        el.onclick = function (e) {
          e.stopPropagation();
          ctx.host && ctx.host.confirm ? ctx.host.confirm("Delete subfolder “" + el.dataset.del + "”?", function () { var dd = data(); delete dd[typeKey][el.dataset.del]; save(dd); rerender(); }, { yes: "Delete" }) : (function () { var dd = data(); delete dd[typeKey][el.dataset.del]; save(dd); rerender(); })();
        };
      });
    }
    function renderSub(c, d, typeKey, sub) {
      var t = TYPE_BY_KEY[typeKey], list = (d[typeKey] || {})[sub] || [];
      var needs = [], canRun = (t.run || []).some(function (target) {
        if (target === "flashcards" && !pluginActive("flashcards::")) { if (needs.indexOf("Flashcards") < 0) needs.push("Flashcards"); return false; }
        if (target === "coach" && !pluginActive("coach-mode::")) { if (needs.indexOf("Coach Mode") < 0) needs.push("Coach Mode"); return false; }
        return true;
      });
      c.innerHTML =
        '<div class="fo-head"><button class="btn btn-sm btn-ghost" id="fo-back">‹ Back</button>' +
          '<span class="fo-crumb">' + esc(t.label) + " / " + esc(sub) + "</span>" +
          '<button class="btn btn-sm" id="fo-run"' + (canRun && list.length ? "" : ' disabled title="' + esc(!list.length ? "Folder is empty" : needs.length ? "Needs " + needs.join(" or ") : "Unavailable") + '"') + '>Run ▸</button>' +
          '<button class="btn btn-sm btn-ghost" id="fo-rename">Rename</button></div>' +
        (list.length ? list.map(function (it, i) { return itemCard(it, i, t); }).join("") : '<div class="text-muted" style="padding:16px">Empty folder.</div>');
      c.querySelector("#fo-back").onclick = function () { _nav.pop(); rerender(); };
      c.querySelector("#fo-run").onclick = function (e) { runMenu(typeKey, sub, e); };
      c.querySelector("#fo-rename").onclick = function () { namePrompt("Rename subfolder", sub, function (n) {
        var dd = data(); if (n === sub) return;
        if (Object.prototype.hasOwnProperty.call(dd[typeKey], n)) { ctx.toast("A subfolder named “" + n + "” already exists", "error"); return false; }
        dd[typeKey][n] = dd[typeKey][sub] || []; delete dd[typeKey][sub]; save(dd); _nav = [typeKey, n]; rerender();
      }); };
      c.querySelectorAll("[data-unfile]").forEach(function (el) {
        el.onclick = function () { var dd = data(); dd[typeKey][sub].splice(parseInt(el.dataset.unfile), 1); save(dd); rerender(); };
      });
    }
    function itemCard(it, idx, t) {
      var x = '<button class="fo-x" data-unfile="' + idx + '" title="Remove">×</button>';
      if (t && t.renderItem) { try { var custom = t.renderItem(it); if (custom) return '<div class="qcard expanded fo-card">' + x + custom + "</div>"; } catch (e) {} }
      if (it.q) {
        var q = it.q;
        if (it.type === "bonus") {
          var leadin = q.leadin_sanitized || q.leadin || "";
          var parts = []; try { parts = JSON.parse(q.parts_sanitized || q.parts || "[]"); } catch (e) {}
          var answers = []; try { answers = JSON.parse(q.answers_sanitized || q.answers || "[]"); } catch (e) {}
          var raws = []; try { raws = JSON.parse(q.answers || "[]"); } catch (e) {}
          return '<div class="qcard expanded fo-card">' + x + '<div class="qcard-text">' + esc(leadin) + "</div>" +
            parts.map(function (pt, k) { return '<div class="qcard-part">[10] ' + esc(pt) + "<br><span class=\"ans\">ANSWER: " + ansHtml(raws[k], answers[k] || "") + "</span></div>"; }).join("") + "</div>";
        }
        return '<div class="qcard expanded fo-card">' + x + '<div class="qcard-text">' + esc(q.question_sanitized || q.question || "") + "</div>" +
          '<div class="qcard-answer">ANSWER: <span class="ans">' + ansHtml(q.answer, q.answer_sanitized || "") + "</span></div></div>";
      }
      if (it.card) return '<div class="qcard expanded fo-card">' + x + '<div class="qcard-text"><strong>' + esc(it.card.front || "") + "</strong></div><div class=\"qcard-answer\">" + esc(it.card.back || "") + "</div></div>";
      if (it.kw != null) return '<div class="qcard expanded fo-card">' + x + '<div class="qcard-text">' + esc(it.kw) + " → <strong>" + esc(it.answer || "") + "</strong></div></div>";
      if (it.front != null) return '<div class="qcard expanded fo-card">' + x + '<div class="qcard-text">' + esc(it.front) + " → <strong>" + esc(it.back || "") + "</strong></div></div>";
      return '<div class="qcard expanded fo-card">' + x + "</div>";
    }

    function pluginActive(pageStart) { return ((window.QB && window.QB.getActivePages && window.QB.getActivePages()) || []).some(function (p) { return p.id.indexOf(pageStart) === 0; }); }
    function runMenu(typeKey, sub, ev) {
      var t = TYPE_BY_KEY[typeKey], list = (data()[typeKey] || {})[sub] || [];
      if (!list.length) { ctx.toast("Folder is empty"); return; }
      var opts = [];
      t.run.forEach(function (target) {
        if (target === "flashcards" && !pluginActive("flashcards::")) return;
        if (target === "coach" && !pluginActive("coach-mode::")) return;
        var label = target === "tossups" ? "Run as Tossups" : target === "bonuses" ? "Run as Bonuses" : target === "flashcards" ? "Study as Flashcards" : "Run in Coach Mode";
        opts.push({ target: target, label: label });
      });
      if (!opts.length) { ctx.toast("Enable Flashcards or Coach Mode to run this", "error"); return; }
      closePop();
      var pop = document.createElement("div");
      pop.className = "fo-pop";
      pop.innerHTML = opts.map(function (o) { return '<div class="fo-pop-item" data-run="' + o.target + '"><span>' + esc(o.label) + "</span></div>"; }).join("");
      document.body.appendChild(pop);
      var x = ev && ev.clientX != null ? ev.clientX : 120, y = ev && ev.clientY != null ? ev.clientY : 120;
      pop.style.left = Math.min(x, window.innerWidth - 220) + "px";
      pop.style.top = y + "px";
      pop.querySelectorAll("[data-run]").forEach(function (el) { el.onclick = function () { closePop(); runFolder(typeKey, list, el.dataset.run); }; });
      setTimeout(function () { document.addEventListener("mousedown", closePopOnce, true); }, 0);
    }
    function runFolder(typeKey, list, target) {
      if (target === "tossups" || target === "bonuses") {
        var ids = list.map(function (e) { return e.q && e.q.id; }).filter(Boolean);
        if (!ctx.host || !ctx.host.launchQuestions || !ctx.host.launchQuestions(target, ids)) ctx.toast("Could not start session", "error");
        return;
      }
      if (target === "coach") {
        var cids = list.map(function (e) { return e.q && e.q.id; }).filter(Boolean);
        if (cids.length) { ctx.host.launchQuestions("coach", cids); return; }
        ctx.toast("No questions to coach", "error"); return;
      }
      var qids = list.map(function (e) { return e.q && e.q.id; }).filter(Boolean);
      if (qids.length) { ctx.host.launchQuestions("flashcards", qids); return; }
      var cards = list.map(function (e) {
        if (e.card) return e.card;
        if (e.kw != null) return { front: e.kw, back: e.answer, meta: "buzz word" };
        if (e.front != null) return { front: e.front, back: e.back, meta: "keyword" };
        return null;
      }).filter(Boolean);
      if (!cards.length) { ctx.toast("Nothing to study", "error"); return; }
      try { localStorage.setItem("qb-flashcards-cards", JSON.stringify({ cards: cards, ts: Date.now() })); } catch (e) {}
      if (!(window.QB && window.QB.showPage && window.QB.showPage("flashcards::cards"))) { try { localStorage.removeItem("qb-flashcards-cards"); } catch (e) {} ctx.toast("Enable the Flashcards plugin first", "error"); }
    }


    ctx._unsub.push(function () { try { delete window.QBFolders; } catch (e) {} closePop(); });
  }
