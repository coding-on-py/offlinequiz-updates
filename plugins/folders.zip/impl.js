function __qbMain(ctx) {
    function esc(s) { return (s == null ? "" : String(s)).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
    var ENT = { amp: "&", lt: "<", gt: ">", quot: '"', apos: "'", nbsp: " " };
    function decodeEnt(s) {
      return String(s || "").replace(/&(#x[0-9a-f]+|#\d+|[a-z]+);/gi, function (m, e) {
        try { if (e[0] === "#") return String.fromCodePoint(e[1] === "x" || e[1] === "X" ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10)); } catch (err) { return m; }
        var v = ENT[e.toLowerCase()]; return v != null ? v : m;
      });
    }
    // Allow-listed inline HTML, like the base's answer lines: <b> <u> <i> <em>
    // <strong> <sup> survive, any other "<…>" is text, entities decode once.
    function ansHtml(raw, fallback) {
      var src = (raw && String(raw).trim()) ? String(raw) : String(fallback || "");
      var html = src.split(/(<\/?(?:b|u|i|em|strong|sup)>)/i).map(function (p, i) { return i % 2 ? p.toLowerCase() : esc(decodeEnt(p)); }).join("");
      var d = document.createElement("div"); d.innerHTML = html; return d.innerHTML;
    }
    function jsonArr(v) { if (Array.isArray(v)) return v; try { var a = JSON.parse(v || "[]"); return Array.isArray(a) ? a : []; } catch (e) { return []; } }
    // Snapshot text as the practice screen reads it (host helper: notes and
    // guides per the user's settings); older bases: the plain copy.
    function snapText(q, kind, part, plain) {
      try { if (ctx.host && ctx.host.questionText) { var t = ctx.host.questionText(q, kind, part); if (t != null) return String(t); } } catch (e) {}
      return plain || "";
    }
    // Per-part point values (10 each when the record states none).
    function partValues(q, n) {
      var v = null;
      try { if (ctx.host && ctx.host.bonusValues) v = ctx.host.bonusValues(q).values; } catch (e) { v = null; }
      if (!Array.isArray(v)) v = jsonArr(q && q.point_values);
      var out = [];
      for (var i = 0; i < n; i++) out.push(Number(v[i]) > 0 ? Number(v[i]) : 10);
      return out;
    }
    // The short answer a card is titled with ("Hamlet" from "<b><u>Hamlet</u></b> [or …]").
    function primaryAnswer(raw, sani) {
      var t = "";
      try { if (ctx.host && ctx.host.extractPrimaryAnswer) t = ctx.host.extractPrimaryAnswer(raw || "", sani || "") || ""; } catch (e) { t = ""; }
      if (!t) t = String(sani || decodeEnt(String(raw || "").replace(/<[^>]*>/g, ""))).replace(/\s*[\[(].*$/, "").trim();
      return t || "?";
    }

    // "(*)" in the app's colours, bold up to the power mark.
    function powerMarks(h) {
      var mark = '<span class="power-mark-inline">(*)</span>', i = h.indexOf("(*)");
      if (i < 0) return h;
      return '<strong class="pre-power">' + h.slice(0, i) + "</strong>" + mark + h.slice(i + 3).replace(/\(\*\)/g, mark);
    }
    // ── icons (24×24 stroke, like the app's own set) ──
    var IC = {
      folder: '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
      plus: '<path d="M12 5v14M5 12h14"/>',
      play: '<path d="M7 4l13 8-13 8z"/>',
      pencil: '<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="M13.5 6.5l4 4"/>',
      trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
      more: '<circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/>',
      x: '<path d="M6 6l12 12M18 6L6 18"/>',
      check: '<path d="M5 12l5 5 9-10"/>',
      left: '<path d="M15 6l-6 6 6 6"/>',
      right: '<path d="M9 6l6 6-6 6"/>',
    };
    function ic(name, size) {
      var s = size || 16;
      return '<svg width="' + s + '" height="' + s + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (IC[name] || "") + "</svg>";
    }
    // The twelve roots keep the app's hues on the category badge.
    var ROOT_COLOR = { "Literature": "#bc8cff", "Science and Math": "#58a6ff", "Fine Arts": "#f778ba", "History": "#e3b341", "Geography": "#56d364", "Mythology": "#ffa657", "Pop Culture Sports": "#ff7b72", "Social Science": "#3dd6a3", "Philosophy": "#39c5cf", "Theology": "#8e9bff", "Current Events": "#c9d16b", "Miscellaneous": "#8b949e" };

    // ── folder types ──
    // one / many: how a folder's count reads ("12 tossups", "1 card").
    var TYPES = [
      { key: "tossups", label: "Tossups", one: "tossup", many: "tossups", run: ["tossups", "flashcards", "coach"], core: true },
      { key: "bonuses", label: "Bonuses", one: "bonus", many: "bonuses", run: ["bonuses"], core: true },
      { key: "flashcards", label: "Flashcards", one: "card", many: "cards", run: ["flashcards"], pluginId: "flashcards" },
      { key: "buzzwords", label: "Buzzwords", one: "buzzword", many: "buzzwords", run: ["flashcards"], pluginId: "buzz-words" },
      { key: "keywords", label: "Keywords", one: "keyword", many: "keywords", run: ["flashcards"], pluginId: "keyword-freq" },
      // Nothing saves into this one any more; older folders still show.
      { key: "coachmodes", label: "Coach", one: "question", many: "questions", run: ["coach"], legacy: true },
    ];
    var TYPE_BY_KEY = {}; TYPES.forEach(function (t) { TYPE_BY_KEY[t.key] = t; });
    function pluginOn(t) {
      if (t.core) return true;
      if (t.legacy) return false;
      if (t.dynamic) return !!t.live;
      try { return !!(window.QB && window.QB.isPluginEnabled && window.QB.isPluginEnabled(t.pluginId)); } catch (e) { return true; }
    }
    function countLabel(t, n) { return n + " " + (n === 1 ? t.one : t.many); }
    // A type a plugin uses before (or without) registering it: a plain stand-in
    // until registerType() replaces it.
    function ensureType(k) {
      k = String(k || "");
      if (!k || TYPE_BY_KEY[k]) return TYPE_BY_KEY[k] || null;
      var t = { key: k, label: k.charAt(0).toUpperCase() + k.slice(1), one: "item", many: "items", run: ["flashcards"], provisional: true };
      TYPES.push(t); TYPE_BY_KEY[k] = t;
      return t;
    }

    // ── storage (this computer; the website: this browser) ──
    function blank() { var d = {}; TYPES.forEach(function (t) { d[t.key] = {}; }); return d; }
    var _cache = null;
    function data() {
      if (_cache) return _cache;
      var d = ctx.storage.get("folders2");
      if (!d || typeof d !== "object") { d = migrate(); ctx.storage.set("folders2", d); }
      TYPES.forEach(function (t) { if (!d[t.key] || typeof d[t.key] !== "object") d[t.key] = {}; });
      _cache = d;
      return d;
    }
    function save(d) { _cache = d; ctx.storage.set("folders2", d); }
    // another tab of the website changed them: read them again
    function onStorage(e) { if (e.key === "qb-pl-folders-folders2") { _cache = null; refresh(); } }
    window.addEventListener("storage", onStorage);
    function migrate() {
      var d = blank();
      var old = ctx.storage.get("folders");
      if (old && typeof old === "object") {
        Object.keys(old).forEach(function (name) {
          (old[name] || []).forEach(function (e) {
            if (!e || !e.q) return;
            var bucket = e.type === "bonus" ? "bonuses" : "tossups";
            (d[bucket][name] = d[bucket][name] || []).push({ type: e.type || "tossup", q: e.q });
          });
        });
      }
      return d;
    }
    var has = function (o, k) { return Object.prototype.hasOwnProperty.call(o, k); };
    function names(typeKey) {
      var b = data()[typeKey] || {};
      return Object.keys(b).sort(function (a, c) { return a.localeCompare(c, undefined, { numeric: true, sensitivity: "base" }); });
    }
    // An existing folder whose name matches regardless of case/spacing.
    function findName(typeKey, name) {
      var want = String(name).trim().toLowerCase();
      var b = data()[typeKey] || {};
      var hit = null;
      Object.keys(b).forEach(function (k) { if (!hit && k.trim().toLowerCase() === want) hit = k; });
      return hit;
    }
    function itemKey(it) {
      if (!it) return "";
      if (it.q) return (it.type || "") + ":" + it.q.id;
      if (it.card) return "card:" + (it.card.front || "") + "|" + (it.card.back || "");
      if (it.kw != null) return "bw:" + it.kw + "|" + it.answer;
      if (it.front != null) return "kw:" + it.front + "|" + it.back;
      return JSON.stringify(it);
    }
    function contains(typeKey, name, item) {
      var list = ((data()[typeKey] || {})[name]) || [], k = itemKey(item);
      return list.some(function (e) { return itemKey(e) === k; });
    }
    function createFolder(typeKey, name) {
      var d = data();
      var hit = findName(typeKey, name);
      if (hit) return hit;
      d[typeKey] = d[typeKey] || {};
      d[typeKey][name] = [];
      save(d);
      return name;
    }
    function addItem(typeKey, name, item) {
      var d = data();
      var bucket = d[typeKey] || (d[typeKey] = {});
      var list = bucket[name] = bucket[name] || [];
      if (contains(typeKey, name, item)) return false;
      list.push(item); save(d); refresh();
      return true;
    }
    function removeItem(typeKey, name, item) {
      var d = data(), list = (d[typeKey] || {})[name];
      if (!list) return;
      var k = itemKey(item);
      d[typeKey][name] = list.filter(function (e) { return itemKey(e) !== k; });
      save(d); refresh();
    }
    function renameFolder(typeKey, from, to) {
      var d = data();
      if (from === to) return true;
      var clash = findName(typeKey, to);
      if (clash && clash !== from) return false;
      var b = d[typeKey], out = {};
      // keep the bucket's insertion order apart from the renamed key
      Object.keys(b).forEach(function (k) { out[k === from ? to : k] = b[k]; });
      d[typeKey] = out; save(d);
      if (view.open === from && view.type === typeKey) view.open = to;
      return true;
    }
    function deleteFolder(typeKey, name) {
      var d = data();
      delete d[typeKey][name]; save(d);
      if (view.open === name && view.type === typeKey) view.open = null;
      refresh();
    }

    // Other plugins (Flashcards, Buzzwords, Keyword Frequency, Fact Sheet) and
    // the app's item save menu use this.
    window.QBFolders = {
      add: function (typeKey, sub, item) { if (ensureType(typeKey) && sub && item) addItem(typeKey, sub, item); },
      subfolders: function (typeKey) { return names(typeKey); },
      pick: function (typeKey, item, anchor) { openPicker(typeKey, item, anchor); },
      // spec: { key, label, item (noun for one entry), run (optional: ["flashcards"]),
      //        renderItem (optional: function(item) -> html for the list row) }
      // Returns an unregister function; the type's saved DATA survives and
      // shows (without Play) until the plugin returns.
      registerType: function (spec) {
        if (!spec || !spec.key) return function () {};
        var old = TYPE_BY_KEY[spec.key];
        // a built-in type can't be replaced; a plugin type comes back to life
        // when its plugin is turned on again
        if (old && !old.provisional && !old.dynamic) return function () {};
        var noun = spec.item || "item";
        var t = old && old.dynamic ? old : {};
        Object.assign(t, {
          key: String(spec.key), label: spec.label || spec.key, one: noun, many: /s$/.test(noun) ? noun : noun + "s",
          run: Array.isArray(spec.run) ? spec.run : [], dynamic: true, live: true, provisional: false,
          renderItem: typeof spec.renderItem === "function" ? spec.renderItem : null,
        });
        if (old && old !== t) { TYPES.splice(TYPES.indexOf(old), 1); delete TYPE_BY_KEY[old.key]; }
        if (TYPES.indexOf(t) < 0) TYPES.push(t);
        TYPE_BY_KEY[t.key] = t;
        refresh();
        return function () { t.live = false; refresh(); };
      },
    };

    // ── dialogs & menus (the app's own look; every open/close animates) ──
    function animateOut(el) {
      if (!el || !el.isConnected || el.classList.contains("qb-leaving")) return;
      if (window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches) { el.remove(); return; }
      el.classList.add("qb-leaving");
      el.style.pointerEvents = "none";
      var done = false;
      var fin = function () { if (done) return; done = true; el.remove(); };
      el.addEventListener("animationend", function (e) { if (e.target === el) fin(); });
      setTimeout(fin, 260);
    }
    // A one-line name box: Enter / the button answers, Esc / backdrop / Cancel
    // drop it. check(name) returns an error string to keep the box open.
    function askName(title, initial, yes, check, onOk) {
      var old = document.getElementById("fo-name-dialog"); if (old) old.remove();
      var el = document.createElement("div");
      el.id = "fo-name-dialog";
      el.className = "qb-overlay confirm-overlay fo-dialog";
      el.setAttribute("role", "dialog"); el.setAttribute("aria-modal", "true"); el.setAttribute("aria-label", title);
      el.innerHTML = '<form class="confirm-box prompt-box"><div class="confirm-title">' + esc(title) + "</div>" +
        '<input class="mode-input" id="fo-name-in" maxlength="60" autocomplete="off" spellcheck="false" placeholder="Folder name" value="' + esc(initial || "") + '">' +
        '<div class="fo-name-err" id="fo-name-err" role="alert"></div>' +
        '<div class="confirm-actions"><button type="button" class="btn btn-ghost" id="fo-name-no">Cancel</button><button type="submit" class="btn btn-primary">' + esc(yes || "Save") + "</button></div></form>";
      var close = function () { animateOut(el); };
      el.addEventListener("click", function (e) { if (e.target === el) close(); });
      el.addEventListener("keydown", function (e) { if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); close(); } });
      document.body.appendChild(el);
      var inp = el.querySelector("#fo-name-in"), err = el.querySelector("#fo-name-err");
      inp.addEventListener("input", function () { err.textContent = ""; inp.classList.remove("input-error"); });
      el.querySelector("form").addEventListener("submit", function (e) {
        e.preventDefault();
        var v = inp.value.replace(/\s+/g, " ").trim();
        if (!v) { inp.focus(); return; }
        var bad = check ? check(v) : "";
        if (bad) { err.textContent = bad; inp.classList.add("input-error"); inp.focus(); inp.select(); return; }
        close();
        try { onOk(v); } catch (x) { console.error(x); }
      });
      el.querySelector("#fo-name-no").onclick = close;
      setTimeout(function () { inp.focus(); inp.select(); }, 30);
      return el;
    }
    function confirmDelete(typeKey, name) {
      var t = TYPE_BY_KEY[typeKey], n = (((data()[typeKey] || {})[name]) || []).length;
      var go = function () { deleteFolder(typeKey, name); };
      if (ctx.host && ctx.host.confirm) ctx.host.confirm("Delete “" + name + "”?", go, { yes: "Delete", danger: true, detail: n ? countLabel(t, n) : "" });
      else go();
    }
    function promptRename(typeKey, name) {
      askName("Rename folder", name, "Rename", function (v) {
        var clash = findName(typeKey, v);
        return clash && clash !== name ? "Name already used" : "";
      }, function (v) { renameFolder(typeKey, name, v); refresh(); });
    }
    function promptNew(typeKey, item) {
      var t = TYPE_BY_KEY[typeKey];
      askName(item ? "New folder" : "New " + t.one + " folder", "", item ? "Create and add" : "Create", null, function (v) {
        var name = createFolder(typeKey, v);
        if (item) addItem(typeKey, name, item);
        else { view.type = typeKey; view.open = name; saveView(); }
        refresh();
      });
    }

    // ── the folder picker ("Add to folder…") ──
    var _pick = null;
    function closePicker() {
      if (!_pick) return;
      var p = _pick; _pick = null;
      document.removeEventListener("mousedown", pickAway, true);
      document.removeEventListener("keydown", pickKey, true);
      animateOut(p);
    }
    function pickAway(e) { if (_pick && !_pick.contains(e.target)) closePicker(); }
    function pickKey(e) { if (_pick && e.key === "Escape") { e.preventDefault(); e.stopPropagation(); closePicker(); } }
    function openPicker(typeKey, item, anchor, rectOverride) {
      if (!ensureType(typeKey) || !item) return;
      closePicker();
      var subs = names(typeKey);
      var pop = document.createElement("div");
      pop.className = "save-menu fo-pick";
      pop.setAttribute("role", "menu");
      pop.innerHTML = '<div class="fo-pick-title">Add to folder</div>' +
        (subs.length ? '<div class="fo-pick-list">' + subs.map(function (s) {
          var on = contains(typeKey, s, item);
          return '<button type="button" class="fo-pick-row' + (on ? " on" : "") + '" role="menuitemcheckbox" aria-checked="' + on + '" data-sub="' + esc(s) + '">' +
            '<span class="fo-pick-ico">' + ic("folder", 16) + '</span><span class="fo-pick-name">' + esc(s) + '</span><span class="fo-pick-n">' + (((data()[typeKey] || {})[s]) || []).length + '</span><span class="fo-pick-check">' + ic("check", 15) + "</span></button>";
        }).join("") + "</div>" : "") +
        '<button type="button" class="fo-pick-row fo-pick-new" role="menuitem" data-new="1"><span class="fo-pick-ico">' + ic("plus", 16) + '</span><span class="fo-pick-name">New folder…</span></button>';
      document.body.appendChild(pop);
      _pick = pop;
      var r = rectOverride || null;
      if (!r) { try { r = anchor && anchor.getBoundingClientRect ? anchor.getBoundingClientRect() : null; } catch (e) { r = null; } }
      if (!r || (!r.left && !r.top && !r.bottom)) r = { left: (window.innerWidth - pop.offsetWidth) / 2, bottom: window.innerHeight / 3 };
      var left = Math.max(8, Math.min(r.left, window.innerWidth - pop.offsetWidth - 8));
      var top = (r.bottom != null ? r.bottom : (r.top || 0)) + 4;
      if (top + pop.offsetHeight > window.innerHeight - 8) top = Math.max(8, (r.top != null ? r.top : top) - pop.offsetHeight - 4);
      pop.style.left = left + "px";
      pop.style.top = Math.max(8, Math.min(top, window.innerHeight - pop.offsetHeight - 8)) + "px";
      pop.querySelectorAll("[data-sub]").forEach(function (el) {
        el.onclick = function () {
          var s = el.dataset.sub, on = contains(typeKey, s, item);
          if (on) removeItem(typeKey, s, item); else addItem(typeKey, s, item);
          el.classList.toggle("on", !on); el.setAttribute("aria-checked", String(!on));
          var n = el.querySelector(".fo-pick-n"); if (n) n.textContent = (((data()[typeKey] || {})[s]) || []).length;
          pop.classList.add("fo-pick-done");
          setTimeout(function () { if (_pick === pop) closePicker(); }, 420);
        };
      });
      pop.querySelector("[data-new]").onclick = function () { closePicker(); promptNew(typeKey, item); };
      setTimeout(function () {
        if (_pick !== pop) return;
        document.addEventListener("mousedown", pickAway, true);
        document.addEventListener("keydown", pickKey, true);
        var first = pop.querySelector(".fo-pick-row"); if (first) first.focus({ preventScroll: true });
      }, 0);
    }
    ctx.on("screen:change", closePicker);

    // The question save menu ("+" next to the star, everywhere): straight to a
    // new folder while there are none, else the picker.
    ctx.registerSaveAction(function (q, type) {
      var typeKey = type === "bonus" ? "bonuses" : "tossups";
      var item = { type: type, q: q };
      if (!names(typeKey).length) return [{ label: "Add to new folder…", onClick: function () { promptNew(typeKey, item); } }];
      return [{ label: "Add to folder…", onClick: function (opts) { openPicker(typeKey, item, document.getElementById("save-menu"), opts && opts.anchorRect); } }];
    });

    // ── the Folders view: the plugin page AND Database → Plugin tools → Folders ──
    var view = Object.assign({ type: "tossups", open: null }, ctx.storage.get("view") || {});
    function saveView() { ctx.storage.set("view", { type: view.type, open: view.open }); }
    var _container = null;

    ctx.registerPage({
      id: "folders", navLabel: "Folders", title: "Folders",
      onShow: function (el, info) {
        _container = el;
        if (!(info && info.back)) view.open = null;
        render();
      },
    });
    ctx.registerStarredProvider({
      id: "folders", title: "Folders",
      render: function (container) { _container = container; view.open = null; render(); },
    });
    function shown() { return !!(_container && _container.isConnected && _container.offsetParent !== null); }
    function refresh() { if (shown()) render(); }
    ctx.onBack(function () {
      if (view.open != null && shown()) { view.open = null; saveView(); render(); return true; }
      return false;
    });

    // Types offered as tabs: the two question types, plus each plugin type
    // whose plugin is on or that still holds folders.
    function visibleTypes(d) {
      // Folders of a type whose plugin hasn't registered it (yet) still show.
      Object.keys(d).forEach(function (k) {
        if (!TYPE_BY_KEY[k] && d[k] && typeof d[k] === "object" && Object.keys(d[k]).length) ensureType(k);
      });
      return TYPES.filter(function (t) { return t.core || pluginOn(t) || Object.keys(d[t.key] || {}).length > 0; });
    }
    function render() {
      if (!_container) return;
      var d = data();
      var types = visibleTypes(d);
      if (!types.some(function (t) { return t.key === view.type; })) { view.type = "tossups"; view.open = null; }
      if (view.open != null && !has(d[view.type] || {}, view.open)) view.open = null;
      if (view.open != null) renderFolder(d, types); else renderHome(d, types);
    }

    function renderHome(d, types) {
      var t = TYPE_BY_KEY[view.type], bucket = d[t.key] || {}, subs = names(t.key);
      var tabs = types.map(function (x) {
        var n = Object.keys(d[x.key] || {}).length, on = x.key === t.key;
        return '<button type="button" class="db-tab fo-tab' + (on ? " active" : "") + '" role="tab" aria-selected="' + on + '" data-type="' + esc(x.key) + '">' + esc(x.label) + (n ? '<span class="fo-tab-n num">' + n + "</span>" : "") + "</button>";
      }).join("");
      var rows = subs.map(function (s) {
        var n = (bucket[s] || []).length;
        return '<div class="list-row clickable fo-row" role="button" tabindex="0" data-sub="' + esc(s) + '">' +
          '<span class="fo-row-ico">' + ic("folder", 18) + "</span>" +
          '<span class="lr-name">' + esc(s) + "</span>" +
          '<span class="fo-row-n num">' + esc(countLabel(t, n)) + "</span>" +
          '<button type="button" class="btn btn-ghost btn-icon btn-sm fo-more" data-more="' + esc(s) + '" aria-label="Folder actions" title="More">' + ic("more", 16) + "</button>" +
          "</div>";
      }).join("");
      _container.innerHTML =
        '<div class="fo-page">' +
          '<div class="fo-bar">' +
            '<div class="fo-tabs" role="tablist" aria-label="Folder type">' + tabs + "</div>" +
            '<button type="button" class="btn btn-primary fo-new" id="fo-new">' + ic("plus", 16) + '<span>New<span class="fo-new-long"> folder</span></span></button>' +
          "</div>" +
          (subs.length ? '<div class="list fo-list">' + rows + "</div>" : '<div class="db-empty fo-empty">No folders yet</div>') +
        "</div>";
      _container.querySelectorAll("[data-type]").forEach(function (b) {
        b.onclick = function () { view.type = b.dataset.type; view.open = null; saveView(); render(); };
      });
      // a narrow screen scrolls the tabs sideways: keep the chosen one in view
      var strip = _container.querySelector(".fo-tabs"), on = strip && strip.querySelector(".fo-tab.active");
      if (strip && on && strip.scrollWidth > strip.clientWidth) strip.scrollLeft = Math.max(0, on.offsetLeft - strip.offsetLeft - (strip.clientWidth - on.offsetWidth) / 2);
      if (strip) {
        var fades = function () { strip.classList.toggle("fo-fade-l", strip.scrollLeft > 2); strip.classList.toggle("fo-fade-r", strip.scrollLeft + strip.clientWidth < strip.scrollWidth - 2); };
        strip.addEventListener("scroll", fades, { passive: true }); fades();
      }
      _container.querySelector("#fo-new").onclick = function () { promptNew(t.key, null); };
      _container.querySelectorAll(".fo-row").forEach(function (row) {
        var s = row.dataset.sub;
        var open = function () { view.open = s; saveView(); render(); };
        row.addEventListener("click", function (e) { if (!e.target.closest(".fo-more")) open(); });
        row.addEventListener("keydown", function (e) { if ((e.key === "Enter" || e.key === " ") && e.target === row) { e.preventDefault(); open(); } });
        row.addEventListener("contextmenu", function (e) { e.preventDefault(); folderMenu(t.key, s, e.clientX, e.clientY); });
      });
      _container.querySelectorAll("[data-more]").forEach(function (b) {
        b.onclick = function (e) {
          e.stopPropagation();
          var r = b.getBoundingClientRect();
          folderMenu(t.key, b.dataset.more, Math.max(8, r.right - 200), r.bottom + 4);
        };
      });
    }
    function folderMenu(typeKey, name, x, y) {
      var list = ((data()[typeKey] || {})[name]) || [];
      var opts = runOptions(TYPE_BY_KEY[typeKey]);
      var items = [];
      if (list.length) opts.filter(function (o) { return o.ok; }).forEach(function (o) { items.push({ label: o.label, onClick: function () { runFolder(typeKey, name, o.target); } }); });
      if (items.length) items.push({ sep: true });
      items.push({ label: "Rename…", onClick: function () { promptRename(typeKey, name); } });
      items.push({ label: "Delete…", danger: true, onClick: function () { confirmDelete(typeKey, name); } });
      if (ctx.contextMenu) ctx.contextMenu(x, y, items, { title: name });
    }

    // What a folder can be played as. ok = the page that plays it is here.
    function pagePresent(prefix) { return ((window.QB && window.QB.getActivePages && window.QB.getActivePages()) || []).some(function (p) { return p.id.indexOf(prefix) === 0; }); }
    function runOptions(t) {
      if (!t || (t.dynamic && !t.live)) return [];
      return (t.run || []).map(function (target) {
        if (target === "tossups") return { target: target, label: "Play", primary: true, ok: true };
        if (target === "bonuses") return { target: target, label: "Play", primary: true, ok: true };
        if (target === "coach") return { target: target, label: "Coach", ok: pagePresent("coach-mode::") };
        return { target: target, label: "Flashcards", primary: t.key !== "tossups", ok: pagePresent("flashcards::") };
      });
    }

    function renderFolder(d, types) {
      var t = TYPE_BY_KEY[view.type], name = view.open, list = (d[t.key] || {})[name] || [];
      var opts = runOptions(t).filter(function (o) { return o.ok; });
      var btns = opts.map(function (o, i) {
        var main = i === 0;
        return '<button type="button" class="btn' + (main ? " btn-primary" : "") + ' fo-run" data-run="' + o.target + '"' + (list.length ? "" : " disabled") + ">" + (main ? ic("play", 14) : "") + esc(o.label) + "</button>";
      }).join("");
      _container.innerHTML =
        '<div class="fo-page">' +
          '<div class="fo-crumbs"><button type="button" class="btn btn-ghost btn-sm fo-back" id="fo-back">' + ic("left", 15) + "Folders</button></div>" +
          '<div class="fo-head">' +
            '<span class="fo-head-ico">' + ic("folder", 22) + "</span>" +
            '<div class="fo-title"><b id="fo-title">' + esc(name) + '</b><small class="num">' + esc(countLabel(t, list.length)) + '<span class="fo-status" id="fo-status"></span></small></div>' +
            '<div class="fo-actions">' + btns +
              '<button type="button" class="btn btn-ghost btn-icon" id="fo-rename" title="Rename" aria-label="Rename folder">' + ic("pencil", 16) + "</button>" +
              '<button type="button" class="btn btn-ghost btn-icon fo-del" id="fo-delete" title="Delete" aria-label="Delete folder">' + ic("trash", 16) + "</button>" +
            "</div>" +
          "</div>" +
          (list.length ? '<div class="results fo-items">' + list.map(function (it, i) { return itemCard(it, i, t); }).join("") + "</div>"
            : '<div class="db-empty fo-empty">No ' + esc(t.many) + " yet</div>") +
        "</div>";
      _container.querySelector("#fo-back").onclick = function () { view.open = null; saveView(); render(); };
      _container.querySelector("#fo-rename").onclick = function () { promptRename(t.key, name); };
      _container.querySelector("#fo-delete").onclick = function () { confirmDelete(t.key, name); };
      _container.querySelectorAll("[data-run]").forEach(function (b) { b.onclick = function () { runFolder(t.key, name, b.dataset.run); }; });
      _container.querySelectorAll("[data-unfile]").forEach(function (b) {
        b.onclick = function (e) {
          e.stopPropagation();
          var it = list[parseInt(b.dataset.unfile, 10)];
          var card = b.closest(".qcard");
          if (card) { card.classList.add("fo-going"); }
          setTimeout(function () { removeItem(t.key, name, it); }, card ? 160 : 0);
        };
      });
      _container.querySelectorAll(".fo-items .qcard .save-plus").forEach(function (b) {
        b.onclick = function (e) {
          e.stopPropagation();
          var it = list[parseInt(b.closest(".qcard").dataset.i, 10)];
          if (it && it.q && ctx.host && ctx.host.openSaveMenu) ctx.host.openSaveMenu(it.q, it.type === "bonus" ? "bonus" : "tossup", b);
        };
      });
    }

    function tagsRow(q) {
      var path = String(q.category_path || [q.category, q.subcategory, q.alternate_subcategory].filter(Boolean).join(" > "));
      var parts = path.split(" > ").filter(Boolean), out = "";
      if (parts.length) {
        var short = parts.length > 1 ? parts[0] + " › " + parts[parts.length - 1] : parts[0];
        out += '<span class="badge cat-badge" style="--c:' + (ROOT_COLOR[parts[0]] || "#8b949e") + '" title="' + esc(parts.join(" › ")) + '"><span class="dot"></span><span class="t">' + esc(short) + "</span></span>";
      }
      if (q.set_year) out += '<span class="badge year-badge">' + esc(String(q.set_year)) + "</span>";
      if (q.set_name) out += '<span class="src">' + esc(q.set_name + (q.packet_number ? " · packet " + q.packet_number : "")) + "</span>";
      return out ? '<div class="qcard-tags qmeta-row">' + out + "</div>" : "";
    }
    function itemCard(it, idx, t) {
      var x = '<button type="button" class="btn btn-ghost btn-icon btn-sm fo-unfile" data-unfile="' + idx + '" title="Remove from folder" aria-label="Remove from folder">' + ic("x", 15) + "</button>";
      var head = function (title, kind, side) {
        return '<div class="qcard-head"><span class="qcard-chev" aria-hidden="true"></span><div class="qcard-title"><span class="qcard-ans">' + title + "</span>" +
          (kind ? '<span class="qcard-kind">' + esc(kind) + "</span>" : "") + '</div><span class="qcard-side">' + (side || "") + x + "</span></div>";
      };
      if (t && t.renderItem) {
        try {
          var custom = t.renderItem(it);
          if (custom) return '<div class="qcard expanded fo-card fo-plain" data-self-toggle data-i="' + idx + '"><div class="fo-plain-row"><div class="fo-plain-body">' + custom + "</div>" + x + "</div></div>";
        } catch (e) {}
      }
      if (it.q) {
        var q = it.q, diff = q.difficulty != null && q.difficulty !== "" ? " · Diff " + q.difficulty : "";
        var plus = '<span class="star-btn save-plus" title="Save to review / folders">+</span>';
        if (it.type === "bonus") {
          var leadin = snapText(q, "leadin", 0, q.leadin_sanitized || q.leadin || "");
          var parts = jsonArr(q.parts_sanitized); if (!parts.length) parts = jsonArr(q.parts);
          var answers = jsonArr(q.answers_sanitized); if (!answers.length) answers = jsonArr(q.answers);
          var raws = jsonArr(q.answers);
          var vals = partValues(q, parts.length);
          var title = answers.map(function (a, k) { return esc(primaryAnswer(raws[k], a)); }).filter(Boolean).join(" / ") || "?";
          return '<div class="qcard compact fo-card" data-i="' + idx + '">' + head('<span class="ans">' + title + "</span>", "Bonus · " + parts.length + " part" + (parts.length === 1 ? "" : "s") + diff, plus) +
            '<div class="qcard-body"><div class="qcard-text">' + esc(leadin) + "</div>" +
            parts.map(function (pt, k) { return '<div class="qcard-part">[' + vals[k] + "] " + esc(snapText(q, "part", k, pt)) + '<br><span class="ans">ANSWER: ' + ansHtml(raws[k], answers[k] || "") + "</span></div>"; }).join("") + "</div>" +
            tagsRow(q) + "</div>";
        }
        return '<div class="qcard compact fo-card" data-i="' + idx + '">' + head('<span class="ans">' + esc(primaryAnswer(q.answer, q.answer_sanitized)) + "</span>", "Tossup" + diff, plus) +
          '<div class="qcard-body"><div class="qcard-text">' + powerMarks(esc(snapText(q, "question", 0, q.question_sanitized || q.question || ""))) + "</div>" +
          '<div class="qcard-answer"><span class="ra-k">Answer</span> <span class="ans">' + ansHtml(q.answer, q.answer_sanitized || "") + "</span></div></div>" +
          tagsRow(q) + "</div>";
      }
      var front = "", back = "";
      if (it.card) { front = it.card.front || ""; back = it.card.back || ""; }
      else if (it.kw != null) { front = it.kw; back = it.answer || ""; }
      else if (it.front != null) { front = it.front; back = it.back || ""; }
      return '<div class="qcard expanded fo-card fo-plain" data-self-toggle data-i="' + idx + '"><div class="fo-plain-row"><div class="fo-plain-body"><b>' + esc(front) + "</b>" +
        (back ? '<span class="fo-plain-arrow">' + ic("right", 14) + '</span><span class="ans">' + esc(back) + "</span>" : "") + "</div>" + x + "</div></div>";
    }

    // ── playing a folder ──
    // A question row by id: the stored type first, then the other one (the
    // new database moved 28 old tossup ids to bonuses). null = not found.
    async function fetchRow(id, type) {
      var order = type === "bonus" ? ["bonus", "tossup"] : ["tossup", "bonus"];
      for (var k = 0; k < order.length; k++) {
        try {
          var r = await ctx.api.get("/api/" + (order[k] === "bonus" ? "bonuses/" : "tossups/") + encodeURIComponent(id));
          var row = r && (order[k] === "bonus" ? r.bonus : r.tossup);
          if (row) return { type: order[k], q: row };
        } catch (e) {}
      }
      return null;
    }
    // Snapshots are what a folder SHOWS; a run works on the live rows. Every
    // question item is re-fetched by id, its snapshot refreshed (type
    // included), and the resolved list returned; unfound items are skipped.
    async function liveItems(typeKey, list) {
      var out = [], fresh = {};
      for (var i = 0; i < list.length; i++) {
        var e = list[i];
        if (!e || !e.q || !e.q.id) { out.push(e); continue; }
        var got = await fetchRow(e.q.id, e.type);
        if (!got) continue;
        fresh[(e.type || "") + ":" + e.q.id] = got;
        out.push(got);
      }
      // Write the refreshed rows back into the CURRENT folders (they may have
      // changed while fetching); an id already present under its new type
      // is not duplicated.
      var d = data(), changed = false;
      Object.keys(d[typeKey] || {}).forEach(function (sub) {
        var arr = d[typeKey][sub], seen = {};
        arr.forEach(function (e) { if (e && e.q) seen[(e.type || "") + ":" + e.q.id] = true; });
        for (var j = arr.length - 1; j >= 0; j--) {
          var e = arr[j], k = e && e.q ? (e.type || "") + ":" + e.q.id : null, got = k && fresh[k];
          if (!got) continue;
          var nk = got.type + ":" + got.q.id;
          if (nk !== k && seen[nk]) { arr.splice(j, 1); changed = true; continue; }
          arr[j] = { type: got.type, q: got.q }; seen[nk] = true; changed = true;
        }
      });
      if (changed) { try { save(d); } catch (e) {} }
      return out;
    }
    function runStatus(t) { var el = document.getElementById("fo-status"); if (el) el.textContent = t ? " · " + t : ""; }
    async function runFolder(typeKey, name, target) {
      var list = ((data()[typeKey] || {})[name] || []).slice();
      if (!list.length) return;
      var hasQ = list.some(function (e) { return e && e.q && e.q.id; });
      if (hasQ) {
        document.querySelectorAll(".fo-run").forEach(function (b) { b.disabled = true; });
        runStatus("Loading…");
        try { list = await liveItems(typeKey, list); } catch (e) {}
        document.querySelectorAll(".fo-run").forEach(function (b) { b.disabled = false; });
        runStatus("");
      }
      var idsOf = function (type) { return list.map(function (e) { return e && e.q && e.type === type ? e.q.id : null; }).filter(Boolean); };
      var launch = function (to, ids) { return !!(ids.length && ctx.host && ctx.host.launchQuestions && ctx.host.launchQuestions(to, ids)); };
      if (target === "tossups" || target === "bonuses") {
        if (!launch(target, idsOf(target === "bonuses" ? "bonus" : "tossup"))) runStatus("Nothing to play");
        return;
      }
      if (target === "coach") { if (!launch("coach", idsOf("tossup"))) runStatus("Nothing to play"); return; }
      if (hasQ) { if (!launch("flashcards", idsOf("tossup"))) runStatus("Nothing to play"); return; }
      var cards = list.map(function (e) {
        if (!e) return null;
        if (e.card) return e.card;
        if (e.kw != null) return { front: e.kw, back: e.answer, meta: "buzz word" };
        if (e.front != null) return { front: e.front, back: e.back, meta: "keyword" };
        return null;
      }).filter(function (c) { return c && (c.front || c.back); });
      if (!cards.length) { runStatus("Nothing to play"); return; }
      try { localStorage.setItem("qb-flashcards-cards", JSON.stringify({ cards: cards, ts: Date.now() })); } catch (e) {}
      if (!(window.QB && window.QB.showPage && window.QB.showPage("flashcards::cards"))) { try { localStorage.removeItem("qb-flashcards-cards"); } catch (e) {} runStatus("Needs Flashcards"); }
    }

    ctx.on("plugins:changed", function () { refresh(); });
    ctx._unsub.push(function () { try { delete window.QBFolders; } catch (e) {} window.removeEventListener("storage", onStorage); closePicker(); var dl = document.getElementById("fo-name-dialog"); if (dl) dl.remove(); });
  }
