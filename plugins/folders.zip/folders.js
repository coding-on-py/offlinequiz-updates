/**
 * OfflineQuiz plugin: Question Folders
 *
 * Organize questions into named folders. While practicing, the ＋ button next
 * to the star opens the save menu — with this plugin enabled it lists every
 * folder you've made (plus "New folder…") alongside "Add to Review". Browse,
 * expand, and prune your folders from Database → Folders.
 */
QB.registerPlugin({
  id: "folders",
  name: "Question Folders",
  version: "1.6.0",
  author: "OfflineQuiz",
  description: "Save questions into named folders from the ＋ button next to the star; browse and manage them in the Database screen.",
  onEnable: function (ctx) {
    function esc(s) { return (s == null ? "" : String(s)).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
    function ansHtml(raw, fallback) {
      var src = (raw && String(raw).trim()) ? String(raw) : String(fallback || "");
      var html = esc(src).replace(/&lt;(\/?)(b|u|i|em|strong)&gt;/gi, "<$1$2>");
      var d = document.createElement("div"); d.innerHTML = html; return d.innerHTML;
    }
    function folders() { return ctx.storage.get("folders") || {}; }
    function save(f) { ctx.storage.set("folders", f); }
    var _openFolders = {};   // collapse/expand state per folder name
    function askConfirm(message, onYes, yesLabel) {
      try { if (ctx.host && ctx.host.confirm) { ctx.host.confirm(message, onYes, { yes: yesLabel || "Delete" }); return; } } catch (e) {}
      if (window.confirm(message)) onYes();
    }
    // Small overlay to name a new folder (no question to file yet).
    function newFolderPrompt(onName) {
      var ov = document.createElement("div");
      ov.className = "fo-overlay";
      ov.innerHTML = '<div class="fo-dialog"><div class="filter-label">NEW FOLDER</div>' +
        '<input type="text" id="fo-newname" class="mode-input" placeholder="Folder name…" autocomplete="off" spellcheck="false">' +
        '<div class="fo-row"><button class="btn btn-primary" id="fo-mk">Create</button>' +
        '<button class="btn btn-ghost" id="fo-x">Cancel</button></div></div>';
      document.body.appendChild(ov);
      var inp = ov.querySelector("#fo-newname"); inp.focus();
      function done() { ov.remove(); }
      function mk() { var n = inp.value.trim(); if (!n) { inp.focus(); return; } done(); onName(n); }
      ov.querySelector("#fo-mk").onclick = mk;
      ov.querySelector("#fo-x").onclick = done;
      inp.addEventListener("keydown", function (e) { if (e.key === "Enter") { e.preventDefault(); mk(); } if (e.key === "Escape") { e.stopPropagation(); done(); } });
      ov.addEventListener("click", function (e) { if (e.target === ov) done(); });
    }
    function addTo(name, q, type) {
      var f = folders();
      var list = f[name] = f[name] || [];
      if (list.some(function (e) { return e.q && e.q.id === q.id && e.type === type; })) {
        ctx.toast("Already in “" + name + "”");
        return;
      }
      list.push({ type: type, q: q });
      save(f);
      ctx.toast("Added to “" + name + "”");
    }

    // ── entries in the base ＋ save menu ──
    ctx.registerSaveAction(function (q, type) {
      var f = folders();
      var items = Object.keys(f).sort().map(function (name) {
        return { label: "Folder: " + name + " (" + f[name].length + ")", onClick: function () { addTo(name, q, type); } };
      });
      items.push({ label: "New folder…", onClick: function () { newFolderDialog(q, type); } });
      return items;
    });

    // Tiny overlay dialog for naming a new folder (prompt() is unreliable in Electron).
    function newFolderDialog(q, type) {
      var ov = document.createElement("div");
      ov.className = "fo-overlay";
      ov.innerHTML =
        '<div class="fo-dialog">' +
          '<div class="filter-label">NEW FOLDER</div>' +
          '<input type="text" id="fo-name" class="mode-input" placeholder="Folder name…" autocomplete="off" spellcheck="false">' +
          '<div class="fo-row"><button class="btn btn-primary" id="fo-create">Create &amp; add</button>' +
          '<button class="btn btn-ghost" id="fo-cancel">Cancel</button></div>' +
        "</div>";
      document.body.appendChild(ov);
      var inp = ov.querySelector("#fo-name");
      inp.focus();
      function done() { ov.remove(); }
      function create() {
        var name = inp.value.trim();
        if (!name) { inp.focus(); return; }
        addTo(name, q, type);
        done();
      }
      ov.querySelector("#fo-create").onclick = create;
      ov.querySelector("#fo-cancel").onclick = done;
      inp.addEventListener("keydown", function (e) {
        if (e.key === "Enter") { e.preventDefault(); create(); }
        if (e.key === "Escape") { e.stopPropagation(); done(); }
      });
      ov.addEventListener("click", function (e) { if (e.target === ov) done(); });
    }

    // ── Database → Folders tab ──
    function qcardFor(entry, name, idx) {
      var q = entry.q || {};
      var head =
        '<div class="qcard-head"><span class="qcard-chev" aria-hidden="true"></span>' +
          '<span class="qcard-meta"><span>' + (entry.type === "bonus" ? "BONUS" : "TOSSUP") + "</span>" +
            "<span>" + esc(q.category || "?") + (q.subcategory ? " / " + esc(q.subcategory) : "") + "</span>" +
            "<span>Diff " + esc(String(q.difficulty != null ? q.difficulty : "?")) + "</span></span>" +
          '<span class="qcard-side"><button class="btn btn-sm btn-ghost" data-unfile="' + esc(name) + '" data-i="' + idx + '" title="Remove from folder">&times;</button></span></div>';
      var dataAttrs = ' data-cat="' + esc(q.category || "") + '" data-sub="' + esc(q.subcategory || "") + '" data-alt="' + esc(q.alternate_subcategory || "") + '"';
      if (entry.type === "bonus") {
        var parts = [], answers = [], raws = [];
        var _b = 1;
        try { parts = JSON.parse(q.parts_sanitized || "[]"); } catch (e) {}
        try { answers = JSON.parse(q.answers_sanitized || "[]"); } catch (e) {}
        try { raws = JSON.parse(q.answers || "[]"); } catch (e) {}
        return '<div class="qcard compact"' + dataAttrs + '>' + head +
          '<div class="qcard-answer">Answers: <span class="ans">' + answers.map(function (a, k) { return ansHtml(raws[k], a); }).join(" · ") + "</span></div>" +
          '<div class="qcard-body"><div class="qcard-text">' + esc(q.leadin_sanitized || "") + "</div>" +
          parts.map(function (pt, k) {
            return '<div class="qcard-part">[10] ' + esc(pt) + '<br><span class="ans">ANSWER: ' + ansHtml(raws[k], answers[k] || "") + "</span></div>";
          }).join("") + "</div></div>";
      }
      return '<div class="qcard compact"' + dataAttrs + '>' + head +
        '<div class="qcard-answer">Answer: <span class="ans">' + ansHtml(q.answer, q.answer_sanitized) + "</span></div>" +
        '<div class="qcard-body"><div class="qcard-text">' + esc(q.question_sanitized || q.question || "") + "</div></div></div>";
    }

    ctx.registerStarredProvider({
      id: "folders",
      title: "Folders",
      render: function renderFolders(container) {
        var f = folders();
        var names = Object.keys(f).sort();
        var header = '<div class="fo-bar">' +
          '<select id="fo-cat" class="mode-input"><option value="">All categories</option></select>' +
          '<select id="fo-sub" class="mode-input"><option value="">All subcategories</option></select>' +
          '<select id="fo-alt" class="mode-input"><option value="">All alternate subcategories</option></select>' +
          '<input type="text" id="fo-search" class="mode-input" placeholder="Search\u2026" autocomplete="off">' +
          '<button class="btn btn-primary" id="fo-new">+ New folder</button></div>';
        if (!names.length) {
          container.innerHTML = header + '<div class="text-muted" style="padding:16px">No folders yet — make one here, or press the ＋ next to the star while practicing.</div>';
        } else {
          container.innerHTML = header + names.map(function (name) {
            var open = _openFolders[name];
            return '<div class="fo-folder">' +
              '<div class="fo-head" data-toggle="' + esc(name) + '"><span class="fo-chev">' + (open ? "\u25be" : "\u25b8") + "</span>" +
              '<span class="filter-label" style="margin:0;flex:1">' + esc(name) + " (" + f[name].length + ")</span>" +
              '<button class="btn btn-sm btn-ghost" data-runfc="' + esc(name) + '" title="Study this folder as flashcards">▶ Flashcards</button>' +
              '<button class="btn btn-sm btn-ghost" data-runcm="' + esc(name) + '" title="Drill this folder in Coach Mode">▶ Coach</button>' +
              '<button class="btn btn-sm btn-ghost" data-delfolder="' + esc(name) + '">Delete folder</button></div>' +
              '<div class="fo-cards' + (open ? "" : " hidden") + '">' + f[name].map(function (entry, i) { return qcardFor(entry, name, i); }).join("") + "</div>" +
              "</div>";
          }).join("");
        }
        // create a new (empty) folder
        var nb = container.querySelector("#fo-new");
        if (nb) nb.onclick = function () {
          newFolderPrompt(function (name) {
            var ff = folders();
            if (ff[name]) { ctx.toast("Folder \u201c" + name + "\u201d already exists"); return; }
            ff[name] = []; save(ff); _openFolders[name] = true; renderFolders(container);
          });
        };
        // populate category / subcat / alt filters from the questions present
        var allQ = [];
        Object.keys(f).forEach(function (nm) { (f[nm] || []).forEach(function (e) { if (e.q) allQ.push(e.q); }); });
        var fcat = container.querySelector("#fo-cat"), fsub = container.querySelector("#fo-sub"), falt = container.querySelector("#fo-alt");
        function fill(sel, vals) { if (!sel) return; var cur = sel.value; var opts = vals.filter(Boolean).filter(function (v, i, a) { return a.indexOf(v) === i; }).sort(); sel.innerHTML = sel.options[0].outerHTML + opts.map(function (v) { return '<option value="' + esc(v) + '">' + esc(v) + "</option>"; }).join(""); if (opts.indexOf(cur) >= 0) sel.value = cur; }
        if (fcat) fill(fcat, allQ.map(function (q) { return q.category || ""; }));
        function refillSub() { var c = fcat ? fcat.value : ""; fill(fsub, allQ.filter(function (q) { return !c || q.category === c; }).map(function (q) { return q.subcategory || ""; })); fill(falt, allQ.filter(function (q) { return !c || q.category === c; }).map(function (q) { return q.alternate_subcategory || ""; })); }
        refillSub();
        function applyFilters() {
          var c = fcat ? fcat.value : "", su = fsub ? fsub.value : "", al = falt ? falt.value : "", qq = (sb && sb.value || "").toLowerCase().trim();
          container.querySelectorAll(".fo-folder").forEach(function (fol) {
            var any = false;
            fol.querySelectorAll(".qcard").forEach(function (card) {
              var show = true;
              if (c && (card.getAttribute("data-cat") || "") !== c) show = false;
              if (su && (card.getAttribute("data-sub") || "") !== su) show = false;
              if (al && (card.getAttribute("data-alt") || "") !== al) show = false;
              if (qq && (card.textContent || "").toLowerCase().indexOf(qq) < 0) show = false;
              card.classList.toggle("hidden", !show);
              if (show) any = true;
            });
            var active = c || su || al || qq;
            var bodyEl = fol.querySelector(".fo-cards");
            if (active) { if (bodyEl) bodyEl.classList.remove("hidden"); fol.classList.toggle("hidden", !any); }
            else fol.classList.remove("hidden");
          });
        }
        if (fcat) fcat.addEventListener("change", function () { refillSub(); applyFilters(); });
        if (fsub) fsub.addEventListener("change", applyFilters);
        if (falt) falt.addEventListener("change", applyFilters);
        var sb = container.querySelector("#fo-search");
        if (sb) sb.addEventListener("input", applyFilters);
        // collapse / expand a folder
        container.querySelectorAll("[data-toggle]").forEach(function (h) {
          h.addEventListener("click", function (e) {
            if (e.target.closest("[data-delfolder]")) return;
            var nm = h.dataset.toggle; _openFolders[nm] = !_openFolders[nm]; renderFolders(container);
          });
        });
        container.querySelectorAll("[data-unfile]").forEach(function (b) {
          b.addEventListener("click", function (e) {
            e.stopPropagation();
            askConfirm("Remove this question from the folder?", function () {
              var ff = folders();
              (ff[b.dataset.unfile] || []).splice(parseInt(b.dataset.i), 1);
              save(ff);
              renderFolders(container);
            }, "Remove");
          });
        });
        // Run a folder's tossups as Flashcards / Coach Mode (needs that plugin on).
        function folderTossupIds(name) { return (folders()[name] || []).filter(function (e) { return e.type === "tossup" && e.q && e.q.id; }).map(function (e) { return e.q.id; }); }
        function runFolder(name, target) {
          var ids = folderTossupIds(name);
          if (!ids.length) { ctx.toast("No tossups in this folder", "error"); return; }
          if (!ctx.launchQuestions) { ctx.toast("Update the app to run folders here", "error"); return; }
          ctx.playSound && ctx.playSound("toggle");
          ctx.launchQuestions(target, ids);
        }
        container.querySelectorAll("[data-runfc]").forEach(function (b) {
          b.addEventListener("click", function (e) { e.stopPropagation(); runFolder(b.dataset.runfc, "flashcards"); });
        });
        container.querySelectorAll("[data-runcm]").forEach(function (b) {
          b.addEventListener("click", function (e) { e.stopPropagation(); runFolder(b.dataset.runcm, "coach"); });
        });
        container.querySelectorAll("[data-delfolder]").forEach(function (b) {
          b.addEventListener("click", function (e) {
            e.stopPropagation();
            var ff = folders();
            var n = (ff[b.dataset.delfolder] || []).length;
            askConfirm("Delete the folder \u201c" + b.dataset.delfolder + "\u201d" + (n ? " and its " + n + " question" + (n === 1 ? "" : "s") : "") + "?", function () {
              var ff2 = folders();
              delete ff2[b.dataset.delfolder];
              save(ff2);
              renderFolders(container);
            }, "Delete folder");
          });
        });
      },
    });

    ctx.addCSS(
      ".fo-overlay{position:fixed;inset:0;z-index:10001;background:rgba(0,0,0,.5);display:flex;align-items:center;justify-content:center}" +
      ".fo-dialog{background:var(--bg-secondary);border:1px solid var(--border);border-radius:var(--radius);padding:16px;display:flex;flex-direction:column;gap:10px;min-width:300px}" +
      ".fo-row{display:flex;gap:8px;justify-content:flex-end}" +
      ".fo-folder{display:flex;flex-direction:column;gap:8px;margin-bottom:14px}" +
      ".fo-bar{display:flex;gap:8px;margin-bottom:14px;flex-wrap:wrap;align-items:stretch}" +
      ".fo-bar select{flex:1 1 150px;min-width:130px}" +
      ".fo-bar input{flex:1 1 100%;min-width:160px}" +
      ".fo-bar .btn{flex:0 0 auto;display:inline-flex;align-items:center}" +
      ".fo-head{display:flex;align-items:center;gap:8px;cursor:pointer;padding:4px 0}" +
      ".fo-chev{flex:0 0 auto;color:var(--text-muted);font-size:11px;width:12px}" +
      ".fo-cards{display:flex;flex-direction:column;gap:8px}"
    );
    ctx.toast("Question Folders enabled — use the ＋ next to the star.");
  },
  onDisable: function () {},
});
