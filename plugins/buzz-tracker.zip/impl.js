function __qbMain(ctx) {
  // ── the kit the 15.62 plugins share (text, icons, questions, judging, history) ──
  function esc(s) { return (s == null ? "" : String(s)).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
  var IC = {
    play: '<path d="M7 4l13 8-13 8z"/>',
    pause: '<path d="M8 5v14M16 5v14"/>',
    left: '<path d="M15 6l-6 6 6 6"/>',
    right: '<path d="M9 6l6 6-6 6"/>',
    next: '<path d="M6 5l9 7-9 7zM18 5v14"/>',
    refresh: '<path d="M20 11a8 8 0 10-2.3 5.7M20 4v7h-7"/>',
    x: '<path d="M6 6l12 12M18 6L6 18"/>',
    check: '<path d="M5 12l5 5 9-10"/>',
    mic: '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
    volume: '<path d="M4 9v6h4l5 4V5L8 9z"/><path d="M16 9a4 4 0 0 1 0 6M19 6a8 8 0 0 1 0 12"/>',
    copy: '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h3"/>',
    edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="M13.5 6.5l4 4"/>',
    bolt: '<path d="M13 3L5 14h6l-1 7 8-11h-6z"/>',
    flag: '<path d="M5 21V4M5 4h11l-2 4 2 4H5"/>',
    users: '<circle cx="9" cy="8" r="3"/><path d="M3 20a6 6 0 0 1 12 0M16 4a3 3 0 0 1 0 6M21 20a6 6 0 0 0-4-5.6"/>',
    target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
    down: '<path d="M6 9l6 6 6-6"/>',
    up: '<path d="M6 15l6-6 6 6"/>',
    quote: '<path d="M7 7h4v4c0 3-1.5 5-4 6M15 7h4v4c0 3-1.5 5-4 6"/>',
    ear: '<path d="M7 9a5 5 0 0 1 10 0c0 3-3 4-3 7a3 3 0 0 1-6 0"/><path d="M10 9a2 2 0 0 1 4 0"/>',
  };
  function ic(name, size) {
    var s = size || 16;
    return '<svg width="' + s + '" height="' + s + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (IC[name] || "") + "</svg>";
  }
  function loading(label) { return '<div class="pk-loading">' + (ctx.loadingBarHtml ? ctx.loadingBarHtml(label) : esc(label)) + "</div>"; }
  function norm(s) { return String(s || "").toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[^a-z0-9]+/g, " ").trim(); }
  function pct(a, n) { return n ? Math.round(100 * a / n) : 0; }
  function fmt(n) { return Number(n || 0).toLocaleString(); }
  function plural(n, one, many) { return fmt(n) + " " + (n === 1 ? one : (many || one + "s")); }
  function shuffle(a) { for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)), t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
  function inField(e) { var t = e && e.target; return !!t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT" || t.isContentEditable); }
  function dayKey(t) { var d = new Date(t || Date.now()); return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0"); }
  var DAY = 86400000;

  // the practice setup (Setup panel): its filters and reading settings
  function cfg() { try { return (ctx.host && ctx.host.getPracticeConfig && ctx.host.getPracticeConfig()) || {}; } catch (e) { return {}; } }
  // filters → query parameters, the ones the app sends for a random question
  function filtersQuery(f, extra) {
    f = f || {}; var p = [];
    var add = function (k, v) { p.push(k + "=" + encodeURIComponent(v)); };
    if (f.categories && f.categories.length) add("categories", f.categories.join(","));
    if (f.categoryIds && f.categoryIds.length) add("categoryIds", f.categoryIds.join(","));
    if (f.difficulties && f.difficulties.length) add("difficulties", f.difficulties.join(","));
    if (f.setNames && f.setNames.length) add("setNames", f.setNames.join(","));
    if (f.packetNumbers && f.packetNumbers.length) add("packetNumbers", f.packetNumbers.join(","));
    if (f.yearMin != null) add("yearMin", f.yearMin);
    if (f.yearMax != null) add("yearMax", f.yearMax);
    if (f.powermarkOnly) add("powermarkOnly", "true");
    if (f.canon && f.canon.length) add("canon", f.canon.join(","));
    add("cleanOnly", "1");
    Object.keys(extra || {}).forEach(function (k) { if (extra[k] != null && extra[k] !== false) add(k, extra[k]); });
    return p.join("&");
  }
  // the practice filters without a set (a drill draws from everything the player picked)
  function practiceFilters() { var f = Object.assign({}, cfg().filters || {}); delete f.setNames; delete f.packetNumbers; delete f.setIds; return f; }
  async function getTossups(n, f, extra) {
    try { var d = await ctx.api.get("/api/tossups/query?" + filtersQuery(f || practiceFilters(), Object.assign({ random: 1, limit: n }, extra || {}))); return (d && d.rows) || []; } catch (e) { return []; }
  }
  async function getBonuses(n, f, extra) {
    try { var d = await ctx.api.get("/api/bonuses/query?" + filtersQuery(f || practiceFilters(), Object.assign({ random: 1, limit: n }, extra || {}))); return (d && d.rows) || []; } catch (e) { return []; }
  }
  async function getTossup(id) { try { return (await ctx.api.get("/api/tossups/" + encodeURIComponent(id))).tossup || null; } catch (e) { return null; } }
  async function getBonus(id) { try { return (await ctx.api.get("/api/bonuses/" + encodeURIComponent(id))).bonus || null; } catch (e) { return null; } }
  async function searchTossups(query, limit, f) {
    try { var d = await ctx.api.get("/api/tossups/search?query=" + encodeURIComponent(query) + "&limit=" + (limit || 20) + (f ? "&" + filtersQuery(f) : "")); return { rows: (d && d.rows) || [], total: (d && d.total) || 0 }; } catch (e) { return { rows: [], total: 0 }; }
  }
  // tossups whose answer line names an answer
  async function tossupsOn(answer, limit) { return (await searchTossups('answer_sanitized : ("' + String(answer).replace(/"/g, "") + '")', limit || 20)).rows; }

  // a record's text as practice reads it (notes and pronunciation guides per the player's settings)
  function readText(q) {
    try { if (ctx.host && ctx.host.questionText) { var t = ctx.host.questionText(q, "question"); if (t != null) return String(t).replace(/\(\*\)/g, "").replace(/\s{2,}/g, " ").trim(); } } catch (e) {}
    return String((q && q.question_sanitized) || "").replace(/\(\*\)/g, "").trim();
  }
  function powerAt(q) { return String((q && q.question_sanitized) || "").indexOf("(*)"); }
  // sentences, without breaking at "St." or an initial ("J. R. R. Tolkien")
  var ABBR = /(?:\b(?:St|Ste|Mt|Mts|Dr|Mr|Mrs|Ms|Mme|Prof|Sr|Jr|Rev|Fr|Gen|Col|Capt|Lt|Sgt|Maj|Adm|Hon|Pres|Gov|Sen|Rep|vs|etc|cf|ca|al|Inc|Co|Corp|Ltd|Bros|approx|No|Nos|Op|op|no|Vol|vol|Ch|ch|Fig|fig|Ft|Pt|pt|Ave|[A-Za-z])\.["”’']?)$/;
  function sentences(text) {
    var parts = String(text || "").split(/(?<=[.?!]["”’)]*)\s+(?=["“(]?[A-Z0-9])/), out = [], cur = "";
    for (var i = 0; i < parts.length; i++) {
      cur = cur ? cur + " " + parts[i] : parts[i];
      if (i < parts.length - 1 && ABBR.test(cur.trim())) continue;
      out.push(cur.trim()); cur = "";
    }
    if (cur.trim()) out.push(cur.trim());
    return out.filter(Boolean);
  }
  // where each sentence of a text ends (indexes into it)
  function sentenceEnds(text) {
    var at = 0, out = []; text = String(text || "");
    sentences(text).forEach(function (x) { var i = text.indexOf(x, at); if (i < 0) return; at = i + x.length; out.push(at); });
    return out;
  }
  // ── categories (15.63): the app's own picker, its picks kept under `key` ([] = every category) ──
  // mountCats(root, key, onChange) puts it in root's [data-cats] (made once, moved into each new render);
  // inCats(pk, e): a history entry or question in the picks; with no picks, all are
  var PICKERS = {};
  function catPicker(key, onChange) {
    if (PICKERS[key]) return PICKERS[key];
    if (!ctx.host || !ctx.host.categoryPicker) return null;
    var pk = ctx.host.categoryPicker(null, { selected: ctx.storage.get(key) || [], onChange: function (ids) { ctx.storage.set(key, ids); if (onChange) onChange(ids); } });
    PICKERS[key] = pk;
    // the picks match nothing until the tree is in: draw again once it is
    if (pk.ready && (ctx.storage.get(key) || []).length) pk.ready.then(function () { if (onChange) onChange(pk.get()); });
    return pk;
  }
  function mountCats(root, key, onChange) {
    var pk = catPicker(key, onChange), host = root && root.querySelector("[data-cats]");
    if (pk && host) host.appendChild(pk.el);
    return pk;
  }
  function inCats(pk, e) {
    if (!pk || !pk.get().length) return true;
    return pk.matches(String((e && (e.category_path || e.path || e.category || e.root)) || ""));
  }
  // ── the app's reader on a page titled for the plugin (15.63: ctx.host.playPractice). Its Setup picks the categories ──
  function canRead() { return !!(ctx.host && ctx.host.playPractice); }
  function onReader() { return !!(ctx.host && ctx.host.onPracticePage && ctx.host.onPracticePage()); }
  // a plugin's start page: an icon, what it is, a Start button (data-pk="start"), a note under it
  function heroHtml(icon, title, text, start, note) {
    return '<div class="pk-hero"><span class="pk-hero-ico">' + ic(icon, 26) + "</span><h2>" + esc(title) + "</h2><p>" + esc(text) + "</p>" +
      '<div class="pk-actions pk-center"><button type="button" class="btn btn-primary" data-pk="start">' + ic("play", 14) + esc(start || "Start") + "</button></div>" +
      (note ? '<div class="pk-muted pk-small">' + note + "</div>" : "") + "</div>";
  }
  // the answer line, with its bold and underlining (nothing else of the HTML)
  function answerHtml(q) {
    var h = String((q && q.answer) || "");
    if (!/<\/?(b|u|strong|em|i)\b/i.test(h)) return esc((q && q.answer_sanitized) || h);
    return h.replace(/<(\/?)(b|u|strong|em|i)\b[^>]*>/gi, "\u0001$1$2\u0002").replace(/<[^>]*>/g, "").replace(/&(?!(?:amp|lt|gt|quot|#\d+);)/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/\u0001(\/?)(\w+)\u0002/g, "<$1$2>");
  }
  function primary(q) {
    var a = "";
    try { if (ctx.host && ctx.host.extractPrimaryAnswer) a = ctx.host.extractPrimaryAnswer((q && q.answer) || "", (q && q.answer_sanitized) || ""); } catch (e) {}
    return a || String((q && q.answer_sanitized) || "").replace(/\s*[\[(].*$/, "").trim();
  }
  // judged right here, like practice (judge.js); { status: "accept" | "prompt" | "reject", prompt }
  async function judge(q, answer, opts) {
    opts = opts || {};
    try {
      if (ctx.host && ctx.host.judgeTossup) return (await ctx.host.judgeTossup(q, answer, { strictness: opts.strictness != null ? opts.strictness : (cfg().strictness || 10), buzzPosition: opts.buzzPosition, previous: opts.previous || null })) || { status: "reject" };
      return (await ctx.api.post("/api/evaluate-tossup", { questionId: q.id, answer: answer, strictness: cfg().strictness || 10, buzzPosition: opts.buzzPosition, previous: opts.previous || null })) || { status: "reject" };
    } catch (e) { return { status: "reject" }; }
  }
  async function judgePart(b, part, answer, opts) {
    opts = opts || {};
    try {
      if (ctx.host && ctx.host.judgeBonusPart) return (await ctx.host.judgeBonusPart(b, part, answer, { strictness: cfg().strictness || 10, previous: opts.previous || null })) || { status: "reject" };
      return (await ctx.api.post("/api/evaluate-bonus-part", { questionId: b.id, part: part, answer: answer, strictness: cfg().strictness || 10 })) || { status: "reject" };
    } catch (e) { return { status: "reject" }; }
  }
  async function judgeLine(line, sani, answer, opts) {
    opts = opts || {};
    try {
      if (ctx.host && ctx.host.judgeAnswerLine) return (await ctx.host.judgeAnswerLine(line, sani, answer, { strictness: cfg().strictness || 10, previous: opts.previous || null })) || { status: "reject" };
      return (await ctx.api.post("/api/evaluate-answer", { answerline: line, answer: answer, strictness: cfg().strictness || 10 })) || { status: "reject" };
    } catch (e) { return { status: "reject" }; }
  }
  function bonusParts(b) { try { return JSON.parse((b && (b.parts_sanitized || b.parts)) || "[]"); } catch (e) { return []; } }
  function bonusAnswers(b) { try { return JSON.parse((b && b.answers) || "[]"); } catch (e) { return []; } }
  function bonusAnswersSani(b) { try { return JSON.parse((b && b.answers_sanitized) || "[]"); } catch (e) { return []; } }

  // the player's answers (Stats' history), only the fields asked for
  async function history(fields) {
    try { return ((await ctx.api.get("/api/sessions/all-entries?" + (/\banswer\b/.test(fields || "") ? "answers=1&" : "") + "fields=" + encodeURIComponent(fields || ""))).entries) || []; } catch (e) { return []; }
  }
  // record a tossup answered on a plugin's page into the player's stats (the path Coach Mode uses)
  function record(q, r) {
    try {
      ctx.api.post("/api/check-tossup", { questionId: q.id, answer: r.answer || "", buzzPosition: r.buzzPosition || 0, sessionId: r.session, overriding: true,
        correct: !!r.correct, isPower: !!r.power, points: r.points || 0, celerity: r.celerity != null ? r.celerity : 1 }).catch(function () {});
    } catch (e) {}
  }

  var ROOT_COLOR = { "Literature": "#bc8cff", "Science": "#58a6ff", "Math": "#a5e05b", "Pop Culture": "#ff7b72", "Sports": "#ff6f91", "Fine Arts": "#f778ba", "History": "#e3b341", "Geography": "#56d364", "Mythology": "#ffa657", "Social Science": "#3dd6a3", "Philosophy": "#39c5cf", "Theology": "#8e9bff", "Current Events": "#c9d16b", "Miscellaneous": "#8b949e" };
  // NAQT's high school distribution, per 24 tossups / bonuses (naqt.com/hs/distribution.jsp)
  var NAQT = [["Literature", 3.9, 3.8], ["Science", 4.5, 4.3], ["Math", 1.0, 1.0], ["Fine Arts", 2.0, 2.0], ["History", 4.6, 4.5], ["Geography", 1.9, 1.9], ["Mythology", 0.6, 0.7],
    ["Pop Culture", 1.0, 0.9], ["Sports", 0.7, 0.7], ["Social Science", 0.6, 0.6], ["Philosophy", 0.3, 0.3], ["Theology", 0.4, 0.4], ["Current Events", 1.5, 1.4], ["Miscellaneous", 1.0, 1.5]];
  function rootOf(e) { return String((e && (e.category_path || e.category)) || "").split(" > ")[0] || "Miscellaneous"; }
  function dot(root) { return '<span class="pk-dot" style="--c:' + (ROOT_COLOR[root] || "#8b949e") + '"></span>'; }
  var _roots = null;
  async function roots() {
    if (_roots) return _roots;
    try { var t = ctx.host && ctx.host.getCategoryTree ? await ctx.host.getCategoryTree("tossups") : (await ctx.api.get("/api/category-tree?type=tossups")).tree; _roots = (t || []).map(function (n) { return { id: n.id, name: n.name, count: n.count }; }); }
    catch (e) { _roots = []; }
    return _roots;
  }
  var DIFF_NAME = { 0: "Unrated", 1: "Middle school", 2: "Easy high school", 3: "Regular high school", 4: "Hard high school", 5: "National high school", 6: "Easy college", 7: "Medium college", 8: "Regionals college", 9: "Nationals college", 10: "Open" };

  function tile(value, label, cls) { return '<div class="pk-tile' + (cls ? " " + cls : "") + '"><b class="num">' + value + "</b><span>" + esc(label) + "</span></div>"; }
  function segHtml(name, items, on) {
    return '<div class="seg pk-seg" role="group">' + items.map(function (it) {
      return '<button type="button" data-' + name + '="' + esc(it[0]) + '" aria-pressed="' + (String(on) === String(it[0])) + '">' + esc(it[1]) + "</button>";
    }).join("") + "</div>";
  }
  function emptyHtml(text) { return '<div class="db-empty pk-empty">' + esc(text) + "</div>"; }
  function playList(kind, ids, title) {
    if (!ids || !ids.length) return false;
    try { return !!(ctx.host && ctx.host.launchQuestions && ctx.host.launchQuestions(kind, ids, { title: title })); } catch (e) { return false; }
  }

  // a reader: shows `text` a character at a time at the practice reading speed. start(), pause(), go(), stop();
  // at() is how far it is; onEnd once it's all shown
  function Reader(el, text, opts) {
    opts = opts || {};
    var ms = opts.ms != null ? opts.ms : (Number(cfg().revealSpeed) || 25), idx = 0, raf = 0, last = 0, on = false;
    var paint = function () { el.innerHTML = '<span class="pk-read">' + esc(text.slice(0, idx)) + '</span><span class="pk-unread" aria-hidden="true">' + esc(text.slice(idx)) + "</span>"; };
    var step = function (t) {
      raf = 0; if (!on) return;
      if (!last) last = t;
      var n = ms > 0 ? Math.floor((t - last) / ms) : text.length;
      if (n > 0) { idx = Math.min(text.length, idx + n); last += n * ms; paint(); if (opts.onTick) opts.onTick(idx); }
      if (idx >= text.length) { on = false; if (opts.onEnd) opts.onEnd(); return; }
      raf = requestAnimationFrame(step);
    };
    paint();
    return {
      start: function () { if (on) return; on = true; last = 0; raf = requestAnimationFrame(step); },
      pause: function () { on = false; if (raf) cancelAnimationFrame(raf); raf = 0; },
      stop: function () { on = false; if (raf) cancelAnimationFrame(raf); raf = 0; },
      showAll: function () { this.stop(); idx = text.length; el.textContent = text; },
      at: function () { return idx; },
      running: function () { return on; },
    };
  }
  // a reader's position in the displayed text → the record's question_sanitized (what judging and stats count)
  function serverPos(q, display, pos) {
    try { if (ctx.host && ctx.host.mapDisplayPos) return ctx.host.mapDisplayPos(display, (q && q.question_sanitized) || "", pos); } catch (e) {}
    return pos;
  }

  // ── Buzz Tracker: where in the question you buzz, by category and week by week ──
  // A buzz point is how much of the question had been read when you buzzed (Stats' celerity). Lower is earlier.
  var body = null, page = null;
  var view = Object.assign({ weeks: 12, root: "" }, ctx.storage.get("view") || {});
  function saveView() { ctx.storage.set("view", view); }
  var entries = null;
  var PERIODS = [[4, "4 weeks"], [12, "12 weeks"], [0, "All time"]];

  function within(e) { return (!view.weeks || e.timestamp >= Date.now() - view.weeks * 7 * DAY) && inCats(catPicker("cats", render), e); }
  function bp(e) { return e.celerity != null && e.celerity > 0 && e.celerity <= 1 ? e.celerity : null; }
  function summary(list) {
    var right = list.filter(function (e) { return e.correct && bp(e) != null; }), negs = list.filter(function (e) { return (e.points || 0) < 0; });
    var pts = right.map(bp).sort(function (a, b) { return a - b; });
    return {
      heard: list.length, right: right.length, negs: negs.length, powers: right.filter(function (e) { return (e.points || 0) >= 15; }).length,
      avg: pts.length ? pts.reduce(function (s, x) { return s + x; }, 0) / pts.length : null,
      q1: pts.length >= 4 ? pts[Math.floor(pts.length / 4)] : null,
    };
  }
  // the average buzz point on right answers per week, oldest first
  function weekly(list) {
    var start = Date.now() - (view.weeks || 26) * 7 * DAY, by = {};
    list.forEach(function (e) { if (!e.correct || bp(e) == null || e.timestamp < start) return; var w = Math.floor((Date.now() - e.timestamp) / (7 * DAY)); (by[w] = by[w] || []).push(bp(e)); });
    var n = view.weeks || 26, out = [];
    for (var w = n - 1; w >= 0; w--) { var a = by[w] || []; out.push({ w: w, n: a.length, avg: a.length ? a.reduce(function (s, x) { return s + x; }, 0) / a.length : null }); }
    return out;
  }
  function chartHtml(series) {
    var W = 920, H = 230, P = { l: 40, r: 14, t: 12, b: 26 }, iw = W - P.l - P.r, ih = H - P.t - P.b;
    var pts = series.map(function (s, i) { return s.avg == null || s.n < 3 ? null : { x: P.l + (series.length > 1 ? i / (series.length - 1) : 0.5) * iw, y: P.t + s.avg * ih, s: s }; });
    var path = "", started = false;
    pts.forEach(function (p) { if (!p) { started = false; return; } path += (started ? "L" : "M") + p.x.toFixed(1) + " " + p.y.toFixed(1); started = true; });
    var grid = [0, 0.25, 0.5, 0.75, 1].map(function (v) { var y = P.t + v * ih; return '<line x1="' + P.l + '" x2="' + (W - P.r) + '" y1="' + y + '" y2="' + y + '" class="bt-grid"/><text x="' + (P.l - 6) + '" y="' + (y + 4) + '" class="bt-ax" text-anchor="end">' + Math.round(v * 100) + "%</text>"; }).join("");
    var lab = series.map(function (s, i) { if (series.length > 6 && i % Math.ceil(series.length / 6) && i !== series.length - 1) return ""; var x = P.l + (series.length > 1 ? i / (series.length - 1) : 0.5) * iw; return '<text x="' + x + '" y="' + (H - 6) + '" class="bt-ax" text-anchor="' + (i === 0 ? "start" : i === series.length - 1 ? "end" : "middle") + '">' + (s.w === 0 ? "This week" : s.w + "w ago") + "</text>"; }).join("");
    var dots = pts.filter(Boolean).map(function (p) { return '<circle cx="' + p.x.toFixed(1) + '" cy="' + p.y.toFixed(1) + '" r="3.2" class="bt-dot"><title>' + Math.round(p.s.avg * 100) + "% read, " + p.s.n + " right</title></circle>"; }).join("");
    return '<svg class="bt-chart" viewBox="0 0 ' + W + " " + H + '" role="img" aria-label="Average buzz point by week">' + grid + lab + (path ? '<path d="' + path + '" class="bt-line"/>' : "") + dots + "</svg>";
  }
  function histHtml(list) {
    var bins = [], i; for (i = 0; i < 10; i++) bins.push({ r: 0, n: 0 });
    list.forEach(function (e) { var b = bp(e); if (b == null || b >= 1) return; var k = Math.min(9, Math.floor(b * 10)); if (e.correct) bins[k].r++; else if ((e.points || 0) < 0) bins[k].n++; });
    var max = Math.max.apply(null, bins.map(function (b) { return b.r + b.n; }).concat([1]));
    return '<div class="bt-hist">' + bins.map(function (b, k) {
      return '<div class="bt-col" title="' + (k * 10) + "–" + (k * 10 + 10) + "% read: " + b.r + " right, " + b.n + ' negs"><span class="bt-stack"><span class="bt-r" style="height:' + (100 * b.r / max) + '%"></span><span class="bt-n" style="height:' + (100 * b.n / max) + '%"></span></span><small>' + (k * 10) + "</small></div>";
    }).join("") + "</div>";
  }

  function render() {
    if (!body) return;
    if (!entries) { body.innerHTML = '<div class="pk-wrap bt">' + loading("Reading your buzzes…") + "</div>"; return; }
    var all = entries.filter(within), list = view.root ? all.filter(function (e) { return rootOf(e) === view.root; }) : all;
    var inPick = entries.filter(function (e) { return inCats(catPicker("cats", render), e); });
    var s = summary(list), series = weekly(view.root ? inPick.filter(function (e) { return rootOf(e) === view.root; }) : inPick);
    var half = Math.floor(series.length / 2), early = series.slice(0, half).filter(function (x) { return x.avg != null; }), late = series.slice(half).filter(function (x) { return x.avg != null; });
    var avgOf = function (a) { var n = a.reduce(function (t, x) { return t + x.n; }, 0); return n ? a.reduce(function (t, x) { return t + x.avg * x.n; }, 0) / n : null; };
    var a0 = avgOf(early), a1 = avgOf(late), trend = a0 != null && a1 != null ? Math.round((a0 - a1) * 100) : null;
    var roots = {};
    all.forEach(function (e) { (roots[rootOf(e)] = roots[rootOf(e)] || []).push(e); });
    var rows = Object.keys(roots).map(function (r) { return { r: r, s: summary(roots[r]) }; }).filter(function (x) { return x.s.right >= 3; }).sort(function (a, b) { return a.s.avg - b.s.avg; });
    body.innerHTML = '<div class="pk-wrap bt">' +
      '<div class="pk-bar-top">' + segHtml("weeks", PERIODS, view.weeks) + '<span data-cats></span>' + (view.root ? '<span class="pk-chip pk-on">' + dot(view.root) + esc(view.root) + ' <button type="button" class="bt-x" id="bt-all" aria-label="All categories">' + ic("x", 12) + "</button></span>" : "") + "</div>" +
      (!s.heard ? emptyHtml("No tossups in this period yet. Practice a few and come back.") :
      '<div class="pk-tiles">' + tile(s.avg != null ? Math.round(s.avg * 100) + "<small>%</small>" : "–", "Average buzz point") +
        tile(s.q1 != null ? Math.round(s.q1 * 100) + "<small>%</small>" : "–", "Your earliest quarter of buzzes", "pk-good") +
        tile(s.right ? pct(s.powers, s.right) + "<small>%</small>" : "–", "Of right answers powered", "pk-gold") +
        tile(pct(s.negs, s.heard) + "<small>%</small>", "Negs", "pk-bad") + "</div>" +
      '<div class="pk-card"><div class="pk-row"><h3 class="pk-grow" style="margin:0">Buzz point on right answers, by week</h3>' +
        (trend != null ? '<span class="pk-small ' + (trend > 0 ? "pk-good" : trend < 0 ? "pk-bad" : "pk-muted") + '">' + (trend > 0 ? trend + " points earlier than before" : trend < 0 ? -trend + " points later than before" : "No change") + "</span>" : "") + "</div>" +
        '<div class="pk-muted pk-small" style="margin:2px 0 8px">How much of the question had been read. Lower is earlier.</div>' + chartHtml(series) + "</div>" +
      '<div class="pk-card"><h3>Where you buzz</h3><div class="pk-row pk-small pk-muted" style="gap:14px;margin:-4px 0 8px"><span class="pk-row" style="gap:5px"><span class="bt-key bt-r"></span>Right</span><span class="pk-row" style="gap:5px"><span class="bt-key bt-n"></span>Neg</span><span>% of the question read</span></div>' + histHtml(list) + "</div>" +
      (rows.length ? '<div class="pk-sechead"><span class="eyebrow">By category, earliest first</span></div><div class="list pk-list">' + rows.map(function (x) {
        var a = Math.round(x.s.avg * 100);
        return '<div class="list-row clickable bt-cat' + (x.r === view.root ? " on" : "") + '" role="button" tabindex="0" data-root="' + esc(x.r) + '">' + dot(x.r) + '<span class="bt-name">' + esc(x.r) + "</span>" +
          '<span class="pk-grow"><span class="pk-meter bt-pos"><span style="width:' + a + '%;--c:' + (ROOT_COLOR[x.r] || "var(--accent)") + '"></span></span></span>' +
          '<span class="bt-nums num"><b>' + a + '%</b><small class="pk-muted"> · ' + pct(x.s.powers, x.s.right) + "% powered · " + pct(x.s.negs, x.s.heard) + "% negs</small></span></div>";
      }).join("") + "</div>" : "")) + "</div>";
    mountCats(body, "cats", render);
    body.querySelectorAll("[data-weeks]").forEach(function (b) { b.onclick = function () { view.weeks = Number(b.dataset.weeks); saveView(); render(); }; });
    body.querySelectorAll(".bt-cat").forEach(function (el) {
      var go = function () { view.root = view.root === el.dataset.root ? "" : el.dataset.root; saveView(); render(); };
      el.onclick = go; el.onkeydown = function (e) { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); go(); } };
    });
    var x = body.querySelector("#bt-all"); if (x) x.onclick = function () { view.root = ""; saveView(); render(); };
  }

  page = ctx.registerPage({
    id: "buzz-tracker", navLabel: "Buzz Tracker", title: "Buzz Tracker",
    onShow: function (el) {
      body = el; entries = null; render();
      history("type,correct,points,celerity,category_path,category,timestamp").then(function (es) { entries = es.filter(function (e) { return e.type === "tossup" && !e.skipped; }); render(); });
    },
  });
  if (ctx.onBack) ctx.onBack(function () { if (!(page && page.screenEl && page.screenEl.classList.contains("active")) || !view.root) return false; view.root = ""; saveView(); render(); return true; });

}
