/**
 * OfflineQuiz plugin: Buzz Tracker
 *
 * Your buzz points from Stats' history: how much of each question had been read when you buzzed,
 * week by week and by category, with your power and neg rates and where your negs land.
 */
QB.registerPlugin({
  id: "buzz-tracker",
  name: "Buzz Tracker",
  version: "1.1.0",
  author: "OfflineQuiz",
  description: "See where in the question you buzz in each category, and whether you're buzzing earlier over time.",
  onEnable: __qbMain,
  onDisable: function (ctx) { if (ctx._cleanup) ctx._cleanup(); },
});
