function __qbMain(ctx) {
  // ── the kit the 15.62 plugins share (text, icons, questions, judging, history) ──
  function esc(s) { return (s == null ? "" : String(s)).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
  var IC = {
    play: '<path d="M7 4l13 8-13 8z"/>',
    pause: '<path d="M8 5v14M16 5v14"/>',
    left: '<path d="M15 6l-6 6 6 6"/>',
    right: '<path d="M9 6l6 6-6 6"/>',
    next: '<path d="M6 5l9 7-9 7zM18 5v14"/>',
    refresh: '<path d="M20 11a8 8 0 10-2.3 5.7M20 4v7h-7"/>',
    x: '<path d="M6 6l12 12M18 6L6 18"/>',
    check: '<path d="M5 12l5 5 9-10"/>',
    mic: '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
    volume: '<path d="M4 9v6h4l5 4V5L8 9z"/><path d="M16 9a4 4 0 0 1 0 6M19 6a8 8 0 0 1 0 12"/>',
    copy: '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h3"/>',
    edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="M13.5 6.5l4 4"/>',
    bolt: '<path d="M13 3L5 14h6l-1 7 8-11h-6z"/>',
    flag: '<path d="M5 21V4M5 4h11l-2 4 2 4H5"/>',
    users: '<circle cx="9" cy="8" r="3"/><path d="M3 20a6 6 0 0 1 12 0M16 4a3 3 0 0 1 0 6M21 20a6 6 0 0 0-4-5.6"/>',
    target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
    down: '<path d="M6 9l6 6 6-6"/>',
    up: '<path d="M6 15l6-6 6 6"/>',
    quote: '<path d="M7 7h4v4c0 3-1.5 5-4 6M15 7h4v4c0 3-1.5 5-4 6"/>',
    grid: '<rect x="3" y="3" width="8" height="10" rx="2"/><rect x="13" y="3" width="8" height="6" rx="2"/><rect x="13" y="11" width="8" height="10" rx="2"/><rect x="3" y="15" width="8" height="6" rx="2"/>',
    ear: '<path d="M7 9a5 5 0 0 1 10 0c0 3-3 4-3 7a3 3 0 0 1-6 0"/><path d="M10 9a2 2 0 0 1 4 0"/>',
  };
  function ic(name, size) {
    var s = size || 16;
    return '<svg width="' + s + '" height="' + s + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (IC[name] || "") + "</svg>";
  }
  function loading(label) { return '<div class="pk-loading">' + (ctx.loadingBarHtml ? ctx.loadingBarHtml(label) : esc(label)) + "</div>"; }
  function norm(s) { return String(s || "").toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[^a-z0-9]+/g, " ").trim(); }
  function pct(a, n) { return n ? Math.round(100 * a / n) : 0; }
  function fmt(n) { return Number(n || 0).toLocaleString(); }
  function plural(n, one, many) { return fmt(n) + " " + (n === 1 ? one : (many || one + "s")); }
  function shuffle(a) { for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)), t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
  function inField(e) { var t = e && e.target; return !!t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT" || t.isContentEditable); }
  function dayKey(t) { var d = new Date(t || Date.now()); return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0"); }
  var DAY = 86400000;

  // the practice setup (Setup panel): its filters and reading settings
  function cfg() { try { return (ctx.host && ctx.host.getPracticeConfig && ctx.host.getPracticeConfig()) || {}; } catch (e) { return {}; } }
  // filters → query parameters, the ones the app sends for a random question
  function filtersQuery(f, extra) {
    f = f || {}; var p = [];
    var add = function (k, v) { p.push(k + "=" + encodeURIComponent(v)); };
    if (f.categories && f.categories.length) add("categories", f.categories.join(","));
    if (f.categoryIds && f.categoryIds.length) add("categoryIds", f.categoryIds.join(","));
    if (f.difficulties && f.difficulties.length) add("difficulties", f.difficulties.join(","));
    if (f.setNames && f.setNames.length) add("setNames", f.setNames.join(","));
    if (f.packetNumbers && f.packetNumbers.length) add("packetNumbers", f.packetNumbers.join(","));
    if (f.yearMin != null) add("yearMin", f.yearMin);
    if (f.yearMax != null) add("yearMax", f.yearMax);
    if (f.powermarkOnly) add("powermarkOnly", "true");
    if (f.canon && f.canon.length) add("canon", f.canon.join(","));
    add("cleanOnly", "1");
    Object.keys(extra || {}).forEach(function (k) { if (extra[k] != null && extra[k] !== false) add(k, extra[k]); });
    return p.join("&");
  }
  // the practice filters without a set (a drill draws from everything the player picked)
  function practiceFilters() { var f = Object.assign({}, cfg().filters || {}); delete f.setNames; delete f.packetNumbers; delete f.setIds; return f; }
  async function getTossups(n, f, extra) {
    try { var d = await ctx.api.get("/api/tossups/query?" + filtersQuery(f || practiceFilters(), Object.assign({ random: 1, limit: n }, extra || {}))); return (d && d.rows) || []; } catch (e) { return []; }
  }
  async function getBonuses(n, f, extra) {
    try { var d = await ctx.api.get("/api/bonuses/query?" + filtersQuery(f || practiceFilters(), Object.assign({ random: 1, limit: n }, extra || {}))); return (d && d.rows) || []; } catch (e) { return []; }
  }
  async function getTossup(id) { try { return (await ctx.api.get("/api/tossups/" + encodeURIComponent(id))).tossup || null; } catch (e) { return null; } }
  async function getBonus(id) { try { return (await ctx.api.get("/api/bonuses/" + encodeURIComponent(id))).bonus || null; } catch (e) { return null; } }
  async function searchTossups(query, limit, f) {
    try { var d = await ctx.api.get("/api/tossups/search?query=" + encodeURIComponent(query) + "&limit=" + (limit || 20) + (f ? "&" + filtersQuery(f) : "")); return { rows: (d && d.rows) || [], total: (d && d.total) || 0 }; } catch (e) { return { rows: [], total: 0 }; }
  }
  // tossups whose answer line names an answer
  async function tossupsOn(answer, limit) { return (await searchTossups('answer_sanitized : ("' + String(answer).replace(/"/g, "") + '")', limit || 20)).rows; }

  // a record's text as practice reads it (notes and pronunciation guides per the player's settings)
  function readText(q) {
    try { if (ctx.host && ctx.host.questionText) { var t = ctx.host.questionText(q, "question"); if (t != null) return String(t).replace(/\(\*\)/g, "").replace(/\s{2,}/g, " ").trim(); } } catch (e) {}
    return String((q && q.question_sanitized) || "").replace(/\(\*\)/g, "").trim();
  }
  function powerAt(q) { return String((q && q.question_sanitized) || "").indexOf("(*)"); }
  // sentences, without breaking at "St." or an initial ("J. R. R. Tolkien")
  var ABBR = /(?:\b(?:St|Ste|Mt|Mts|Dr|Mr|Mrs|Ms|Mme|Prof|Sr|Jr|Rev|Fr|Gen|Col|Capt|Lt|Sgt|Maj|Adm|Hon|Pres|Gov|Sen|Rep|vs|etc|cf|ca|al|Inc|Co|Corp|Ltd|Bros|approx|No|Nos|Op|op|no|Vol|vol|Ch|ch|Fig|fig|Ft|Pt|pt|Ave|[A-Za-z])\.["”’']?)$/;
  function sentences(text) {
    var parts = String(text || "").split(/(?<=[.?!]["”’)]*)\s+(?=["“(]?[A-Z0-9])/), out = [], cur = "";
    for (var i = 0; i < parts.length; i++) {
      cur = cur ? cur + " " + parts[i] : parts[i];
      if (i < parts.length - 1 && ABBR.test(cur.trim())) continue;
      out.push(cur.trim()); cur = "";
    }
    if (cur.trim()) out.push(cur.trim());
    return out.filter(Boolean);
  }
  // where each sentence of a text ends (indexes into it)
  function sentenceEnds(text) {
    var at = 0, out = []; text = String(text || "");
    sentences(text).forEach(function (x) { var i = text.indexOf(x, at); if (i < 0) return; at = i + x.length; out.push(at); });
    return out;
  }
  // ── categories (15.63): the app's own picker, its picks kept under `key` ([] = every category) ──
  // mountCats(root, key, onChange) puts it in root's [data-cats] (made once, moved into each new render);
  // inCats(pk, e): a history entry or question in the picks; with no picks, all are
  var PICKERS = {};
  // opts.label: "" for just the picks, in a row that has its own label
  function catPicker(key, onChange, opts) {
    if (PICKERS[key]) return PICKERS[key];
    if (!ctx.host || !ctx.host.categoryPicker) return null;
    var o = { selected: ctx.storage.get(key) || [], onChange: function (ids) { ctx.storage.set(key, ids); if (onChange) onChange(ids); } };
    if (opts && opts.label != null) o.label = opts.label;
    var pk = ctx.host.categoryPicker(null, o);
    PICKERS[key] = pk;
    // the picks match nothing until the tree is in: draw again once it is
    if (pk.ready && (ctx.storage.get(key) || []).length) pk.ready.then(function () { if (onChange) onChange(pk.get()); });
    return pk;
  }
  function mountCats(root, key, onChange, opts) {
    var pk = catPicker(key, onChange, opts), host = root && root.querySelector("[data-cats]");
    if (pk && host) host.appendChild(pk.el);
    return pk;
  }
  function inCats(pk, e) {
    if (!pk || !pk.get().length) return true;
    return pk.matches(String((e && (e.category_path || e.path || e.category || e.root)) || ""));
  }
  // ── the app's reader on a page titled for the plugin (15.63: ctx.host.playPractice). Its Setup picks the categories ──
  function canRead() { return !!(ctx.host && ctx.host.playPractice); }
  function onReader() { return !!(ctx.host && ctx.host.onPracticePage && ctx.host.onPracticePage()); }
  // a plugin's start page: an icon, what it is, a Start button (data-pk="start"), a note under it
  function heroHtml(icon, title, text, start, note) {
    return '<div class="pk-hero"><span class="pk-hero-ico">' + ic(icon, 26) + "</span><h2>" + esc(title) + "</h2><p>" + esc(text) + "</p>" +
      '<div class="pk-actions pk-center"><button type="button" class="btn btn-primary" data-pk="start">' + ic("play", 14) + esc(start || "Start") + "</button></div>" +
      (note ? '<div class="pk-muted pk-small">' + note + "</div>" : "") + "</div>";
  }
  // the answer line, with its bold and underlining (nothing else of the HTML)
  function answerHtml(q) {
    var h = String((q && q.answer) || "");
    if (!/<\/?(b|u|strong|em|i)\b/i.test(h)) return esc((q && q.answer_sanitized) || h);
    return h.replace(/<(\/?)(b|u|strong|em|i)\b[^>]*>/gi, "\u0001$1$2\u0002").replace(/<[^>]*>/g, "").replace(/&(?!(?:amp|lt|gt|quot|#\d+);)/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/\u0001(\/?)(\w+)\u0002/g, "<$1$2>");
  }
  function primary(q) {
    var a = "";
    try { if (ctx.host && ctx.host.extractPrimaryAnswer) a = ctx.host.extractPrimaryAnswer((q && q.answer) || "", (q && q.answer_sanitized) || ""); } catch (e) {}
    return a || String((q && q.answer_sanitized) || "").replace(/\s*[\[(].*$/, "").trim();
  }
  // judged right here, like practice (judge.js); { status: "accept" | "prompt" | "reject", prompt }
  async function judge(q, answer, opts) {
    opts = opts || {};
    try {
      if (ctx.host && ctx.host.judgeTossup) return (await ctx.host.judgeTossup(q, answer, { strictness: opts.strictness != null ? opts.strictness : (cfg().strictness || 10), buzzPosition: opts.buzzPosition, previous: opts.previous || null })) || { status: "reject" };
      return (await ctx.api.post("/api/evaluate-tossup", { questionId: q.id, answer: answer, strictness: cfg().strictness || 10, buzzPosition: opts.buzzPosition, previous: opts.previous || null })) || { status: "reject" };
    } catch (e) { return { status: "reject" }; }
  }
  async function judgePart(b, part, answer, opts) {
    opts = opts || {};
    try {
      if (ctx.host && ctx.host.judgeBonusPart) return (await ctx.host.judgeBonusPart(b, part, answer, { strictness: cfg().strictness || 10, previous: opts.previous || null })) || { status: "reject" };
      return (await ctx.api.post("/api/evaluate-bonus-part", { questionId: b.id, part: part, answer: answer, strictness: cfg().strictness || 10 })) || { status: "reject" };
    } catch (e) { return { status: "reject" }; }
  }
  async function judgeLine(line, sani, answer, opts) {
    opts = opts || {};
    try {
      if (ctx.host && ctx.host.judgeAnswerLine) return (await ctx.host.judgeAnswerLine(line, sani, answer, { strictness: cfg().strictness || 10, previous: opts.previous || null })) || { status: "reject" };
      return (await ctx.api.post("/api/evaluate-answer", { answerline: line, answer: answer, strictness: cfg().strictness || 10 })) || { status: "reject" };
    } catch (e) { return { status: "reject" }; }
  }
  function bonusParts(b) { try { return JSON.parse((b && (b.parts_sanitized || b.parts)) || "[]"); } catch (e) { return []; } }
  function bonusAnswers(b) { try { return JSON.parse((b && b.answers) || "[]"); } catch (e) { return []; } }
  function bonusAnswersSani(b) { try { return JSON.parse((b && b.answers_sanitized) || "[]"); } catch (e) { return []; } }

  // the player's answers (Stats' history), only the fields asked for
  async function history(fields) {
    try { return ((await ctx.api.get("/api/sessions/all-entries?" + (/\banswer\b/.test(fields || "") ? "answers=1&" : "") + "fields=" + encodeURIComponent(fields || ""))).entries) || []; } catch (e) { return []; }
  }
  // record a tossup answered on a plugin's page into the player's stats (the path Coach Mode uses)
  function record(q, r) {
    try {
      ctx.api.post("/api/check-tossup", { questionId: q.id, answer: r.answer || "", buzzPosition: r.buzzPosition || 0, sessionId: r.session, overriding: true,
        correct: !!r.correct, isPower: !!r.power, points: r.points || 0, celerity: r.celerity != null ? r.celerity : 1 }).catch(function () {});
    } catch (e) {}
  }

  var ROOT_COLOR = { "Literature": "#bc8cff", "Science": "#58a6ff", "Math": "#a5e05b", "Pop Culture": "#ff7b72", "Sports": "#ff6f91", "Fine Arts": "#f778ba", "History": "#e3b341", "Geography": "#56d364", "Mythology": "#ffa657", "Social Science": "#3dd6a3", "Philosophy": "#39c5cf", "Theology": "#8e9bff", "Current Events": "#c9d16b", "Miscellaneous": "#8b949e" };
  // NAQT's high school distribution, per 24 tossups / bonuses (naqt.com/hs/distribution.jsp)
  var NAQT = [["Literature", 3.9, 3.8], ["Science", 4.5, 4.3], ["Math", 1.0, 1.0], ["Fine Arts", 2.0, 2.0], ["History", 4.6, 4.5], ["Geography", 1.9, 1.9], ["Mythology", 0.6, 0.7],
    ["Pop Culture", 1.0, 0.9], ["Sports", 0.7, 0.7], ["Social Science", 0.6, 0.6], ["Philosophy", 0.3, 0.3], ["Theology", 0.4, 0.4], ["Current Events", 1.5, 1.4], ["Miscellaneous", 1.0, 1.5]];
  function rootOf(e) { return String((e && (e.category_path || e.category)) || "").split(" > ")[0] || "Miscellaneous"; }
  function dot(root) { return '<span class="pk-dot" style="--c:' + (ROOT_COLOR[root] || "#8b949e") + '"></span>'; }
  var _roots = null;
  async function roots() {
    if (_roots) return _roots;
    try { var t = ctx.host && ctx.host.getCategoryTree ? await ctx.host.getCategoryTree("tossups") : (await ctx.api.get("/api/category-tree?type=tossups")).tree; _roots = (t || []).map(function (n) { return { id: n.id, name: n.name, count: n.count }; }); }
    catch (e) { _roots = []; }
    return _roots;
  }
  var DIFF_NAME = { 0: "Unrated", 1: "Middle school", 2: "Easy high school", 3: "Regular high school", 4: "Hard high school", 5: "National high school", 6: "Easy college", 7: "Medium college", 8: "Regionals college", 9: "Nationals college", 10: "Open" };

  function tile(value, label, cls) { return '<div class="pk-tile' + (cls ? " " + cls : "") + '"><b class="num">' + value + "</b><span>" + esc(label) + "</span></div>"; }
  function segHtml(name, items, on) {
    return '<div class="seg pk-seg" role="group">' + items.map(function (it) {
      return '<button type="button" data-' + name + '="' + esc(it[0]) + '" aria-pressed="' + (String(on) === String(it[0])) + '">' + esc(it[1]) + "</button>";
    }).join("") + "</div>";
  }
  function emptyHtml(text) { return '<div class="db-empty pk-empty">' + esc(text) + "</div>"; }
  // square toggles 0 to 10, Setup's difficulty look (the app's .diff-toggles), `on` the ones picked; diffsIn reads them
  function diffHtml(name, on) {
    var h = '<div class="diff-toggles pk-diffs" role="group" aria-label="Difficulty">';
    for (var d = 0; d <= 10; d++) h += '<label title="' + esc(DIFF_NAME[d]) + '"><input type="checkbox" data-' + name + '="' + d + '"' + ((on || []).indexOf(d) >= 0 ? " checked" : "") + "><span>" + d + "</span></label>";
    return h + "</div>";
  }
  function diffsIn(root, name) { return [].slice.call(root.querySelectorAll("[data-" + name + "]")).filter(function (i) { return i.checked; }).map(function (i) { return Number(i.getAttribute("data-" + name)); }); }
  // a list of difficulties in a few words: [2, 3, 4, 5] → "2 to 5"
  function diffWords(ds) {
    ds = (ds || []).slice().sort(function (a, b) { return a - b; });
    if (!ds.length) return "any difficulty";
    var run = ds.every(function (d, i) { return !i || d === ds[i - 1] + 1; });
    return ds.length === 1 ? "difficulty " + ds[0] : run ? "difficulty " + ds[0] + " to " + ds[ds.length - 1] : "difficulty " + ds.join(", ");
  }
  function playList(kind, ids, title) {
    if (!ids || !ids.length) return false;
    try { return !!(ctx.host && ctx.host.launchQuestions && ctx.host.launchQuestions(kind, ids, { title: title })); } catch (e) { return false; }
  }

  // a reader: shows `text` a character at a time at the practice reading speed. start(), pause(), go(), stop();
  // at() is how far it is; onEnd once it's all shown
  function Reader(el, text, opts) {
    opts = opts || {};
    var ms = opts.ms != null ? opts.ms : (Number(cfg().revealSpeed) || 25), idx = 0, raf = 0, last = 0, on = false;
    var paint = function () { el.innerHTML = '<span class="pk-read">' + esc(text.slice(0, idx)) + '</span><span class="pk-unread" aria-hidden="true">' + esc(text.slice(idx)) + "</span>"; };
    var step = function (t) {
      raf = 0; if (!on) return;
      if (!last) last = t;
      var n = ms > 0 ? Math.floor((t - last) / ms) : text.length;
      if (n > 0) { idx = Math.min(text.length, idx + n); last += n * ms; paint(); if (opts.onTick) opts.onTick(idx); }
      if (idx >= text.length) { on = false; if (opts.onEnd) opts.onEnd(); return; }
      raf = requestAnimationFrame(step);
    };
    paint();
    return {
      start: function () { if (on) return; on = true; last = 0; raf = requestAnimationFrame(step); },
      pause: function () { on = false; if (raf) cancelAnimationFrame(raf); raf = 0; },
      stop: function () { on = false; if (raf) cancelAnimationFrame(raf); raf = 0; },
      showAll: function () { this.stop(); idx = text.length; el.textContent = text; },
      at: function () { return idx; },
      running: function () { return on; },
    };
  }
  // a reader's position in the displayed text → the record's question_sanitized (what judging and stats count)
  function serverPos(q, display, pos) {
    try { if (ctx.host && ctx.host.mapDisplayPos) return ctx.host.mapDisplayPos(display, (q && q.question_sanitized) || "", pos); } catch (e) {}
    return pos;
  }

  // ── Pyramid Check: is a tossup you wrote hardest first and easiest last? ──
  // Each line's clues (names, titles, rare words) are looked up in the database: how many tossups use each, and
  // where in the question tossups on the same answer put it. A line whose clues are much better known than a later
  // line's is out of order. It also checks for the answer in the text, the power mark, the giveaway and the length.
  var body = null, page = null;
  var draft = Object.assign({ text: "", answer: "" }, ctx.storage.get("draft") || {});
  var result = null, busy = false;
  var STOP = new Set("this these that those which what with from into their there then than when where while after before about against between through during under over also only other another such some many most more each every both name names named called known work works title author figure point points first second third last".split(" "));
  function saveDraft() { ctx.storage.set("draft", draft); }

  // 1.1 (15.63): every clue a line has, not the first six. Quoted titles, names (capitalized runs, at a sentence's start
  // too), two-word phrases and single words. How well known each is comes from up to 200 tossups on the answer, counted
  // here, and a random sample of tossups says which words are everyday ones ("depicted", "London") to leave out.
  var FW = new Set("his her hers its their theirs them they she he him and but for nor yet with without from into onto upon this that these those which whose whom where when while what then than there here very much many some most more less such also only just even still both each every either neither other another after before about above below over under among along across around against within during since until though although because whether being been having have has had does did doing done made make makes making used uses using said says saying known called named name names whose work works shows show shown depicts depict depicting depicted painted paint paints wrote write writes written figure figures character characters".split(" "));
  var LEAD = /^(For|This|These|That|Those|The|A|An|In|On|One|It|He|She|They|His|Her|Its|Their|After|When|While|During|Name|Identify|Give|Like|With|Along|According|Although|Before|Since|Its)$/;
  function cluesOf(line) {
    var out = [], seen = {}, m;
    var add = function (t, kind) {
      t = t.trim().replace(/^[^\w"“]+|['’]s$|[.,;:!?'’"”)]+$/g, ""); var k = t.toLowerCase();
      if (!t || t.length < 4 || seen[k] || STOP.has(k)) return; seen[k] = 1; out.push({ t: t, kind: kind });
    };
    var re1 = /["“]([^"”]{3,80})["”]/g; while ((m = re1.exec(line))) add(m[1], "title");
    var re2 = /[A-Z][\w'’-]+(?:\s+(?:(?:of|the|de|von|van|la|le|du|del|da|and)\s+)?[A-Z][\w'’-]+)*/g;
    while ((m = re2.exec(line))) {
      var parts = m[0].split(/\s+/);
      while (parts.length && LEAD.test(parts[0])) parts.shift();
      if (parts.length) add(parts.join(" "), "name");
    }
    // single lowercase words, and two of them side by side ("pocket watch"); a name's pieces are the name's
    var toks = line.split(/[^A-Za-z'’-]+/).filter(Boolean).map(function (w) { return w.replace(/['’]s$/, ""); });
    toks.forEach(function (w, k) {
      var lw = w.toLowerCase(), nx = toks[k + 1];
      if (/^[A-Z]/.test(w)) return;
      if (lw.length >= 5 && !STOP.has(lw) && !FW.has(lw)) add(lw, "word");
      if (nx && !/^[A-Z]/.test(nx)) { var ln = nx.toLowerCase(); if (lw.length >= 4 && ln.length >= 4 && !STOP.has(lw) && !STOP.has(ln) && !FW.has(lw) && !FW.has(ln)) add(lw + " " + ln, "phrase"); }
    });
    return out;
  }
  function has(text, term) { var i = text.indexOf(term); while (i >= 0) { var a = text[i - 1], b = text[i + term.length]; if (!(a && /[a-z0-9]/.test(a)) && !(b && /[a-z0-9]/.test(b))) return true; i = text.indexOf(term, i + 1); } return false; }
  async function check() {
    if (busy) return;
    var text = draft.text.trim(), answer = draft.answer.trim();
    if (!text) return;
    busy = true; result = "loading"; render();
    var lines = sentences(text.replace(/\(\*\)/g, " (*) ").replace(/\s+/g, " "));
    var rowsA = answer ? await tossupsOn(answer, 200) : [];
    // the background: random tossups from the answer's own category (a painter's clues against other art questions)
    var rootName = rowsA.length ? rootOf(rowsA[0]) : "", rt = rootName ? (await roots()).find(function (r) { return r.name === rootName; }) : null;
    var bg = (await getTossups(250, rt ? { categoryIds: [rt.id] } : {})).map(function (q) { return String(q.question_sanitized || "").toLowerCase(); });
    var plainA = rowsA.map(function (q) { return String(q.question_sanitized || "").toLowerCase(); });
    var ansWords = norm(answer.replace(/\[.*?\]|\(.*?\)/g, "")).split(" ").filter(function (w) { return w.length >= 3; });
    // with enough tossups on the answer, a clue is as well known as the share of them that use it (stock clues are in
    // many); otherwise, as the number of tossups anywhere that mention it
    var useA = rowsA.length >= 5;
    var perLine = await Promise.all(lines.map(async function (line) {
      var cs = cluesOf(line.replace(/\(\*\)/g, ""));
      cs.forEach(function (c) {
        var low = c.t.toLowerCase();
        c.inA = 0; var pos = [];
        plainA.forEach(function (t) { if (has(t, low)) { c.inA++; pos.push(t.indexOf(low) / Math.max(1, t.length)); } });
        c.pos = pos.length ? pos.reduce(function (s, x) { return s + x; }, 0) / pos.length : null;
        c.bg = bg.length ? bg.filter(function (t) { return has(t, low); }).length / bg.length : 0;
      });
      // everyday words and phrases (in 3% of random tossups or more) and the answer's own words aren't clues
      var whole = cs.filter(function (c) { return c.kind === "title" || (c.kind === "name" && / /.test(c.t)); }).map(function (c) { return c.t.toLowerCase(); });
      cs = cs.filter(function (c) {
        var low = c.t.toLowerCase();
        if (ansWords.some(function (w) { return norm(c.t).split(" ").indexOf(w) >= 0; })) return false;
        if (c.kind !== "title" && whole.some(function (w) { return w !== low && w.indexOf(low) >= 0; })) return false;   // a piece of a name already there
        if (c.kind === "word") return c.bg < 0.012;
        if (c.kind === "phrase") return c.bg < 0.02;
        if (c.kind === "name" && !/ /.test(c.t)) return c.bg < 0.03;
        return c.bg < 0.08;
      });
      // a word no tossup on the answer uses: an everyday one ("stayed", "dozens") is in hundreds of tossups anywhere
      var odd = cs.filter(function (c) { return (c.kind === "word" || c.kind === "phrase") && !c.inA; }).slice(0, 12);
      await Promise.all(odd.map(async function (c) { c.n = (await searchTossups('"' + c.t.replace(/"/g, "") + '"', 1)).total; }));
      cs = cs.filter(function (c) { return !(c.kind === "word" && c.n != null && c.n > 120) && !(c.kind === "phrase" && c.n != null && c.n > 40); });
      // without enough tossups on the answer: how many tossups anywhere use the rarest-looking ones
      if (!useA) {
        var look = cs.filter(function (c) { return c.n == null; }).sort(function (a, b) { return (a.kind === "word") - (b.kind === "word") || a.bg - b.bg; }).slice(0, 12);
        await Promise.all(look.map(async function (c) { c.n = (await searchTossups('"' + c.t.replace(/"/g, "") + '"', 1)).total; }));
        cs = cs.filter(function (c) { return c.n == null || c.n > 0; });
      }
      cs.sort(function (a, b) { return useA ? b.inA - a.inA : (b.n || 0) - (a.n || 0); });
      var known = cs.reduce(function (m, c) { return Math.max(m, useA ? c.inA : c.n || 0); }, 0);
      return { line: line, clues: cs, known: known, power: /\(\*\)/.test(line) };
    }));
    var notes = [];
    // order: a line much better known than a later one
    for (var i = 0; i < perLine.length - 1; i++) {
      var later = perLine.slice(i + 1, perLine.length - 1).filter(function (x) { return x.clues.length; });
      var minLater = later.length ? Math.min.apply(null, later.map(function (x) { return x.known; })) : null;
      if (minLater != null && perLine[i].clues.length && (useA ? perLine[i].known >= 3 && perLine[i].known > minLater * 1.4 && perLine[i].known - minLater >= 3 : perLine[i].known > Math.max(20, minLater * 3))) {
        var top = perLine[i].clues.slice().sort(function (a, b) { return useA ? b.inA - a.inA : b.n - a.n; })[0];
        notes.push({ line: i, warn: true, text: useA ? "Line " + (i + 1) + " uses “" + top.t + "”, which " + top.inA + " of the " + rowsA.length + " tossups on this answer use. That's a stock clue, better known than a later line. Move it down."
          : "Line " + (i + 1) + " uses “" + top.t + "”, which comes up in " + fmt(top.n) + " tossups. That's better known than a later line. Move it down." });
      }
      perLine[i].clues.forEach(function (c) { if (c.inA >= 3 && c.pos != null && c.pos > 0.6 && i < perLine.length / 2 && !notes.some(function (n) { return n.line === i && n.text.indexOf("“" + c.t + "”") >= 0; })) notes.push({ line: i, warn: true, text: "“" + c.t + "” is in " + c.inA + " tossups on this answer, usually near the end. Line " + (i + 1) + " is too early for it." }); });
    }
    var low = text.toLowerCase();
    if (answer) norm(answer.replace(/\[.*?\]|\(.*?\)/g, "")).split(" ").filter(function (w) { return w.length >= 4 && !STOP.has(w); }).forEach(function (w) {
      if (new RegExp("\\b" + w + "\\b").test(low)) notes.push({ warn: true, text: "The question says “" + w + "”, part of the answer." });
    });
    if (!/\(\*\)/.test(text)) notes.push({ text: "No power mark yet. Put (*) after the last clue a strong player should know." });
    var last = lines[lines.length - 1] || "";
    if (!/^for (10|ten) points/i.test(last)) notes.push({ text: "The last line usually starts with “For 10 points” and gives the answer away." });
    if (!/\b(this|these)\b/i.test(lines[0] || "")) notes.push({ text: "The first line doesn't say what the answer is, like “this author” or “this battle”." });
    if (text.length > 900 || lines.length > 9) notes.push({ warn: true, text: "Long for a tossup, " + text.length + " characters in " + lines.length + " lines. Most are under 800." });
    if (lines.length < 4) notes.push({ text: "Short for a tossup. Most have five to eight lines." });
    if (rowsA.length) notes.push({ text: "The database has " + plural(rowsA.length, "tossup") + " on this answer" + (rowsA.length >= 200 ? " or more" : "") + ". Clues they use a lot are easy, however hard they feel." });
    result = { lines: perLine, notes: notes, rows: rowsA.length, useA: useA };
    busy = false; render();
  }

  function render() {
    if (!body) return;
    var maxK = result && result.lines ? Math.max.apply(null, result.lines.map(function (x) { return x.known; }).concat([10])) : 10;
    var bar = function (n) { return n ? Math.max(4, Math.round(100 * Math.log10(n + 1) / Math.log10(maxK + 1))) : 2; };
    body.innerHTML = '<div class="pk-wrap py">' +
      '<div class="pk-card py-form"><label class="pk-field"><span>Your tossup</span><textarea id="py-text" rows="8" placeholder="Paste a tossup you\'re writing, hardest clue first. Mark the power with (*).">' + esc(draft.text) + "</textarea></label>" +
        '<label class="pk-field"><span>Its answer</span><input id="py-ans" placeholder="For example, Claude Monet" value="' + esc(draft.answer) + '"></label>' +
        '<div class="pk-actions"><button type="button" class="btn btn-primary" id="py-go"' + (busy ? " disabled" : "") + ">" + ic("search", 14) + (busy ? "Checking…" : "Check it") + "</button></div></div>" +
      (result === "loading" ? loading("Looking up each clue…") : result ? (
        (result.notes.length ? '<div class="pk-card py-notes">' + result.notes.map(function (n) { return '<p class="' + (n.warn ? "py-warn" : "") + '">' + (n.warn ? ic("flag", 13) : ic("check", 13)) + "<span>" + esc(n.text) + "</span></p>"; }).join("") + "</div>" : "") +
        '<div class="pk-sechead"><span class="eyebrow">Line by line, how well known its clues are</span></div><div class="list pk-list">' + result.lines.map(function (x, i) {
          var flagged = result.notes.some(function (n) { return n.line === i && n.warn; });
          return '<div class="list-row py-row' + (flagged ? " flagged" : "") + '"><span class="py-n num">' + (i + 1) + '</span><span class="pk-grow py-body"><span class="py-line">' + esc(x.line) + "</span>" +
            '<span class="py-clues">' + x.clues.slice(0, 10).map(function (c) { return '<span class="pk-chip" title="' + (c.n != null ? "In " + fmt(c.n) + " tossups, " : "") + c.inA + " of the tossups on this answer" + '">' + esc(c.t) + ' <b class="num">&nbsp;' + fmt(result.useA ? c.inA : c.n || 0) + "</b></span>"; }).join("") + "</span></span>" +
            '<span class="py-known"><span class="pk-meter"><span style="width:' + bar(x.known) + "%;--c:" + (flagged ? "var(--red)" : "var(--accent)") + '"></span></span></span></div>';
        }).join("") + '</div><div class="pk-muted pk-small py-hint">Each number is how many tossups mention that clue, and each bar is the line\'s best-known clue. From top to bottom they should grow.</div>'
      ) : "") + "</div>";
    var hint = body.querySelector(".py-hint"); if (hint && result && result.useA) hint.textContent = "Each number is how many of the " + result.rows + " tossups on this answer use that clue, and each bar is the line's most used clue. From top to bottom they should grow.";
    var ta = body.querySelector("#py-text"), an = body.querySelector("#py-ans");
    [ta, an].forEach(function (el) { el.addEventListener("keydown", function (e) { e.stopPropagation(); if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) { e.preventDefault(); check(); } }); });
    ta.addEventListener("input", function () { draft.text = ta.value; saveDraft(); });
    an.addEventListener("input", function () { draft.answer = an.value; saveDraft(); });
    body.querySelector("#py-go").onclick = check;
  }

  page = ctx.registerPage({
    id: "pyramid-check", navLabel: "Pyramid Check", title: "Pyramid Check",
    onShow: function (el) { body = el; render(); },
  });

}
