/**
 * OfflineQuiz plugin: Pyramid Check
 *
 * For writers. Paste a tossup and its answer. Every clue in it is looked up in the database: how many
 * tossups use it, and where tossups on the same answer put it. Lines out of order are marked, along with
 * the answer appearing in the text, a missing power mark or giveaway, and the length.
 */
QB.registerPlugin({
  id: "pyramid-check",
  name: "Pyramid Check",
  version: "1.1.1",
  author: "OfflineQuiz",
  description: "Check a tossup you wrote: each clue looked up in the database, to see that it goes hardest to easiest.",
  onEnable: __qbMain,
  onDisable: function (ctx) { if (ctx._cleanup) ctx._cleanup(); },
});
